"""Verify packaged ResearchHarness in a temporary environment.

Run with a release directory and a supported Python. Requires uv and network
access to resolve dependencies unless they are already cached.
"""

import argparse
from hashlib import sha256
from io import BytesIO
import json
import os
from pathlib import Path
import subprocess
import sys
import tarfile
import tempfile
from zipfile import ZipFile


PLUGIN_ENTRIES = {
    "agent-plugin": "plugin.json",
    "codex-plugin": ".codex-plugin/plugin.json",
    "cursor-plugin": ".cursor-plugin/plugin.json",
    "claude-plugin": ".claude-plugin/plugin.json",
    "gemini-extension": "gemini-extension.json",
    "opencode-plugin": "package.json",
    "openclaw-plugin": "openclaw.plugin.json",
}


def verify_plugins(release, wheel, work):
    """Check every plugin's skill inventory and run the bundled CLI."""
    version = wheel.name.split("-")[1]
    wheel_data = wheel.read_bytes()
    with ZipFile(wheel) as installed:
        metadata_name, = (n for n in installed.namelist() if n.endswith(".dist-info/METADATA"))
        if b"Name: ever-research\n" not in installed.read(metadata_name):
            raise ValueError("Incorrect Python package name")
        with ZipFile(BytesIO(installed.read("harness/public_resources.zip"))) as resources:
            expected = {
                name.removeprefix(".agents/"): resources.read(name)
                for name in resources.namelist() if name.startswith(".agents/skills/")
            }

    def compare(actual, label):
        for name, body in expected.items():
            runner = name.removesuffix("/SKILL.md") + "/scripts/rh.py"
            if name.endswith("/SKILL.md") and runner in actual:
                _, frontmatter, _ = body.split(b"---", 2)
                if actual[name].split(b"---", 2)[1] != frontmatter:
                    raise ValueError(f"Unexpected skill metadata in {label}: {name}")
            elif actual.get(name) != body:
                raise ValueError(f"Unexpected skill file in {label}: {name}")
        for name in actual.keys() - expected.keys():
            if name.endswith(".whl") and actual[name] == wheel_data:
                continue
            if not name.endswith("/scripts/rh.py"):
                raise ValueError(f"Unexpected plugin addition in {label}: {name}")
        if actual.get(f"skills/maintain-project/scripts/{wheel.name}") != wheel_data:
            raise ValueError(f"Missing bundled runtime in {label}")

    readmes = set()
    for platform, manifest in PLUGIN_ENTRIES.items():
        with ZipFile(release / f"ever-research-{version}-{platform}.zip") as archive:
            actual = {name: archive.read(name) for name in archive.namelist()
                      if name.startswith("skills/")}
            if manifest not in archive.namelist():
                raise ValueError(f"Missing manifest in {platform}")
            readme = archive.read("README.md")
            if b"@DOWNLOAD@" in readme or b"## Install" not in readme:
                raise ValueError(f"Incomplete installation guide in {platform}")
            readmes.add(readme)
            compare(actual, platform)
            if platform in {"claude-plugin", "agent-plugin"}:
                destination = work / platform
                if platform == "claude-plugin":
                    files = [n for n in actual if n.startswith("skills/maintain-project/")]
                    archive.extractall(destination, files)
                else:
                    archive.extractall(destination)
    if len(readmes) != len(PLUGIN_ENTRIES):
        raise ValueError("Each plugin format must have its own README")
    with tarfile.open(release / f"opensae-ever-research-dsh-{version}.tgz") as archive:
        manifest = json.load(archive.extractfile("package/package.json"))
        if "bundle" not in manifest.get("dsh", {}):
            raise ValueError("Missing DeepSeek Harness bundle manifest")
        actual = {entry.name.removeprefix("package/"): archive.extractfile(entry).read()
                  for entry in archive.getmembers()
                  if entry.isfile() and entry.name.startswith("package/skills/")}
        compare(actual, "DeepSeek")
    return len(PLUGIN_ENTRIES) + 1


def check_release(release, work):
    files = set()
    for line in (release / "SHA256SUMS").read_text(encoding="ascii").splitlines():
        digest, name = line.split("  ", 1)
        if Path(name).name != name or sha256((release / name).read_bytes()).hexdigest() != digest:
            raise ValueError(f"Invalid release checksum for {name}")
        files.add(name)
    wheel, = (release / name for name in files if name.endswith(".whl"))
    plugins = verify_plugins(release, wheel, work)
    example, = (release / name for name in files if name.endswith("-example.zip"))
    with ZipFile(example) as archive:
        archive.extractall(work)
    project = work / "BirdStudy"
    environment = {**os.environ, "RH_STATE_DIR": str(work / "state"),
                   "RH_PLUGIN_CACHE_DIR": str(work / "plugin-cache")}
    for platform in ("claude-plugin", "agent-plugin"):
        runner = work / platform / "skills/maintain-project/scripts/rh.py"
        subprocess.run([sys.executable, "-I", str(runner), "projects", "project", "check", str(project)],
                       cwd=work, env=environment, check=True, capture_output=True, text=True)
    venv = work / "venv"
    scripts = venv / ("Scripts" if os.name == "nt" else "bin")
    python = scripts / ("python.exe" if os.name == "nt" else "python")
    rh = scripts / ("rh.exe" if os.name == "nt" else "rh")
    environment["PATH"] = str(scripts) + os.pathsep + environment.get("PATH", "")

    def run(command, *arguments):
        return subprocess.run(
            [str(command), *map(str, arguments)], cwd=work, env=environment,
            check=True, capture_output=True, text=True, encoding="utf-8",
        ).stdout

    run("uv", "venv", "--python", sys.executable, venv)
    run("uv", "pip", "install", "--python", python, wheel)
    health = json.loads(run(rh, "doctor", "--json", "--project", project))
    if health["mode"] != "installed":
        raise ValueError("The release is using a source checkout")
    run(rh, "projects", "project", "check", project)
    run(rh, "projects", "register", "bird-study", "--path", project)
    marker = project / ".researchharness/mode.toml"
    marker.write_text(marker.read_text(encoding="utf-8").replace(
        "enabled = false", "enabled = true"), encoding="utf-8")
    run(rh, "projects", "setup-maintenance", project, "--online")
    run(python, "-IS", project / ".researchharness/maintain.py", "check")
    targets = ["--project", project, "--agent", "codex", "--agent", "claude-code"]
    install = json.loads(run(rh, "skills", "install", *targets))
    repeat = json.loads(run(rh, "skills", "install", *targets))
    if not install or len(repeat) != len(install) or any(r["action"] != "unchanged" for r in repeat):
        raise ValueError("Skill installation failed its repeatability check")
    own = project / ".agents/skills/local-example"
    own.mkdir()
    (own / "SKILL.md").write_text("Project-owned skill.\n", encoding="utf-8")
    run(rh, "skills", "uninstall", *targets)
    if not (own / "SKILL.md").is_file():
        raise ValueError("Uninstall removed a project-owned skill")
    run(rh, "projects", "project", "check", project)
    return {"checksums": len(files), "skills": len(install), "plugin_formats": plugins,
            "python": health["python"],
            "system": health["system"], "passed": True}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("release", type=Path)
    args = parser.parse_args()
    try:
        with tempfile.TemporaryDirectory(prefix="researchharness-smoke-") as temporary:
            print(json.dumps(check_release(args.release.resolve(), Path(temporary)), indent=2))
    except subprocess.CalledProcessError as error:
        print(error.stdout, file=sys.stderr, end="")
        print(error.stderr, file=sys.stderr, end="")
        raise SystemExit(error.returncode)
