---
name: maintain-experiment
description: Run, monitor, recover, or review a research experiment. Use for run recipes, effective configurations, execution records, and results produced by the experiment.
---

# Run and maintain research experiments

## Run the EverResearch CLI

This plugin includes EverResearch's `rh` command. Use Python 3.11, 3.12, or 3.13
to run `scripts/rh.py` from the current skill, followed by the arguments after
`rh`. For example, pass `projects project check <project-path>` to check a
project. Use `${CLAUDE_SKILL_DIR}` in Claude Code or Cowork and the staged skill
directory in Claude web.

The launcher creates an isolated Python environment on first use and may fetch
dependencies. With no Python execution available, review the files you can
access and tell the user which automated checks you could not run.

For a separate terminal installation, the official PyPI package is
`ever-research` from OpenSAE. The PyPI project named `researchharness` is
maintained separately.

## Purpose and main function

Run, monitor, resume, or review an experiment. Keep its effective configuration, execution record, logs, and results together so it can be understood and reproduced.

## Scope of application

Use this skill for a specific run, a set of runs, or their results. Start with the project's `AGENTS.md`, README, and operating guide. Follow the project's documented entry points and the user's authorization for runs and resource use.

The [experiment procedures](references/procedures.md) cover configuration, result inspection, recovery, failure diagnosis, and performance comparisons.

## Use an existing configuration

Start from the project's defaults and recipes. Apply the selected overrides through the public entry point and save the effective configuration with the run under `experiment/`. To review or rerun an earlier experiment, recover its configuration from the run record. Use `maintain-conf` for changes to available parameters, their meaning, or their defaults.

## Start experiments or read results

1. Determines the user's selected configuration, data, model, scope of work and results to be used. Re-use the existing formulation and environment to see the effective configuration through read-only project support. Select to automatically call the task portal `precheck` before the formal computation.
2. Put reusable preprocessing inputs in the named asset defined by `maintain-dataset`. Positioning Level One Directory From Project Roots `experiment/`.All new operations and their precheck, debugging, comparison and subsequent analysis products are placed in this directory.(`subname`),The list refers to the effective configuration and the subproduct. The cover must be clearly authorized. The top level task is performed at the user ' s request. The back desk uses the tools and log position of the project to save the start-up command, session, running directory, log and restoration.
3. Verify the actual delivery from the official results portal. Read the features by task and their interpretation, generation, intervention, evaluation indicators or training reports and points. Link the current operational identity, input, actual scope and protocol.

## Automatic precheck before a formal run

The normal entry point runs precheck before computation. Reuse evidence already obtained through that entry point. If the entry point, precheck, or its failure blocking needs verification, use the task skill's precheck procedure and share the successful and rejected run records. Experiment maintenance verifies the actual outputs through their normal reader.

## Commencing access and piloting.

A single operation uses `experiment/<dataset>/<model>/<task>/<experiment-name>/<optional-role>/`. Datasets, models and tasks are removed from actual calls, configurations and registrations. Data catalogue users can identify the actual dataset, queues or baseline names from the project document. Only the directory with the source registration number is checked for the actual queue and the recognized name, checking conflicts with the same name, and keeping the original registration number in the running record open to the stable corresponding access to the directory, keeping the original registration number in the operating record.

### First, to determine the responsibility for each type of document.

If you have a family and there are several members to choose, the family name is written once, and the members only use their own names. The data set position is `<dataset-family>/<cohort-or-subset>`, the model position is `<model-family>/<variant>`, and the role of the data set and model is maintained separately. Based on the family organization already in place of the project, the component with a true independent identity follows its own name. The common term itself can only be used to find clues, and the actual component relationship decides whether or not to group.

A stable map obtains its complete relative path from an open component identity. Existing running, subsequent writing, batch members reading and document navigation uses the same map; public configuration identifiers and historical lists continue to retain their true component identity. For group directory, at least two different members of the same family are selected to check that they actually write and read their own separate, readable results, and confirm that the public entry point will not create the old flat directory.

The public identification contains the name of the organization, separator, remote address, framework syntax or running parameter. The directory selects the identifiable data, model and task name, which are mapped by project registration. The complete machine identifier and the normal operational parameter are recorded in the record. The reader's published directory is marked by a name that can be read directly, and the character is transliterated internally by a reading and writing protocol. In short-name conflicts, the identification information is supplemented by real sources, tasks or variations, and the map is verified to be stable.

When you have an existing catalogue, you take the evidence of a group of documents that can be read independently. First, you look at the person that is valid to configure, generate commands or achieve and read downstream, then you check the content of the product and confirm the input, tasks and actual uses. An old directory may be mixed with multiple types of files, and it should be determined separately.

- **Independent experiment.** Each group enters the standard path by its own data set, model, mission and experimental purpose when the same command starts independent operation. The sample, indicator, point of inspection, operational configuration and diagnosis are kept with its own operation. The scheduler uses its official running record to keep progress and membership status; it locates the members according to the same path rules and does not use the dispatch container as a layer of the result path.
- **Joint analysis.** identifies from the analytical program which inputs are actually involved in the same calculation, confirming whether they are read for comparison of the existing results, or using multiple data sets or models as a physical input for this operation. The report and machine-readable results are attached to the analysis's own public entry point. When an analysis has a clear master data, archive the actual master data, reference the entry into the list. The same type of entry is entered as an optional, rerunable joint input, a joint entry that follows the actual registration of the project; where there is a lack of registration, the public entry point of identity, a member, an identifiable name and a readable agreement, and then a corresponding directory is created. The list of objects mentioned in the report cannot be used as a register, nor can the spell-in-entry name substitute for this step.
- The **running evidence and engineering maintenance.** Recapturing the environment, precheck and performance evidence necessary for an experiment, explanation of indicators or for the continuation of a study follows the actual operation. The record of the validation code adjustment or collation process follows the entry and use of the project. The sustainable return examination goes into the project file, with the long-term explanation being applied, and the temporary engineering material ending `maintain-tmp`.

After confirming the path, adjust the generator, normal reader, configuration and document, and then move the group results and read them back from the new location. The purpose is unknown, the object is still in operation or there is an existing old entry, giving evidence and processing boundary by case. After rereading and checking the group contents, clear the empty old container. See the new and old path differences of the actual root of the project before delivery, confirm that the mixed information has not been moved to another generic container, and also check whether the only catalogue of registration numbers found at the beginning has been renamed through a stabilization map.

When checking the directory generated by the frame configuration, the actual path is analysed separately from the operation of multiple combinations. Read out the valid laboratory name, data, model and task identity, confirming that the automatically created directory and subsequent project reading and writing in the same rule-cover framework. The random torrent, time and internal execution number are recorded in a single execution record. Retain the contents of the document and the source identity of the completed product, with multiple implementations for the same purpose, read back. Independent review checks the movement of the original physical container from the tree to the file group, while testing the valid use and invalid name through a formal order.

Reread the project layouts by front-office single, multi-assembly and downstream. The control directories that the batch frames require to be created for start-up are part of the dispatch process, using the temporary workspace over its life cycle; the movement information that needs to be maintained to reproduce results is kept with the actual member's execution records. Starting with the physical tree left behind by the frame, each searchable directory under the root of the experiment is directed to the actual input. The temporary or hidden directory written by the operational tool is also checked for its use and end-actions. Model weights that exist before the operation is a model resource, and the specific operational weights generated are retained with the experiment. The transferable path segment is calculated by the actual path generator, and the current configuration, log and downstream reading are reviewed after migration and still using the same operational identity.

When you return to the old experiment, identify the experimental uses that can be operated independently or formally read from the configuration, command or product. Once the data sets, models and tasks are put in place, you continue to check the use and research roles that are directly displayed below them. Preserve old rotations, seeds and numeric identifiers in record fields or in frozen snapshots outside `experiment/`. The absolute location of the historical configuration is determined by the caller to resolve the configuration value, the product of the same execution or the external resource. The normal consumer within the project maintains the historical configuration in the original language and validates its reading.

When processing a history configuration, find out from the official read-back portal the actual realization of reading the old address, giving priority to locating the product according to the selected execution location, and sharing the input according to the named data or model resource. When matching an old field, allow the reading end to provide the required explanation. The check is performed when the old physical address does not exist and the historical configuration is maintained in the original language, and check to read the same data or weights. After the research-use directory is renamed, an example of a command that can be run by checking the link to the report and copying. The path to the command in the work directory is determined by the read-only entry or configuration preview that its objective remains and is valid.

You can register to run directly under the task directory if the name of the experiment is fully located.

Sub-missions or experimental names under the mandate give priority to the actual main method, for example. `capture/non_whiten/answer_stability` Medium,`capture` _Other Organiser,`non_whiten` Show method,`answer_stability` Shows that this time you check the stability of the answer with it. When the upper level has expressed the method, the lower level will write the specific purpose of the study or the specific role to be assumed. Each level will express only the new information that has been added to the level. Parameters will be used to describe their meaning in complete terms, for example, when the condition of the study or the comparison is made. `candidate_limit` is the upper limit for the study. The value is written into the valid configuration and list, and the real data set and model identity can be kept as the version number.

## Name every experiment path with meaningful words

Apply this rule to every segment beneath `experiment/`, including dataset and model branches, execution folders, framework-generated folders, and output filename stems. Each segment contains at least one complete English word that describes its actual content or role. Use descriptive words joined with underscores for project-defined names. A scientific identifier can accompany a descriptive word when it conveys a real dataset or model identity.

Reject date or time information in any segment. Reject opaque IDs, hashes, UUIDs, random suffixes, and names composed solely of numbers or abbreviations. Adding a descriptive prefix does not make a date, timestamp, or opaque suffix acceptable. Store start and finish times, seeds, hashes, and machine execution IDs in the manifest or effective configuration. Use `run_id` for the machine identity. If a run has a separate execution directory, record its descriptive name in `execution_name`. Resolve readers through this descriptive path. A run stored directly at its study or role directory can omit `execution_name`. Give separately retained executions distinguishable names tied to their purpose, comparison condition, or role. When those facts provide no distinct name, require a meaningful name from the caller before creating another directory. Protect earlier results from accidental replacement.

Check the names produced by the official writer as well as names explicitly provided by the caller. Inspect every segment of the effective path before writing, including paths formed by a framework, batch launcher, or downstream exporter. For a migration, update the writer, readers, defaults and documentation together. Preserve original identity fields and frozen configuration contents. A dated or opaque historical path may be preserved inside a frozen archive outside `experiment/`. An alias under `experiment/` has the same naming requirements as a physical directory.

## Fixed Naming & Results Read

The directory and product of the same function uses the fixed level and file name agreed upon in the project. Paths are extrapolated from the actual data set, model, task, test name and meaningful method or role. Schedule records keep the identity, condition, status and count of members. Maintain the sample identity and necessary research evidence when the sample is re-used. Regular reading is based on the member ' s identity to construct the agreed path, and when the path is missing, the actual missing item is noted. Removes the path fields of the movement record or writes the wrong address at the time of acceptance, checking that the normal entry still locates the true result from the same naming rules.

The default root results are located from the workspace of the project or project statement. Checks the default output of the same entry at the start of the project root and other work directories, using a configuration preview or segregation input. Visible relative input and output parameters are still deconstructed according to the project's public agreement. Installing packages can also be executed outside the source tree, indicating how the workspace is specified or located.

## Tracking and recovery

1. Checks the running identity with the original start-up command, effective configuration, actual interpreter, device and process, session logs, outcome lists and check points. Supports the group configuration to read back the current version.
2. If you want to keep track of your work, read your logs and indicators, and wait on the tool's ability, so that you can keep up with your status.
3. Determines which results can be reused, which steps are missing and which preconditions need to be repaired. Prior to running, confirm that the current task supports recovery and differentiates between the full training status and the weights to be used for reasoning only. Checks the configuration, input, environment and historical status of the check points. If there is no resilience or necessary evidence, identify the specific missing items and give the path to running or restarting. When restoration is needed, fill the missing items with the actually responsible outcome interface.
4. Report on the real status, completed results and follow-up actions.

## Debugment and Performance

1. Distinguishing between observed phenomena, identified causes and explanations yet to be validated.
2. Select the minimum input and inspection that is sufficient to locate the problem. Use the synthesis input, small precheck, or short running when sufficient. The diagnostic file is placed at the project's specified operational information and the results of the original experiment are maintained. Use the existing back-office service switch of the project to control the testing process.
3. Performance questions are counted from the actual transfer chain to record data, equipment, workload and numerical conditions. Candidates are compared with the same input and test; local measurements correspond to local conclusions. Humans make trade-offs when results are changed in semantic, resource budget or historical comparability.
4. The project scripts are formally implemented in accordance with project practice, are subject to long-term inspection and are cleaned up after a temporary check has been completed. The restoration is confirmed by the approved regular access and the basis and scope of application are included in the mission information.

## Validation criteria

### Independent experimental inspection

- After full operation, and when repairing the result producer or receiving and inspection project, run `rh projects experiment check <project root directory>`.This command is independent of the tree-wide path check and exits on the basis of the configuration, directory identity, running list, product name, complete path and disk file for each execution check. `0` The number of checks is zero, which means that the current tree is not formally executed and delivered as it is.
- The public entry point is written down. `metadata/manifest.json` or `manifest.json`.Records `run_id`, `subname`, `status`, `effective_config`, and `outputs`, with `role` and `execution_name` when the physical path includes those levels.effective configuration Data Sets, Optional Models and Tasks `name` or a string expresses the current selection. Open identification is different from the path or configuration structure, by `component_paths` Save datasets, optional models and task paths derived from actual selections.`outputs` The key fixes the main name of the file and the value starts with the root. `artifacts/` or `reports/` Internal complete path. The home name of the product contains a full word in English and the executive number is kept in the operating record. Register every official artifact and report at its path relative to the run. Keep independently rerunnable evaluations, visualizations, and comparisons under their own descriptive experiment purpose. Their manifests name the input runs, relevant checkpoint or data identities, and the actual outputs. Keep scratch renderings in the temporary workspace until they are selected for retention.
- Move frozen experiments and demonstrations to `assets/history_experiment/<named-result>/files/`. Preserve the original files and internal paths, and document their source and readback procedure in the adjacent README. Check for active writers before moving files and verify representative readback afterward. Keep an old run in `experiment/` when the original evidence establishes its identity, effective configuration, and outputs and the run passes the independent experiment check.

- Project-wide maintenance coverage `experiment/` All existing experiments and additional experiments. First, the actual running and results group from the disk, including independent running, analysis and engineering information hidden in the product's subtree. Check the data, models, tasks, uses and performance attributions of each experiment with the original order, the validity configuration and the execution record; generate and access the type, fixed file name and complete relative path of the results for which the check is made, and read the actual document to verify the relationship. Independently run checks separately, the same product agrees that a mass check is available. `experiment/`.The reconciliation of the remaining experiments and results groups continues to be completed after full-tree inspection and individual reading back.
- When you organize an existing product, take a separate inventory of the experiment, method or role level and within each package. The current path to browse is regulated by identifying the research according to the configuration, command and results in effect. Store fold, seed, time, and attempt information as fields in the execution record. You can keep the original archive and internal format and register the original identity. The current entry to verify the old results locates the same result and reads key files.
- The path is revised to review old addresses, unknown components, temporary directories and duplicate products without users from the physical tree by group; the exception is to clear the source, depend on and access the entry.
- Checks path identification using actually readable data and exemplified models. Writes folds, numbers and duplicates into the record or product. Reads independently from the public entry point of the parent and the role when there is an independent control role. Use a controlable input to check whether the reruner parent keeps the other roles, whether the log is still in this operation, and whether the summary is read out of the corresponding discounts and indicators.
- Checks the real file from each available path, checking the location of the independent operation to write to the corresponding data, model and task, and the joint results are read along the physical analysis entry, and the movement status and project evidence are positioned by the actual user. The actual check of the entire level 1 directory of the root of the experiment and the input of evidence for each mark. After moving the historical results, verify that the normal entry is read back against the key elements before the change, and check that the new operation will also be written into the same structure.

- Matches data, models, tasks, status, indicators, necessary documents and executing identities with current valid configuration and project access. For runbacks or restorations, check which result is selected, whether the conditions will be covered or mixed, and the specific tips when missing.
- Compare the pre-operational check to delineate the participant role, model selection, calibration of indicators and coverage. Save the original conditions for historical results.

### The path or product of this operation is not checked

1. Proceeding from the path and expected results indicated in the inspection report, and in conjunction with this official order, effective configuration and disk file, locate the target project to actually determine the path or write the code of the product. Based on ResearchHarness's original checker and rules. When repairing this failure, all code and configuration changes are limited to the target item that was authorized to be maintained.
2. **Path generation error.** Amends the routing logic of the public entry point to the data, models, tasks and experimental uses actually used for this time and synchronizes the affected reading portal. Confirms that the existing products are in the current operation and moves them to the right position to preserve the reusable results.
3. **Error at product under path.** When a file is found to be ungenerated, the missing position is calculated or steps are written, and priority is given to the restoration of the item or to the completion of the entry. Only if the missing result has to be recalculated will the result be recalculated and the corresponding calculation made within the authorization.
4. **Accepts the current result and the production code, respectively.** Rechecks the results with the original checker and opens the user's product by formally reading the entry to the project. Then executes a minimum rerun from the same public entry point to cover the original error, confirming that automatic prechecking and actual writing can produce compliance, readable results. There are still deviations to continue repairing the new evidence. Only if the existing conditions do block subsequent processing will the specific results of the failure to deliver, the methods tried, the reasons identified and the conditions required for continuation be reported.

## Synchronization of the experimental report and description to humans

When the experiment is carried out, the state or outcome impact study judgement, the `doc/experiment.md` or the equivalent project page is updated simultaneously. The article-by-line project document specifications: object and judgement, operation and conditions, status and product, conclusions and uses, limits and follow-up, link to the configuration, implementation environment and operation list in effect.

The results, causes, effects, or choices to be used by the user first. Only the framework, environmental variables, algorithms, parameters, and measurement limits that affect understanding or decision are placed in the body of the document, while the rest remain on the available record. The necessary terminology is then introduced with specific experimental examples; user feedback is difficult to understand and reduces the concept presented at the same time. The reasons for this are to be found in the context of existing facts and missing evidence. Similar cases and temporary retreats support the next investigation. The performance report also indicates what is measured, where the results are applicable and what can be decided on the basis.

## Item-by-line

Repeating, seeding and digestion can be attributed to the same experiment, with a list of identities and meaningful differences. precheck, acceptance and formal results are presented in their respective statements.

The body of the experimental report presents key values, conditions for comparison and limitations.
