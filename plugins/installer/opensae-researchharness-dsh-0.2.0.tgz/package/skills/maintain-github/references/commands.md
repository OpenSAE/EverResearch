# 准备、发布与保存

## 目的和主要功能

说明发布程序的命令、文件范围、内部副本、差异和结果保存方式。

同时说明如何在技能内部准备本地与 GitHub 的比较副本，覆盖两边文件集合并记录差异。

## 适用范围

执行目录或文件复制、仓库发布、合并请求（PR）、版本包或版本发布（Release）操作时使用。此文档供智能助手调用内部程序，对用户的交流沿用 SKILL.md 中的功能语言。

对照 GitHub 项目与本地技能、准备比较副本和查看差异时，同样使用本文件。

## 内部实现与运行条件

`../scripts/publish.py` 是唯一程序入口，只使用 Python 3.11 及以上版本的标准库，调用已安装的 Git 和 GitHub 命令行入口。独立文件夹中的说明、脚本即可完成流程；程序按自身位置定位 `results/`，整体移动后仍可运行。

仓库操作使用 GitHub.com 的 `owner/name`。已有登录从当前机器读取，也可使用环境中的 `GH_TOKEN` 或 `GITHUB_TOKEN`。程序将凭据保留在内存和子进程环境中，GitHub 命令行入口的配置位置与工具临时、缓存位置指向任务内部。登录或安装软件另按用户授权处理。

命令中的 `<Skill目录>` 替换为当前 `SKILL.md` 所在目录的完整绝对路径。下文是结构示例，来源、仓库、分支和作者按真实任务填写。

对于已安装版本，用 `rh guide skill-state maintain-github` 定位可写目录，在该目录保存下文的本地产物。启动本技能的脚本时，对该进程设置 `RH_SKILL_WORK_DIR` 为这个路径。

## 对照检查的操作方式

先按 `SKILL.md` 确定每个项目的本地绝对路径、文件范围、GitHub 仓库、版本、仓库子目录与路径对应关系。使用当前任务新建的 `results/<任务标识>/`，在内部保存：

- `local/`：选定本地文件的独立副本。
- `remote-checkout/`：指定 GitHub 仓库的读取副本。
- `remote/`：按同一比较范围与路径对应关系整理的 GitHub 文件副本。
- `comparison.json`：本地来源、范围、路径对应关系、远程分支与实际提交，以及两边文件清单和比较结果。
- `comparison.diff`：文本与文件差异。

将本地路径的文件按确定范围复制到 `local/`。通过 Git 读取指定仓库和版本，在 `remote-checkout/` 中取得实际提交，再从对应目录按相同取舍复制到 `remote/`。所有工具的工作目录、临时文件和缓存使用本任务内部位置；调用 Git 时沿用发布程序中隔离来源仓库与内部操作的方式，认证读取已有登录。已有任务资料保留原样，本次结果写入新的任务目录。

比较两份副本的完整文件清单和实际内容，并保留需要交付的可执行属性。先按路径识别两边独有文件，再比较共有文件；空目录按实际目录结构记录。文本差异可在任务目录内使用以下标准 Git 命令保存：

```bash
git diff --no-index --binary --no-ext-diff --no-textconv -- local remote > comparison.diff
```

此命令退出码为 0 时表示一致，为 1 时表示存在差异；其他退出码说明操作出错，需要查明原因后报告实际完成范围。`comparison.json` 和 `comparison.diff` 通过本任务的 `log_updates.jsonl` 记录时间、技能内相对路径、内容和实际来源。读取失败或文件在复制期间变化时，说明具体对象，并在重新取得对应内容后继续比较。

对用户解释实际文件差异及用途，最后请用户决定是否对齐和对齐方向。用户选择更新 GitHub 后，再调用下文 `prepare` 准备相应发布；GitHub 独有文件的删除按用户批准的具体路径填写 `--delete`。用户选择调整本地时，先在内部副本准备选定改动并展示差异，原目录的实际修改按目标项目维护流程处理。

## 准备文件范围

`prepare` 只读取来源和远程仓库，在技能内复制、准备差异，实际创建仓库、推送、PR 和 Release 均在后续独立命令中执行。

```bash
python <Skill目录>/scripts/publish.py prepare \
  --root /path/to/ResearchHarness \
  --map .agents/skills/extract-structure=. \
  --exclude .agents/skills/extract-structure/results \
  --repo OWNER/extract-structure \
  --new --visibility private
```

`--map 来源=目标` 可以重复。来源相对于 `--root`，目标相对于目标仓库根目录：

- 目录映射到 `.`：把该目录的内容放到仓库根目录。
- 目录映射到 `tools/environment`：保留目录内部结构，放到该位置。
- 文件映射到 `tools/probe.py`：将该文件放到这个具体路径。单个文件映射到 `.` 时使用原文件名。
- 多个映射发生同名或文件与目录冲突时停止，保留来源文件。

`--exclude` 可重复，使用相对于来源根目录的路径或通配符。路径匹配会连同其子目录排除。文件选择按照映射和排除项执行，运行产物、本机配置和暂存目录是否纳入，由用户确定，并落实到映射和排除参数中；`.gitignore` 用于 Git 的文件忽略设置。

调用 `prepare` 前，按 SKILL.md 的范围询问要求说明实际发现的历史资料、备份和结果等内容，并取得具体取舍。把用户决定写成 `--map` 和 `--exclude`；命令示例中的排除项仅用于演示，以当前用户的决定为准。程序本身按给定范围复制，文件类别及其用途由智能助手阅读后判断。

当前任务中，ZIP 附件范围与 `source/` 中的选定内容一致。若用户希望仓库与附件采用不同范围，为附件范围单独执行一次 `prepare` 和 `pack`，所有文件仍保存在本技能内；使用 GitHub 命令行入口上传该包时明确指定原发布仓库、版本标签和内部包路径。已有仓库中的资料默认保留，用户要求从仓库移除时，将具体目标文件列入获准的 `--delete` 范围。GitHub 自带源码包的范围随标签对应的整个仓库确定。

程序始终略过 Git 元数据。选择包含本技能的父目录时略过本技能的 `results/`；明确选择某份已有产物作为来源时可以纳入。符号链接与特殊文件会报告其位置并停止，用户可以改为选择实际文件；独立副本采用普通文件复制。Git 和 ZIP 版本包以实际文件为单位交付，目录结构由其中的文件保留。

`--new` 表示用户明确要求新建仓库，搭配 `--visibility private` 或 `public`。默认分支为 `main`；实际使用其他分支时提供 `--base`。此步骤在本地准备；远程仓库在后续发布步骤中创建。

已有仓库示例：

```bash
python <Skill目录>/scripts/publish.py prepare \
  --root /path/to/ResearchHarness \
  --map src/harness/environment/probe.py=tools/probe.py \
  --repo OWNER/research-tools \
  --base main --branch publish-environment
```

`--base` 是读取的远程基础分支。`--branch` 省略时直接准备更新基础分支；使用新分支时可在发布时建立 PR。目标新分支已存在时停止；要直接更新这个已有分支，使用相同的 `--base` 和 `--branch`，或者选择另一个新分支。

`--delete 目标文件路径` 只在用户明确要求删除目标文件时使用，可重复。默认保留目标仓库中其余文件。删除对象为具体已跟踪文件；目录清理先列出具体文件，再按批准范围传入。

仅制作本地副本与版本包时，可以省略 `--repo`，后续使用 `pack`。它仍使用内部 Git 仓库保存可查看的差异。

## 查看准备结果

命令返回任务标识、文件数、忽略项、内部副本位置和 `changes.diff` 路径。按实际结果向用户说明待发布变化；内部文件组织如下：

```text
results/<任务标识>/
├── source/              # 用户选定内容的独立副本，按目标路径排列
├── checkout/            # 目标仓库及其 Git 元数据
├── plan.json            # 映射后的文件、摘要、仓库和分支
├── changes.diff         # 已准备的实际 Git 差异
├── result.json          # 实际操作结果，执行后生成
├── release/             # 版本包，按需生成
├── tmp/                 # 工具临时资料
├── cache/               # 工具缓存
├── config/gh/           # 工具运行配置位置
├── hooks/               # 本任务使用的空 Git hooks 位置
└── log_updates.jsonl
```

这些目录按使用需要建立。`plan.json` 与 `result.json` 用 `purpose`、`scope` 说明资料用途与范围；日志记录带时区的时间、技能内相对路径、内容和程序来源。来源目录及其暂存区、分支和 Git 元数据保持原样，准备工作使用任务内部的副本与 Git 仓库。

需要调整发布内容时，只编辑内部副本。为更新后的副本新建一轮准备：将 `--root` 指向该轮的 `source/`，使用 `--map .=.`，重复目标仓库和分支等参数。新增说明、版本号等按用户具体授权添加，新的差异重新展示后再发布。

## 提交和推送

在用户对具体范围已授权后调用：

```bash
python <Skill目录>/scripts/publish.py publish \
  --run <任务标识> \
  --message "Publish selected environment tools"
```

程序使用现有 Git 作者身份；确有需要时在命令中同时提供 `--author-name` 与 `--author-email`。身份配置用于内部提交，用户全局配置和来源仓库保持原样。

程序检查内部副本、待提交内容及远程分支是否仍与准备结果对应，远程写入失败或出现冲突时停止。它采用普通推送，并保存本地提交和实际远程操作结果。再次执行前查看 `result.json` 和远程状态；已记录或已推送的同一提交继续沿用。

新建仓库在此步骤使用明确的公开或私有设置创建；来源内容提前提交到内部仓库。创建成功但推送失败时，记录已经创建的事实。网络响应有待确认时，先查清仓库或分支的实际状态，再决定沿用已有结果或继续创建。

## 通过 PR 交付

已有仓库、新分支的准备结果可使用：

```bash
python <Skill目录>/scripts/publish.py publish \
  --run <任务标识> \
  --message "Publish selected environment tools" \
  --pr --title "Add environment tools" \
  --body-file <可写技能目录>/results/<任务标识>/pr_description.md
```

先将准确的说明写到技能内部，`--body-file` 使用完整路径。需要草稿 PR 时增加 `--draft`。程序先推送，再查找该来源分支到目标基础分支的开放 PR；已有时返回其链接，缺少时创建。新仓库首次发布以及直接更新基础分支的任务使用提交链接。

创建或接续当前任务的 PR 后，宿主提供附件工具时调用它附上真实 PR 链接。宿主提供普通链接交付方式时，直接返回链接；发布程序使用本技能自带的实现。

## 版本包与 Release

仅制作本地 ZIP：

```bash
python <Skill目录>/scripts/publish.py pack --run <任务标识>
```

ZIP 的内容为选定内部副本中的文件，路径采用映射后的目标路径。目标仓库中的其他文件和本任务记录分别保存在原有位置。文件保存在内部 `release/`，文件名带任务标识。

用户要求 GitHub Release 时，先发布内容取得真实提交，再准备内部版本说明：

```bash
python <Skill目录>/scripts/publish.py release \
  --run <任务标识> \
  --tag v0.1.0 --title "ExtractStructure 0.1.0" \
  --notes-file <可写技能目录>/results/<任务标识>/version_notes.md
```

需要草稿 Release 时增加 `--draft`。程序为本次真实发布的提交创建 Release 并上传选定文件的 ZIP；已有版本标签须指向同一提交。已有 Release 或附件冲突会停止，先查看实际状态再决定是否继续。

GitHub 自带的源码下载对应标签处的整个仓库；本技能上传的 ZIP 附件对应本次选定内容。这两种下载内容各自按实际范围向用户说明。

## 失败后的处理与其他发布需求

一次外部操作失败后保留所有副本与状态，说明已创建仓库、已推送提交、已创建 PR 或 Release 中哪些真实完成。根据 `result.json` 与远程实际状态决定继续方式。新增或删除远程资源、修改公开范围、强制覆盖分支以及运行来源项目的构建命令，分别按用户明确授权处理。

运行入口提供普通文件复制、仓库发布、PR、ZIP 和 Release。保留提交历史、子模块、Git LFS、自动化持续同步和网站部署等需求，先说明与本入口的差别再确定实际操作；完整流程的所有本地写入仍位于技能内。
