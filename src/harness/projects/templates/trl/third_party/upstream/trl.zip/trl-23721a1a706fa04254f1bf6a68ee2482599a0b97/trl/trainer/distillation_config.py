# Copyright 2020-2026 The HuggingFace Team. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from dataclasses import dataclass, field
from typing import Any

from .base_config import _BaseConfig


@dataclass
class DistillationConfig(_BaseConfig):
    r"""
    Configuration class for the [`DistillationTrainer`].

    Extends [`~transformers.TrainingArguments`] with parameters specific to knowledge distillation. All necessary
    fields are declared here.

    Using [`~transformers.HfArgumentParser`] we can turn this class into
    [argparse](https://docs.python.org/3/library/argparse#module-argparse) arguments that can be specified on the
    command line.

    Parameters:
        > Parameters that control the model and the teacher model

        model_init_kwargs (`str` or `dict[str, Any]`, *optional*):
            Keyword arguments for `AutoModelForCausalLM.from_pretrained`, used when the `model` argument of the trainer
            is provided as a string. The `revision` value is also used when loading the processing class.
        trust_remote_code (`bool`, *optional*, defaults to `False`):
            Whether to allow loading models and tokenizers that ship custom Python code from the Hub. Forwarded to
            [`~transformers.AutoModelForCausalLM.from_pretrained`] and [`~transformers.AutoTokenizer.from_pretrained`],
            for both the student and teacher.
        teacher_model_name_or_path (`str` or `dict[str, str]`, *optional*):
            Model name or path for the teacher model. Used when the teacher is loaded locally. A mapping from teacher
            ID to model name or path uses several teachers, where the `teacher_id` column of each row selects its
            teacher.
        teacher_model_revision (`str`, *optional*):
            Model revision of the teacher model (e.g., branch name, tag, or commit hash).
        teacher_model_init_kwargs (`str` or `dict[str, Any]`, *optional*):
            Keyword arguments passed to `AutoModelForCausalLM.from_pretrained` when instantiating the teacher model
            from a string. When `teacher_model_name_or_path` is a mapping, provide a mapping from teacher ID to loading
            kwargs instead, e.g. `{"math": {"dtype": "bfloat16"}, "code": {"revision": "main"}}`. Omitted teachers use
            the default loading kwargs.
        disable_dropout (`bool`, *optional*, defaults to `False`):
            Whether to disable dropout in the student model during training.

        > Parameters that control the data preprocessing

        remove_unused_columns (`bool`, *optional*, defaults to `False`):
            Whether to remove dataset columns other than `"prompt"`, `"image"`, `"images"`, `"teacher_id"`, and
            `"environment"`.
        max_completion_length (`int` or `None`, *optional*, defaults to `512`):
            Maximum number of tokens to generate per completion during on-policy generation. With `tools` or
            `environment_factory`, it caps the whole multi-turn completion after the prompt (all model turns plus tool
            results).
        ds3_gather_for_generation (`bool`, *optional*, defaults to `True`):
            This setting applies to DeepSpeed ZeRO-3. If enabled, the policy model weights are gathered for generation,
            improving generation speed. However, disabling this option allows training models that exceed the VRAM
            capacity of a single GPU, albeit at the cost of slower generation. Disabling this option is not compatible
            with vLLM generation.
        shuffle_dataset (`bool`, *optional*, defaults to `True`):
            Whether to shuffle the training dataset.
        pad_to_multiple_of (`int` or `str`, *optional*, defaults to `"auto"`):
            If set, the prompts ids and completions ids will be padded to a multiple of this value. `"auto"` pads to a
            multiple of 128 on Neuron (AWS Trainium), which compiles once per input shape, and does not pad elsewhere.

        > Parameters that control generation

        temperature (`float`, *optional*, defaults to `1.0`):
            Temperature for sampling during generation and for computing the distillation loss. Higher values produce
            softer probability distributions.
        top_p (`float`, *optional*, defaults to `1.0`):
            Top-p (nucleus) sampling parameter for on-policy generation.
        top_k (`int`, *optional*, defaults to `0`):
            Top-k sampling parameter for on-policy generation. `0` disables top-k filtering.
        min_p (`float`, *optional*):
            Minimum token probability, which will be scaled by the probability of the most likely token. It must be a
            value between `0.0` and `1.0`. Typical values are in the `0.01-0.2` range.
        generation_kwargs (`dict[str, Any]`, *optional*):
            Additional keyword arguments to pass to [`~transformers.GenerationConfig`] (if using transformers) or
            `SamplingParams` (if using vLLM) when sampling completions. This can be used to further customize the
            generation behavior, such as setting `suppress_tokens`, `num_beams`, etc. If it contains keys that conflict
            with the other generation parameters (like `min_p`, `top_p`, etc.), they will override them.
        chat_template_kwargs (`dict[str, Any]`, *optional*):
            Additional keyword arguments to pass to the `apply_chat_template` function when generating completions.
        repetition_penalty (`float`, *optional*, defaults to `1.0`):
            Float that penalizes new tokens based on whether they appear in the prompt and the generated text so far.
            Values > `1.0` encourage the model to use new tokens, while values < `1.0` encourage the model to repeat
            tokens.
        cache_implementation (`str`, *optional*):
            Implementation of the cache method for faster generation when `use_vllm` is set to `False`.

        > Parameters that control generation acceleration powered by vLLM

        use_vllm (`bool`, *optional*, defaults to `False`):
            Whether to use vLLM for generating on-policy completions from the student model.
        vllm_mode (`str`, *optional*, defaults to `"colocate"`):
            Mode for student vLLM integration. Either `"server"` or `"colocate"`.
        vllm_model_impl (`str`, *optional*, defaults to `"vllm"`):
            Model implementation backend for vLLM. Use `"vllm"` or `"transformers"`.
        vllm_enable_sleep_mode (`bool`, *optional*, defaults to `False`):
            Enable vLLM sleep mode to offload student weights during the optimizer step.
        vllm_structured_outputs_regex (`str`, *optional*):
            Regex pattern for vLLM structured outputs.

        > Parameters that control the vLLM server (only used when `vllm_mode` is `"server"`)

        vllm_server_base_url (`str`, *optional*):
            Base URL for the student vLLM server. If provided, `vllm_server_host` and `vllm_server_port` are ignored.
        vllm_server_host (`str`, *optional*, defaults to `"0.0.0.0"`):
            Host of the student vLLM server.
        vllm_server_port (`int`, *optional*, defaults to `8000`):
            Port of the student vLLM server.
        vllm_server_timeout (`float`, *optional*, defaults to `240.0`):
            Timeout for connecting to the student vLLM server.
        vllm_group_port (`int`, *optional*, defaults to `51216`):
            Port for the vLLM weight-update group (NCCL communicator).

        > Parameters that control colocated vLLM execution (only used when `vllm_mode` is `"colocate"`)

        vllm_gpu_memory_utilization (`float`, *optional*, defaults to `0.3`):
            GPU memory utilization for the colocated student vLLM engine.
        vllm_max_model_length (`int`, *optional*):
            Maximum model sequence length for the colocated vLLM engine.
        vllm_tensor_parallel_size (`int`, *optional*, defaults to `1`):
            Tensor parallel size for the colocated student vLLM engine.

        > Parameters that control the training

        beta (`float`, *optional*, defaults to `1.0`):
            Interpolation coefficient for the Generalized Jensen-Shannon Divergence loss. When `0.0`, the loss is the
            forward KL divergence. When `1.0`, the loss is the reverse KL divergence. When `0.5`, it is the standard
            JSD. Unlike GRPO's `beta` (a KL-penalty coefficient against a reference model), here it selects the
            divergence itself; there is no reference-model KL penalty.
        max_tool_calling_iterations (`int`, *optional*):
            Maximum number of tool-calling turns when training an agent. If `None`, there is no limit and generation
            stops when the model generates a response turn with no tool calls, when the completion (all turns and tool
            results) reaches `max_completion_length` tokens, or when the full sequence reaches the model's maximum
            length (`vllm_max_model_length` with `vllm_mode="colocate"`, the model's `max_position_embeddings`
            otherwise). When the limit is reached, the tool calls of the last generated turn are not executed and the
            completion ends with that turn, so a final tool call (for example one that submits an answer) is never
            executed.

        > Parameters that control the logging

        log_completions (`bool`, *optional*, defaults to `False`):
            Whether to log a sample of (prompt, completion) pairs every `logging_steps` steps. If `rich` is installed,
            it prints the sample. If `wandb` and/or `trackio` logging is enabled, it logs it to `wandb` and/or
            `trackio`.
        num_completions_to_print (`int`, *optional*):
            Number of completions to print with `rich`. If `None`, all completions are logged.
        log_unique_prompts (`bool`, *optional*, defaults to `False`):
            Whether to log unique prompts. If `True`, only unique prompts are logged. If `False`, all prompts are
            logged.

    > [!NOTE]
    > These parameters have default values different from [`~transformers.TrainingArguments`]:
    > - `logging_steps`: Defaults to `10` instead of `500`.
    > - `gradient_checkpointing`: Defaults to `True` instead of `False`.
    > - `bf16`: Defaults to `True` if `fp16` is not set, instead of `False`.
    > - `learning_rate`: Defaults to `1e-6` instead of `5e-5`.
    """

    _VALID_DICT_FIELDS = _BaseConfig._VALID_DICT_FIELDS + [
        "model_init_kwargs",
        "teacher_model_name_or_path",
        "teacher_model_init_kwargs",
        "generation_kwargs",
        "chat_template_kwargs",
    ]

    # Parameters whose default values are overridden from TrainingArguments
    learning_rate: float = field(
        default=1e-6,
        metadata={"help": "The initial learning rate for AdamW."},
    )

    # Parameters that control the model and the teacher model
    model_init_kwargs: dict[str, Any] | str | None = field(
        default=None,
        metadata={
            "help": "Keyword arguments for `AutoModelForCausalLM.from_pretrained`, used when the `model` argument "
            "of the trainer is provided as a string. The `revision` value is also used when loading the processing "
            "class."
        },
    )
    trust_remote_code: bool = field(
        default=False,
        metadata={
            "help": "Whether to allow loading models and tokenizers that ship custom Python code from the Hub. "
            "Forwarded to `AutoModelForCausalLM.from_pretrained` and `AutoTokenizer.from_pretrained`, for both the "
            "student and teacher."
        },
    )
    teacher_model_name_or_path: dict[str, str] | str | None = field(
        default=None,
        metadata={
            "help": "Model name or path for the teacher model, or a mapping from teacher ID to model name or path."
        },
    )
    teacher_model_revision: str | None = field(
        default=None,
        metadata={"help": "Model revision of the teacher model (e.g., branch name, tag, or commit hash)."},
    )
    teacher_model_init_kwargs: dict[str, Any] | str | None = field(
        default=None,
        metadata={
            "help": "Keyword arguments for `AutoModelForCausalLM.from_pretrained` when instantiating the teacher, or "
            "a mapping from teacher ID to such kwargs."
        },
    )
    disable_dropout: bool = field(
        default=False,
        metadata={"help": "Whether to disable dropout in the student model during training."},
    )

    # Parameters that control the data preprocessing
    # The default `remove_unused_columns` is overwritten from the parent class: distillation trains on the raw
    # `prompt` column and generates completions on-policy, so no columns are dropped.
    remove_unused_columns: bool | None = field(
        default=False,
        metadata={
            "help": "Whether to remove dataset columns other than 'prompt', 'image', 'images', 'teacher_id', and "
            "'environment'."
        },
    )
    max_completion_length: int | None = field(
        default=512,
        metadata={
            "help": "Maximum number of tokens to generate per completion. With `tools` or `environment_factory`, it "
            "caps the whole multi-turn completion after the prompt (all model turns plus tool results)."
        },
    )
    ds3_gather_for_generation: bool = field(
        default=True,
        metadata={
            "help": "This setting applies to DeepSpeed ZeRO-3. If enabled, the policy model weights are gathered for "
            "generation, improving generation speed. However, disabling this option allows training models that "
            "exceed the VRAM capacity of a single GPU, albeit at the cost of slower generation. Disabling this option "
            "is not compatible with vLLM generation."
        },
    )
    shuffle_dataset: bool | None = field(
        default=True,
        metadata={"help": "Whether to shuffle the training dataset."},
    )
    pad_to_multiple_of: int | str | None = field(
        default="auto",
        metadata={
            "help": "If set, the prompts ids and completions ids will be padded to a multiple of this value. `'auto'` "
            "pads to a multiple of 128 on Neuron (AWS Trainium), which compiles once per input shape, and does not "
            "pad elsewhere."
        },
    )

    # Parameters that control generation
    temperature: float = field(
        default=1.0,
        metadata={
            "help": "Temperature for sampling and loss computation. Higher values produce softer distributions."
        },
    )
    top_p: float = field(
        default=1.0,
        metadata={"help": "Top-p (nucleus) sampling parameter for on-policy generation."},
    )
    top_k: int = field(
        default=0,
        metadata={"help": "Top-k sampling parameter for on-policy generation. 0 disables top-k filtering."},
    )
    min_p: float | None = field(
        default=None,
        metadata={
            "help": "Minimum token probability, which will be scaled by the probability of the most likely token. It "
            "must be a value between 0.0 and 1.0. Typical values are in the 0.01-0.2 range."
        },
    )
    generation_kwargs: dict | str | None = field(
        default=None,
        metadata={
            "help": "Additional keyword arguments to pass to `GenerationConfig` (if using transformers) or "
            "`SamplingParams` (if using vLLM) when sampling completions. This can be used to further customize the "
            "generation behavior, such as setting `suppress_tokens`, `num_beams`, etc. If it contains keys that "
            "conflict with the other generation parameters (like `min_p`, `top_p`, etc.), they will override them."
        },
    )
    chat_template_kwargs: dict | str | None = field(
        default=None,
        metadata={
            "help": "Additional keyword arguments to pass to the `apply_chat_template` function when generating "
            "completions."
        },
    )
    repetition_penalty: float = field(
        default=1.0,
        metadata={
            "help": "Float that penalizes new tokens based on whether they appear in the prompt and the generated "
            "text so far. Values > 1.0 encourage the model to use new tokens, while values < 1.0 encourage the model "
            "to repeat tokens."
        },
    )
    cache_implementation: str | None = field(
        default=None,
        metadata={"help": "Implementation of the cache method for faster generation when use_vllm is set to False."},
    )

    # Parameters that control generation acceleration powered by vLLM
    use_vllm: bool = field(
        default=False,
        metadata={"help": "Whether to use vLLM for generating on-policy completions from the student model."},
    )
    vllm_mode: str = field(
        default="colocate",
        metadata={"help": 'Mode for student vLLM integration. Either "server" or "colocate".'},
    )
    vllm_model_impl: str = field(
        default="vllm",
        metadata={"help": 'Model implementation backend for vLLM. Use "vllm" or "transformers".'},
    )
    vllm_enable_sleep_mode: bool = field(
        default=False,
        metadata={"help": "Enable vLLM sleep mode to offload student weights during the optimizer step."},
    )
    vllm_structured_outputs_regex: str | None = field(
        default=None,
        metadata={"help": "Regex pattern for vLLM structured outputs."},
    )

    # Parameters that control the vLLM server (only used when `vllm_mode` is `"server"`)
    vllm_server_base_url: str | None = field(
        default=None,
        metadata={"help": "Base URL for the student vLLM server."},
    )
    vllm_server_host: str = field(
        default="0.0.0.0",
        metadata={"help": "Host of the student vLLM server."},
    )
    vllm_server_port: int = field(
        default=8000,
        metadata={"help": "Port of the student vLLM server."},
    )
    vllm_server_timeout: float = field(
        default=240.0,
        metadata={"help": "Timeout for connecting to the student vLLM server."},
    )
    vllm_group_port: int = field(
        default=51216,
        metadata={"help": "Port for the vLLM weight-update group (NCCL communicator)."},
    )

    # Parameters that control colocated vLLM execution (only used when `vllm_mode` is `"colocate"`)
    vllm_gpu_memory_utilization: float = field(
        default=0.3,
        metadata={"help": "GPU memory utilization for the colocated student vLLM engine."},
    )
    vllm_max_model_length: int | None = field(
        default=None,
        metadata={"help": "Maximum model sequence length for the colocated vLLM engine."},
    )
    vllm_tensor_parallel_size: int = field(
        default=1,
        metadata={"help": "Tensor parallel size for the colocated student vLLM engine."},
    )

    # Parameters that control the training
    beta: float = field(
        default=1.0,
        metadata={
            "help": "Interpolation coefficient for the Generalized JSD loss. 0.0 = forward KL, 0.5 = JSD, 1.0 = reverse "
            "KL. Unlike GRPO's `beta` (a KL-penalty coefficient against a reference model), here it selects the "
            "divergence itself; there is no reference-model KL penalty."
        },
    )
    max_tool_calling_iterations: int | None = field(
        default=None,
        metadata={
            "help": "Maximum number of tool-calling turns when training an agent. If `None`, there is no limit and "
            "generation stops when the model generates a response turn with no tool calls, when the completion "
            "(all turns and tool results) reaches `max_completion_length` tokens, or when the full sequence reaches "
            "the model's maximum length (`vllm_max_model_length` with `vllm_mode=\"colocate\"`, the model's "
            "`max_position_embeddings` otherwise). When the limit is reached, the tool calls of the last generated "
            "turn are not executed and the completion ends with that turn, so a final tool call (for example one "
            "that submits an answer) is never executed."
        },
    )

    # Parameters that control the logging
    log_completions: bool = field(
        default=False,
        metadata={
            "help": "Whether to log a sample of (prompt, completion) pairs every `logging_steps` steps. If `rich` is "
            "installed, it prints the sample. If `wandb` and/or `trackio` logging is enabled, it logs it to `wandb` "
            "and/or `trackio`."
        },
    )
    num_completions_to_print: int | None = field(
        default=None,
        metadata={"help": "Number of completions to print with `rich`. If `None`, all completions are logged."},
    )
    log_unique_prompts: bool = field(
        default=False,
        metadata={
            "help": "Whether to log unique prompts. If `True`, only unique prompts are logged. If `False`, all "
            "prompts are logged."
        },
    )

    def __post_init__(self):
        super().__post_init__()
        # The CLI passes the value as a string
        if isinstance(self.pad_to_multiple_of, str) and self.pad_to_multiple_of != "auto":
            self.pad_to_multiple_of = (
                None if self.pad_to_multiple_of.lower() in ("none", "null") else int(self.pad_to_multiple_of)
            )
        if self.pad_to_multiple_of == "auto":
            # Neuron compiles once per input shape, so padding bounds the number of compilations
            self.pad_to_multiple_of = 128 if self.device.type == "neuron" else None

        if self.beta < 0.0 or self.beta > 1.0:
            raise ValueError(f"beta must be in [0.0, 1.0], got {self.beta}.")

        if self.parallelism_config is not None and (
            self.parallelism_config.cp_enabled or self.parallelism_config.sp_enabled
        ):
            raise ValueError(
                "DistillationTrainer does not support sequence-dim parallelism (`parallelism_config.cp_size > 1` "
                "or `parallelism_config.sp_size > 1`) yet. Distillation builds model inputs after generation "
                "inside the trainer, so Transformers' context-parallel / Ulysses sequence-parallel input "
                "sharding cannot be applied to the raw generation batch. Set both `cp_size=1` and `sp_size=1`, "
                "or disable `parallelism_config`."
            )
