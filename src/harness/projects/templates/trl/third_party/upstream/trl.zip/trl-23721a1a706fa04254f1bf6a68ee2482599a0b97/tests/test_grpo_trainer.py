# Copyright 2020-2026 The HuggingFace Team. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import json
import os
from collections import defaultdict
from collections.abc import Callable
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

import pytest
import torch
import transformers
from accelerate.utils.memory import release_memory
from datasets import Dataset, DatasetDict, IterableDatasetDict, load_dataset
from packaging.version import Version
from transformers import (
    AutoConfig,
    AutoModelForCausalLM,
    AutoModelForImageTextToText,
    AutoModelForSequenceClassification,
    AutoProcessor,
    AutoTokenizer,
    BitsAndBytesConfig,
)
from transformers.testing_utils import torch_device
from transformers.utils import is_peft_available

from trl import GRPOConfig, GRPOTrainer
from trl.chat_template_utils import _SUPPORTS_RESPONSE_TEMPLATE, deepseekv3_v5_chat_template
from trl.generation.vllm_client import VLLMClient
from trl.import_utils import is_vllm_available

from .testing_utils import (
    TrlTestCase,
    is_ampere_or_newer,
    is_bf16_supported,
    require_bitsandbytes,
    require_peft,
    require_response_parsing,
    require_torch_accelerator,
    require_vision,
    require_vllm,
)


if is_peft_available():
    import peft
    from peft import LoraConfig, PromptTuningConfig, get_peft_model
    from peft.utils import TaskType


def multiply_tool(a: int, b: int) -> int:
    """
    Multiplies two integers.

    Args:
        a: The first integer.
        b: The second integer.

    Returns:
        The product of the two integers.
    """
    return a * b


async def async_multiply_tool(a: int, b: int) -> int:
    """
    Asynchronously multiplies two integers.

    Args:
        a: The first integer.
        b: The second integer.

    Returns:
        The product of the two integers.
    """
    return a * b


def str_length_reward(completions, **kwargs):
    """Reward function that rewards longer completions, whatever their format."""
    return [float(len(str(completion))) for completion in completions]


def lookup_tool(query: str) -> list:
    """
    Looks up the items matching a query.

    Args:
        query: What to look up.

    Returns:
        The matching items, as text content blocks.
    """
    return [{"type": "text", "text": "crate"}]


def screenshot_tool() -> str:
    """Simple text-returning tool."""
    return "The image shows a red square."


def screenshot_image_tool() -> list:
    """
    Takes a screenshot and returns it.

    Returns:
        A list of content blocks with the screenshot image.
    """
    from PIL import Image as PILImage

    img = PILImage.new("RGB", (64, 64), color="red")
    return [{"type": "image", "image": img}, {"type": "text", "text": "Here is the screenshot"}]


def record(key: str, value):
    """Append `value` under `key` to the file `TRL_TEST_RECORD` names.

    Tools and environments run in the rollout worker's process, so they report what they see through a file rather than
    through the test's variables.
    """
    with open(os.environ["TRL_TEST_RECORD"], "a") as f:
        f.write(json.dumps([key, value]) + "\n")


def recorded(path: str) -> dict[str, list]:
    """Read back what [`record`] wrote to `path`, as `{key: [value, ...]}`."""
    records = defaultdict(list)
    with open(path) as f:
        for line in f:
            key, value = json.loads(line)
            records[key].append(value)
    return records


class ScriptedTurns:
    """Answers each prompt with a completion written as text, in place of the model's generation.

    The k-th first turn of a prompt gets `first_turns[k % len(first_turns)]`, and a turn after a tool result gets
    `after_tool`. Call it with a prompt's token ids, or patch [`~ScriptedTurns.generate`] in for the model's
    `generate`.

    Args:
        tokenizer ([`~transformers.PreTrainedTokenizerBase`]):
            Tokenizer of the model.
        first_turns (`list[str]` or `Callable[[str], list[str]]`):
            Completions of the first turn, or a function of the prompt's text returning them.
        after_tool (`str`, *optional*, defaults to `"Done!<|im_end|>"`):
            Completion of a turn after a tool result.
        tool_response_marker (`str`, *optional*, defaults to `"<tool_response>"`):
            Text the chat template renders a tool result with, which tells the turns apart.

    Attributes:
        turns_after_tool (`int`):
            Number of turns answered after a tool result.
    """

    def __init__(self, tokenizer, first_turns, after_tool="Done!<|im_end|>", tool_response_marker="<tool_response>"):
        self.tokenizer = tokenizer
        self.first_turns = first_turns
        self.after_tool = after_tool
        self.tool_response_marker = tool_response_marker
        self.seen = defaultdict(int)
        self.turns_after_tool = 0

    def __call__(self, prompt_ids: list[int]) -> list[int]:
        prompt = self.tokenizer.decode(prompt_ids)
        if self.tool_response_marker in prompt:
            self.turns_after_tool += 1
            text = self.after_tool
        else:
            first_turns = self.first_turns(prompt) if callable(self.first_turns) else self.first_turns
            text = first_turns[self.seen[prompt] % len(first_turns)]
            self.seen[prompt] += 1
        return self.tokenizer(text, add_special_tokens=False).input_ids

    def generate(self, input_ids, attention_mask, **kwargs):
        """Answer a batch of left-padded prompts as `generate` does: each prompt followed by its completion,
        right-padded."""
        completions = [self(ids[mask.bool()].tolist()) for ids, mask in zip(input_ids, attention_mask, strict=True)]
        width = max(len(ids) for ids in completions)
        completion_ids = [ids + [self.tokenizer.pad_token_id] * (width - len(ids)) for ids in completions]
        return torch.cat([input_ids, torch.tensor(completion_ids, device=input_ids.device)], dim=-1)


class CounterEnvironment:
    def reset(self, **kwargs):
        record("reset_counter", kwargs)
        return "Count."

    def increment(self, step: int) -> int:
        """
        Increment the internal counter.

        Args:
            step: Value to add to the counter.

        Returns:
            The updated counter value.
        """
        record("increment", step)
        return step


class EchoEnvironment:
    def reset(self, **kwargs):
        record("reset_echo", kwargs)
        return "Echo."

    def shout(self, text: str) -> str:
        """
        Shout the given text.

        Args:
            text: Text to shout.

        Returns:
            The text in upper case.
        """
        record("shout", text)
        return text.upper()


class ZipEnvironment:
    def reset(self, **kwargs):
        return "Give the zip code."

    def submit(self, answer: str) -> str:
        """
        Submit the zip code.

        Args:
            answer: The zip code.

        Returns:
            A confirmation.
        """
        record("zip", answer)
        return "ok"


class CountEnvironment:
    def reset(self, **kwargs):
        return "Count."

    def submit(self, answer: int) -> str:
        """
        Submit the count.

        Args:
            answer: The count.

        Returns:
            A confirmation.
        """
        record("count", answer)
        return "ok"


class IncrementEnvironment:
    def reset(self, **kwargs):
        self._counter = 0

    def increment(self, step: int) -> int:
        """
        Increment the internal counter.

        Args:
            step: Value to add to the counter.

        Returns:
            The updated counter value.
        """
        self._counter += step
        return self._counter


class IncrementRewardEnvironment(IncrementEnvironment):
    def get_reward(self) -> float:
        return float(self._counter)


class PropertyEnvironment:
    def __init__(self):
        self.is_reset = False

    def reset(self, **kwargs):
        self.is_reset = True

    @property
    def reward(self) -> float:
        if self.is_reset:
            raise RuntimeError("`reward` must not be evaluated while discovering tools")
        return 0.0

    def echo(self, text: str) -> str:
        """
        Echo the text back.

        Args:
            text: Text to echo.

        Returns:
            The text, unchanged.
        """
        return text


class ScoredEnvironment:  # owns its reward
    def reset(self, **kwargs): ...

    def act(self, x: int) -> int:
        """
        Act.

        Args:
            x: A value.

        Returns:
            The value.
        """
        return x

    def get_reward(self) -> float:
        return 1.0


class GuessTheWordEnvironment:
    def reset(self, **kwargs):
        return "Guess the 5-letter word."  # the env owns the data and returns the prompt


class TestGetHighEntropyMask(TrlTestCase):
    def get_high_entropy_mask(self, entropies, mask, threshold):
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")
        trainer = GRPOTrainer(
            model="trl-internal-testing/tiny-Qwen2ForCausalLM-2.5",
            reward_funcs=str_length_reward,
            args=GRPOConfig(output_dir=self.tmp_dir, report_to="none"),
            train_dataset=dataset,
        )
        return trainer.get_high_entropy_mask(entropies, mask, threshold)

    def test_compute_entropy_mask_0(self):
        # We have a total of 12 tokens out of which 10 are non-pad.
        # for a top_entropy_quantile of 0.8, we expect the top 20% i.e 2 non-pad tokens corresponding to
        # the highest entropy to be unmasked.
        # In our example these will be the tokens corresponding to the entropies 0.9 and 1.0 since 1.1 and 1.2 are pad
        # tokens they are excluded from the entropy threshold calculation.
        entropies = torch.tensor([[0.1, 0.2, 0.3, 0.4, 0.5, 0.6], [0.7, 0.8, 0.9, 1.0, 1.1, 1.2]])
        mask = torch.tensor([[1, 1, 1, 1, 1, 1], [1, 1, 1, 1, 0, 0]])
        entropy_mask = self.get_high_entropy_mask(entropies, mask, threshold=0.8)
        expected_mask = torch.tensor([[0, 0, 0, 0, 0, 0], [0, 0, 1, 1, 0, 0]], dtype=torch.bool)
        torch.testing.assert_close(entropy_mask, expected_mask)

    def test_compute_entropy_mask_1(self):
        # Another example with a different set of entropies and a different mask.
        entropies = torch.tensor([[0.1, 0.2, 0.3, 1.4, 0.5, 0.14], [0.5, 0.6, 0.7, 0.8, 0.9, 1.0]])
        mask = torch.tensor([[1, 1, 1, 1, 0, 0], [1, 1, 1, 1, 0, 0]])
        entropy_mask = self.get_high_entropy_mask(entropies, mask, threshold=0.8)
        expected_mask = torch.tensor([[0, 0, 0, 1, 0, 0], [0, 0, 0, 1, 0, 0]], dtype=torch.bool)
        torch.testing.assert_close(entropy_mask, expected_mask)

    def test_compute_entropy_mask_lower_threshold(self):
        # For a threshold of 0.5 we expect the top half of the non-pad tokens to be unmasked.
        entropies = torch.tensor([[0.1, 0.2, 0.3, 0.4, 0.5, 0.6], [0.7, 0.8, 0.9, 1.0, 1.1, 1.2]])
        mask = torch.tensor([[1, 1, 1, 1, 1, 1], [1, 1, 1, 1, 0, 0]])
        entropy_mask = self.get_high_entropy_mask(entropies, mask, threshold=0.5)
        expected_mask = torch.tensor([[0, 0, 0, 0, 0, 1], [1, 1, 1, 1, 0, 0]], dtype=torch.bool)
        torch.testing.assert_close(entropy_mask, expected_mask)

    def test_compute_entropy_threshold_0(self):
        # If the threshold is 0.0 then we expect the mask to be all ones for non-pad tokens.
        entropies = torch.tensor([[0.1, 0.2, 0.3, 0.4, 0.5, 0.6], [0.7, 0.8, 0.9, 1.0, 1.1, 1.2]])
        mask = torch.tensor([[1, 1, 1, 1, 1, 1], [1, 1, 1, 1, 0, 0]])
        entropy_mask = self.get_high_entropy_mask(entropies, mask, threshold=0.0)
        expected_mask = torch.tensor([[1, 1, 1, 1, 1, 1], [1, 1, 1, 1, 0, 0]], dtype=torch.bool)
        torch.testing.assert_close(entropy_mask, expected_mask)

    def test_compute_entropy_threshold_1(self):
        # If the threshold is 1.0 then we expect the mask to be all zeros BUT ONE VALUE.
        entropies = torch.tensor([[0.1, 0.2, 0.3, 0.4, 0.5, 0.6], [0.7, 0.8, 0.9, 1.0, 1.1, 1.2]])
        mask = torch.tensor([[1, 1, 1, 1, 1, 1], [1, 1, 1, 1, 0, 0]])
        entropy_mask = self.get_high_entropy_mask(entropies, mask, threshold=1.0)
        expected_mask = torch.tensor([[0, 0, 0, 0, 0, 0], [0, 0, 0, 1, 0, 0]], dtype=torch.bool)
        torch.testing.assert_close(entropy_mask, expected_mask)

    def test_compute_entropy_all_masked(self):
        # If there are no non-pad tokens we expect the mask to be all zeros.
        entropies = torch.tensor([[0.1, 0.2, 0.3, 0.4, 0.5, 0.6], [0.7, 0.8, 0.9, 1.0, 1.1, 1.2]])
        mask = torch.tensor([[0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0]])
        entropy_mask = self.get_high_entropy_mask(entropies, mask, threshold=0.5)
        expected_mask = torch.tensor([[0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0]], dtype=torch.bool)
        torch.testing.assert_close(entropy_mask, expected_mask)


class TestGRPORolloutDispatch(TrlTestCase):
    def _make_rollout_func(self, **output):
        # A plain callable, as a user passes, recording the calls it gets
        def rollout_func(prompts, trainer):
            rollout_func.calls.append((prompts, trainer))
            return output

        rollout_func.calls = []
        return rollout_func

    def _make_trainer(self, rollout_func):
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")
        return GRPOTrainer(
            model="trl-internal-testing/tiny-Qwen2ForCausalLM-2.5",
            reward_funcs=str_length_reward,
            args=GRPOConfig(output_dir=self.tmp_dir, report_to="none"),
            train_dataset=dataset,
            rollout_func=rollout_func,
        )

    @patch.dict(os.environ, {"TRL_EXPERIMENTAL_SILENCE": "1"})
    def test_generate_prefers_rollout_func(self):
        rollout_func = self._make_rollout_func(
            prompt_ids=[[1]], completion_ids=[[2]], logprobs=[[-0.1]], env_mask=[[1]]
        )
        trainer = self._make_trainer(rollout_func)

        result = trainer._generate(["prompt"])

        assert result[0] == [[1]]  # prompt_ids
        assert result[1] == [[2]]  # completion_ids
        assert result[2] == [[1]]  # tool_mask (from env_mask)
        assert rollout_func.calls == [(["prompt"], trainer)]

    @patch.dict(os.environ, {"TRL_EXPERIMENTAL_SILENCE": "1"})
    def test_generate_rollout_func_syncs_vllm_weights_when_needed(self):
        rollout_func = self._make_rollout_func(prompt_ids=[[1]], completion_ids=[[2]], logprobs=[[0.0]])
        trainer = self._make_trainer(rollout_func)
        # Stand in for the vLLM server, which cannot run here, and start from the step __init__ sets with use_vllm=True
        trainer.use_vllm = True
        trainer.vllm_generation = MagicMock()
        trainer._last_loaded_step = -1

        trainer._generate(["prompt"])

        trainer.vllm_generation.sync_weights.assert_called_once()
        assert trainer._last_loaded_step == trainer.state.global_step
        assert rollout_func.calls == [(["prompt"], trainer)]

    @patch.dict(os.environ, {"TRL_EXPERIMENTAL_SILENCE": "1"})
    def test_generate_rollout_func_raises_when_required_keys_are_missing(self):
        trainer = self._make_trainer(self._make_rollout_func(prompt_ids=[[1]], completion_ids=[[2]]))

        with pytest.raises(ValueError, match="rollout_func must return keys"):
            trainer._generate(["prompt"])


@pytest.mark.skipif(
    Version(transformers.__version__) < Version("5.8.0"),
    reason="transformers continuous batching requires transformers>=5.8.0",
)
class TestTransformersContinuousBatchingContract:
    """Contract tests for the transformers CB API that GRPOTrainer depends on."""

    def test_generation_output_has_logprobs_field(self):
        from transformers.generation.continuous_batching.requests import GenerationOutput

        output = GenerationOutput(request_id="req_0")
        assert output.logprobs == [], "GenerationOutput.logprobs must default to an empty list"

    def test_generation_output_logprobs_accepts_floats(self):
        from transformers.generation.continuous_batching.requests import GenerationOutput

        output = GenerationOutput(request_id="req_0", generated_tokens=[1, 2, 3], logprobs=[-0.1, -0.5, -0.3])
        assert output.logprobs == [-0.1, -0.5, -0.3]

    def test_continuous_batching_config_has_return_logprobs(self):
        from transformers.generation import ContinuousBatchingConfig

        cfg = ContinuousBatchingConfig(return_logprobs=True)
        assert cfg.return_logprobs is True

    def test_generate_batch_accepts_continuous_batching_config(self):
        import inspect

        from transformers.generation.continuous_batching.continuous_api import ContinuousMixin

        sig = inspect.signature(ContinuousMixin.generate_batch)
        assert "continuous_batching_config" in sig.parameters, (
            "generate_batch() must accept a continuous_batching_config parameter"
        )


class TestGRPOTrainer(TrlTestCase):
    def test_init_minimal(self):
        # Test that GRPOTrainer can be instantiated with only model, reward function and train_dataset
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")
        GRPOTrainer(
            model="trl-internal-testing/tiny-Qwen2ForCausalLM-2.5",
            reward_funcs=str_length_reward,
            train_dataset=dataset,
        )

    @pytest.mark.parametrize(
        "model_id",
        [
            pytest.param(
                "trl-internal-testing/tiny-Cohere2ForCausalLM",
                id="cohere2",
                marks=pytest.mark.xfail(
                    Version(transformers.__version__) < Version("5.0.0"),
                    raises=ValueError,
                    reason="Before transformers 5.0, its generic tokenizer class returns `token_type_ids`, which "
                    "`generate` rejects for this model",
                    strict=True,
                ),
            ),
            pytest.param(
                "trl-internal-testing/tiny-Glm4MoeForCausalLM",
                id="glm4-moe",
                marks=pytest.mark.skipif(
                    Version(transformers.__version__) < Version("5.0.0"),
                    reason="GLM4 tokenizer requires transformers>=5.0.0",
                ),
            ),
            pytest.param("trl-internal-testing/tiny-GptOssForCausalLM", id="gpt-oss"),
            pytest.param("trl-internal-testing/tiny-GraniteMoeForCausalLM", id="granite-moe"),
            pytest.param("trl-internal-testing/tiny-GraniteMoeHybridForCausalLM", id="granite-moe-hybrid"),
            pytest.param("trl-internal-testing/tiny-PhimoeForCausalLM", id="phimoe"),
            pytest.param("trl-internal-testing/tiny-Qwen2ForCausalLM-2.5", id="qwen2.5"),
            pytest.param("trl-internal-testing/tiny-Qwen3MoeForCausalLM", id="qwen3-moe"),
            pytest.param(
                "trl-internal-testing/tiny-BeamForCausalLM",
                id="beam",
                marks=pytest.mark.skipif(
                    Version(transformers.__version__) < Version("5.20.1"),
                    reason="Beam was introduced in transformers-5.20.1",
                ),
            ),
            pytest.param(
                "trl-internal-testing/tiny-NemotronHForCausalLM-nano",
                id="nemotron3-nano",
                marks=pytest.mark.skipif(
                    Version(transformers.__version__) < Version("5.7.0"),
                    reason="Nemotron 3 gradient checkpointing requires transformers>=5.7.0 (see transformers#45625)",
                ),
            ),
        ],
    )
    def test_train(self, model_id):
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")

        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            num_generations=3,  # reduce the number of generations to reduce memory usage
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            report_to="none",
        )
        trainer = GRPOTrainer(
            model=model_id,
            reward_funcs=str_length_reward,
            args=training_args,
            train_dataset=dataset,
        )

        previous_trainable_params = {n: param.clone() for n, param in trainer.model.named_parameters()}

        trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None

        # MoE models log the load-balancing auxiliary loss (on by default)
        if trainer.aux_loss_enabled:
            assert trainer.state.log_history[-1]["aux_loss"] is not None

        # Check that the params have changed
        for n, param in previous_trainable_params.items():
            new_param = trainer.model.get_parameter(n)
            assert not torch.equal(param, new_param), f"Parameter {n} has not changed."

    def test_saved_model_keeps_its_router_config(self):
        # Regression test for https://github.com/huggingface/trl/issues/8102
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")
        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            num_generations=3,  # reduce the number of generations to reduce memory usage
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            router_aux_loss_coef=0.5,
            max_steps=1,  # running the training loop once is enough
            logging_steps=1,
            report_to="none",
        )
        trainer = GRPOTrainer(
            model="trl-internal-testing/tiny-Qwen3MoeForCausalLM",
            reward_funcs=str_length_reward,
            args=training_args,
            train_dataset=dataset,
        )
        trainer.train()
        trainer.save_model()

        # Trained with another aux loss coef, saved with the router config it was loaded with
        assert "aux_loss" in trainer.state.log_history[0]
        config = AutoConfig.from_pretrained(self.tmp_dir)
        assert config.output_router_logits is False
        assert config.router_aux_loss_coef == 0.001

    @pytest.mark.parametrize("config_name", ["standard_prompt_only", "conversational_prompt_only"])
    def test_train_dataset_format(self, config_name):
        dataset = load_dataset("trl-internal-testing/zen", config_name, split="train")

        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            num_generations=3,  # reduce the number of generations to reduce memory usage
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            report_to="none",
        )
        trainer = GRPOTrainer(
            model="trl-internal-testing/tiny-Qwen2ForCausalLM-2.5",
            reward_funcs=str_length_reward,
            args=training_args,
            train_dataset=dataset,
        )

        previous_trainable_params = {n: param.clone() for n, param in trainer.model.named_parameters()}

        trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None

        # Check that the params have changed
        for n, param in previous_trainable_params.items():
            new_param = trainer.model.get_parameter(n)
            assert not torch.equal(param, new_param), f"Parameter {n} has not changed."

    def test_trust_remote_code(self):
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")
        model_id = "trl-internal-testing/tiny-RemoteForCausalLM"

        with pytest.raises(ValueError, match="custom code"):
            GRPOTrainer(
                model=model_id,
                args=GRPOConfig(output_dir=self.tmp_dir, report_to="none"),
                reward_funcs=str_length_reward,
                train_dataset=dataset,
            )

        trainer = GRPOTrainer(
            model=model_id,
            args=GRPOConfig(output_dir=self.tmp_dir, report_to="none", trust_remote_code=True),
            reward_funcs=str_length_reward,
            train_dataset=dataset,
        )
        assert type(trainer.model).__name__ == "RemoteForCausalLM"

    @pytest.mark.parametrize("loss_type", ["bnpo", "dr_grpo", "dapo", "cispo", "sapo", "luspo", "vespo"])
    def test_train_loss_types(self, loss_type):
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")

        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            importance_sampling_level="sequence" if loss_type == "luspo" else "token",
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            num_generations=3,  # reduce the number of generations to reduce memory usage
            max_completion_length=32,  # reduce the completion length to reduce memory usage
            gradient_accumulation_steps=2,  # set to 2 to test than DAPO can operate with accumulated batch
            loss_type=loss_type,
            report_to="none",
        )
        trainer = GRPOTrainer(
            model="trl-internal-testing/tiny-Qwen2ForCausalLM-2.5",
            reward_funcs=str_length_reward,
            args=training_args,
            train_dataset=dataset,
        )

        previous_trainable_params = {n: param.clone() for n, param in trainer.model.named_parameters()}

        trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None

        # Check that the params have changed
        for n, param in previous_trainable_params.items():
            new_param = trainer.model.get_parameter(n)
            assert not torch.equal(param, new_param), f"Parameter {n} has not changed."

    def test_logps_match_plain_forward(self):
        # The fused LM head scores the completion tokens like a plain forward of the model, at the sampling temperature
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")
        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            bf16=False,  # compare in full precision
            per_device_train_batch_size=2,  # reduce the batch size to reduce memory usage
            num_generations=2,  # reduce the number of generations to reduce memory usage
            temperature=0.7,
            report_to="none",
        )
        trainer = GRPOTrainer(
            model="trl-internal-testing/tiny-Qwen2ForCausalLM-2.5",
            reward_funcs=str_length_reward,
            args=training_args,
            train_dataset=dataset,
        )
        input_ids = torch.randint(0, trainer.model.config.vocab_size, (2, 16), device=trainer.accelerator.device)
        attention_mask = torch.ones_like(input_ids)
        attention_mask[0, :3] = 0  # left padding
        attention_mask[1, -2:] = 0  # padding after the end of the completion

        logps, entropies, _ = trainer._get_per_token_logps_and_entropies(
            trainer.model, input_ids, attention_mask, logits_to_keep=10, compute_entropy=True
        )
        with torch.no_grad():
            logits = trainer.model(input_ids=input_ids, attention_mask=attention_mask).logits[:, -11:-1] / 0.7
        ref_logps = logits.log_softmax(-1)
        completion_mask = attention_mask[:, -10:].bool()

        expected_logps = ref_logps.gather(-1, input_ids[:, -10:, None]).squeeze(-1)
        expected_entropies = -(ref_logps.exp() * ref_logps).sum(-1)
        torch.testing.assert_close(logps[completion_mask], expected_logps[completion_mask], atol=1e-4, rtol=1e-4)
        torch.testing.assert_close(
            entropies[completion_mask], expected_entropies[completion_mask], atol=1e-4, rtol=1e-4
        )
        assert (logps[~completion_mask] == 0).all()

    @pytest.mark.skipif(not is_bf16_supported(), reason="test requires bf16 support")
    def test_logps_use_mixed_precision(self):
        # Scoring runs outside `compute_loss`, so it has to enter autocast itself. Without that the backbone would
        # silently run in fp32 under bf16 training.
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")
        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            bf16=True,
            per_device_train_batch_size=2,  # reduce the batch size to reduce memory usage
            num_generations=2,  # reduce the number of generations to reduce memory usage
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            report_to="none",
        )
        trainer = GRPOTrainer(
            model="trl-internal-testing/tiny-Qwen2ForCausalLM-2.5",
            reward_funcs=str_length_reward,
            args=training_args,
            train_dataset=dataset,
        )
        projection = next(module for name, module in trainer.model.named_modules() if name.endswith("q_proj"))
        projection_dtypes = []

        def record_projection_dtype(_module, _args, output):
            projection_dtypes.append(output.dtype)

        with projection.register_forward_hook(record_projection_dtype):
            trainer.train()

        assert projection_dtypes  # the hook fired at all
        assert set(projection_dtypes) == {torch.bfloat16}

        release_memory(trainer.model, trainer)

    def test_train_with_eval(self):
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only")

        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            per_device_eval_batch_size=3,  # reduce the batch size to reduce memory usage
            num_generations=3,  # reduce the number of generations to reduce memory usage
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            eval_strategy="steps",
            eval_steps=2,
            report_to="none",
        )
        trainer = GRPOTrainer(
            model="trl-internal-testing/tiny-Qwen2ForCausalLM-2.5",
            reward_funcs=str_length_reward,
            args=training_args,
            train_dataset=dataset["train"],
            eval_dataset=dataset["test"],
        )

        trainer.train()

    def test_train_with_num_generations_eval(self):
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only")

        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            per_device_eval_batch_size=3,  # reduce the batch size to reduce memory usage
            num_generations=3,  # reduce the number of generations to reduce memory usage
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            num_generations_eval=1,
            eval_strategy="steps",
            eval_steps=2,
            report_to="none",
        )
        trainer = GRPOTrainer(
            model="trl-internal-testing/tiny-Qwen2ForCausalLM-2.5",
            reward_funcs=str_length_reward,
            args=training_args,
            train_dataset=dataset["train"],
            eval_dataset=dataset["test"],
        )

        trainer.train()

    def test_train_with_iterable_dataset(self):
        # Iterable (streaming) datasets have no length, so `max_steps` is required.
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train", streaming=True)

        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            num_generations=3,  # reduce the number of generations to reduce memory usage
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            max_steps=4,
            report_to="none",
        )
        trainer = GRPOTrainer(
            model="trl-internal-testing/tiny-Qwen2ForCausalLM-2.5",
            reward_funcs=str_length_reward,
            args=training_args,
            train_dataset=dataset,
        )

        # Iterable datasets force `dispatch_batches=False` so the stream can be sharded per process.
        assert trainer.args.accelerator_config.dispatch_batches is False

        previous_trainable_params = {n: param.clone() for n, param in trainer.model.named_parameters()}

        trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None

        # Check that the params have changed
        for n, param in previous_trainable_params.items():
            new_param = trainer.model.get_parameter(n)
            assert not torch.equal(param, new_param), f"Parameter {n} has not changed."

    @pytest.mark.parametrize("train_dataset_type", ["dataset", "iterable_dataset", "none", "unsupported_dataset_dict"])
    def test_init_with_train_dataset(self, train_dataset_type):
        streaming = "iterable" in train_dataset_type
        if train_dataset_type == "none":
            train_dataset = None
        else:
            train_dataset = load_dataset(
                "trl-internal-testing/zen", "conversational_prompt_only", split="train", streaming=streaming
            )
            if train_dataset_type == "unsupported_dataset_dict":
                # `DatasetDict` is representative of any unsupported type here; not exhaustive
                train_dataset = DatasetDict({"train": train_dataset})

        # Iterable (streaming) datasets have no length, so `max_steps` is required.
        training_args = GRPOConfig(output_dir=self.tmp_dir, max_steps=4 if streaming else -1, report_to="none")

        if train_dataset_type == "none":
            with pytest.raises(ValueError, match="`train_dataset` is required"):
                GRPOTrainer(
                    model="trl-internal-testing/tiny-Qwen2ForCausalLM-2.5",
                    reward_funcs=str_length_reward,
                    args=training_args,
                    train_dataset=train_dataset,
                )
        elif train_dataset_type == "unsupported_dataset_dict":
            with pytest.raises(TypeError, match="`train_dataset` must be a `Dataset` or `IterableDataset`"):
                GRPOTrainer(
                    model="trl-internal-testing/tiny-Qwen2ForCausalLM-2.5",
                    reward_funcs=str_length_reward,
                    args=training_args,
                    train_dataset=train_dataset,
                )
        else:
            trainer = GRPOTrainer(
                model="trl-internal-testing/tiny-Qwen2ForCausalLM-2.5",
                reward_funcs=str_length_reward,
                args=training_args,
                train_dataset=train_dataset,
            )
            assert trainer.train_dataset is train_dataset

    @pytest.mark.parametrize(
        "eval_dataset_type",
        [
            "dataset",
            "iterable_dataset",
            "dataset_dict",
            "iterable_dataset_dict",
            "dict_of_dataset",
            "dict_of_iterable_dataset",
            "none",
        ],
    )
    def test_init_with_eval_dataset(self, eval_dataset_type):
        train_dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")

        if eval_dataset_type == "none":
            eval_dataset = None
        else:
            streaming = "iterable" in eval_dataset_type
            eval_split = load_dataset(
                "trl-internal-testing/zen", "conversational_prompt_only", split="test", streaming=streaming
            )
            if eval_dataset_type in ("dataset", "iterable_dataset"):
                eval_dataset = eval_split
            elif eval_dataset_type in ("dataset_dict", "iterable_dataset_dict"):
                dataset_dict_cls = IterableDatasetDict if streaming else DatasetDict
                eval_dataset = dataset_dict_cls({"data1": eval_split, "data2": eval_split})
            else:  # "dict_of_dataset" or "dict_of_iterable_dataset"
                eval_dataset = {"data1": eval_split, "data2": eval_split}

        training_args = GRPOConfig(output_dir=self.tmp_dir, report_to="none")
        trainer = GRPOTrainer(
            model="trl-internal-testing/tiny-Qwen2ForCausalLM-2.5",
            reward_funcs=str_length_reward,
            args=training_args,
            train_dataset=train_dataset,
            eval_dataset=eval_dataset,
        )

        if eval_dataset_type == "none":
            assert trainer.eval_dataset is None
        elif isinstance(trainer.eval_dataset, dict):
            assert set(trainer.eval_dataset.keys()) == {"data1", "data2"}
        else:
            assert trainer.eval_dataset is eval_dataset

    def test_iterable_dataset_requires_dispatch_batches_false(self):
        # `dispatch_batches=True` is incompatible with iterable datasets (see get_train_dataloader).
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train", streaming=True)

        training_args = GRPOConfig(
            output_dir=self.tmp_dir, accelerator_config={"dispatch_batches": True}, report_to="none"
        )
        with pytest.raises(ValueError, match="Iterable datasets require `dispatch_batches=False`"):
            GRPOTrainer(
                model="trl-internal-testing/tiny-Qwen2ForCausalLM-2.5",
                reward_funcs=str_length_reward,
                args=training_args,
                train_dataset=dataset,
            )

    def test_iterable_dataset_forces_num_workers_zero(self):
        # Multiple workers would shard and interleave the repeated stream, splitting num_generations groups, so
        # `dataloader_num_workers` is forced to 0 for iterable datasets.
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train", streaming=True)

        training_args = GRPOConfig(output_dir=self.tmp_dir, dataloader_num_workers=4, max_steps=1, report_to="none")
        trainer = GRPOTrainer(
            model="trl-internal-testing/tiny-Qwen2ForCausalLM-2.5",
            reward_funcs=str_length_reward,
            args=training_args,
            train_dataset=dataset,
        )

        assert trainer.args.dataloader_num_workers == 0

    def test_iterable_eval_keeps_map_style_train_workers(self):
        # A map-style train set keeps its workers even when the eval set is iterable; the single-worker restriction is
        # scoped to the iterable eval loader and not persisted.
        train_dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")
        eval_dataset = load_dataset(
            "trl-internal-testing/zen", "conversational_prompt_only", split="test", streaming=True
        )

        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            per_device_eval_batch_size=3,  # reduce the batch size to reduce memory usage
            num_generations=3,  # reduce the number of generations to reduce memory usage
            dataloader_num_workers=4,
            report_to="none",
        )
        trainer = GRPOTrainer(
            model="trl-internal-testing/tiny-Qwen2ForCausalLM-2.5",
            reward_funcs=str_length_reward,
            args=training_args,
            train_dataset=train_dataset,
            eval_dataset=eval_dataset,
        )

        assert trainer.args.dataloader_num_workers == 4  # not disabled by the iterable eval set
        assert trainer.get_train_dataloader().num_workers == 4  # map-style train keeps its workers
        assert trainer.get_eval_dataloader().num_workers == 0  # iterable eval loader uses a single worker
        assert trainer.args.dataloader_num_workers == 4  # override is scoped, not persisted

    @pytest.mark.parametrize(
        "eval_dataset_type",
        [
            "dataset",
            "iterable_dataset",
            "dataset_dict",
            "iterable_dataset_dict",
            "dict_of_dataset",
            "dict_of_iterable_dataset",
        ],
    )
    def test_evaluate_with_eval_dataset(self, eval_dataset_type):
        # `evaluate` accepts a dataset passed directly, not only an `eval_dataset` set at init. Iterable datasets passed
        # this way must still be configured for the iterable path, since they are absent at init.
        train_dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")

        streaming = "iterable" in eval_dataset_type
        eval_split = load_dataset(
            "trl-internal-testing/zen", "conversational_prompt_only", split="test", streaming=streaming
        )
        if eval_dataset_type in ("dataset", "iterable_dataset"):
            eval_dataset = eval_split
        elif eval_dataset_type in ("dataset_dict", "iterable_dataset_dict"):
            dataset_dict_cls = IterableDatasetDict if streaming else DatasetDict
            eval_dataset = dataset_dict_cls({"data1": eval_split, "data2": eval_split})
        else:  # "dict_of_dataset" or "dict_of_iterable_dataset"
            eval_dataset = {"data1": eval_split, "data2": eval_split}

        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            per_device_eval_batch_size=3,  # reduce the batch size to reduce memory usage
            num_generations=3,  # reduce the number of generations to reduce memory usage
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            report_to="none",
        )
        trainer = GRPOTrainer(
            model="trl-internal-testing/tiny-Qwen2ForCausalLM-2.5",
            reward_funcs=str_length_reward,
            args=training_args,
            train_dataset=train_dataset,
        )

        metrics = trainer.evaluate(eval_dataset=eval_dataset)
        if eval_dataset_type in ("dataset", "iterable_dataset"):
            assert metrics["eval_loss"] is not None
        else:
            assert metrics["eval_data1_loss"] is not None
            assert metrics["eval_data2_loss"] is not None

    # Regression test for eval_on_start with loss_type="grpo" (one of the loss types that depends on
    # current_gradient_accumulation_steps): evaluation runs before the first training step, when that value is still
    # unset. Previously this caused the initial eval to crash.
    def test_train_eval_on_start(self):
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only")
        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            per_device_eval_batch_size=3,  # reduce the batch size to reduce memory usage
            num_generations=3,  # reduce the number of generations to reduce memory usage
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            loss_type="grpo",
            eval_strategy="steps",
            eval_steps=2,
            eval_on_start=True,
            report_to="none",
        )
        trainer = GRPOTrainer(
            model="trl-internal-testing/tiny-Qwen2ForCausalLM-2.5",
            reward_funcs=str_length_reward,
            args=training_args,
            train_dataset=dataset["train"],
            eval_dataset=dataset["test"],
        )
        trainer.train()

    def test_train_multiple_iterations(self):
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")

        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            num_generations=3,  # reduce the number of generations to reduce memory usage
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            num_iterations=2,
            report_to="none",
        )
        trainer = GRPOTrainer(
            model="trl-internal-testing/tiny-Qwen2ForCausalLM-2.5",
            reward_funcs=str_length_reward,
            args=training_args,
            train_dataset=dataset,
        )

        previous_trainable_params = {n: param.clone() for n, param in trainer.model.named_parameters()}

        trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None

        # Check that the params have changed
        for n, param in previous_trainable_params.items():
            new_param = trainer.model.get_parameter(n)
            assert not torch.equal(param, new_param), f"Parameter {n} has not changed."

    @require_peft
    def test_peft_init_is_seeded(self):
        # Two trainers with the same seed start from the same adapter weights
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")
        adapters = []
        for global_seed in range(2):
            torch.manual_seed(global_seed)  # a different global RNG state, as in two separate runs
            trainer = GRPOTrainer(
                model="trl-internal-testing/tiny-Qwen2ForCausalLM-2.5",
                reward_funcs=str_length_reward,
                args=GRPOConfig(output_dir=self.tmp_dir, report_to="none"),
                train_dataset=dataset,
                peft_config=LoraConfig(),
            )
            adapters.append({n: p.clone() for n, p in trainer.model.named_parameters() if "lora_A" in n})

        assert adapters[0]
        for n, param in adapters[0].items():
            assert torch.equal(param, adapters[1][n]), f"Parameter {n} differs between the two trainers."

    @require_peft
    def test_train_peft_config(self):
        model = AutoModelForCausalLM.from_pretrained("trl-internal-testing/tiny-Qwen2ForCausalLM-2.5", dtype="float32")
        base_param_names = [f"base_model.model.{n}" for n, _ in model.named_parameters()]
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")

        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            num_generations=3,  # reduce the number of generations to reduce memory usage
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            report_to="none",
        )
        trainer = GRPOTrainer(
            model=model,
            reward_funcs=str_length_reward,
            args=training_args,
            train_dataset=dataset,
            peft_config=LoraConfig(),
        )

        previous_trainable_params = {n: param.clone() for n, param in trainer.model.named_parameters()}

        trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None

        # Check that the peft params have changed and the base model params have not changed
        for n, param in previous_trainable_params.items():
            new_param = trainer.model.get_parameter(n)
            if n in base_param_names:  # We expect the base model params to be the same
                torch.testing.assert_close(param, new_param, msg=f"Parameter {n} has changed.")
            elif "base_layer" not in n:  # We expect the peft params to be different (except for the base layer)
                assert not torch.equal(param, new_param), f"Parameter {n} has not changed."

    @require_peft
    @require_bitsandbytes
    def test_train_peft_and_quantization(self):
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")

        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            num_generations=3,  # reduce the number of generations to reduce memory usage
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            report_to="none",
        )
        quantization_config = BitsAndBytesConfig(
            load_in_4bit=True,
            bnb_4bit_use_double_quant=True,
            bnb_4bit_quant_type="nf4",
            bnb_4bit_compute_dtype=torch.bfloat16,
        )
        trainer = GRPOTrainer(
            model="trl-internal-testing/tiny-Qwen2ForCausalLM-2.5",  # identifier, so that the trainer quantizes it
            reward_funcs=str_length_reward,
            args=training_args,
            train_dataset=dataset,
            quantization_config=quantization_config,
            peft_config=LoraConfig(),
        )

        # Check that the trainer applied the quantization config when loading the model
        assert trainer.model.base_model.model.is_loaded_in_4bit

        previous_trainable_params = {n: param.clone() for n, param in trainer.model.named_parameters()}

        trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None

        # Check that the peft params have changed, and that they are cast to bfloat16, as recommended by the QLoRA
        # paper. The base model params are not checked: bitsandbytes casts the biases of a Linear4bit in-place during
        # the forward pass, so some of them change in a way that is unrelated to training.
        for n, param in previous_trainable_params.items():
            new_param = trainer.model.get_parameter(n)
            if "lora" in n:  # We expect the peft params to be different
                assert param.dtype == torch.bfloat16, f"Parameter {n} is not in bfloat16."
                assert not torch.equal(param, new_param), f"Parameter {n} has not changed."

    @require_peft
    @require_bitsandbytes
    def test_train_peft_dora_and_quantization(self):
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")

        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            num_generations=3,  # reduce the number of generations to reduce memory usage
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            report_to="none",
        )
        quantization_config = BitsAndBytesConfig(
            load_in_4bit=True,
            bnb_4bit_use_double_quant=True,
            bnb_4bit_quant_type="nf4",
            bnb_4bit_compute_dtype=torch.bfloat16,
        )
        trainer = GRPOTrainer(
            model="trl-internal-testing/tiny-Qwen2ForCausalLM-2.5",  # identifier, so that the trainer quantizes it
            reward_funcs=str_length_reward,
            args=training_args,
            train_dataset=dataset,
            quantization_config=quantization_config,
            peft_config=LoraConfig(use_dora=True),
        )

        # Check that the trainer applied the quantization config when loading the model
        assert trainer.model.base_model.model.is_loaded_in_4bit

        previous_trainable_params = {n: param.clone() for n, param in trainer.model.named_parameters()}

        trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None

        # Check that the peft params have changed, and that they are cast to bfloat16, as recommended by the QLoRA
        # paper. The base model params are not checked: bitsandbytes casts the biases of a Linear4bit in-place during
        # the forward pass, so some of them change in a way that is unrelated to training.
        for n, param in previous_trainable_params.items():
            new_param = trainer.model.get_parameter(n)
            # The DoRA magnitude vector is the exception: it must stay in float32, since its optimizer updates can be
            # smaller than bfloat16 can represent, which would otherwise silently freeze it, see #7268
            if "lora_magnitude_vector" in n:
                assert param.dtype == torch.float32, f"Parameter {n} is not in float32."
                assert not torch.equal(param, new_param), f"Parameter {n} has not changed."
            elif "lora" in n:  # We expect the peft params to be different
                assert param.dtype == torch.bfloat16, f"Parameter {n} is not in bfloat16."
                assert not torch.equal(param, new_param), f"Parameter {n} has not changed."

    @require_peft
    def test_peft_lm_head_raises(self):
        # The chunked projection reads `lm_head.weight` directly, so a LoRA adapter on `lm_head` is silently
        # ignored and never trained. The trainer must fail fast instead of training a silently-frozen head (#4612).
        model = AutoModelForCausalLM.from_pretrained("trl-internal-testing/tiny-Qwen2ForCausalLM-2.5", dtype="float32")
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")
        training_args = GRPOConfig(output_dir=self.tmp_dir, report_to="none")
        # `ensure_weight_tying=True` silences PEFT's weight-tying warning fired when lm_head is in the adapter on a
        # model with untied embeddings; once tying respects `tie_word_embeddings`, the flag itself warns that no tied
        # modules were found, so it must only be set on the affected range.
        # - Introduced in PEFT 0.19.0 (peft#2879); fixed in PEFT 0.20.0 (peft#3171)
        needs_ensure_weight_tying = Version("0.19.0") <= Version(peft.__version__) < Version("0.20.0")
        lora_config = LoraConfig(
            target_modules=["q_proj", "v_proj", "lm_head"],
            **({"ensure_weight_tying": True} if needs_ensure_weight_tying else {}),
        )
        with pytest.raises(ValueError, match="lm_head"):
            GRPOTrainer(
                model=model,
                reward_funcs=str_length_reward,
                args=training_args,
                train_dataset=dataset,
                peft_config=lora_config,
            )

    @require_peft
    def test_peft_modules_to_save_lm_head_allowed(self):
        # `modules_to_save=["lm_head"]` makes the head a fully trained copy (ModulesToSaveWrapper, not a tuner layer),
        # so `lm_head.weight` resolves to the trained weight and the chunked projection trains it correctly. This is the documented
        # workaround in the guard's error message, so it must stay unblocked.
        model = AutoModelForCausalLM.from_pretrained("trl-internal-testing/tiny-Qwen2ForCausalLM-2.5", dtype="float32")
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")
        training_args = GRPOConfig(output_dir=self.tmp_dir, report_to="none")
        # `ensure_weight_tying=True` silences PEFT's weight-tying warning fired when lm_head is in the adapter on a
        # model with untied embeddings; once tying respects `tie_word_embeddings`, the flag itself warns that no tied
        # modules were found, so it must only be set on the affected range.
        # - Introduced in PEFT 0.19.0 (peft#2879); fixed in PEFT 0.20.0 (peft#3171)
        needs_ensure_weight_tying = Version("0.19.0") <= Version(peft.__version__) < Version("0.20.0")
        peft_config = LoraConfig(
            target_modules=["q_proj", "v_proj"],
            modules_to_save=["lm_head"],
            **({"ensure_weight_tying": True} if needs_ensure_weight_tying else {}),
        )
        # Must construct without raising
        GRPOTrainer(
            model=model,
            reward_funcs=str_length_reward,
            args=training_args,
            train_dataset=dataset,
            peft_config=peft_config,
        )

    @require_peft
    def test_train_peft_prompt_tuning(self):
        model = AutoModelForCausalLM.from_pretrained("trl-internal-testing/tiny-Qwen2ForCausalLM-2.5", dtype="float32")
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")
        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            num_generations=3,  # reduce the number of generations to reduce memory usage
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            report_to="none",
        )
        trainer = GRPOTrainer(
            model=model,
            reward_funcs=str_length_reward,
            args=training_args,
            train_dataset=dataset,
            peft_config=PromptTuningConfig(task_type=TaskType.CAUSAL_LM, num_virtual_tokens=8),
        )
        previous_trainable_params = {n: param.clone() for n, param in trainer.model.named_parameters()}

        trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None

        # Check that the prompt embeddings have changed
        for n, param in previous_trainable_params.items():
            new_param = trainer.model.get_parameter(n)
            if "prompt_encoder" in n:
                assert not torch.equal(param, new_param), f"Parameter {n} has not changed."

    @require_peft
    def test_train_peft_model(self):
        model = AutoModelForCausalLM.from_pretrained("trl-internal-testing/tiny-Qwen2ForCausalLM-2.5", dtype="float32")
        base_param_names = [f"base_model.model.{n}" for n, _ in model.named_parameters()]
        lora_config = LoraConfig()
        model = get_peft_model(model, lora_config)
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")

        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            num_generations=3,  # reduce the number of generations to reduce memory usage
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            report_to="none",
        )
        trainer = GRPOTrainer(
            model=model,
            reward_funcs=str_length_reward,
            args=training_args,
            train_dataset=dataset,
        )

        previous_trainable_params = {n: param.clone() for n, param in trainer.model.named_parameters()}

        trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None

        # Check that the peft params have changed and the base model params have not changed
        for n, param in previous_trainable_params.items():
            new_param = trainer.model.get_parameter(n)
            if n in base_param_names:  # We expect the base model params to be the same
                torch.testing.assert_close(param, new_param, msg=f"Parameter {n} has changed.")
            elif "base_layer" not in n and "ref" not in n:  # and the peft params to be different (except base and ref)
                assert not torch.equal(param, new_param), f"Parameter {n} has not changed."

    def test_ref_model_like_model_instance(self):
        # A policy passed as an instance has no `model_init_kwargs`: the reference is built with its dtype and attention
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")
        model = AutoModelForCausalLM.from_pretrained(
            "trl-internal-testing/tiny-Qwen2ForCausalLM-2.5", dtype=torch.bfloat16, attn_implementation="eager"
        )
        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            beta=0.1,  # set beta to a non-zero value so that the trainer needs a reference model
            report_to="none",
        )
        trainer = GRPOTrainer(
            model=model,
            reward_funcs=str_length_reward,
            args=training_args,
            train_dataset=dataset,
        )

        assert trainer.ref_model.dtype == torch.bfloat16
        assert trainer.ref_model.config._attn_implementation == "eager"

    @pytest.mark.skipif(
        Version(transformers.__version__) < Version("5.0.0"),
        reason="Qwen3-MoE experts are fused parameters since transformers-5.0.0",
    )
    @require_peft
    def test_train_moe_peft_model(self):
        # Regression test for https://github.com/huggingface/trl/issues/5222. Before PEFT 0.20.0, only one adapter per
        # model was supported when the LoRA config uses `target_parameters` (see peft#3340, fixed in peft#3350), so no
        # "ref" adapter could be created and the reference log probs were computed with adapters disabled instead.
        model = AutoModelForCausalLM.from_pretrained("trl-internal-testing/tiny-Qwen3MoeForCausalLM", dtype="float32")
        base_param_names = [f"base_model.model.{n}" for n, _ in model.named_parameters()]
        lora_config = LoraConfig(target_parameters=["mlp.experts.down_proj", "mlp.experts.gate_up_proj"])
        model = get_peft_model(model, lora_config)
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")

        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            num_generations=3,  # reduce the number of generations to reduce memory usage
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            beta=0.1,  # set beta to a non-zero value so that the trainer needs a reference model
            report_to="none",
        )
        trainer = GRPOTrainer(
            model=model,
            reward_funcs=str_length_reward,
            args=training_args,
            train_dataset=dataset,
        )

        if Version(peft.__version__) < Version("0.20.0"):
            assert "ref" not in trainer.model.peft_config
        else:
            assert "ref" in trainer.model.peft_config

        previous_trainable_params = {n: param.clone() for n, param in trainer.model.named_parameters()}

        trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None

        # Check that the peft params have changed and the base model params have not changed
        for n, param in previous_trainable_params.items():
            new_param = trainer.model.get_parameter(n)
            if n in base_param_names:  # We expect the base model params to be the same
                torch.testing.assert_close(param, new_param, msg=f"Parameter {n} has changed.")
            elif "base_layer" not in n and "ref" not in n:  # and the peft params to be different (except base and ref)
                assert not torch.equal(param, new_param), f"Parameter {n} has not changed."

    # In practice, this test is the same as `test_train_peft_config`, since gradient checkpointing is enabled by
    # default in `GRPOTrainer`. We keep it as a regression guard: the assert fails if the default ever changes.
    @require_peft
    def test_train_peft_with_gradient_checkpointing(self):
        model = AutoModelForCausalLM.from_pretrained("trl-internal-testing/tiny-Qwen2ForCausalLM-2.5", dtype="float32")
        base_param_names = [f"base_model.model.{n}" for n, _ in model.named_parameters()]
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")

        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            num_generations=3,  # reduce the number of generations to reduce memory usage
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            report_to="none",
        )
        assert training_args.gradient_checkpointing
        trainer = GRPOTrainer(
            model=model,
            reward_funcs=str_length_reward,
            args=training_args,
            train_dataset=dataset,
            peft_config=LoraConfig(),
        )

        previous_trainable_params = {n: param.clone() for n, param in trainer.model.named_parameters()}

        trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None

        # Check that the peft params have changed and the base model params have not changed
        for n, param in previous_trainable_params.items():
            new_param = trainer.model.get_parameter(n)
            if n in base_param_names:  # We expect the base model params to be the same
                torch.testing.assert_close(param, new_param, msg=f"Parameter {n} has changed.")
            elif "base_layer" not in n:  # We expect the peft params to be different (except for the base layer)
                assert not torch.equal(param, new_param), f"Parameter {n} has not changed."

    @require_torch_accelerator
    def test_train_with_fp16(self):
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")

        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            num_generations=3,  # reduce the number of generations to reduce memory usage
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            fp16=True,
            report_to="none",
        )
        trainer = GRPOTrainer(
            model="trl-internal-testing/tiny-Qwen2ForCausalLM-2.5",
            reward_funcs=str_length_reward,
            args=training_args,
            train_dataset=dataset,
        )

        previous_trainable_params = {n: param.clone() for n, param in trainer.model.named_parameters()}

        trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None

        # Check that the params have changed
        for n, param in previous_trainable_params.items():
            new_param = trainer.model.get_parameter(n)
            assert not torch.equal(param, new_param), f"Parameter {n} has not changed."

    @pytest.mark.parametrize("config_name", ["standard_prompt_only", "conversational_prompt_only"])
    def test_train_with_reward_model(self, config_name):
        dataset = load_dataset("trl-internal-testing/zen", config_name, split="train")
        reward_model_id = "trl-internal-testing/tiny-LlamaForSequenceClassification-3.2"
        reward_model = AutoModelForSequenceClassification.from_pretrained(reward_model_id)
        reward_tokenizer = AutoTokenizer.from_pretrained(reward_model_id)
        # By default, the trainer uses the eos token as the padding token. However, for Llama models, the eos token
        # appears in the chat template. Using it as a pad token disrupts the reward calculation, as the calculation
        # considers the score of the last token before the first pad token. To ensure correct reward calculations,
        # we use a separate pad token instead.
        reward_tokenizer.pad_token = "<|finetune_right_pad_id|>"

        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            num_generations=3,  # reduce the number of generations to reduce memory usage
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            report_to="none",
        )
        trainer = GRPOTrainer(
            model="trl-internal-testing/tiny-Qwen2ForCausalLM-2.5",
            reward_funcs=reward_model,
            args=training_args,
            train_dataset=dataset,
            reward_processing_classes=reward_tokenizer,
        )

        previous_trainable_params = {n: param.clone() for n, param in trainer.model.named_parameters()}

        trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None

        # Check that the params have changed
        for n, param in previous_trainable_params.items():
            new_param = trainer.model.get_parameter(n)
            assert not torch.equal(param, new_param), f"Parameter {n} has not changed."

    def test_train_multiple_reward_funcs(self):
        # Test that GRPOTrainer can be instantiated with multiple reward functions
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")

        def reward_func1(completions, **kwargs):
            """Reward function that rewards longer completions."""
            return [float(len(completion[0]["content"])) for completion in completions]

        def reward_func2(completions, **kwargs):
            """Reward function that rewards completions with more unique letters."""
            return [float(len(set(completion[0]["content"]))) for completion in completions]

        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            num_generations=3,  # reduce the number of generations to reduce memory usage
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            report_to="none",
        )
        trainer = GRPOTrainer(
            model="trl-internal-testing/tiny-Qwen2ForCausalLM-2.5",
            reward_funcs=[reward_func1, reward_func2],
            args=training_args,
            train_dataset=dataset,
        )

        previous_trainable_params = {n: param.clone() for n, param in trainer.model.named_parameters()}

        trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None

        # Check that the params have changed
        for n, param in previous_trainable_params.items():
            new_param = trainer.model.get_parameter(n)
            assert not torch.equal(param, new_param), f"Parameter {n} has not changed."

    def test_train_sync_and_async_reward_funcs(self):
        # Test that GRPOTrainer can be instantiated with multiple reward functions, one of which is async, in both the
        # function and the callable class form.
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")

        def sync_reward_func1(completions, **kwargs):
            """Reward function that rewards longer completions."""
            return [float(len(completion[0]["content"])) for completion in completions]

        def sync_reward_func2(completions, **kwargs):
            return [1 for _ in completions]

        async def async_reward_func(completions, **kwargs):
            """Async Reward function that rewards completions with more unique letters."""
            return [float(len(set(completion[0]["content"]))) for completion in completions]

        class AsyncCallableReward:
            """Async reward function written as a callable class."""

            async def __call__(self, completions, **kwargs):
                return [float(completion[0]["content"].count(" ")) for completion in completions]

        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            num_generations=3,  # reduce the number of generations to reduce memory usage
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            report_to="none",
        )
        trainer = GRPOTrainer(
            model="trl-internal-testing/tiny-Qwen2ForCausalLM-2.5",
            reward_funcs=[sync_reward_func1, sync_reward_func2, async_reward_func, AsyncCallableReward()],
            args=training_args,
            train_dataset=dataset,
        )

        previous_trainable_params = {n: param.clone() for n, param in trainer.model.named_parameters()}

        trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None

        # Check that the params have changed
        for n, param in previous_trainable_params.items():
            new_param = trainer.model.get_parameter(n)
            assert not torch.equal(param, new_param), f"Parameter {n} has not changed."

    def test_train_multiple_reward_funcs_with_None_output(self):
        """Test that a valid math reward function is processed correctly while the code reward function returns None."""
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")

        def applicable_reward_func(completions, **kwargs):
            """A reward function that rewards longer completions."""
            return [float(len(completion[0]["content"])) for completion in completions]

        def non_applicable_reward_func(completions, **kwargs):
            """A reward function that returns None for all inputs, as it is not applicable to this sample."""
            return [None] * len(completions)

        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            num_generations=3,  # reduce the number of generations to reduce memory usage
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            report_to="none",
        )

        trainer = GRPOTrainer(
            model="trl-internal-testing/tiny-Qwen2ForCausalLM-2.5",
            reward_funcs=[
                applicable_reward_func,
                non_applicable_reward_func,
            ],  # One applicable, one non applicable
            args=training_args,
            train_dataset=dataset,
        )

        previous_trainable_params = {
            n: param.clone() for n, param in trainer.model.named_parameters() if param.requires_grad
        }

        trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None

        # Check that the params have changed
        for n, param in previous_trainable_params.items():
            new_param = trainer.model.get_parameter(n)
            assert not torch.equal(param, new_param), f"Parameter {n} has not changed."

    def test_train_multiple_reward_funcs_with_weights(self):
        """Test that GRPOTrainer can handle multiple reward functions with weights."""
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")

        def reward_func1(completions, **kwargs):
            """Reward function that rewards longer completions."""
            return [float(len(completion[0]["content"])) for completion in completions]

        def reward_func2(completions, **kwargs):
            """Reward function that rewards completions with more unique letters."""
            return [float(len(set(completion[0]["content"]))) for completion in completions]

        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            num_generations=3,  # reduce the number of generations to reduce memory usage
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            report_to="none",
            reward_weights=[0.7, 0.3],  # weight of reward_func1 and reward_func2 respectively
        )
        trainer = GRPOTrainer(
            model="trl-internal-testing/tiny-Qwen2ForCausalLM-2.5",
            reward_funcs=[reward_func1, reward_func2],
            args=training_args,
            train_dataset=dataset,
        )

        previous_trainable_params = {n: param.clone() for n, param in trainer.model.named_parameters()}

        trainer.train()

        # Check that training logs contain both reward metrics
        assert trainer.state.log_history[-1]["train_loss"] is not None
        assert "rewards/reward_func1/mean" in trainer.state.log_history[-1]
        assert "rewards/reward_func1/std" in trainer.state.log_history[-1]
        assert "rewards/reward_func2/mean" in trainer.state.log_history[-1]
        assert "rewards/reward_func2/std" in trainer.state.log_history[-1]

        # Check that the params have changed
        for n, param in previous_trainable_params.items():
            new_param = trainer.model.get_parameter(n)
            assert not torch.equal(param, new_param), f"Parameter {n} has not changed."

    @pytest.mark.parametrize("multi_objective_aggregation", ["sum_then_normalize", "normalize_then_sum"])
    def test_reward_metric_reflects_reward_weights(self, multi_objective_aggregation):
        """Test that the logged 'reward' metric uses reward_weights, not an unweighted sum."""
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")

        def constant_reward_1(completions, **kwargs):
            return [1.0] * len(completions)

        def constant_reward_0(completions, **kwargs):
            return [0.0] * len(completions)

        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            num_generations=3,  # reduce the number of generations to reduce memory usage
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            report_to="none",
            reward_weights=[0.7, 0.3],
            multi_objective_aggregation=multi_objective_aggregation,
        )
        trainer = GRPOTrainer(
            model="trl-internal-testing/tiny-Qwen2ForCausalLM-2.5",
            reward_funcs=[constant_reward_1, constant_reward_0],
            args=training_args,
            train_dataset=dataset,
        )

        trainer.train()

        log = trainer.state.log_history[-1]
        # With reward_weights=[0.7, 0.3] and rewards [1.0, 0.0]:
        # weighted reward = 0.7*1.0 + 0.3*0.0 = 0.7
        # unweighted reward = 1.0 + 0.0 = 1.0
        assert abs(log["reward"] - 0.7) < 1e-5, (
            f"Expected logged reward to be ~0.7 (weighted), got {log['reward']}. "
            "The reward metric should reflect reward_weights."
        )

    def test_train_multiple_mixed_reward_funcs(self):
        # Test if the trainer can handle a mix of reward functions and reward models
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")

        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            num_generations=3,  # reduce the number of generations to reduce memory usage
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            report_to="none",
        )
        trainer = GRPOTrainer(
            model="trl-internal-testing/tiny-Qwen2ForCausalLM-2.5",
            reward_funcs=[str_length_reward, "trl-internal-testing/tiny-Qwen2ForSequenceClassification-2.5"],
            args=training_args,
            train_dataset=dataset,
        )

        previous_trainable_params = {n: param.clone() for n, param in trainer.model.named_parameters()}

        trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None

        # Check that the params have changed
        for n, param in previous_trainable_params.items():
            new_param = trainer.model.get_parameter(n)
            assert not torch.equal(param, new_param), f"Parameter {n} has not changed."

    def test_train_reward_func_additional_column(self):
        # Test if trainer can handle reward function that rely on additional columns in the dataset
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")

        # Add a column to the dataset (dummy example, the column could be anything)
        some_values = list(range(len(dataset)))
        dataset = dataset.add_column("some_values", some_values)

        def reward_func(completions, some_values, **kwargs):
            """Reward function that rewards completions with lengths closer to the values in some_values."""
            return [
                float(abs(len(completion[0]["content"]) - value))
                for completion, value in zip(completions, some_values, strict=True)
            ]

        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            num_generations=3,  # reduce the number of generations to reduce memory usage
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            report_to="none",
        )
        trainer = GRPOTrainer(
            model="trl-internal-testing/tiny-Qwen2ForCausalLM-2.5",
            reward_funcs=reward_func,
            args=training_args,
            train_dataset=dataset,
        )

        previous_trainable_params = {n: param.clone() for n, param in trainer.model.named_parameters()}

        trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None

        # Check that the params have changed
        for n, param in previous_trainable_params.items():
            new_param = trainer.model.get_parameter(n)
            assert not torch.equal(param, new_param), f"Parameter {n} has not changed."

    def test_train_with_sync_ref_model(self):
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")

        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            beta=0.1,  # ensure ref model is created so sync can update it
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            num_generations=3,  # reduce the number of generations to reduce memory usage
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            sync_ref_model=True,
            ref_model_sync_steps=2,  # reduce sync steps to ensure a sync happens
            report_to="none",
        )
        trainer = GRPOTrainer(
            model="trl-internal-testing/tiny-Qwen2ForCausalLM-2.5",
            reward_funcs=str_length_reward,
            args=training_args,
            train_dataset=dataset,
        )

        previous_trainable_params = {n: param.clone() for n, param in trainer.model.named_parameters()}
        assert trainer.ref_model is not None
        previous_ref_params = {n: param.clone() for n, param in trainer.ref_model.named_parameters()}

        trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None

        # Check that the params have changed
        for n, param in previous_trainable_params.items():
            new_param = trainer.model.get_parameter(n)
            assert not torch.equal(param, new_param), f"Parameter {n} has not changed."
            new_ref_param = trainer.ref_model.get_parameter(n)
            assert not torch.equal(previous_ref_params[n], new_ref_param), f"Ref Parameter {n} has not changed."

    def test_train_beta_non_zero(self):
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")
        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            beta=0.1,  # set beta to non-zero value to test the case where the reference model is used
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            num_generations=3,  # reduce the number of generations to reduce memory usage
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            report_to="none",
        )
        trainer = GRPOTrainer(
            model="trl-internal-testing/tiny-Qwen2ForCausalLM-2.5",
            reward_funcs=str_length_reward,
            args=training_args,
            train_dataset=dataset,
        )

        previous_trainable_params = {n: param.clone() for n, param in trainer.model.named_parameters()}

        trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None

        # Check that the params have changed
        for n, param in previous_trainable_params.items():
            new_param = trainer.model.get_parameter(n)
            assert not torch.equal(param, new_param), f"Parameter {n} has not changed."

    def test_train_with_pad_to_multiple_of(self):
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")

        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            num_generations=3,  # reduce the number of generations to reduce memory usage
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            pad_to_multiple_of=8,
            report_to="none",
        )
        trainer = GRPOTrainer(
            model="trl-internal-testing/tiny-Qwen2ForCausalLM-2.5",
            reward_funcs=str_length_reward,
            args=training_args,
            train_dataset=dataset,
        )

        previous_trainable_params = {n: param.clone() for n, param in trainer.model.named_parameters()}

        trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None

        # Check that the params have changed
        for n, param in previous_trainable_params.items():
            new_param = trainer.model.get_parameter(n)
            assert not torch.equal(param, new_param), f"Parameter {n} has not changed."

    def test_get_off_policy_mask(self):
        """
        Test the logic of off-policy masking:
        - Keep if Advantage >= 0
        - Keep if KL <= threshold
        - Drop if Advantage < 0 AND KL > threshold
        """
        mask = torch.ones((3, 4))  # B=3 sequences, T=4 tokens

        advantages = torch.tensor([1.0, -1.0, -1.0]).unsqueeze(-1)
        sampling_per_token_logps = torch.zeros((3, 4))
        per_token_logps = torch.zeros((3, 4))

        per_token_logps[0, :] = -2.0  # Pos adv + High KL (0−(−2)=2) -> Keep
        per_token_logps[1, :] = -0.5  # Neg adv + Low KL (0.5) -> Keep
        per_token_logps[2, :] = -2.0  # Neg adv + High KL (2.0) -> Drop

        off_policy_threshold = 1.0

        expected_mask = torch.tensor([[1.0], [1.0], [0.0]])

        off_policy_mask = GRPOTrainer.get_off_policy_mask(
            advantages, per_token_logps, sampling_per_token_logps, mask, off_policy_threshold
        )

        torch.testing.assert_close(off_policy_mask, expected_mask)

    def test_get_off_policy_mask_padding(self):
        """Test that padding is correctly ignored in KL calculation."""
        mask = torch.tensor([[1.0, 1.0, 0.0, 0.0]])  # 2 valid tokens
        advantages = torch.tensor([[-1.0]])  # Negative advantage

        sampling_per_token_logps = torch.zeros((1, 4))
        per_token_logps = torch.zeros((1, 4))

        # Valid tokens have High KL (2.0)
        per_token_logps[0, 0] = -2.0
        per_token_logps[0, 1] = -2.0

        # Padding tokens have abnormal values (should be ignored)
        per_token_logps[0, 2] = -10_000.0
        per_token_logps[0, 3] = 10_000.0

        off_policy_threshold = 1.0

        # Avg KL on valid tokens = (2+2)/2 = 2.0 > 1.0 -> Drop
        expected_mask = torch.tensor([[0.0]])

        off_policy_mask = GRPOTrainer.get_off_policy_mask(
            advantages, per_token_logps, sampling_per_token_logps, mask, off_policy_threshold
        )

        torch.testing.assert_close(off_policy_mask, expected_mask)

        # Now test with Low KL on valid tokens
        per_token_logps[0, 0] = -0.5
        per_token_logps[0, 1] = -0.5
        # Avg KL = 0.5 <= 1.0 -> Keep
        expected_mask_keep = torch.tensor([[1.0]])

        off_policy_mask_keep = GRPOTrainer.get_off_policy_mask(
            advantages, per_token_logps, sampling_per_token_logps, mask, off_policy_threshold
        )

        torch.testing.assert_close(off_policy_mask_keep, expected_mask_keep)

    def test_get_gamma_weights_ignores_masked_tokens(self):
        # Regression test for #7952: a token outside the mask must not contribute to the sequence weight, even when
        # its importance sampling ratio is 0 (as set by `vllm_importance_sampling_mode="token_mask"`).
        advantages = torch.tensor([[1.0], [-1.0]])
        log_ratio_per_token = torch.zeros((2, 4))
        importance_sampling_ratio = torch.ones((2, 4))
        importance_sampling_ratio[:, 2] = 0.0
        mask = torch.ones((2, 4))
        mask[:, 2] = 0.0

        phi_seq = GRPOTrainer.get_gamma_weights(advantages, log_ratio_per_token, mask, importance_sampling_ratio)

        # Every remaining token is on-policy with ratio 1, so w = 1 and φ(1) = 1
        torch.testing.assert_close(phi_seq, torch.ones((2, 1)))

    @pytest.mark.parametrize(
        "vllm_importance_sampling_mode", ["token_truncate", "token_mask", "sequence_truncate", "sequence_mask"]
    )
    def test_sampling_logps_none_yields_neutral_importance_ratio(self, vllm_importance_sampling_mode):
        # Regression test for #6166: when vLLM cannot score a token it returns a NaN logprob, which
        # `extract_logprobs` replaces with `None`. That `None` reaches `torch.tensor(logps)` in
        # `_generate_and_score_completions` and raises "Could not infer dtype of NoneType". The fix builds the
        # tensor with those positions as NaN, then zeroes them out of the importance-sampling difference so the
        # ratio is exactly 1 (no correction) for that token while every other token is untouched.
        #
        # This drives the real trainer instead of re-deriving the arithmetic, so removing either half of the fix
        # fails the test. vLLM itself is not needed: the weight sync lives inside `_generate`, so replacing that
        # method bypasses vLLM while still exercising both fix sites. All four importance-sampling modes are
        # covered, because the sequence-level ones sum the per-token difference and a NaN there would poison the
        # whole sequence and evade the clipping guard as well (comparisons against NaN are False).
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")

        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            per_device_train_batch_size=3,
            num_generations=3,
            max_completion_length=8,
            max_steps=1,
            report_to="none",
            # Exercise the off-policy mask as well, which is the third consumer of the sampling logprobs. The
            # threshold is large enough that every sequence is under it, so with the fix in place nothing is
            # dropped; a NaN sequence KL would compare false and drop the negative-advantage ones instead.
            off_policy_mask_threshold=1e9,
        )

        def varied_reward(completions, **kwargs):
            # Distinct rewards guarantee a non-degenerate group, so some advantages are negative. Without that,
            # every sequence would be kept on `advantages >= 0` alone and the off-policy mask would prove nothing.
            return [float(i) for i in range(len(completions))]

        trainer = GRPOTrainer(
            model="trl-internal-testing/tiny-Qwen2ForCausalLM-2.5",
            reward_funcs=varied_reward,
            args=training_args,
            train_dataset=dataset,
        )

        # Enable the correction after construction so that no vLLM server is required.
        trainer.use_vllm = True
        trainer.vllm_importance_sampling_correction = True
        trainer.vllm_importance_sampling_mode = vllm_importance_sampling_mode

        # Wrap the real `_generate` and inject an unscorable token into its own output, so the shapes come from the
        # trainer rather than being fixed here.
        original_generate = trainer._generate

        def generate_with_one_unscorable_token(prompts):
            # Generation itself must take the ordinary path, so drop the flag for the duration of the call and
            # restore it afterwards for the loss, which is where the correction is applied.
            trainer.use_vllm = False
            try:
                outputs = list(original_generate(prompts))
            finally:
                trainer.use_vllm = True
            completion_ids = outputs[1]
            outputs[4] = [[-0.5] * len(ids) for ids in completion_ids]
            for logps in outputs[4]:
                if logps:
                    logps[0] = None  # vLLM returned no logprob for this token
            return tuple(outputs)

        trainer._generate = generate_with_one_unscorable_token

        # Snapshot the divergence metric as soon as it is produced. Reading `_metrics` after training is useless,
        # because the dict is cleared on every log.
        original_score = trainer._generate_and_score_completions
        recorded_metrics = []

        def record_metrics(inputs):
            outputs = original_score(inputs)
            for key in ["sampling/sampling_logp_difference/mean", "sampling/sampling_logp_difference/max"]:
                recorded_metrics.extend((key, value) for value in trainer._metrics["train"][key])
            return outputs

        trainer._generate_and_score_completions = record_metrics

        # Capture the off-policy mask, the third consumer of the sampling logprobs.
        original_off_policy_mask = trainer.get_off_policy_mask
        off_policy_masks = []

        def record_off_policy_mask(*args, **kwargs):
            off_policy_mask = original_off_policy_mask(*args, **kwargs)
            off_policy_masks.append(off_policy_mask)
            return off_policy_mask

        trainer.get_off_policy_mask = record_off_policy_mask

        # Assert on every loss the trainer actually returns. The aggregate reported in `log_history` is not a
        # reliable witness here, since it can stay finite while an individual step's loss carries NaN.
        original_compute_loss = trainer._compute_loss
        losses = []

        def record_loss(model, inputs):
            loss = original_compute_loss(model, inputs)
            losses.append(loss)
            return loss

        trainer._compute_loss = record_loss

        trainer.train()

        assert losses, "the training step never computed a loss, so nothing was verified"
        for loss in losses:
            assert torch.isfinite(loss).all(), (
                f"NaN or inf reached the loss in {vllm_importance_sampling_mode} mode: an unscorable token must "
                f"contribute a neutral importance ratio instead of poisoning the update"
            )

        # The raw sampling logprobs feed another consumer: the logged divergence. It must stay a real number
        # rather than NaN.
        assert recorded_metrics, "the divergence metric was never recorded, so nothing was verified"
        for key, value in recorded_metrics:
            assert torch.isfinite(torch.tensor(value)), f"{key} became NaN because of an unscorable token"

        # And a third: the off-policy mask. The threshold above is far larger than any real sequence KL, so every
        # sequence must be kept. A NaN sequence KL compares false against it, which would silently drop exactly the
        # negative-advantage sequences.
        assert off_policy_masks, "the off-policy mask was never computed, so nothing was verified"
        for off_policy_mask in off_policy_masks:
            assert off_policy_mask.all(), (
                "an unscorable token caused sequences to be dropped by the off-policy mask, even though the "
                "threshold is high enough to keep every sequence"
            )

    def test_train_with_off_policy_mask(self):
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")

        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            off_policy_mask_threshold=0.5,
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            num_generations=3,  # reduce the number of generations to reduce memory usage
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            report_to="none",
        )

        trainer = GRPOTrainer(
            model="trl-internal-testing/tiny-Qwen2ForCausalLM-2.5",
            reward_funcs=str_length_reward,
            args=training_args,
            train_dataset=dataset,
        )

        previous_trainable_params = {n: param.clone() for n, param in trainer.model.named_parameters()}

        trainer.train()

        # Check that the params have changed
        for n, param in previous_trainable_params.items():
            new_param = trainer.model.get_parameter(n)
            assert not torch.equal(param, new_param), f"Parameter {n} has not changed."

    @pytest.mark.parametrize("use_bias_correction_kl", [True, False])
    def test_train_bias_correction_kl(self, use_bias_correction_kl):
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")
        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            beta=0.1,  # set beta to non-zero value to test the case where the reference model is used
            use_bias_correction_kl=use_bias_correction_kl,
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            num_generations=3,  # reduce the number of generations to reduce memory usage
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            report_to="none",
        )
        trainer = GRPOTrainer(
            model="trl-internal-testing/tiny-Qwen2ForCausalLM-2.5",
            reward_funcs=str_length_reward,
            args=training_args,
            train_dataset=dataset,
        )

        previous_trainable_params = {n: param.clone() for n, param in trainer.model.named_parameters()}

        trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None

        # Check that the params have changed
        for n, param in previous_trainable_params.items():
            new_param = trainer.model.get_parameter(n)
            assert not torch.equal(param, new_param), f"Parameter {n} has not changed."

    def test_reward_func_wrong_number_of_rewards(self):
        # A reward function that returns the wrong number of rewards should raise a clear error instead of silently
        # broadcasting (when it returns a single value) or failing later with an opaque shape error.
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")

        def wrong_length_reward(completions, **kwargs):
            return [1.0]  # too few: one reward is expected per completion

        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            num_generations=3,  # reduce the number of generations to reduce memory usage
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            report_to="none",
        )
        trainer = GRPOTrainer(
            model="trl-internal-testing/tiny-Qwen2ForCausalLM-2.5",
            reward_funcs=wrong_length_reward,
            args=training_args,
            train_dataset=dataset,
        )
        with pytest.raises(ValueError, match="returned 1 rewards"):
            trainer.train()

    @pytest.mark.parametrize(
        "model_name",
        [
            pytest.param("trl-internal-testing/tiny-Qwen3ForCausalLM", id="qwen3"),
            pytest.param("trl-internal-testing/tiny-Gemma2ForCausalLM", id="gemma2"),
        ],
        # Gemma2 has the input word embeddings and lm_head tied, Qwen3 does not
    )
    def test_train_with_cast_lm_head_to_fp32(self, model_name):
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")
        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            num_generations=3,  # reduce the number of generations to reduce memory usage
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            report_to="none",
            cast_lm_head_to_fp32=True,
        )
        trainer = GRPOTrainer(
            model=model_name,
            reward_funcs=str_length_reward,
            args=training_args,
            train_dataset=dataset,
        )
        previous_trainable_params = {n: param.clone() for n, param in trainer.model.named_parameters()}

        trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None
        assert trainer.model.lm_head.weight.dtype == torch.float32

        # Check that the params have changed
        for n, param in previous_trainable_params.items():
            new_param = trainer.model.get_parameter(n)
            assert not torch.equal(param, new_param), f"Parameter {n} has not changed."

    def test_train_with_static_entropy(self):
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")
        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            num_generations=3,  # reduce the number of generations to reduce memory usage
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            report_to="none",
            entropy_coef=0.1,
        )
        trainer = GRPOTrainer(
            model="trl-internal-testing/tiny-Qwen2ForCausalLM-2.5",
            reward_funcs=str_length_reward,
            args=training_args,
            train_dataset=dataset,
        )

        previous_trainable_params = {n: param.clone() for n, param in trainer.model.named_parameters()}

        trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None
        assert trainer.state.log_history[-1]["policy_loss"] is not None
        assert trainer.state.log_history[-1]["entropy_coef"] is not None

        # Check that the params have changed
        for n, param in previous_trainable_params.items():
            new_param = trainer.model.get_parameter(n)
            assert not torch.equal(param, new_param), f"Parameter {n} has not changed."

    def test_train_with_adaptive_entropy(self):
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")
        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            num_generations=3,  # reduce the number of generations to reduce memory usage
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            report_to="none",
            entropy_coef=0.01,
            use_adaptive_entropy=True,
            entropy_target=15.0,  # above any realistic entropy → coef is always incremented
        )
        trainer = GRPOTrainer(
            model="trl-internal-testing/tiny-Qwen2ForCausalLM-2.5",
            reward_funcs=str_length_reward,
            args=training_args,
            train_dataset=dataset,
        )

        previous_trainable_params = {n: param.clone() for n, param in trainer.model.named_parameters()}

        trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None
        assert trainer.state.log_history[-1]["policy_loss"] is not None
        assert trainer.state.log_history[-1]["entropy_coef"] is not None
        # Coefficient should have increased since entropy < target throughout training
        assert trainer.entropy_coef > 0.01

        # Check that the params have changed
        for n, param in previous_trainable_params.items():
            new_param = trainer.model.get_parameter(n)
            assert not torch.equal(param, new_param), f"Parameter {n} has not changed."

    @pytest.mark.parametrize("top_entropy_quantile", [1.0, 0.2])
    def test_entropy_bonus_scale(self, top_entropy_quantile):
        # Regression test: the entropy bonus is the mean per-token entropy H for every loss type (documented
        # objective L = L_policy - entropy_coef * H), so it must not inherit any loss-type-specific policy
        # normalization. A previous "unified" formula divided H by a global token count for the
        # cispo/dapo/vespo family, making the bonus ~1/sequence_length too small; conversely, scaling the
        # bonus like the dr_grpo (fixed budget) or luspo (sequence-weighted) policy term would also be wrong.
        #
        # With gradient_accumulation_steps=1, contrib = policy_loss - loss = entropy_coef * entropy_loss, so
        # contrib / entropy is entropy_coef * (H_eff / H_full): H_eff is what the bonus actually uses
        # (over effective_mask, the entropy-quantile-filtered subset), while the logged "entropy" metric is
        # H_full (global_masked_mean over the full completion mask, see `global_masked_mean(entropies)`
        # above). These only coincide when top_entropy_quantile == 1.0. At 0.2, comparing contrib/entropy
        # to a fixed entropy_coef is fixture-lucky: it only holds because this tiny, ~untrained model's
        # entropy is ~uniform across tokens (H_eff/H_full ~= 1.0), which isn't true in general. The actual
        # invariant this PR restores is loss-type independence, so assert that directly: every loss type's
        # ratio must agree with every other's, at the same quantile.
        entropy_coef = 0.5

        def ratio_for(loss_type):
            dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")
            training_args = GRPOConfig(
                output_dir=self.tmp_dir,
                importance_sampling_level="sequence" if loss_type == "luspo" else "token",
                learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
                per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
                num_generations=3,  # reduce the number of generations to reduce memory usage
                max_completion_length=16,  # reduce the completion length to reduce memory usage
                gradient_accumulation_steps=1,  # so contrib == entropy_coef * entropy_loss holds per step
                loss_type=loss_type,
                top_entropy_quantile=top_entropy_quantile,
                logging_steps=1,
                report_to="none",
                entropy_coef=entropy_coef,
            )
            trainer = GRPOTrainer(
                model="trl-internal-testing/tiny-Qwen2ForCausalLM-2.5",
                reward_funcs=str_length_reward,
                args=training_args,
                train_dataset=dataset,
            )

            trainer.train()

            logs = [h for h in trainer.state.log_history if "policy_loss" in h and "loss" in h and h.get("entropy")]
            assert logs
            ratios = sorted((h["policy_loss"] - h["loss"]) / h["entropy"] for h in logs)
            return ratios[len(ratios) // 2]  # median, robust to per-step noise

        ratios = {loss_type: ratio_for(loss_type) for loss_type in ["grpo", "dr_grpo", "dapo", "luspo"]}
        baseline = ratios["grpo"]
        for loss_type, ratio in ratios.items():
            # Every loss type regularizes the same mean per-token entropy, so their ratios must agree with
            # each other regardless of top_entropy_quantile, even though none of them individually needs to
            # equal entropy_coef once quantile filtering makes H_eff diverge from the logged H_full.
            assert ratio == pytest.approx(baseline, rel=0.3), (
                f"entropy bonus ratio for loss_type={loss_type!r} at top_entropy_quantile={top_entropy_quantile} "
                f"diverges from the grpo baseline ({ratio} vs {baseline})"
            )

    @pytest.mark.parametrize(
        ("importance_sampling_level", "beta"),
        [
            ("sequence", 0.1),  # per_token_loss is (B, T) via the KL term
            ("token", 0.0),  # per_token_loss is (B, T) via importance_sampling_level itself, the config default
        ],
    )
    def test_luspo_loss_ignores_padding(self, importance_sampling_level, beta):
        # Regression test: the luspo branch assumes per_token_loss is (B, 1) and uses `mask` only as a per-sequence
        # length, not as an elementwise mask. That assumption breaks once per_token_loss is actually (B, T),
        # letting padded positions leak into the loss. The loss must not depend on padded positions.
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")
        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            loss_type="luspo",
            beta=beta,
            importance_sampling_level=importance_sampling_level,
            report_to="none",
        )
        trainer = GRPOTrainer(
            model="trl-internal-testing/tiny-Qwen2ForCausalLM-2.5",
            reward_funcs=str_length_reward,
            args=training_args,
            train_dataset=dataset,
        )
        trainer.model.eval()

        # Trainer.__init__ moves the model to args.device, so on a GPU runner the inputs have to be built there too.
        device = next(trainer.model.parameters()).device
        batch_size, prompt_len, completion_len = 2, 3, 6
        # This is the first test in this file to call _compute_loss with hand-built inputs; there is no other way
        # to isolate padded positions directly, so a future refactor of _compute_loss's input contract should keep
        # this pinned.
        prompt_ids = torch.randint(1, 1000, (batch_size, prompt_len), device=device)
        prompt_mask = torch.ones(batch_size, prompt_len, dtype=torch.long, device=device)
        completion_ids = torch.randint(1, 1000, (batch_size, completion_len), device=device)
        # trailing positions are padding for every sequence
        completion_mask = torch.tensor([[1, 1, 1, 1, 0, 0], [1, 1, 1, 0, 0, 0]], device=device)

        # old_per_token_logps/ref_per_token_logps must be close in scale to the model's actual per-token log-probs,
        # not arbitrary noise: for this tiny, near-uniform model log-probs sit around -log(vocab_size) (~-11), so
        # plain torch.randn() (mean 0) either makes the importance-sampling ratio astronomically small or the KL
        # term astronomically large, and the resulting difference can fall below torch.testing.assert_close's
        # tolerance regardless of whether the padding fix under test is correct. A small fixed offset from the
        # model's real log-probs keeps both signals in a comparable, well-scaled range.
        with torch.no_grad():
            baseline_logps, _, _ = trainer._get_per_token_logps_and_entropies(
                trainer.model,
                torch.cat([prompt_ids, completion_ids], dim=1),
                torch.cat([prompt_mask, completion_mask], dim=1),
                completion_len,
            )
        inputs = {
            "prompt_ids": prompt_ids,
            "prompt_mask": prompt_mask,
            "completion_ids": completion_ids,
            "completion_mask": completion_mask,
            "advantages": torch.tensor([1.0, -1.0], device=device),
            # old_per_token_logps must be given explicitly: left unset, it falls back to per_token_logps.detach(),
            # which makes the token-level importance-sampling ratio exactly 1 everywhere and defeats this test for
            # importance_sampling_level="token" (per_token_loss would be (B, T) in shape but constant-valued, so
            # masked vs. unmasked aggregation would coincidentally agree regardless of the bug).
            "old_per_token_logps": baseline_logps + 0.05,
            "ref_per_token_logps": baseline_logps + 0.05,
        }

        loss_before = trainer._compute_loss(trainer.model, inputs)

        # Perturb both ref_per_token_logps (feeds the beta > 0 KL term) and old_per_token_logps (feeds the
        # importance_sampling_level="token" ratio) at padded positions only. Whichever one the current
        # parametrization doesn't route through padding is an unaffected no-op; the loss must be unaffected either
        # way.
        perturbed_inputs = dict(inputs)
        for key in ("ref_per_token_logps", "old_per_token_logps"):
            perturbed = inputs[key].clone()
            perturbed[inputs["completion_mask"] == 0] += 1.0
            perturbed_inputs[key] = perturbed

        loss_after = trainer._compute_loss(trainer.model, perturbed_inputs)

        torch.testing.assert_close(loss_before, loss_after)

    def test_train_with_adaptive_entropy_gradient_accumulation(self):
        # Adaptive entropy must behave correctly under gradient accumulation: the coefficient and gating are
        # frozen across an accumulation window and the controller updates once per optimizer step (not once
        # per micro-batch). With entropy_target above any realistic entropy the coefficient is incremented by
        # entropy_coef_delta on every optimizer step, so the final value pins down the number of updates.
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")
        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            num_generations=3,  # reduce the number of generations to reduce memory usage
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            gradient_accumulation_steps=2,  # exercise the accumulation window
            report_to="none",
            entropy_coef=0.01,
            use_adaptive_entropy=True,
            entropy_target=15.0,  # above any realistic entropy → coef incremented once per optimizer step
            entropy_coef_delta=0.005,
        )
        trainer = GRPOTrainer(
            model="trl-internal-testing/tiny-Qwen2ForCausalLM-2.5",
            reward_funcs=str_length_reward,
            args=training_args,
            train_dataset=dataset,
        )

        previous_trainable_params = {n: param.clone() for n, param in trainer.model.named_parameters()}

        trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None
        # Exactly one increment per optimizer step (global_step counts optimizer steps, not micro-batches);
        # a per-micro-batch update would overshoot this.
        expected_coef = min(0.01 + 0.005 * trainer.state.global_step, 1.0)
        assert trainer.entropy_coef == pytest.approx(expected_coef, abs=1e-6)

        # Check that the params have changed
        for n, param in previous_trainable_params.items():
            new_param = trainer.model.get_parameter(n)
            assert not torch.equal(param, new_param), f"Parameter {n} has not changed."

    def test_entropy_bonus_flows_gradients(self):
        # Regression test: entropies were computed under torch.no_grad(), which made the entropy bonus a
        # no-op for training — it lowered the reported loss but contributed no gradient. When the bonus is
        # active (entropy_coef != 0 or use_adaptive_entropy), entropies must carry grad.
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")
        trainer = GRPOTrainer(
            model="trl-internal-testing/tiny-Qwen2ForCausalLM-2.5",
            reward_funcs=str_length_reward,
            args=GRPOConfig(output_dir=self.tmp_dir, report_to="none", entropy_coef=0.1),
            train_dataset=dataset,
        )
        model = trainer.model
        input_ids = torch.tensor([[0, 1, 2, 3, 4, 5, 6, 7]], device=model.device)
        attention_mask = torch.ones_like(input_ids)

        # Bonus active (entropy_coef=0.1 sets _entropy_bonus_enabled at init) → entropies must be
        # differentiable so the term contributes gradients.
        assert trainer._entropy_bonus_enabled
        _, entropies, _ = trainer._get_per_token_logps_and_entropies(
            model, input_ids, attention_mask, logits_to_keep=4, compute_entropy=True
        )
        assert entropies.requires_grad

    def test_train_with_entropy_filter(self):
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")
        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            num_generations=3,  # reduce the number of generations to reduce memory usage
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            report_to="none",
            top_entropy_quantile=0.2,
        )
        trainer = GRPOTrainer(
            model="trl-internal-testing/tiny-Qwen2ForCausalLM-2.5",
            reward_funcs=str_length_reward,
            args=training_args,
            train_dataset=dataset,
        )

        previous_trainable_params = {n: param.clone() for n, param in trainer.model.named_parameters()}

        trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None

        # Check that the params have changed
        for n, param in previous_trainable_params.items():
            new_param = trainer.model.get_parameter(n)
            assert not torch.equal(param, new_param), f"Parameter {n} has not changed."

    @require_vllm
    def test_train_vllm(self):
        """Test that training works with vLLM for generation."""
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")

        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            num_generations=3,  # reduce the number of generations to reduce memory usage
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            report_to="none",
            use_vllm=True,
        )
        trainer = GRPOTrainer(
            model="trl-internal-testing/tiny-Qwen3ForCausalLM",
            reward_funcs=str_length_reward,
            args=training_args,
            train_dataset=dataset,
        )

        previous_trainable_params = {n: param.clone() for n, param in trainer.model.named_parameters()}

        trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None

        # Check that the params have changed
        for n, param in previous_trainable_params.items():
            new_param = trainer.model.get_parameter(n)
            assert not torch.equal(param, new_param), f"Parameter {n} has not changed."

    @pytest.mark.skipif(
        not is_vllm_available(min_version="0.28.0"),
        reason="returning the candidate set of each sampled token requires vLLM >= 0.28",
    )
    def test_train_vllm_top_k(self):
        """Test that with top_k, the log-probs are normalized over the candidate set vLLM sampled from."""
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")

        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            num_generations=3,  # reduce the number of generations to reduce memory usage
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            logging_steps=1,
            report_to="none",
            use_vllm=True,
            top_k=10,
        )
        trainer = GRPOTrainer(
            model="trl-internal-testing/tiny-Qwen3ForCausalLM",
            reward_funcs=str_length_reward,
            args=training_args,
            train_dataset=dataset,
        )

        previous_trainable_params = {n: param.clone() for n, param in trainer.model.named_parameters()}

        trainer.train()

        # The tiny model is near uniform, so over the full vocabulary its log-probs would be
        # ~log(vocab_size / top_k) ≈ 9.6 lower
        for log in trainer.state.log_history[:-1]:
            assert log["sampling/sampling_logp_difference/mean"] < 0.1

        # Check that the params have changed
        for n, param in previous_trainable_params.items():
            new_param = trainer.model.get_parameter(n)
            assert not torch.equal(param, new_param), f"Parameter {n} has not changed."

    @pytest.mark.parametrize(
        "sampling_kwargs",
        [
            {"top_p": 0.9},
            {"min_p": 0.05},
            {"vllm_structured_outputs_regex": r"\d+"},
            {"generation_kwargs": {"structured_outputs": {"regex": r"\d+"}}},
        ],
    )
    def test_vllm_filtered_sampling_requires_top_k(self, sampling_kwargs):
        with pytest.raises(ValueError, match="top_k"):
            GRPOConfig(output_dir=self.tmp_dir, use_vllm=True, report_to="none", **sampling_kwargs)

    @require_vllm
    @pytest.mark.parametrize(
        "server_returns_sampling_mask",
        [
            False,
            pytest.param(
                True,
                marks=pytest.mark.skipif(
                    not is_vllm_available(min_version="0.28.0"),
                    reason="returning the candidate set of each sampled token requires vLLM >= 0.28",
                ),
            ),
        ],
    )
    def test_vllm_server_structured_outputs_needs_sampling_mask(self, server_returns_sampling_mask):
        # Without the candidate sets the grammar leaves, the importance ratio would be ~0
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")
        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            report_to="none",
            use_vllm=True,
            vllm_mode="server",
            top_k=10,
            vllm_structured_outputs_regex=r"\d+",
        )
        model_config = {"logprobs_mode": "processed_logprobs", "return_sampling_mask": server_returns_sampling_mask}
        with (  # stand in for the vLLM server
            patch.object(VLLMClient, "check_server"),
            patch.object(VLLMClient, "_get", return_value={"data": [{"id": "Qwen/Qwen2.5-0.5B-Instruct"}]}),
            patch.object(VLLMClient, "init_communicator"),
            patch.object(VLLMClient, "get_server_info", return_value={"model_config": model_config}),
        ):
            if server_returns_sampling_mask:
                trainer = GRPOTrainer(
                    model="trl-internal-testing/tiny-Qwen2ForCausalLM-2.5",
                    reward_funcs=str_length_reward,
                    args=training_args,
                    train_dataset=dataset,
                )
                assert trainer.vllm_generation.return_sampling_mask
            else:
                with pytest.raises(ValueError, match="--return-sampling-mask"):
                    GRPOTrainer(
                        model="trl-internal-testing/tiny-Qwen2ForCausalLM-2.5",
                        reward_funcs=str_length_reward,
                        args=training_args,
                        train_dataset=dataset,
                    )

    def test_vllm_repetition_penalty_requires_no_importance_sampling_correction(self):
        with pytest.raises(ValueError, match="repetition_penalty"):
            GRPOConfig(output_dir=self.tmp_dir, use_vllm=True, report_to="none", repetition_penalty=1.2)

    @require_peft
    @require_vllm
    @require_torch_accelerator
    def test_vllm_weight_sync_skips_ref_adapter_modules_to_save(self):
        # With a pretrained adapter and `beta != 0`, GRPO adds a "ref" copy of the adapter. Its copy of the
        # `modules_to_save` head must not reach vLLM, which only knows `lm_head.weight`.
        model = AutoModelForCausalLM.from_pretrained(
            "trl-internal-testing/tiny-Qwen3ForCausalLM", dtype=torch.bfloat16
        )
        model = get_peft_model(model, LoraConfig(target_modules=["q_proj", "v_proj"], modules_to_save=["lm_head"]))
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")
        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            report_to="none",
            beta=0.04,
            use_vllm=True,
            vllm_mode="colocate",
            max_steps=1,
            per_device_train_batch_size=3,
            num_generations=3,
            max_completion_length=8,
        )
        trainer = GRPOTrainer(
            model=model,
            reward_funcs=str_length_reward,
            args=training_args,
            train_dataset=dataset,
        )

        trainer.train()

    @require_peft
    # peft warns about this config before TRL raises (#8387)
    @pytest.mark.filterwarnings("ignore:Model has `tie_word_embeddings=True`")
    def test_vllm_and_peft_copies_of_tied_embeddings_raises(self):
        # PEFT trains separate copies of tied embeddings in `modules_to_save`, which vLLM cannot hold
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")
        training_args = GRPOConfig(output_dir=self.tmp_dir, report_to="none", use_vllm=True)
        lora_config = LoraConfig(target_modules="all-linear", modules_to_save=["embed_tokens", "lm_head"])
        with pytest.raises(ValueError, match="ensure_weight_tying"):
            GRPOTrainer(
                model="trl-internal-testing/tiny-LlamaForCausalLM-3.2",
                reward_funcs=str_length_reward,
                args=training_args,
                train_dataset=dataset,
                peft_config=lora_config,
            )

    @require_peft
    @pytest.mark.parametrize("peft_config_name", ["prompt_tuning", "lora_bias"])
    def test_vllm_and_peft_without_lora_merge_raises(self, peft_config_name):
        # The weight sync sends vLLM the base weights with the LoRA deltas merged in, which can't express the virtual
        # tokens of prompt tuning or a LoRA bias
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")
        training_args = GRPOConfig(output_dir=self.tmp_dir, report_to="none", use_vllm=True)
        peft_config = {
            "prompt_tuning": PromptTuningConfig(task_type=TaskType.CAUSAL_LM, num_virtual_tokens=4),
            "lora_bias": LoraConfig(lora_bias=True),
        }[peft_config_name]
        with pytest.raises(ValueError, match="LoRA adapters without `lora_bias` only"):
            GRPOTrainer(
                model="trl-internal-testing/tiny-Qwen2ForCausalLM-2.5",
                reward_funcs=str_length_reward,
                args=training_args,
                train_dataset=dataset,
                peft_config=peft_config,
            )

    @require_peft
    @require_vllm
    def test_train_vllm_and_peft(self):
        """Test that training works with vLLM for generation."""
        # Tied embeddings, which vLLM holds as one tensor
        model = AutoModelForCausalLM.from_pretrained(
            "trl-internal-testing/tiny-Qwen3ForCausalLM-Instruct-2507", dtype="float32"
        )
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")

        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            num_generations=3,  # reduce the number of generations to reduce memory usage
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            report_to="none",
            use_vllm=True,
        )
        lora_config = LoraConfig(
            target_modules="all-linear",
            # test with non-default modules as it adds extra keys in state_dict that we need to handle
            modules_to_save=["embed_tokens", "lm_head"],
            ensure_weight_tying=True,  # vLLM holds the tied embeddings as one tensor
        )
        trainer = GRPOTrainer(
            model=model,
            reward_funcs=str_length_reward,
            args=training_args,
            train_dataset=dataset,
            peft_config=lora_config,
        )

        previous_trainable_params = {n: param.clone() for n, param in trainer.model.named_parameters()}

        trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None

        # Check that the peft params have changed and the frozen base model params are unchanged, bit for bit
        for n, param in previous_trainable_params.items():
            new_param = trainer.model.get_parameter(n)
            if new_param.requires_grad:
                assert not torch.equal(param, new_param), f"Parameter {n} has not changed."
            else:
                assert torch.equal(param, new_param), f"Parameter {n} has changed."

    @pytest.mark.skipif(
        not is_vllm_available(min_version="0.28.0"),
        reason="returning the candidate set of each sampled token requires vLLM >= 0.28",
    )
    def test_train_vllm_structured_outputs(self):
        """Test that training works with vLLM for generation with structured outputs."""
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")

        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            num_generations=3,  # reduce the number of generations to reduce memory usage
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            report_to="none",
            logging_steps=1,
            use_vllm=True,
            top_k=10,  # the trainer normalizes its log-probs over the candidate set the grammar leaves to vLLM
            vllm_structured_outputs_regex=r"<reasoning>\n.*\n</reasoning>\n<answer>\n.*\n</answer>",
        )
        trainer = GRPOTrainer(
            model="trl-internal-testing/tiny-Qwen3ForCausalLM",
            reward_funcs=str_length_reward,
            args=training_args,
            train_dataset=dataset,
        )

        previous_trainable_params = {n: param.clone() for n, param in trainer.model.named_parameters()}

        trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None
        # Over the full vocabulary, the trainer's log-probs of the tokens the grammar forces would be several nats lower
        # Only the first step: the high learning rate collapses the model after it (see #8260)
        assert trainer.state.log_history[0]["sampling/sampling_logp_difference/mean"] < 0.1

        # Check that the params have changed
        for n, param in previous_trainable_params.items():
            new_param = trainer.model.get_parameter(n)
            assert not torch.equal(param, new_param), f"Parameter {n} has not changed."

    @require_vllm
    @pytest.mark.parametrize(
        "vllm_importance_sampling_clip_min, vllm_importance_sampling_clip_max",
        [
            (None, 3.0),  # only max (current default)
            (0.5, None),  # only min
            (0.5, 5.0),  # both (IcePop)
        ],
    )
    def test_train_vllm_importance_sampling_correction(
        self, vllm_importance_sampling_clip_min, vllm_importance_sampling_clip_max
    ):
        """Test that training works with vLLM for generation with importance sampling correction."""
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")

        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            num_generations=3,  # reduce the number of generations to reduce memory usage
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            report_to="none",
            use_vllm=True,
            vllm_importance_sampling_correction=True,
            vllm_importance_sampling_clip_min=vllm_importance_sampling_clip_min,
            vllm_importance_sampling_clip_max=vllm_importance_sampling_clip_max,
        )
        trainer = GRPOTrainer(
            model="trl-internal-testing/tiny-Qwen3ForCausalLM",
            reward_funcs=str_length_reward,
            args=training_args,
            train_dataset=dataset,
        )

        previous_trainable_params = {n: param.clone() for n, param in trainer.model.named_parameters()}

        trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None

        # Check that the params have changed
        for n, param in previous_trainable_params.items():
            new_param = trainer.model.get_parameter(n)
            assert not torch.equal(param, new_param), f"Parameter {n} has not changed."

    def test_train_with_additional_generation_kwargs(self):
        """Test that training works with additional generation kwargs."""
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")

        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            num_generations=3,  # reduce the number of generations to reduce memory usage
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            report_to="none",
            top_p=0.9,
            top_k=10,
            min_p=0.01,
            repetition_penalty=1.1,
        )

        trainer = GRPOTrainer(
            model="trl-internal-testing/tiny-Qwen2ForCausalLM-2.5",
            reward_funcs=str_length_reward,
            args=training_args,
            train_dataset=dataset,
        )

        previous_trainable_params = {n: param.clone() for n, param in trainer.model.named_parameters()}

        trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None

        # Check that the params have changed
        for n, param in previous_trainable_params.items():
            new_param = trainer.model.get_parameter(n)
            assert not torch.equal(param, new_param), f"Parameter {n} has not changed."

    @require_vllm
    def test_train_vllm_with_additional_generation_kwargs(self):
        """Test that training works with vLLM and additional generation kwargs."""
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")

        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            num_generations=3,  # reduce the number of generations to reduce memory usage
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            report_to="none",
            use_vllm=True,
            top_p=0.9,
            top_k=10,
            min_p=0.01,
            repetition_penalty=1.1,
            vllm_importance_sampling_correction=False,  # vLLM applies `repetition_penalty` to its log-probs
        )

        trainer = GRPOTrainer(
            model="trl-internal-testing/tiny-Qwen3ForCausalLM",
            reward_funcs=str_length_reward,
            args=training_args,
            train_dataset=dataset,
        )

        previous_trainable_params = {n: param.clone() for n, param in trainer.model.named_parameters()}

        trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None

        # Check that the params have changed
        for n, param in previous_trainable_params.items():
            new_param = trainer.model.get_parameter(n)
            assert not torch.equal(param, new_param), f"Parameter {n} has not changed."

    # Flash Attention needs a `head_size` multiple of 8, hence a `small-*` model (`tiny-*` ones have `head_size=2`)
    @pytest.mark.skipif(
        Version(transformers.__version__) < Version("5.8.0"),
        reason="transformers continuous batching requires transformers>=5.8.0",
    )
    @pytest.mark.skipif(
        not is_ampere_or_newer() and torch_device != "xpu" and torch.version.hip is None,
        reason="transformers continuous batching switches attention to Flash Attention, which requires an Ampere or "
        "newer GPU, XPU, or ROCm (see https://github.com/huggingface/transformers/issues/47926)",
    )
    def test_train_with_transformers_continuous_batching(self):
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")

        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            num_generations=3,  # reduce the number of generations to reduce memory usage
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            max_steps=2,  # continuous batching adds about 1s per step
            report_to="none",
            use_transformers_continuous_batching=True,
            transformers_continuous_batching_config={"num_blocks": 16},  # reduce the KV cache size, see #7824
        )
        trainer = GRPOTrainer(
            model="trl-internal-testing/small-Qwen3ForCausalLM",
            reward_funcs=str_length_reward,
            args=training_args,
            train_dataset=dataset,
        )

        previous_trainable_params = {n: param.clone() for n, param in trainer.model.named_parameters()}

        trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None

        # Check that the params have changed
        for n, param in previous_trainable_params.items():
            new_param = trainer.model.get_parameter(n)
            assert not torch.equal(param, new_param), f"Parameter {n} has not changed."

    def test_train_normalize_then_sum_aggregation(self):
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")

        def reward_func1(completions, **kwargs):
            """Reward function that rewards longer completions."""
            return [float(len(completion[0]["content"])) for completion in completions]

        def reward_func2(completions, **kwargs):
            """Reward function that rewards completions with more unique letters."""
            return [float(len(set(completion[0]["content"]))) for completion in completions]

        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            num_generations=3,  # reduce the number of generations to reduce memory usage
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            multi_objective_aggregation="normalize_then_sum",
            report_to="none",
        )
        trainer = GRPOTrainer(
            model="trl-internal-testing/tiny-Qwen2ForCausalLM-2.5",
            reward_funcs=[reward_func1, reward_func2],
            args=training_args,
            train_dataset=dataset,
        )

        previous_trainable_params = {n: param.clone() for n, param in trainer.model.named_parameters()}

        trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None

        # Check that the params have changed
        for n, param in previous_trainable_params.items():
            new_param = trainer.model.get_parameter(n)
            assert not torch.equal(param, new_param), f"Parameter {n} has not changed."

    @pytest.mark.parametrize("scale_rewards", [False, "group", "batch", True, "none"])
    def test_train_scale_rewards(self, scale_rewards):
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")

        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            num_generations=3,  # reduce the number of generations to reduce memory usage
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            scale_rewards=scale_rewards,
            report_to="none",
        )
        trainer = GRPOTrainer(
            model="trl-internal-testing/tiny-Qwen2ForCausalLM-2.5",
            reward_funcs=str_length_reward,
            args=training_args,
            train_dataset=dataset,
        )

        previous_trainable_params = {n: param.clone() for n, param in trainer.model.named_parameters()}

        trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None

        # Check that the params have changed
        for n, param in previous_trainable_params.items():
            new_param = trainer.model.get_parameter(n)
            assert not torch.equal(param, new_param), f"Parameter {n} has not changed."

    @patch("transformers.generation.utils.GenerationMixin.generate")
    def test_train_with_mask_truncated_completions(self, mock_generate):
        """Test that training works with mask_truncated_completions=True parameter."""

        # We mock the generate method because the model's random weights make it extremely unlikely to produce a
        # sequence containing the EOS token within the allowed max_completion_length. As a result, all tokens are
        # masked in the loss, the model doesn't update, and the final check (which verifies the update) fails.
        def fake_generate(input_ids, **kwargs):
            # pad_token_id = 151643; eos_token_id = 151645
            completion_ids = torch.tensor(
                [
                    [1, 2, 3, 4, 5, 6, 7, 8],  # this one is truncated
                    [9, 10, 11, 151645, 151643, 151643, 151643, 151643],  # this one contains eos
                    [12, 13, 14, 15, 16, 17, 18, 151645],  # particular case, eos is generated just within the limit
                ],
                device=input_ids.device,
            )
            return torch.cat([input_ids, completion_ids], dim=1)

        mock_generate.side_effect = fake_generate

        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")

        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            num_generations=3,  # reduce the number of generations to reduce memory usage
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            mask_truncated_completions=True,  # Enable masking of truncated completions
            loss_type="dapo",  # we test specifically dapo because it normalizes by num_items_in_batch
            report_to="none",
        )
        trainer = GRPOTrainer(
            model="trl-internal-testing/tiny-Qwen2ForCausalLM-2.5",
            reward_funcs=str_length_reward,
            args=training_args,
            train_dataset=dataset,
        )

        previous_trainable_params = {n: param.clone() for n, param in trainer.model.named_parameters()}

        trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None

        # Check that the params have changed
        for n, param in previous_trainable_params.items():
            new_param = trainer.model.get_parameter(n)
            assert not torch.equal(param, new_param), f"Parameter {n} has not changed."

    def test_train_with_mask_truncated_completions_all_masked(self):
        """
        Test that when all generated completions are truncated (i.e., none contain an EOS token), and
        mask_truncated_completions=True, the model receives no effective learning signal and therefore does not update
        its parameters.

        Here, we don't mock the generate method, be we rely on the fact that the model the probability of generating
        the EOS token is extremely low, so all generated completions are truncated.

        The streamed log-prob path gathers only unmasked rows, so with nothing left it has to scatter back into a
        tensor that is still attached to the model, otherwise `backward()` fails instead of contributing zero.
        """
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")

        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            num_generations=3,  # reduce the number of generations to reduce memory usage
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            mask_truncated_completions=True,  # Enable masking of truncated completions
            loss_type="dapo",  # we test specifically dapo because it normalizes by num_items_in_batch
            report_to="none",
        )
        trainer = GRPOTrainer(
            model="trl-internal-testing/tiny-Qwen2ForCausalLM-2.5",
            reward_funcs=str_length_reward,
            args=training_args,
            train_dataset=dataset,
        )

        previous_trainable_params = {n: param.clone() for n, param in trainer.model.named_parameters()}

        trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] == pytest.approx(0.0)

        # Check that the params have not changed
        for n, param in previous_trainable_params.items():
            new_param = trainer.model.get_parameter(n)
            assert torch.equal(param, new_param), f"Parameter {n} has changed."

    def test_warning_raised_all_rewards_none(self, caplog):
        """Test that a proper warning is raised when all rewards are None."""
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")

        def always_none_reward_func(completions, **kwargs):
            """Reward function that always returns None."""
            return [None] * len(completions)

        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            num_generations=3,  # reduce the number of generations to reduce memory usage
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            report_to="none",
        )
        trainer = GRPOTrainer(
            model="trl-internal-testing/tiny-Qwen2ForCausalLM-2.5",
            reward_funcs=always_none_reward_func,
            args=training_args,
            train_dataset=dataset,
        )

        with caplog.at_level("WARNING", logger="trl.trainer.grpo_trainer"):
            trainer.train()

        expected_warning = "All reward functions returned None for the following kwargs:"
        assert expected_warning in caplog.text

    @pytest.mark.parametrize("loss_type", ["grpo", "bnpo", "dr_grpo", "dapo", "cispo"])
    def test_warning_raised_sequence_level_with_token_summed_loss(self, caplog, loss_type):
        """Test that a warning is raised when sequence-level importance sampling is combined with a loss type that
        sums per-token contributions (length-weighting each sequence instead of following the GSPO objective)."""
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")

        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            importance_sampling_level="sequence",
            loss_type=loss_type,
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            num_generations=3,  # reduce the number of generations to reduce memory usage
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            report_to="none",
        )
        with caplog.at_level("WARNING", logger="trl.trainer.grpo_trainer"):
            GRPOTrainer(
                model="trl-internal-testing/tiny-Qwen2ForCausalLM-2.5",
                reward_funcs=str_length_reward,
                args=training_args,
                train_dataset=dataset,
            )

        expected_warning = "weights each sequence by its completion length"
        assert (expected_warning in caplog.text) == (loss_type != "grpo")

    def test_train_num_generations_larger_than_batch_size(self):
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")

        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            num_generations=6,  # the number of generations is larger than the batch size, but
            gradient_accumulation_steps=2,  # gradient accumulation should allow that
            report_to="none",
        )
        trainer = GRPOTrainer(
            model="trl-internal-testing/tiny-Qwen2ForCausalLM-2.5",
            reward_funcs=str_length_reward,
            args=training_args,
            train_dataset=dataset,
        )

        previous_trainable_params = {n: param.clone() for n, param in trainer.model.named_parameters()}

        trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None

        # Check that the params have changed
        for n, param in previous_trainable_params.items():
            new_param = trainer.model.get_parameter(n)
            assert not torch.equal(param, new_param), f"Parameter {n} has not changed."

    def test_train_delta_clipping(self):
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")

        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            num_generations=3,  # reduce the number of generations to reduce memory usage
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            delta=2.0,  # set delta to a non-None value
            report_to="none",
        )
        trainer = GRPOTrainer(
            model="trl-internal-testing/tiny-Qwen2ForCausalLM-2.5",
            reward_funcs=str_length_reward,
            args=training_args,
            train_dataset=dataset,
        )

        previous_trainable_params = {n: param.clone() for n, param in trainer.model.named_parameters()}

        trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None

        # Check that the params have changed
        for n, param in previous_trainable_params.items():
            new_param = trainer.model.get_parameter(n)
            assert not torch.equal(param, new_param), f"Parameter {n} has not changed."

    def test_train_multiple_dataloader_workers(self):
        # Pytest/CI often starts background threads before tests run. With Python 3.12, using the default "fork" start
        # method in a multi-threaded process emits a DeprecationWarning and may deadlock.
        #
        # We force "spawn" here to make multiprocessing safe under pytest when DataLoader workers are enabled. This is
        # test-environment–specific and not required by the training logic itself.
        #
        # This means the test does not cover "fork". However, "spawn" is stricter (requires full picklability and clean
        # state) and avoids fork-after-threads issues that pytest cannot reliably test anyway. Fork-specific behavior,
        # if needed, should be tested in a clean process outside pytest.
        torch.multiprocessing.set_start_method("spawn", force=True)

        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")

        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            num_generations=3,  # reduce the number of generations to reduce memory usage
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            dataloader_num_workers=2,  # use multiple dataloader workers
            report_to="none",
        )
        trainer = GRPOTrainer(
            model="trl-internal-testing/tiny-Qwen2ForCausalLM-2.5",
            reward_funcs=str_length_reward,
            args=training_args,
            train_dataset=dataset,
        )

        previous_trainable_params = {n: param.clone() for n, param in trainer.model.named_parameters()}

        trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None

        # Check that the params have changed
        for n, param in previous_trainable_params.items():
            new_param = trainer.model.get_parameter(n)
            assert not torch.equal(param, new_param), f"Parameter {n} has not changed."

    def test_train_with_generation_kwargs(self):
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")

        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            num_generations=3,  # reduce the number of generations to reduce memory usage
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            # Pass gen kwargs
            generation_kwargs={"do_sample": True, "top_k": 50, "num_beams": 2, "length_penalty": -0.1},
            report_to="none",
        )
        trainer = GRPOTrainer(
            model="trl-internal-testing/tiny-Qwen2ForCausalLM-2.5",
            reward_funcs=str_length_reward,
            args=training_args,
            train_dataset=dataset,
        )

        previous_trainable_params = {n: param.clone() for n, param in trainer.model.named_parameters()}

        trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None

        # Check that the params have changed
        for n, param in previous_trainable_params.items():
            new_param = trainer.model.get_parameter(n)
            assert not torch.equal(param, new_param), f"Parameter {n} has not changed."

    def test_train_with_reward_func_accessing_trainer_state(self):
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")

        def reward_func(completions, **kwargs):
            trainer_state = kwargs.get("trainer_state")
            assert trainer_state is not None
            # transformers.TrainerState instance should have a `global_step` property.
            assert hasattr(trainer_state, "global_step")
            return [float(len(set(completion[0]["content"]))) for completion in completions]

        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            num_generations=3,  # reduce the number of generations to reduce memory usage
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            report_to="none",
        )
        trainer = GRPOTrainer(
            model="trl-internal-testing/tiny-Qwen2ForCausalLM-2.5",
            reward_funcs=reward_func,
            args=training_args,
            train_dataset=dataset,
        )
        trainer.train()

    def test_train_reward_func_with_log_extra(self):
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")

        def reward_func(completions, **kwargs):
            log_extra = kwargs.get("log_extra")
            assert log_extra is not None
            log_extra("test_column", [completion[0]["content"][:5] for completion in completions])
            return [float(len(completion[0]["content"])) for completion in completions]

        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            num_generations=3,  # reduce the number of generations to reduce memory usage
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            report_to="none",
            log_completions=True,
        )
        trainer = GRPOTrainer(
            model="trl-internal-testing/tiny-Qwen2ForCausalLM-2.5",
            reward_funcs=reward_func,
            args=training_args,
            train_dataset=dataset,
        )
        trainer.train()
        assert "test_column" in trainer._logs["extra"]

    def test_train_reward_func_with_log_metric(self):
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")

        def reward_func(completions, **kwargs):
            log_metric = kwargs.get("log_metric")
            assert log_metric is not None
            log_metric("custom_accuracy", 0.75)
            return [float(len(completion[0]["content"])) for completion in completions]

        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            num_generations=3,  # reduce the number of generations to reduce memory usage
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            report_to="none",
        )
        trainer = GRPOTrainer(
            model="trl-internal-testing/tiny-Qwen2ForCausalLM-2.5",
            reward_funcs=reward_func,
            args=training_args,
            train_dataset=dataset,
        )
        trainer.train()
        # log_metric appends to _metrics, which gets averaged and merged into log_history
        logged_keys = {k for entry in trainer.state.log_history for k in entry}
        assert "custom_accuracy" in logged_keys

    def test_prepare_input_called_with_correct_data(self):
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")
        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            gradient_accumulation_steps=3,  # can be anything in this test
            # steps_per_generation*per_device_train_batch_size=24 is divisible by num_generations=4
            steps_per_generation=4,
            num_generations=4,
            per_device_train_batch_size=6,  # reduce the batch size to reduce memory usage
            num_iterations=2,
            shuffle_dataset=False,
            report_to="none",
        )
        trainer = GRPOTrainer(
            model="trl-internal-testing/tiny-Qwen2ForCausalLM-2.5",
            reward_funcs=str_length_reward,
            args=training_args,
            train_dataset=dataset,
        )
        # steps_per_generation=4, per_device_train_batch_size=6 and num_generations=4, so we expect a
        # generation batch of 24 samples (steps_per_generation * per_device_train_batch_size), containing 6
        # different prompts (steps_per_generation * per_device_train_batch_size // num_generations), each repeated
        # 4 times (num_generations).
        expected_first_generation_batch = (
            [{"prompt": [{"role": "user", "content": "What is better than ugly?"}]}] * 4
            + [{"prompt": [{"role": "user", "content": "What is better than implicit?"}]}] * 4
            + [{"prompt": [{"role": "user", "content": "What is better than complex?"}]}] * 4
            + [{"prompt": [{"role": "user", "content": "What is better than complicated?"}]}] * 4
            + [{"prompt": [{"role": "user", "content": "What is better than nested?"}]}] * 4
            + [{"prompt": [{"role": "user", "content": "What is better than dense?"}]}] * 4
        )
        expected_second_generation_batch = (
            [{"prompt": [{"role": "user", "content": "What counts?"}]}] * 4
            + [{"prompt": [{"role": "user", "content": "Are special cases enough to break the rules?"}]}] * 4
            + [{"prompt": [{"role": "user", "content": "What beats purity?"}]}] * 4
            + [{"prompt": [{"role": "user", "content": "What should never pass silently?"}]}] * 4
            + [{"prompt": [{"role": "user", "content": "When can errors pass silently?"}]}] * 4
            + [{"prompt": [{"role": "user", "content": "What should you do in the face of ambiguity?"}]}] * 4
        )

        with patch.object(GRPOTrainer, "training_step", wraps=trainer.training_step) as mock_prepare:
            trainer.train()
            # 3 epochs * 2 iterations * 2 generation batches to cover the dataset * 4 steps_per_generation
            assert mock_prepare.call_count == 48
            for i in range(0, 8):  # Generation batch repeated 8 times (steps_per_generation*num_iterations)
                assert mock_prepare.call_args_list[i].args[1] == expected_first_generation_batch
            for i in range(8, 16):
                assert mock_prepare.call_args_list[i].args[1] == expected_second_generation_batch

    def test_train_sequence_importance_sampling(self):
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")

        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            num_generations=3,  # reduce the number of generations to reduce memory usage
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            num_iterations=2,  # the importance sampling weights won't be 0 in this case
            importance_sampling_level="sequence",
            report_to="none",
        )
        trainer = GRPOTrainer(
            model="trl-internal-testing/tiny-Qwen2ForCausalLM-2.5",
            reward_funcs=str_length_reward,
            args=training_args,
            train_dataset=dataset,
        )

        previous_trainable_params = {n: param.clone() for n, param in trainer.model.named_parameters()}

        trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None

        # Check that the params have changed
        for n, param in previous_trainable_params.items():
            new_param = trainer.model.get_parameter(n)
            assert not torch.equal(param, new_param), f"Parameter {n} has not changed."

    def test_train_stops_on_every_eos_token_id(self):
        # Phi-3.5 ends a turn with `<|end|>`, which only its generation config declares as eos, not its tokenizer
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")

        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            num_generations=3,  # reduce the number of generations to reduce memory usage
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            report_to="none",
        )
        trainer = GRPOTrainer(
            model="trl-internal-testing/tiny-Phi3ForCausalLM-3.5",
            reward_funcs=str_length_reward,
            args=training_args,
            train_dataset=dataset,
        )
        assert 32007 in trainer.generation_config.eos_token_id  # `<|end|>`

        def fake_generate(input_ids, **kwargs):
            # 'Blue<|end|>and green': the turn ends on `<|end|>`, and generation goes on after it
            completion_ids = torch.tensor([[10924, 32007, 322, 7933]] * input_ids.shape[0], device=input_ids.device)
            return torch.cat([input_ids, completion_ids], dim=-1)

        with patch.object(trainer.model, "generate", side_effect=fake_generate):
            trainer.train()

        # Completions are cut after `<|end|>` and count as terminated, not clipped
        assert trainer.state.log_history[-1]["completions/mean_length"] == 2.0
        assert trainer.state.log_history[-1]["completions/clipped_ratio"] == 0.0

    def test_train_with_chat_template_kwargs(self):
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")

        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            num_generations=3,  # reduce the number of generations to reduce memory usage
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            report_to="none",
            chat_template_kwargs={"enable_thinking": False},
        )
        trainer = GRPOTrainer(
            model="trl-internal-testing/tiny-Qwen3ForCausalLM",
            reward_funcs=str_length_reward,
            args=training_args,
            train_dataset=dataset,
        )

        previous_trainable_params = {n: param.clone() for n, param in trainer.model.named_parameters()}

        trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None

        # Check that the params have changed
        for n, param in previous_trainable_params.items():
            new_param = trainer.model.get_parameter(n)
            assert not torch.equal(param, new_param), f"Parameter {n} has not changed."

    @pytest.mark.xfail(
        condition=Version(transformers.__version__) < Version("5.0.0"),
        reason="Tool parsing is not supported in transformers versions below 5.0.0",
        strict=True,
    )
    @require_response_parsing
    @pytest.mark.parametrize("tools", [[multiply_tool], [async_multiply_tool]])
    def test_train_with_tools(self, tools: list[Callable]):
        # In this test, we define a simple tool that multiplies two integers. Regardless of the input prompt,
        # the model will generate 3 completions, 2 of which will be valid tool calls. Among the 2 tool calls, one will
        # succeed and the other will fail (because of a wrong argument name).

        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")

        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            num_generations=3,  # reduce the number of generations to reduce memory usage
            max_completion_length=128,
            report_to="none",
        )
        trainer = GRPOTrainer(
            model="trl-internal-testing/tiny-Qwen3MoeForCausalLM",
            reward_funcs=str_length_reward,
            args=training_args,
            train_dataset=dataset,
            tools=tools,
        )

        previous_trainable_params = {n: param.clone() for n, param in trainer.model.named_parameters()}
        tool_name = tools[0].__name__

        script = ScriptedTurns(
            trainer.processing_class,
            first_turns=[
                f'<tool_call>\n{{"name": "{tool_name}", "arguments": {{"a": 3, "b": 4}}}}\n</tool_call><|im_end|>',
                # an invalid tool call with wrong argument name
                f'<tool_call>\n{{"name": "{tool_name}", "arguments": {{"a": 3, "c": 4}}}}\n</tool_call><|im_end|>',
                "I don't know any tool<|im_end|>",
            ],
        )
        with patch.object(trainer.model, "generate", script.generate):
            trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None
        assert trainer.state.log_history[-1]["tools/call_frequency"] is not None
        assert trainer.state.log_history[-1]["tools/call_frequency"] == pytest.approx(2 / 3)
        assert trainer.state.log_history[-1]["tools/failure_frequency"] is not None
        assert trainer.state.log_history[-1]["tools/failure_frequency"] == pytest.approx(1 / 2)

        # Check that the params have changed
        for n, param in previous_trainable_params.items():
            new_param = trainer.model.get_parameter(n)
            assert not torch.equal(param, new_param), f"Parameter {n} has not changed."

    @pytest.mark.skipif(
        Version(transformers.__version__) < Version("5.0.0"),
        reason="GLM4 tokenizer requires transformers>=5.0.0",
    )
    @require_response_parsing
    def test_train_with_tools_glm4moe(self):
        # GLM ends a tool call with `<|observation|>`, and its chat template opens the tool result with it too
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")

        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=2,  # reduce the batch size to reduce memory usage
            num_generations=2,  # reduce the number of generations to reduce memory usage
            max_completion_length=128,
            report_to="none",
        )
        trainer = GRPOTrainer(
            model="trl-internal-testing/tiny-Glm4MoeForCausalLM",
            reward_funcs=str_length_reward,
            args=training_args,
            train_dataset=dataset,
            tools=[multiply_tool],
        )

        previous_trainable_params = {n: param.clone() for n, param in trainer.model.named_parameters()}

        script = ScriptedTurns(
            trainer.processing_class,
            first_turns=[
                "\n<think></think>\n<tool_call>multiply_tool\n<arg_key>a</arg_key>\n<arg_value>3</arg_value>\n"
                "<arg_key>b</arg_key>\n<arg_value>4</arg_value>\n</tool_call><|observation|>",
                "I don't know any tool<|user|>",
            ],
            after_tool="Done!<|user|>",
        )

        def generate(input_ids, **kwargs):
            if input_ids.shape[0] == 1:  # the turn after the tool call
                # The tool result follows the model's `<|observation|>`, without repeating it
                assert trainer.processing_class.decode(input_ids[0]).count("<|observation|>") == 1
            return script.generate(input_ids, **kwargs)

        with patch.object(trainer.model, "generate", generate):
            trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None
        assert trainer.state.log_history[-1]["tools/call_frequency"] == pytest.approx(1 / 2)
        assert trainer.state.log_history[-1]["tools/failure_frequency"] == pytest.approx(0.0)

        for n, param in previous_trainable_params.items():
            new_param = trainer.model.get_parameter(n)
            assert not torch.equal(param, new_param), f"Parameter {n} has not changed."

    @pytest.mark.xfail(
        condition=Version(transformers.__version__) < Version("5.0.0"),
        reason="Tool parsing is not supported in transformers versions below 5.0.0",
        strict=True,
    )
    @require_response_parsing
    def test_train_with_tools_log_completions(self):
        # The logged completions mix types within a field: the tool returns content blocks while assistant content is
        # a string, and `query` is a string in one call and a list in the other. The completions table must still be
        # written (#7674).
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")

        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            num_generations=3,  # reduce the number of generations to reduce memory usage
            max_completion_length=128,
            max_steps=1,
            logging_steps=1,
            log_completions=True,
            report_to="none",
        )
        trainer = GRPOTrainer(
            model="trl-internal-testing/tiny-Qwen3MoeForCausalLM",
            reward_funcs=str_length_reward,
            args=training_args,
            train_dataset=dataset,
            tools=[lookup_tool],
        )

        script = ScriptedTurns(
            trainer.processing_class,
            first_turns=[  # two tool calls, then a text answer
                '<tool_call>\n{"name": "lookup_tool", "arguments": {"query": "crate"}}\n</tool_call><|im_end|>',
                '<tool_call>\n{"name": "lookup_tool", "arguments": {"query": ["crate"]}}\n</tool_call><|im_end|>',
                "No tool needed.<|im_end|>",
            ],
        )
        with patch.object(trainer.model, "generate", script.generate):
            trainer.train()

        completions = Dataset.from_parquet(os.path.join(self.tmp_dir, "completions", "completions_00001.parquet"))
        assert completions.num_rows == 3
        tool_messages = [message for row in completions["completion"] for message in row if message["role"] == "tool"]
        assert [message["content"] for message in tool_messages] == [[{"type": "text", "text": "crate"}]] * 2

    @pytest.mark.xfail(
        condition=Version(transformers.__version__) < Version("5.0.0"),
        reason="Tool parsing is not supported in transformers versions below 5.0.0",
        strict=True,
    )
    @require_response_parsing
    def test_max_tool_calling_iterations_skips_last_turn_tool_calls(self):
        # The model calls the tool on every turn. With max_tool_calling_iterations=1, the first turn's call runs, and
        # the call in the turn generated after its result is kept in the completion but never executed.
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")

        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            num_generations=3,  # reduce the number of generations to reduce memory usage
            max_completion_length=128,
            max_tool_calling_iterations=1,
            max_steps=1,
            logging_steps=1,
            log_completions=True,
            report_to="none",
        )
        trainer = GRPOTrainer(
            model="trl-internal-testing/tiny-Qwen3MoeForCausalLM",
            reward_funcs=str_length_reward,
            args=training_args,
            train_dataset=dataset,
            tools=[multiply_tool],
        )

        tool_call = '<tool_call>\n{"name": "multiply_tool", "arguments": {"a": 3, "b": 4}}\n</tool_call><|im_end|>'
        script = ScriptedTurns(trainer.processing_class, first_turns=[tool_call], after_tool=tool_call)
        with patch.object(trainer.model, "generate", script.generate):
            trainer.train()

        assert trainer.state.log_history[0]["tools/call_frequency"] == pytest.approx(1.0)  # one executed call each
        completions = Dataset.from_parquet(os.path.join(self.tmp_dir, "completions", "completions_00001.parquet"))
        for completion in completions["completion"]:
            assert [message["role"] for message in completion] == ["assistant", "tool", "assistant"]
            assert completion[-1]["tool_calls"]  # the last turn's tool call was not executed

    @pytest.mark.xfail(
        condition=Version(transformers.__version__) < Version("5.0.0"),
        reason="Tool parsing is not supported in transformers versions below 5.0.0",
        strict=True,
    )
    @require_response_parsing
    def test_train_with_tools_vllm_server(self):
        # Regression test for #7416. In server mode, vLLM generates `num_generations` completions for every
        # `num_generations`-th prompt. After a tool call, each sample has its own history, so each must be continued
        # from its own history.
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")

        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            num_generations=3,  # reduce the number of generations to reduce memory usage
            max_completion_length=128,
            vllm_mode="server",
            report_to="none",
        )
        trainer = GRPOTrainer(
            model="trl-internal-testing/tiny-Qwen3MoeForCausalLM",
            reward_funcs=str_length_reward,
            args=training_args,
            train_dataset=dataset,
            tools=[multiply_tool],
        )

        script = ScriptedTurns(
            trainer.processing_class,
            first_turns=[
                '<tool_call>\n{"name": "multiply_tool", "arguments": {"a": 3, "b": 4}}\n</tool_call><|im_end|>',
                # an invalid tool call with wrong argument name, so that the two tool histories differ
                '<tool_call>\n{"name": "multiply_tool", "arguments": {"a": 3, "c": 4}}\n</tool_call><|im_end|>',
                "I don't know any tool<|im_end|>",
            ],
        )

        def fake_server_generate(prompts, images, num_generations, profiler):
            # Mimic the server: only every `num_generations`-th prompt is sent, and it is sampled `num_generations` times
            used_prompts = [prompt for prompt in prompts[::num_generations] for _ in range(num_generations)]
            assert used_prompts == prompts, "A sample was continued from another sample's history"
            completion_ids = [script(prompt) for prompt in prompts]
            logprobs = [[[-0.1]] * len(ids) for ids in completion_ids]
            return prompts, completion_ids, logprobs, None, None

        trainer.use_vllm = True
        trainer._last_loaded_step = trainer.state.global_step
        trainer.vllm_generation = SimpleNamespace(sync_weights=MagicMock(), generate=fake_server_generate)
        trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None
        assert trainer.state.log_history[-1]["tools/call_frequency"] == pytest.approx(2 / 3)

    @pytest.mark.skipif(
        Version(transformers.__version__) < Version("5.13.0"),
        reason="Tool parsing relies on the legacy jmespath-based `response_schema` parser below transformers 5.13.0",
    )
    def test_tools_without_jmespath(self):
        # jmespath is only used by the legacy `response_schema` parser (transformers < 5.13); the new-style
        # `response_template` parser doesn't need it. The guard must therefore not fire on newer transformers, where
        # jmespath is never imported. Guards against an over-broad regression: none of the openenv examples install
        # jmespath, so a spurious guard breaks them before training starts.
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")
        training_args = GRPOConfig(output_dir=self.tmp_dir, report_to="none")
        with patch("trl.trainer.grpo_trainer.is_jmespath_available", return_value=False):
            GRPOTrainer(  # must construct without raising
                model="trl-internal-testing/tiny-Qwen3MoeForCausalLM",
                reward_funcs=str_length_reward,
                args=training_args,
                train_dataset=dataset,
                tools=[multiply_tool],
            )

    @pytest.mark.xfail(
        condition=Version(transformers.__version__) < Version("5.2.0"),
        reason="Environment factory support is not available in transformers versions below 5.2.0",
        strict=True,
    )
    @require_response_parsing
    @patch.dict(os.environ, {"TRL_EXPERIMENTAL_SILENCE": "1"})
    def test_train_with_multiple_environments(self, monkeypatch):
        # When `environment_factory` is a dict, each rollout selects its environment via its `environment` field, and
        # only that environment's tools are exposed. Here we build a mixed batch with both environments and check that
        # a tool call from a "counter" example dispatches to the CounterEnvironment's `increment`, while a tool call
        # from an "echo" example dispatches to the EchoEnvironment's `shout`. With `shuffle_dataset=False` and
        # `num_generations=2`, every generation batch is [counter, counter, echo, echo].
        dataset = Dataset.from_dict({"environment": ["counter", "echo"] * 8})
        record_path = os.path.join(self.tmp_dir, "record.jsonl")
        monkeypatch.setenv("TRL_TEST_RECORD", record_path)

        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=4,  # 2 prompts x 2 generations, so a batch mixes both environments
            num_generations=2,
            shuffle_dataset=False,  # keep the [counter, counter, echo, echo] batch layout deterministic
            remove_unused_columns=True,  # `environment` must survive column removal
            report_to="none",
        )

        trainer = GRPOTrainer(
            model="trl-internal-testing/tiny-Qwen3MoeForCausalLM",
            reward_funcs=str_length_reward,
            args=training_args,
            train_dataset=dataset,
            environment_factory={"counter": CounterEnvironment, "echo": EchoEnvironment},
        )

        previous_trainable_params = {n: param.clone() for n, param in trainer.model.named_parameters()}

        script = ScriptedTurns(
            trainer.processing_class,
            first_turns=lambda prompt: (
                [
                    # counter example: valid `increment` tool call (only CounterEnvironment exposes it)
                    '<tool_call>\n{"name": "increment", "arguments": {"step": 1}}\n</tool_call><|im_end|>',
                    # counter example: no tool call (gives reward variance within the group)
                    "I won't<|im_end|>",
                ]
                if "Count." in prompt
                else [
                    # echo example: valid `shout` tool call (only EchoEnvironment exposes it)
                    '<tool_call>\n{"name": "shout", "arguments": {"text": "hi"}}\n</tool_call><|im_end|>',
                    # echo example: no tool call
                    "Done!<|im_end|>",
                ]
            ),
        )
        with patch.object(trainer.model, "generate", script.generate):
            trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None
        # The tool call from the counter example ran `increment` (defined only on CounterEnvironment) and the one from
        # the echo example ran `shout` (defined only on EchoEnvironment): each rollout dispatched to its own tools.
        records = recorded(record_path)
        assert records["increment"]
        assert records["shout"]
        # Half of the rollouts issued a tool call, and every call succeeded.
        assert trainer.state.log_history[-1]["tools/call_frequency"] == pytest.approx(2 / 4)
        assert trainer.state.log_history[-1]["tools/failure_frequency"] == pytest.approx(0.0)
        # Both environments were selected and reset, and `environment` is a control field not forwarded to `reset`.
        assert records["reset_counter"] and records["reset_echo"]
        assert all("environment" not in kwargs for kwargs in records["reset_counter"] + records["reset_echo"])
        # Each rollout is shown only the tool of its own environment
        prompts = list(script.seen)
        assert all(("increment" in prompt) == ("Count." in prompt) for prompt in prompts)
        assert all(("shout" in prompt) == ("Echo." in prompt) for prompt in prompts)

        # Check that the params have changed
        for n, param in previous_trainable_params.items():
            new_param = trainer.model.get_parameter(n)
            assert not torch.equal(param, new_param), f"Parameter {n} has not changed."

    @pytest.mark.xfail(
        condition=Version(transformers.__version__) < Version("5.2.0"),
        reason="Environment factory support is not available in transformers versions below 5.2.0",
        strict=True,
    )
    @require_response_parsing
    @patch.dict(os.environ, {"TRL_EXPERIMENTAL_SILENCE": "1"})
    def test_train_with_multiple_environments_same_tool_name(self, monkeypatch):
        # Two environments expose a `submit` tool with different argument types. Each tool call must be parsed with the
        # schema of its own environment's `submit`: the zip code stays the string "42", the count is the integer 42.
        # With `shuffle_dataset=False` and `num_generations=2`, every generation batch is [zip, zip, count, count].
        dataset = Dataset.from_dict({"environment": ["zip", "count"] * 8})
        record_path = os.path.join(self.tmp_dir, "record.jsonl")
        monkeypatch.setenv("TRL_TEST_RECORD", record_path)

        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            per_device_train_batch_size=4,  # 2 prompts x 2 generations, so a batch mixes both environments
            num_generations=2,
            shuffle_dataset=False,  # keep the [zip, zip, count, count] batch layout deterministic
            report_to="none",
        )

        trainer = GRPOTrainer(
            model="trl-internal-testing/tiny-Qwen3MoeForCausalLM",
            reward_funcs=str_length_reward,
            args=training_args,
            train_dataset=dataset,
            environment_factory={"zip": ZipEnvironment, "count": CountEnvironment},
        )

        script = ScriptedTurns(
            trainer.processing_class,
            first_turns=lambda prompt: (
                [
                    '<tool_call>\n{"name": "submit", "arguments": {"answer": "42"}}\n</tool_call><|im_end|>',
                    "I won't<|im_end|>",
                ]
                if "zip code" in prompt
                else [
                    '<tool_call>\n{"name": "submit", "arguments": {"answer": 42}}\n</tool_call><|im_end|>',
                    "Done!<|im_end|>",
                ]
            ),
        )
        with patch.object(trainer.model, "generate", script.generate):
            trainer.train()

        records = recorded(record_path)
        assert records["zip"] and all(answer == "42" for answer in records["zip"])
        assert records["count"] and all(answer == 42 for answer in records["count"])

    @pytest.mark.xfail(
        condition=Version(transformers.__version__) < Version("5.2.0"),
        reason="Environment factory support is not available in transformers versions below 5.2.0",
        strict=True,
    )
    @require_response_parsing
    @patch.dict(os.environ, {"TRL_EXPERIMENTAL_SILENCE": "1"})
    def test_train_with_unknown_environment_raises(self):
        # With a dict `environment_factory`, an example whose `environment` field doesn't match any configured
        # environment should fail with a clear error rather than a bare KeyError mid-rollout.
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")
        dataset = dataset.map(lambda example: {"environment": "unknown"})

        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            num_generations=3,  # reduce the number of generations to reduce memory usage
            report_to="none",
        )

        trainer = GRPOTrainer(
            model="trl-internal-testing/tiny-Qwen3MoeForCausalLM",
            reward_funcs=str_length_reward,
            args=training_args,
            train_dataset=dataset,
            environment_factory={"counter": CounterEnvironment},
        )

        with pytest.raises(ValueError, match="not among the environments"):
            trainer.train()

    @pytest.mark.xfail(
        condition=Version(transformers.__version__) < Version("5.2.0"),
        reason="Environment factory support is not available in transformers versions below 5.2.0",
        strict=True,
    )
    @require_response_parsing
    @patch.dict(os.environ, {"TRL_EXPERIMENTAL_SILENCE": "1"})
    def test_train_with_environment_factory(self):
        # In this test, we define a simple tool that increments an internal counter. Regardless of the input prompt,
        # the model will generate 3 completions, 2 of which will be valid tool calls. Among the 2 tool calls, one will
        # succeed and the other will fail (because `reset` is not exposed as a tool).
        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            num_generations=3,  # reduce the number of generations to reduce memory usage
            max_steps=5,  # required with environment_factory
            report_to="none",
        )

        trainer = GRPOTrainer(
            model="trl-internal-testing/tiny-Qwen3MoeForCausalLM",
            reward_funcs=str_length_reward,
            args=training_args,
            environment_factory=IncrementEnvironment,
        )

        previous_trainable_params = {n: param.clone() for n, param in trainer.model.named_parameters()}

        script = ScriptedTurns(
            trainer.processing_class,
            first_turns=[
                '<tool_call>\n{"name": "increment", "arguments": {"step": 1}}\n</tool_call><|im_end|>',
                # a call to `reset`, which is not exposed as a tool
                '<tool_call>\n{"name": "reset", "arguments": {"step": 2}}\n</tool_call><|im_end|>',
                "I won't increment<|im_end|>",
            ],
        )
        with patch.object(trainer.model, "generate", script.generate):
            trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None
        assert trainer.state.log_history[-1]["tools/call_frequency"] is not None
        assert trainer.state.log_history[-1]["tools/call_frequency"] == pytest.approx(2 / 3)
        assert trainer.state.log_history[-1]["tools/failure_frequency"] is not None
        assert trainer.state.log_history[-1]["tools/failure_frequency"] == pytest.approx(1 / 2)

        # The tools in the prompt are the environment's public methods: `increment`, not `reset`
        prompts = list(script.seen)
        assert '"name": "increment"' in prompts[0]
        assert '"name": "reset"' not in prompts[0]

        # Check that the params have changed
        for n, param in previous_trainable_params.items():
            new_param = trainer.model.get_parameter(n)
            assert not torch.equal(param, new_param), f"Parameter {n} has not changed."

    @pytest.mark.xfail(
        condition=Version(transformers.__version__) < Version("5.2.0"),
        reason="Environment factory support is not available in transformers versions below 5.2.0",
        strict=True,
    )
    @require_response_parsing
    @patch.dict(os.environ, {"TRL_EXPERIMENTAL_SILENCE": "1"})
    def test_tool_discovery_does_not_evaluate_environment_properties(self):
        # Tool discovery must list the environment's methods on its class. `inspect.getmembers` calls `getattr` on
        # every name before applying the predicate, so listing the instance evaluates its properties, and a property
        # may be expensive or have side effects (a Harbor env scores the rollout from one). Here `reward` is inert on
        # a fresh instance and raises once the environment has been reset: the first batch resets the pooled
        # instances, so a second batch that listed the instance would raise before generating anything.
        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            num_generations=3,  # reduce the number of generations to reduce memory usage
            max_steps=2,  # the first batch resets the pooled instances, the second re-lists their tools
            report_to="none",
        )

        trainer = GRPOTrainer(
            model="trl-internal-testing/tiny-Qwen3MoeForCausalLM",
            # Never reads `environments`, so nothing but tool discovery can touch the `reward` property
            reward_funcs=str_length_reward,
            args=training_args,
            environment_factory=PropertyEnvironment,
        )

        # No tool call, so one generation round per rollout. Distinct-length completions within the group give reward
        # variance, so advantages are non-zero.
        script = ScriptedTurns(
            trainer.processing_class, first_turns=["I won't increment<|im_end|>", "I won't increment it<|im_end|>"]
        )
        with patch.object(trainer.model, "generate", script.generate):
            trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None

    @pytest.mark.xfail(
        condition=Version(transformers.__version__) < Version("5.2.0"),
        reason="Environment factory support is not available in transformers versions below 5.2.0",
        strict=True,
    )
    @require_response_parsing
    @patch.dict(os.environ, {"TRL_EXPERIMENTAL_SILENCE": "1"})
    def test_train_with_environment_owned_reward(self):
        # Same setup as `test_train_with_environment_factory`, but the environment owns the reward via a `get_reward`
        # method and no `reward_funcs` is passed. The reward equals the final counter, so the 3 generations
        # (counters 1, 0, 0) get rewards 1.0, 0.0, 0.0.
        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            num_generations=3,  # reduce the number of generations to reduce memory usage
            max_steps=5,  # required with environment_factory
            report_to="none",
        )

        # No `reward_funcs`: the reward is supplied entirely by the environment.
        trainer = GRPOTrainer(
            model="trl-internal-testing/tiny-Qwen3MoeForCausalLM",
            args=training_args,
            environment_factory=IncrementRewardEnvironment,
        )

        previous_trainable_params = {n: param.clone() for n, param in trainer.model.named_parameters()}

        script = ScriptedTurns(
            trainer.processing_class,
            first_turns=[
                '<tool_call>\n{"name": "increment", "arguments": {"step": 1}}\n</tool_call><|im_end|>',
                # a call to `get_reward`, which is not exposed as a tool
                '<tool_call>\n{"name": "get_reward", "arguments": {}}\n</tool_call><|im_end|>',
                "I won't increment<|im_end|>",
            ],
        )
        with patch.object(trainer.model, "generate", script.generate):
            trainer.train()

        # The environment-owned reward is logged like any reward func, under the env class name. Counters are 1, 0, 0
        # -> rewards 1.0, 0.0, 0.0. It is the sole reward source, with weight 1.
        assert trainer.state.log_history[-1]["rewards/IncrementRewardEnvironment/mean"] == pytest.approx(1 / 3)
        assert trainer.state.log_history[-1]["reward"] == pytest.approx(1 / 3)
        # `increment` is a tool, and `get_reward` is not: of the two calls, only the second one fails
        assert trainer.state.log_history[-1]["tools/failure_frequency"] == pytest.approx(1 / 2)
        # The tools in the prompt are the environment's public methods: `increment`, not `reset` or `get_reward`
        prompts = list(script.seen)
        assert '"name": "increment"' in prompts[0]
        assert '"name": "reset"' not in prompts[0]
        assert '"name": "get_reward"' not in prompts[0]

        # Check that the params have changed
        for n, param in previous_trainable_params.items():
            new_param = trainer.model.get_parameter(n)
            assert not torch.equal(param, new_param), f"Parameter {n} has not changed."

    @pytest.mark.xfail(
        condition=Version(transformers.__version__) < Version("5.2.0"),
        reason="Environment factory support is not available in transformers versions below 5.2.0",
        strict=True,
    )
    @require_response_parsing
    @patch.dict(os.environ, {"TRL_EXPERIMENTAL_SILENCE": "1"})
    def test_environment_owned_reward_coexists_with_reward_funcs(self):
        # When both `reward_funcs` and an environment-owned `get_reward` are present, `get_reward` is appended as an
        # extra reward source (weight 1) after the trainer-owned reward functions.
        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            num_generations=3,  # reduce the number of generations to reduce memory usage
            max_steps=5,  # required with environment_factory
            reward_weights=[0.5],  # weight only applies to the trainer-owned reward func
            report_to="none",
        )
        trainer = GRPOTrainer(
            model="trl-internal-testing/tiny-Qwen3MoeForCausalLM",
            reward_funcs=str_length_reward,
            args=training_args,
            environment_factory=IncrementRewardEnvironment,
        )

        script = ScriptedTurns(
            trainer.processing_class,
            first_turns=[
                '<tool_call>\n{"name": "increment", "arguments": {"step": 1}}\n</tool_call><|im_end|>',
                "I won't increment<|im_end|>",
                "I won't increment<|im_end|>",
            ],
        )
        with patch.object(trainer.model, "generate", script.generate):
            trainer.train()

        # The env-owned reward is logged under the env class name next to the trainer-owned reward func, with a fixed
        # weight of 1. Counters are 1, 0, 0 -> env rewards 1.0, 0.0, 0.0
        logged = trainer.state.log_history[-1]
        reward_columns = {key for key in logged if key.startswith("rewards/") and key.endswith("/mean")}
        assert reward_columns == {"rewards/str_length_reward/mean", "rewards/IncrementRewardEnvironment/mean"}
        assert logged["rewards/IncrementRewardEnvironment/mean"] == pytest.approx(1 / 3)
        assert logged["reward"] == pytest.approx(0.5 * logged["rewards/str_length_reward/mean"] + 1 / 3)
        # The tools in the prompt are the environment's public methods: `increment`, not `reset` or `get_reward`
        prompts = list(script.seen)
        assert '"name": "increment"' in prompts[0]
        assert '"name": "reset"' not in prompts[0]
        assert '"name": "get_reward"' not in prompts[0]

    @pytest.mark.xfail(
        condition=Version(transformers.__version__) < Version("5.2.0"),
        reason="Environment factory support is not available in transformers versions below 5.2.0",
        strict=True,
    )
    @require_response_parsing
    @patch.dict(os.environ, {"TRL_EXPERIMENTAL_SILENCE": "1"})
    def test_environment_owned_reward_mixed_environments(self):
        # With a dict `environment_factory`, only some environments may own their reward via `get_reward`. Each such
        # env *class* contributes one reward column (named after its class); a rollout is scored only when its
        # environment is that class, so mixing a reward-owning env with a plain one must not raise. Reward columns are
        # deduplicated by class: two names mapping to the same `get_reward` class share a single column (no
        # double-counting).
        # A dict `environment_factory` routes each example via its `environment` column, so a dataset is required.
        dataset = Dataset.from_dict(
            {
                "prompt": [[{"role": "user", "content": "Play."}]] * 3,
                "environment": ["scored", "scored2", "plain"],
            }
        )

        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            per_device_train_batch_size=9,  # one generation batch holds the 3 environments
            num_generations=3,  # reduce the number of generations to reduce memory usage
            report_to="none",
        )
        trainer = GRPOTrainer(
            model="trl-internal-testing/tiny-Qwen3MoeForCausalLM",
            reward_funcs=str_length_reward,
            args=training_args,
            train_dataset=dataset,
            # `scored` and `scored2` both build `ScoredEnvironment`, so they must collapse to a single reward column.
            environment_factory={
                "scored": ScoredEnvironment,
                "scored2": ScoredEnvironment,
                "plain": IncrementEnvironment,
            },
        )

        # No tool call. Distinct-length completions within the group give reward variance, so advantages are non-zero.
        script = ScriptedTurns(
            trainer.processing_class, first_turns=["I won't increment<|im_end|>", "I won't increment it<|im_end|>"]
        )
        with patch.object(trainer.model, "generate", script.generate):
            trainer.train()

        # Only `ScoredEnvironment` owns a reward, and despite two names mapping to it, a single (deduplicated) env-reward
        # column is logged after the trainer-owned reward func. It scores only the rollouts bound to
        # `ScoredEnvironment`: an `IncrementEnvironment` rollout is left out instead of raising.
        logged = trainer.state.log_history[-1]
        reward_columns = {key for key in logged if key.startswith("rewards/") and key.endswith("/mean")}
        assert reward_columns == {"rewards/str_length_reward/mean", "rewards/ScoredEnvironment/mean"}
        assert logged["rewards/ScoredEnvironment/mean"] == 1.0
        # 6 of the 9 rollouts are bound to `ScoredEnvironment`, so the env reward adds 1.0 to two thirds of them
        assert logged["reward"] == pytest.approx(logged["rewards/str_length_reward/mean"] + 2 / 3)

    def test_no_reward_source_raises(self):
        # `reward_funcs` is optional, but a reward must come from somewhere: with neither `reward_funcs` nor an
        # environment-owned `get_reward`, construction fails fast instead of training on an all-zero reward.
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")
        training_args = GRPOConfig(output_dir=self.tmp_dir, report_to="none")
        with pytest.raises(ValueError, match="No reward source provided"):
            GRPOTrainer(
                model="trl-internal-testing/tiny-Qwen3ForCausalLM",
                args=training_args,
                train_dataset=dataset,
            )

    def test_dataset_required_without_environment(self):
        # The data has to come from somewhere: an external `train_dataset`, or an environment that owns it. With
        # neither, construction fails fast.
        training_args = GRPOConfig(output_dir=self.tmp_dir, report_to="none")
        with pytest.raises(ValueError, match="`train_dataset` is required"):
            GRPOTrainer(
                model="trl-internal-testing/tiny-Qwen3ForCausalLM",
                reward_funcs=str_length_reward,
                args=training_args,
            )

    @pytest.mark.xfail(
        condition=Version(transformers.__version__) < Version("5.2.0"),
        reason="Environment factory support is not available in transformers versions below 5.2.0",
        strict=True,
    )
    @require_response_parsing
    @patch.dict(os.environ, {"TRL_EXPERIMENTAL_SILENCE": "1"})
    def test_environment_owned_data_requires_max_steps(self):
        # When the environment owns the data and no external `train_dataset` is provided, `max_steps` must set the
        # training length.
        training_args = GRPOConfig(output_dir=self.tmp_dir, report_to="none")  # max_steps unset
        with pytest.raises(ValueError, match="max_steps"):
            GRPOTrainer(
                model="trl-internal-testing/tiny-Qwen3ForCausalLM",
                reward_funcs=str_length_reward,
                args=training_args,
                environment_factory=GuessTheWordEnvironment,
            )

    @pytest.mark.xfail(
        condition=Version(transformers.__version__) < Version("5.2.0"),
        reason="Environment factory support is not available in transformers versions below 5.2.0",
        strict=True,
    )
    @require_response_parsing
    @patch.dict(os.environ, {"TRL_EXPERIMENTAL_SILENCE": "1"})
    def test_multiple_environments_without_dataset_raises(self):
        # Multiple environments (a `dict` factory) need a `train_dataset` with an `environment` column to route each
        # example. Without one, there is no per-rollout selector, so construction fails fast with a clear message.
        class EnvA:
            def reset(self, **kwargs): ...

        class EnvB:
            def reset(self, **kwargs): ...

        training_args = GRPOConfig(output_dir=self.tmp_dir, max_steps=1, report_to="none")
        with pytest.raises(ValueError, match="requires a `train_dataset`"):
            GRPOTrainer(
                model="trl-internal-testing/tiny-Qwen3ForCausalLM",
                reward_funcs=str_length_reward,
                args=training_args,
                environment_factory={"a": EnvA, "b": EnvB},
            )

    @pytest.mark.xfail(
        condition=Version(transformers.__version__) < Version("5.2.0"),
        reason="Environment factory support is not available in transformers versions below 5.2.0",
        strict=True,
    )
    @require_response_parsing
    @patch.dict(os.environ, {"TRL_EXPERIMENTAL_SILENCE": "1"})
    def test_train_with_environment_owned_data(self):
        # The environment owns the data — no external `train_dataset` is needed. `reset()` returns the prompt, and
        # `max_steps` drives the training loop. A placeholder dataset is built internally.
        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            num_generations=3,  # reduce the number of generations to reduce memory usage
            max_steps=5,  # the environment owns the data, so `max_steps` sets the training length
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            report_to="none",
        )

        trainer = GRPOTrainer(
            model="trl-internal-testing/tiny-Qwen3ForCausalLM",
            reward_funcs=str_length_reward,
            args=training_args,
            environment_factory=GuessTheWordEnvironment,
        )

        previous_trainable_params = {n: param.clone() for n, param in trainer.model.named_parameters()}

        # Distinct-length completions within the group give reward variance, so advantages are non-zero.
        script = ScriptedTurns(
            trainer.processing_class, first_turns=["DoneDone!<|im_end|>", "DoneDoneDone!<|im_end|>"]
        )
        with patch.object(trainer.model, "generate", script.generate):
            trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None

        # Check that the params have changed
        for n, param in previous_trainable_params.items():
            new_param = trainer.model.get_parameter(n)
            assert not torch.equal(param, new_param), f"Parameter {n} has not changed."

    @pytest.mark.xfail(
        condition=Version(transformers.__version__) < Version("5.0.0"),
        reason="Tool parsing is not supported in transformers versions below 5.0.0",
        strict=True,
    )
    @require_response_parsing
    def test_train_with_malformed_tool_calls(self):
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")

        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            num_generations=3,  # reduce the number of generations to reduce memory usage
            max_completion_length=128,
            report_to="none",
        )
        trainer = GRPOTrainer(
            model="trl-internal-testing/tiny-Qwen3MoeForCausalLM",
            reward_funcs=str_length_reward,
            args=training_args,
            train_dataset=dataset,
            tools=[multiply_tool],
        )

        previous_trainable_params = {n: param.clone() for n, param in trainer.model.named_parameters()}

        script = ScriptedTurns(
            trainer.processing_class,
            first_turns=[
                '<tool_call>\n{"arguments": {"a": 3, "b": 4}}\n</tool_call><|im_end|>',
                '<toolcall>\n{"arguments": {"a": 3, "b": 4}}\n</toolcall><|im_end|>',
                '<tool_call>\n{"arguments": {a: 3, b: 4}}\n</tool_call><|im_end|>',
            ],
        )
        with patch.object(trainer.model, "generate", script.generate):
            trainer.train()

        # No malformed call is run as a tool, so no rollout has a second turn
        assert script.turns_after_tool == 0
        assert trainer.state.log_history[-1]["train_loss"] is not None

        # Check that the params have changed
        for n, param in previous_trainable_params.items():
            new_param = trainer.model.get_parameter(n)
            assert not torch.equal(param, new_param), f"Parameter {n} has not changed."

    def test_mismatched_reward_processing_classes_length(self):
        """Test that mismatched length between reward_funcs and reward_processing_classes raises error."""
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")

        # Use two reward models
        reward_models = [
            "trl-internal-testing/tiny-Qwen2ForSequenceClassification-2.5",
            "trl-internal-testing/tiny-Qwen3ForSequenceClassification",
        ]

        # Create a single processing class (tokenizer)
        single_processing_class = AutoTokenizer.from_pretrained(
            "trl-internal-testing/tiny-Qwen2ForSequenceClassification-2.5"
        )

        training_args = GRPOConfig(output_dir=self.tmp_dir, report_to="none")

        with pytest.raises(ValueError, match="must match"):
            GRPOTrainer(
                model="trl-internal-testing/tiny-Qwen2ForCausalLM-2.5",
                reward_funcs=reward_models,
                reward_processing_classes=single_processing_class,  # only one, but need two
                args=training_args,
                train_dataset=dataset,
            )

    def test_correct_reward_processing_classes_list(self):
        """Test that correct list of reward_processing_classes works properly."""
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")

        # Use two reward models
        reward_models = [
            "trl-internal-testing/tiny-Qwen2ForSequenceClassification-2.5",
            "trl-internal-testing/tiny-Qwen3ForSequenceClassification",
        ]

        # Create processing classes
        processing_class1 = AutoTokenizer.from_pretrained(
            "trl-internal-testing/tiny-Qwen2ForSequenceClassification-2.5"
        )
        processing_class2 = AutoTokenizer.from_pretrained("trl-internal-testing/tiny-Qwen3ForSequenceClassification")

        training_args = GRPOConfig(output_dir=self.tmp_dir, report_to="none")

        # Correct list length should work
        correct_processing_classes = [processing_class1, processing_class2]

        trainer = GRPOTrainer(
            model="trl-internal-testing/tiny-Qwen2ForCausalLM-2.5",
            reward_funcs=reward_models,
            reward_processing_classes=correct_processing_classes,
            args=training_args,
            train_dataset=dataset,
        )

        assert len(trainer.reward_processing_classes) == len(reward_models)

    def test_single_reward_model_with_single_processing_class(self):
        """Test that single reward model with single processing class works."""
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")

        # Use single reward model
        reward_model = "trl-internal-testing/tiny-Qwen2ForSequenceClassification-2.5"

        # Create a single processing class (tokenizer)
        single_processing_class = AutoTokenizer.from_pretrained(
            "trl-internal-testing/tiny-Qwen2ForSequenceClassification-2.5"
        )

        training_args = GRPOConfig(output_dir=self.tmp_dir, report_to="none")

        trainer = GRPOTrainer(
            model="trl-internal-testing/tiny-Qwen2ForCausalLM-2.5",
            reward_funcs=reward_model,
            reward_processing_classes=single_processing_class,  # single object for single reward model
            args=training_args,
            train_dataset=dataset,
        )

        assert len(trainer.reward_processing_classes) == 1
        assert trainer.reward_processing_classes[0] == single_processing_class

    def test_pad_token_id_synced_with_model_config(self):
        # This model's tokenizer has no pad token, so the trainer falls back to the eos token. The model configs must
        # follow: otherwise `Trainer` realigns them at train time and reports it as a change the user did not make.
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")

        training_args = GRPOConfig(output_dir=self.tmp_dir, report_to="none")
        trainer = GRPOTrainer(
            model="trl-internal-testing/tiny-MistralForCausalLM-0.2",
            reward_funcs=str_length_reward,
            args=training_args,
            train_dataset=dataset,
        )

        pad_token_id = trainer.processing_class.pad_token_id
        assert pad_token_id is not None
        assert trainer.model.config.pad_token_id == pad_token_id
        assert trainer.model.generation_config.pad_token_id == pad_token_id

    def test_reward_model_pad_token_id_synced_with_text_config(self):
        # A composite reward model resolves the pad token through its text config, not the top-level one.
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")
        reward_model = AutoModelForSequenceClassification.from_pretrained(
            "trl-internal-testing/tiny-Gemma3ForConditionalGeneration", num_labels=1
        )
        reward_processing_class = AutoTokenizer.from_pretrained(
            "trl-internal-testing/tiny-Gemma3ForConditionalGeneration"
        )
        reward_processing_class.pad_token = reward_processing_class.eos_token

        training_args = GRPOConfig(output_dir=self.tmp_dir, report_to="none")
        trainer = GRPOTrainer(
            model="trl-internal-testing/tiny-Qwen2ForCausalLM-2.5",
            reward_funcs=reward_model,
            reward_processing_classes=reward_processing_class,
            args=training_args,
            train_dataset=dataset,
        )

        pad_token_id = trainer.reward_processing_classes[0].pad_token_id
        assert pad_token_id is not None
        assert reward_model.config.get_text_config().pad_token_id == pad_token_id

    def test_init_reward_model_with_model_revision(self):
        # The policy's revision is a ref of the policy's repo, not of the reward model's (#8532)
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")
        training_args = GRPOConfig(
            output_dir=self.tmp_dir, report_to="none", model_init_kwargs={"revision": "8913f5819566"}
        )
        GRPOTrainer(
            model="trl-internal-testing/tiny-Qwen2ForCausalLM-2.5",
            reward_funcs="trl-internal-testing/tiny-Qwen2ForSequenceClassification-2.5",
            args=training_args,
            train_dataset=dataset,
        )


@require_vision
class TestGRPOTrainerVLM(TrlTestCase):
    @pytest.mark.parametrize(
        "model_id",
        [
            pytest.param("trl-internal-testing/tiny-Gemma3ForConditionalGeneration", id="gemma3"),
            pytest.param(
                "trl-internal-testing/tiny-Gemma4ForConditionalGeneration",
                id="gemma4",
                marks=pytest.mark.skipif(
                    Version(transformers.__version__) < Version("5.5.0"),
                    reason="Gemma4 models were introduced in transformers-5.5.0",
                ),
            ),
            pytest.param(
                "trl-internal-testing/tiny-Inkling2ForConditionalGeneration",
                id="inkling2",
                marks=[
                    pytest.mark.skipif(
                        Version(transformers.__version__) < Version("5.23.0"),
                        reason="Inkling 2 models were introduced in transformers-5.23.0",
                    ),
                    pytest.mark.xfail(
                        reason="The tiny model's random completions never open an answer, so they all parse to the same "
                        "empty one, get the same reward and leave nothing to learn",
                        strict=True,
                    ),
                ],
            ),
            pytest.param(
                "trl-internal-testing/tiny-Inkling2LoopForConditionalGeneration",
                id="inkling2-loop",
                marks=[
                    pytest.mark.skipif(
                        Version(transformers.__version__) < Version("5.24.0"),
                        reason="Inkling 2 Mini models were introduced in transformers-5.24.0",
                    ),
                    pytest.mark.xfail(
                        raises=AssertionError,
                        reason="The tiny model's random completions never open an answer, so they all parse to the same "
                        "empty one, get the same reward and leave nothing to learn",
                        strict=True,
                    ),
                ],
            ),
            pytest.param("trl-internal-testing/tiny-InternVLForConditionalGeneration", id="internvl"),
            pytest.param("trl-internal-testing/tiny-LlavaNextForConditionalGeneration", id="llava-next"),
            pytest.param("trl-internal-testing/tiny-Qwen2_5_VLForConditionalGeneration", id="qwen2.5-vl"),
            pytest.param("trl-internal-testing/tiny-Qwen2VLForConditionalGeneration", id="qwen2-vl"),
            pytest.param(
                "trl-internal-testing/tiny-Qwen3_5ForConditionalGeneration-NoThink",
                id="qwen3.5-nothink",
                marks=pytest.mark.skipif(
                    Version(transformers.__version__) < Version("5.2.0"),
                    reason="Qwen3.5 models were introduced in transformers-5.2.0",
                ),
            ),
            pytest.param(
                "trl-internal-testing/tiny-Qwen3_5MoeForConditionalGeneration-3.6",
                id="qwen3.6-moe",
                marks=pytest.mark.skipif(
                    Version(transformers.__version__) < Version("5.2.0"),
                    reason="Qwen3.5 models were introduced in transformers-5.2.0",
                ),
            ),
            # "trl-internal-testing/tiny-SmolVLMForConditionalGeneration", seems not to support bf16 properly
        ],
    )
    def test_train_vlm(self, model_id):
        dataset = load_dataset("trl-internal-testing/zen-image", "conversational_prompt_only", split="train")

        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=2,  # VLM training is memory intensive, reduce batch size to avoid OOM
            num_generations=2,  # VLM training is memory intensive, reduce num_generations to avoid OOM
            # note: num_generations=2 is only suitable for CI testing; production training should use more generations
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            report_to="none",
        )
        trainer = GRPOTrainer(
            model=model_id,
            reward_funcs=str_length_reward,
            args=training_args,
            train_dataset=dataset,
        )

        previous_trainable_params = {n: param.clone() for n, param in trainer.model.named_parameters()}

        trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None

        # Check that the params have changed
        for n, param in previous_trainable_params.items():
            new_param = trainer.model.get_parameter(n)
            # LLaVA & LLaVA-Next: vision_feature_layer=-2 leaves the last encoder layer (layers.1) and
            # post_layernorm (pooler-only path) without gradient by design. Assert they stay frozen — if they
            # ever start training, the feature-selection plumbing has likely regressed.
            if model_id in (
                "trl-internal-testing/tiny-LlavaForConditionalGeneration",
                "trl-internal-testing/tiny-LlavaNextForConditionalGeneration",
            ) and ("encoder.layers.1" in n or "post_layernorm" in n):
                assert torch.equal(param, new_param), f"Param {n} expected frozen by LLaVA design, but changed"
            else:
                assert not torch.equal(param, new_param), f"Parameter {n} has not changed."

    def test_generation_suppresses_image_token(self):
        # Gemma3: its processor's `image_token_id` is not the placeholder token, unlike its config's
        dataset = load_dataset("trl-internal-testing/zen-image", "conversational_prompt_only", split="train")
        training_args = GRPOConfig(output_dir=self.tmp_dir, report_to="none")
        trainer = GRPOTrainer(
            model="trl-internal-testing/tiny-Gemma3ForConditionalGeneration",
            reward_funcs=str_length_reward,
            args=training_args,
            train_dataset=dataset,
        )

        assert trainer.generation_config.suppress_tokens == [trainer.model.config.image_token_id]

    def test_generation_suppresses_vision_start_token(self):
        # transformers<5.3.0 crashes when a completion ends with <|vision_start|> (see #8163)
        dataset = load_dataset("trl-internal-testing/zen-image", "conversational_prompt_only", split="train")
        training_args = GRPOConfig(output_dir=self.tmp_dir, report_to="none")
        trainer = GRPOTrainer(
            model="trl-internal-testing/tiny-Qwen2_5_VLForConditionalGeneration",
            reward_funcs=str_length_reward,
            args=training_args,
            train_dataset=dataset,
        )

        expected = [trainer.model.config.image_token_id]
        if Version(transformers.__version__) < Version("5.3.0"):
            expected.append(trainer.model.config.vision_start_token_id)
        assert trainer.generation_config.suppress_tokens == expected

    def test_train_vlm_with_pad_to_multiple_of(self):
        # Models like Gemma3 use other forward keyword arguments like token_type_ids that also need to be padded when
        # using pad_to_multiple_of, so we test that the trainer correctly pads all the necessary inputs in this case.
        dataset = load_dataset("trl-internal-testing/zen-image", "conversational_prompt_only", split="train")

        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=2,  # VLM training is memory intensive, reduce batch size to avoid OOM
            num_generations=2,  # VLM training is memory intensive, reduce num_generations to avoid OOM
            # note: num_generations=2 is only suitable for CI testing; production training should use more generations
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            pad_to_multiple_of=7,
            report_to="none",
        )
        trainer = GRPOTrainer(
            model="trl-internal-testing/tiny-Gemma3ForConditionalGeneration",
            reward_funcs=str_length_reward,
            args=training_args,
            train_dataset=dataset,
        )

        previous_trainable_params = {n: param.clone() for n, param in trainer.model.named_parameters()}

        trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None

        # Check that the params have changed
        for n, param in previous_trainable_params.items():
            new_param = trainer.model.get_parameter(n)
            assert not torch.equal(param, new_param), f"Parameter {n} has not changed."

    @pytest.mark.parametrize(
        "model_id",
        [
            pytest.param("trl-internal-testing/tiny-Qwen2_5_VLForConditionalGeneration", id="qwen2.5-vl"),
        ],
    )
    def test_train_vlm_beta_non_zero(self, model_id):
        dataset = load_dataset("trl-internal-testing/zen-image", "conversational_prompt_only", split="train")

        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            beta=0.1,  # set beta to non-zero value to test the case where the reference model is used
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=2,  # VLM training is memory intensive, reduce batch size to avoid OOM
            num_generations=2,  # VLM training is memory intensive, reduce num_generations to avoid OOM
            # note: num_generations=2 is only suitable for CI testing; production training should use more generations
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            report_to="none",
        )
        trainer = GRPOTrainer(
            model=model_id,
            reward_funcs=str_length_reward,
            args=training_args,
            train_dataset=dataset,
        )

        previous_trainable_params = {n: param.clone() for n, param in trainer.model.named_parameters()}

        trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None

        # Check that the params have changed
        for n, param in previous_trainable_params.items():
            new_param = trainer.model.get_parameter(n)
            assert not torch.equal(param, new_param), f"Parameter {n} has not changed."

    @pytest.mark.parametrize(
        "model_id",
        [
            pytest.param("trl-internal-testing/tiny-Qwen2_5_VLForConditionalGeneration", id="qwen2.5-vl"),
        ],
    )
    @require_peft
    def test_train_vlm_peft(self, model_id):
        model = AutoModelForImageTextToText.from_pretrained(model_id, dtype="float32")
        base_param_names = [f"base_model.model.{n}" for n, _ in model.named_parameters()]
        dataset = load_dataset("trl-internal-testing/zen-image", "conversational_prompt_only", split="train")

        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=2,  # VLM training is memory intensive, reduce batch size to avoid OOM
            num_generations=2,  # VLM training is memory intensive, reduce num_generations to avoid OOM
            # note: num_generations=2 is only suitable for CI testing; production training should use more generations
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            report_to="none",
        )
        trainer = GRPOTrainer(
            model=model,
            reward_funcs=str_length_reward,
            args=training_args,
            train_dataset=dataset,
            peft_config=LoraConfig(target_modules=["q_proj", "v_proj"]),
        )

        previous_trainable_params = {n: param.clone() for n, param in trainer.model.named_parameters()}

        trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None

        # Check that the peft params have changed and the base model params have not changed
        for n, param in previous_trainable_params.items():
            new_param = trainer.model.get_parameter(n)
            if n in base_param_names:  # We expect the base model params to be the same
                torch.testing.assert_close(param, new_param, msg=f"Parameter {n} has changed.")
            elif "base_layer" not in n:  # We expect the peft params to be different (except for the base layer)
                assert not torch.equal(param, new_param), f"Parameter {n} has not changed."

    @pytest.mark.parametrize(
        "model_id",
        [
            pytest.param("trl-internal-testing/tiny-Qwen2_5_VLForConditionalGeneration", id="qwen2.5-vl"),
        ],
    )
    @require_peft
    @require_bitsandbytes
    def test_train_vlm_peft_and_quantization(self, model_id):
        dataset = load_dataset("trl-internal-testing/zen-image", "conversational_prompt_only", split="train")

        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=2,  # VLM training is memory intensive, reduce batch size to avoid OOM
            num_generations=2,  # VLM training is memory intensive, reduce num_generations to avoid OOM
            # note: num_generations=2 is only suitable for CI testing; production training should use more generations
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            report_to="none",
        )
        quantization_config = BitsAndBytesConfig(
            load_in_4bit=True,
            bnb_4bit_use_double_quant=True,
            bnb_4bit_quant_type="nf4",
            bnb_4bit_compute_dtype=torch.bfloat16,
        )
        trainer = GRPOTrainer(
            model=model_id,  # pass the model as an identifier, so that the trainer applies the quantization config
            reward_funcs=str_length_reward,
            args=training_args,
            train_dataset=dataset,
            quantization_config=quantization_config,
            peft_config=LoraConfig(target_modules=["q_proj", "v_proj"]),
        )

        # Check that the trainer applied the quantization config when loading the model
        assert trainer.model.base_model.model.is_loaded_in_4bit

        previous_trainable_params = {n: param.clone() for n, param in trainer.model.named_parameters()}

        trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None

        # Check that the peft params have changed, and that they are cast to bfloat16, as recommended by the QLoRA
        # paper. The base model params are not checked: bitsandbytes casts the biases of a Linear4bit in-place during
        # the forward pass, so some of them change in a way that is unrelated to training.
        for n, param in previous_trainable_params.items():
            new_param = trainer.model.get_parameter(n)
            if "lora" in n:  # We expect the peft params to be different
                assert param.dtype == torch.bfloat16, f"Parameter {n} is not in bfloat16."
                assert not torch.equal(param, new_param), f"Parameter {n} has not changed."

    @pytest.mark.parametrize(
        "model_id",
        [
            pytest.param("trl-internal-testing/tiny-Qwen2_5_VLForConditionalGeneration", id="qwen2.5-vl"),
        ],
    )
    @require_peft
    @require_bitsandbytes
    def test_train_vlm_peft_dora_and_quantization(self, model_id):
        dataset = load_dataset("trl-internal-testing/zen-image", "conversational_prompt_only", split="train")

        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=2,  # VLM training is memory intensive, reduce batch size to avoid OOM
            num_generations=2,  # VLM training is memory intensive, reduce num_generations to avoid OOM
            # note: num_generations=2 is only suitable for CI testing; production training should use more generations
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            report_to="none",
        )
        quantization_config = BitsAndBytesConfig(
            load_in_4bit=True,
            bnb_4bit_use_double_quant=True,
            bnb_4bit_quant_type="nf4",
            bnb_4bit_compute_dtype=torch.bfloat16,
        )
        trainer = GRPOTrainer(
            model=model_id,  # pass the model as an identifier, so that the trainer applies the quantization config
            reward_funcs=str_length_reward,
            args=training_args,
            train_dataset=dataset,
            quantization_config=quantization_config,
            peft_config=LoraConfig(target_modules=["q_proj", "v_proj"], use_dora=True),
        )

        # Check that the trainer applied the quantization config when loading the model
        assert trainer.model.base_model.model.is_loaded_in_4bit

        previous_trainable_params = {n: param.clone() for n, param in trainer.model.named_parameters()}

        trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None

        # Check that the peft params have changed, and that they are cast to bfloat16, as recommended by the QLoRA
        # paper. The base model params are not checked: bitsandbytes casts the biases of a Linear4bit in-place during
        # the forward pass, so some of them change in a way that is unrelated to training.
        for n, param in previous_trainable_params.items():
            new_param = trainer.model.get_parameter(n)
            # The DoRA magnitude vector is the exception: it must stay in float32, since its optimizer updates can be
            # smaller than bfloat16 can represent, which would otherwise silently freeze it, see #7268
            if "lora_magnitude_vector" in n:
                assert param.dtype == torch.float32, f"Parameter {n} is not in float32."
                assert not torch.equal(param, new_param), f"Parameter {n} has not changed."
            elif "lora" in n:  # We expect the peft params to be different
                assert param.dtype == torch.bfloat16, f"Parameter {n} is not in bfloat16."
                assert not torch.equal(param, new_param), f"Parameter {n} has not changed."

    @pytest.mark.parametrize(
        "model_id",
        [
            pytest.param("trl-internal-testing/tiny-Qwen2_5_VLForConditionalGeneration", id="qwen2.5-vl"),
        ],
    )
    def test_train_vlm_and_importance_sampling(self, model_id):
        dataset = load_dataset("trl-internal-testing/zen-image", "conversational_prompt_only", split="train")

        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=2,  # VLM training is memory intensive, reduce batch size to avoid OOM
            num_generations=2,  # VLM training is memory intensive, reduce num_generations to avoid OOM
            # note: num_generations=2 is only suitable for CI testing; production training should use more generations
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            steps_per_generation=2,  # increase the steps per generation to trigger IS
            report_to="none",
        )
        trainer = GRPOTrainer(
            model=model_id,
            reward_funcs=str_length_reward,
            args=training_args,
            train_dataset=dataset,
        )

        previous_trainable_params = {n: param.clone() for n, param in trainer.model.named_parameters()}

        trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None

        # Check that the params have changed
        for n, param in previous_trainable_params.items():
            new_param = trainer.model.get_parameter(n)
            assert not torch.equal(param, new_param), f"Parameter {n} has not changed."

    @pytest.mark.parametrize(
        "model_id",
        [
            pytest.param("trl-internal-testing/tiny-Qwen2_5_VLForConditionalGeneration", id="qwen2.5-vl"),
            pytest.param("trl-internal-testing/tiny-Gemma3ForConditionalGeneration", id="gemma3"),
            pytest.param(
                "trl-internal-testing/tiny-Gemma4ForConditionalGeneration",
                id="gemma4",
                marks=pytest.mark.skipif(
                    Version(transformers.__version__) < Version("5.5.0"),
                    reason="Gemma4 models were introduced in transformers-5.5.0",
                ),
            ),
            pytest.param(
                "trl-internal-testing/tiny-Inkling2ForConditionalGeneration",
                id="inkling2",
                marks=pytest.mark.skipif(
                    Version(transformers.__version__) < Version("5.23.0"),
                    reason="Inkling 2 models were introduced in transformers-5.23.0",
                ),
            ),
            pytest.param(
                "trl-internal-testing/tiny-Inkling2LoopForConditionalGeneration",
                id="inkling2-loop",
                marks=pytest.mark.skipif(
                    Version(transformers.__version__) < Version("5.24.0"),
                    reason="Inkling 2 Mini models were introduced in transformers-5.24.0",
                ),
            ),
        ],
    )
    @require_vllm
    @pytest.mark.skip(reason="We should add a mock for the vLLM server.")
    def test_train_vlm_and_vllm(self, model_id) -> None:
        dataset = load_dataset("trl-internal-testing/zen-image", "conversational_prompt_only", split="train")

        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=2,  # VLM training is memory intensive, reduce batch size to avoid OOM
            num_generations=2,  # VLM training is memory intensive, reduce num_generations to avoid OOM
            # note: num_generations=2 is only suitable for CI testing; production training should use more generations
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            report_to="none",
            use_vllm=True,
            vllm_mode="server",
        )
        trainer = GRPOTrainer(
            model=model_id,
            reward_funcs=str_length_reward,
            args=training_args,
            train_dataset=dataset,
        )

        previous_trainable_params = {n: param.clone() for n, param in trainer.model.named_parameters()}

        trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None

        for n, param in previous_trainable_params.items():
            new_param = trainer.model.get_parameter(n)
            assert not torch.equal(param, new_param), f"Parameter {n} has not changed."

    @require_vllm
    @require_torch_accelerator
    def test_vllm_generation_suppresses_image_token(self):
        # A sampled image placeholder token would make the forward pass over prompt + completion fail
        model_id = "HuggingFaceTB/SmolVLM-256M-Instruct"  # tiny models are too small for vLLM
        image_token_id = AutoConfig.from_pretrained(model_id).image_token_id
        dataset = load_dataset("trl-internal-testing/zen-image", "conversational_prompt_only", split="train")
        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            report_to="none",
            use_vllm=True,
            vllm_mode="colocate",
            max_steps=1,
            per_device_train_batch_size=3,
            num_generations=3,
            max_completion_length=8,
            # Leave only the image token and one the model ranks far below it, so an unsuppressed run samples it
            generation_kwargs={"allowed_token_ids": [image_token_id, 43476]},
        )
        trainer = GRPOTrainer(
            model=model_id,
            reward_funcs=str_length_reward,
            args=training_args,
            train_dataset=dataset,
        )

        trainer.train()

    @pytest.mark.parametrize(
        "model_id",
        [
            pytest.param("trl-internal-testing/tiny-Idefics3ForConditionalGeneration", id="idefics3"),
            pytest.param("trl-internal-testing/tiny-LlavaForConditionalGeneration", id="llava"),
            pytest.param("trl-internal-testing/tiny-LlavaNextForConditionalGeneration", id="llava-next"),
            pytest.param("trl-internal-testing/tiny-Qwen2_5_VLForConditionalGeneration", id="qwen2.5-vl"),
        ],
    )
    def test_train_vlm_multi_image(self, model_id):
        dataset = load_dataset("trl-internal-testing/zen-multi-image", "conversational_prompt_only", split="train")

        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=2,  # VLM training is memory intensive, reduce batch size to avoid OOM
            num_generations=2,  # VLM training is memory intensive, reduce num_generations to avoid OOM
            # note: num_generations=2 is only suitable for CI testing; production training should use more generations
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            report_to="none",
        )
        trainer = GRPOTrainer(
            model=model_id,
            reward_funcs=str_length_reward,
            args=training_args,
            train_dataset=dataset,
        )
        # Some samples have no image: their batches leave the vision tower without gradients
        assert trainer.args.ddp_find_unused_parameters

        previous_trainable_params = {n: param.clone() for n, param in trainer.model.named_parameters()}

        trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None

        for n, param in previous_trainable_params.items():
            new_param = trainer.model.get_parameter(n)
            # LLaVA & LLaVA-Next: vision_feature_layer=-2 leaves the last encoder layer (layers.1) and
            # post_layernorm (pooler-only path) without gradient by design. Assert they stay frozen — if they
            # ever start training, the feature-selection plumbing has likely regressed.
            if model_id in (
                "trl-internal-testing/tiny-LlavaForConditionalGeneration",
                "trl-internal-testing/tiny-LlavaNextForConditionalGeneration",
            ) and ("encoder.layers.1" in n or "post_layernorm" in n):
                assert torch.equal(param, new_param), f"Param {n} expected frozen by LLaVA design, but changed"
            else:
                assert not torch.equal(param, new_param), f"Parameter {n} has not changed."

    def test_train_vlm_log_multimodal_false(self):
        dataset = load_dataset("trl-internal-testing/zen-image", "conversational_prompt_only", split="train")

        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            per_device_train_batch_size=2,  # VLM training is memory intensive, reduce batch size to avoid OOM
            num_generations=2,  # VLM training is memory intensive, reduce num_generations to avoid OOM
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            report_to="none",
            log_completions=True,
            log_multimodal=False,
        )
        trainer = GRPOTrainer(
            model="trl-internal-testing/tiny-Gemma3ForConditionalGeneration",
            reward_funcs=str_length_reward,
            args=training_args,
            train_dataset=dataset,
        )
        trainer.train()
        assert len(trainer._logs["images"]) == 0

    @pytest.mark.xfail(
        condition=Version(transformers.__version__) < Version("5.2.0"),
        reason="Qwen3.5 models were introduced in transformers-5.2.0",
        strict=True,
    )
    @require_response_parsing
    def test_train_with_tools_multimodal_response(self):
        # Test that tools returning images (multimodal responses) work correctly with a VLM.
        # The tool returns a list of content blocks including an image.
        dataset = load_dataset("trl-internal-testing/zen-image", "conversational_prompt_only", split="train")

        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=2,  # VLM training is memory intensive, reduce batch size to avoid OOM
            num_generations=2,  # VLM training is memory intensive, reduce num_generations to avoid OOM
            # note: num_generations=2 is only suitable for CI testing; production training should use more generations
            max_completion_length=512,
            report_to="none",
        )
        trainer = GRPOTrainer(
            model="trl-internal-testing/tiny-Qwen3_5ForConditionalGeneration-NoThink",
            reward_funcs=str_length_reward,
            args=training_args,
            train_dataset=dataset,
            tools=[screenshot_image_tool],
        )

        previous_trainable_params = {n: param.clone() for n, param in trainer.model.named_parameters()}

        script = ScriptedTurns(
            trainer.processing_class.tokenizer,
            first_turns=[
                "<tool_call>\n<function=screenshot_image_tool>\n</function>\n</tool_call><|im_end|>",
                "I don't know any tool<|im_end|>",
            ],
        )

        def generate(input_ids, **kwargs):
            if input_ids.shape[0] == 1:  # the turn after the tool call
                # The prompt's image and the one the tool returned
                assert kwargs["image_grid_thw"].shape[0] == 2
            return script.generate(input_ids, **kwargs)

        with patch.object(trainer.model, "generate", generate):
            trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None
        # With num_generations=2: 1 out of 2 completions is a tool call (1/2), and it succeeds (0 failures).
        assert trainer.state.log_history[-1]["tools/call_frequency"] == pytest.approx(1 / 2)
        assert trainer.state.log_history[-1]["tools/failure_frequency"] == pytest.approx(0.0)

        # Check that the params have changed
        for n, param in previous_trainable_params.items():
            new_param = trainer.model.get_parameter(n)
            assert not torch.equal(param, new_param), f"Parameter {n} has not changed."

    @pytest.mark.xfail(
        condition=Version(transformers.__version__) < Version("5.2.0"),
        reason="Qwen3.5 models were introduced in transformers-5.2.0",
        strict=True,
    )
    @require_response_parsing
    def test_train_with_tools_text_response_multimodal_prompt(self):
        # Test that tools returning text (non-multimodal response) work correctly with a VLM prompt having images.
        dataset = load_dataset("trl-internal-testing/zen-image", "conversational_prompt_only", split="train")

        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            learning_rate=0.1,
            per_device_train_batch_size=2,
            num_generations=2,
            max_completion_length=512,
            report_to="none",
        )
        trainer = GRPOTrainer(
            model="trl-internal-testing/tiny-Qwen3_5ForConditionalGeneration-NoThink",
            reward_funcs=str_length_reward,
            args=training_args,
            train_dataset=dataset,
            tools=[screenshot_tool],
        )

        previous_trainable_params = {n: param.clone() for n, param in trainer.model.named_parameters()}

        script = ScriptedTurns(
            trainer.processing_class.tokenizer,
            first_turns=[
                "<tool_call>\n<function=screenshot_tool>\n</function>\n</tool_call><|im_end|>",
                "I don't know any tool<|im_end|>",
            ],
        )

        def generate(input_ids, **kwargs):
            if input_ids.shape[0] == 1:  # the turn after the tool call
                # The prompt's image only: the tool returned text
                assert kwargs["image_grid_thw"].shape[0] == 1
            return script.generate(input_ids, **kwargs)

        with patch.object(trainer.model, "generate", generate):
            trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None
        assert trainer.state.log_history[-1]["tools/call_frequency"] == pytest.approx(1 / 2)
        assert trainer.state.log_history[-1]["tools/failure_frequency"] == pytest.approx(0.0)

        for n, param in previous_trainable_params.items():
            new_param = trainer.model.get_parameter(n)
            assert not torch.equal(param, new_param), f"Parameter {n} has not changed."

    @pytest.mark.skipif(
        not _SUPPORTS_RESPONSE_TEMPLATE,
        reason="Gemma 4 response parsing is only provided as a new-style response template, which requires transformers>=5.13",
    )
    @require_response_parsing
    @pytest.mark.parametrize("eos_token", ["<eos>", "<turn|>"])
    def test_train_with_tools_gemma4(self, eos_token):
        # Gemma 4 ends a tool call with `<|tool_response>` and a turn with `<turn|>`, not with its tokenizer's eos
        dataset = load_dataset("trl-internal-testing/zen-image", "conversational_prompt_only", split="train")

        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=2,  # VLM training is memory intensive, reduce batch size to avoid OOM
            num_generations=2,  # VLM training is memory intensive, reduce num_generations to avoid OOM
            max_completion_length=512,
            report_to="none",
        )
        processor = AutoProcessor.from_pretrained("trl-internal-testing/tiny-Gemma4ForConditionalGeneration")
        # Gemma 4's eos is `<eos>`, but fine-tuned copies may set it to `<turn|>`, e.g. `SFTConfig(eos_token="<turn|>")`
        processor.tokenizer.eos_token = eos_token
        trainer = GRPOTrainer(
            model="trl-internal-testing/tiny-Gemma4ForConditionalGeneration",
            reward_funcs=str_length_reward,
            args=training_args,
            train_dataset=dataset,
            processing_class=processor,
            tools=[screenshot_tool],
        )

        previous_trainable_params = {n: param.clone() for n, param in trainer.model.named_parameters()}

        script = ScriptedTurns(
            trainer.processing_class.tokenizer,
            first_turns=[
                "<|tool_call>call:screenshot_tool{}<tool_call|><|tool_response>",
                "I don't know any tool<turn|>",
            ],
            after_tool="Done!<turn|>",
            tool_response_marker="<tool_response|>",
        )

        def generate(input_ids, **kwargs):
            if input_ids.shape[0] == 1:  # the turn after the tool call
                # The tool result follows the model's only tool call
                assert processor.tokenizer.decode(input_ids[0]).count("<|tool_call>") == 1
            return script.generate(input_ids, **kwargs)

        with patch.object(trainer.model, "generate", generate):
            trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None
        assert trainer.state.log_history[-1]["tools/call_frequency"] == pytest.approx(1 / 2)
        assert trainer.state.log_history[-1]["tools/failure_frequency"] == pytest.approx(0.0)
        # Both completions end on one of Gemma 4's eos ids, so none is clipped
        assert trainer.state.log_history[-1]["completions/clipped_ratio"] == 0.0

        for n, param in previous_trainable_params.items():
            new_param = trainer.model.get_parameter(n)
            assert not torch.equal(param, new_param), f"Parameter {n} has not changed."

    @pytest.mark.skipif(
        not _SUPPORTS_RESPONSE_TEMPLATE,
        reason="DeepSeek-V3 response parsing is only provided as a new-style response template, which requires transformers>=5.13",
    )
    @require_response_parsing
    def test_train_with_tools_deepseekv3(self):
        # DeepSeek-V3's template only renders string tool-call arguments, so the trainer must swap in the training one
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")

        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=2,  # reduce the batch size to reduce memory usage
            num_generations=2,  # reduce the number of generations to reduce memory usage
            max_completion_length=128,
            report_to="none",
        )
        trainer = GRPOTrainer(
            model="trl-internal-testing/tiny-DeepseekV3ForCausalLM",
            reward_funcs=str_length_reward,
            args=training_args,
            train_dataset=dataset,
            tools=[multiply_tool],
        )

        previous_trainable_params = {n: param.clone() for n, param in trainer.model.named_parameters()}

        script = ScriptedTurns(
            trainer.processing_class,
            first_turns=[
                "</think>\n\n<｜tool▁calls▁begin｜><｜tool▁call▁begin｜>function<｜tool▁sep｜>multiply_tool\n```json\n"
                '{"a": 3, "b": 4}\n```<｜tool▁call▁end｜><｜tool▁calls▁end｜><｜end▁of▁sentence｜>',
                "</think>\n\nI don't know any tool<｜end▁of▁sentence｜>",
            ],
            after_tool="Done!<｜end▁of▁sentence｜>",
            tool_response_marker="<｜tool▁output▁begin｜>",
        )
        with patch.object(trainer.model, "generate", script.generate):
            trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None
        assert trainer.state.log_history[-1]["tools/call_frequency"] == pytest.approx(1 / 2)
        assert trainer.state.log_history[-1]["tools/failure_frequency"] == pytest.approx(0.0)

        for n, param in previous_trainable_params.items():
            new_param = trainer.model.get_parameter(n)
            assert not torch.equal(param, new_param), f"Parameter {n} has not changed."

    @pytest.mark.skipif(
        not _SUPPORTS_RESPONSE_TEMPLATE,
        reason="DeepSeek-V3 response parsing is only provided as a new-style response template, which requires transformers>=5.13",
    )
    @require_response_parsing
    def test_train_with_tools_deepseekv3_0528(self):
        # DeepSeek-R1-0528's template only renders string tool-call arguments, so the trainer must swap in the training
        # one, and its generation prompt doesn't pre-fill `<think>`, so the model opens it itself
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")

        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=2,  # reduce the batch size to reduce memory usage
            num_generations=2,  # reduce the number of generations to reduce memory usage
            max_completion_length=128,
            report_to="none",
        )
        trainer = GRPOTrainer(
            model="trl-internal-testing/tiny-DeepseekV3ForCausalLM-0528",
            # Reward must vary across completions, otherwise GRPO advantages are all zero and no parameters update
            reward_funcs=lambda completions, **kwargs: [float(len(str(c))) for c in completions],
            args=training_args,
            train_dataset=dataset,
            tools=[multiply_tool],
        )

        previous_trainable_params = {n: param.clone() for n, param in trainer.model.named_parameters()}

        def fake_generate(input_ids, **kwargs):
            if input_ids.shape[0] == 2:  # first call
                # fmt: off
                completion_ids = torch.tensor(
                    [
                        # '<think>\n\n</think>\n\n<｜tool▁calls▁begin｜><｜tool▁call▁begin｜>function<｜tool▁sep｜>multiply_tool\n```json\n{"a": 3, "b": 4}\n```<｜tool▁call▁end｜><｜tool▁calls▁end｜><｜end▁of▁sentence｜>'
                        [128798, 271, 128799, 271, 128806, 128808, 8701, 128814, 16640, 29717, 3682, 1458, 201, 9854, 14479, 201, 24313, 67, 3362, 223, 21, 14, 582, 68, 3362, 223, 22, 1778, 9854, 128809, 128807, 1],
                        # "<think>\n\n</think>\n\nI don't know any tool<｜end▁of▁sentence｜>" + padding
                        [128798, 271, 128799, 271, 43, 2090, 1664, 1153, 1117, 4105, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
                    ],
                    device=input_ids.device,
                )
                # fmt: on
            else:  # second call: 1 tool call succeeded
                completion_ids = torch.tensor(
                    [
                        # 'Done!<｜end▁of▁sentence｜>'
                        [68520, 3, 1],
                    ],
                    device=input_ids.device,
                )
            return torch.cat([input_ids, completion_ids], dim=-1)

        with patch.object(trainer.model, "generate", side_effect=fake_generate):
            trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None
        assert trainer.state.log_history[-1]["tools/call_frequency"] == pytest.approx(1 / 2)
        assert trainer.state.log_history[-1]["tools/failure_frequency"] == pytest.approx(0.0)

        for n, param in previous_trainable_params.items():
            new_param = trainer.model.get_parameter(n)
            assert not torch.equal(param, new_param), f"Parameter {n} has not changed."

    @pytest.mark.skipif(
        not _SUPPORTS_RESPONSE_TEMPLATE,
        reason="DeepSeek-V3.1 response parsing is only provided as a new-style response template, which requires transformers>=5.13",
    )
    @require_response_parsing
    def test_train_with_tools_deepseekv3_v5(self):
        # DeepSeek-V3.1's template only renders string tool-call arguments, so the trainer must swap in the training one
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")
        tokenizer = AutoTokenizer.from_pretrained("trl-internal-testing/tiny-DeepseekV3ForCausalLM")
        tokenizer.chat_template = deepseekv3_v5_chat_template  # DeepSeek-V3.1 has no tiny model of its own

        training_args = GRPOConfig(
            output_dir=self.tmp_dir,
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=2,  # reduce the batch size to reduce memory usage
            num_generations=2,  # reduce the number of generations to reduce memory usage
            max_completion_length=128,
            report_to="none",
        )
        trainer = GRPOTrainer(
            model="trl-internal-testing/tiny-DeepseekV3ForCausalLM",
            # Reward must vary across completions, otherwise GRPO advantages are all zero and no parameters update
            reward_funcs=lambda completions, **kwargs: [float(len(str(c))) for c in completions],
            args=training_args,
            train_dataset=dataset,
            processing_class=tokenizer,
            tools=[multiply_tool],
        )

        previous_trainable_params = {n: param.clone() for n, param in trainer.model.named_parameters()}

        def fake_generate(input_ids, **kwargs):
            if input_ids.shape[0] == 2:  # first call
                # fmt: off
                completion_ids = torch.tensor(
                    [
                        # '<｜tool▁calls▁begin｜><｜tool▁call▁begin｜>multiply_tool<｜tool▁sep｜>{"a": 3, "b": 4}<｜tool▁call▁end｜><｜tool▁calls▁end｜><｜end▁of▁sentence｜>'
                        [128806, 128808, 16640, 29717, 3682, 1458, 128814, 24313, 67, 3362, 223, 21, 14, 582, 68, 3362, 223, 22, 95, 128809, 128807, 1],
                        # "I don't know any tool<｜end▁of▁sentence｜>" + padding
                        [43, 2090, 1664, 1153, 1117, 4105, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
                    ],
                    device=input_ids.device,
                )
                # fmt: on
            else:  # second call: 1 tool call succeeded
                completion_ids = torch.tensor(
                    [
                        # 'Done!<｜end▁of▁sentence｜>'
                        [68520, 3, 1],
                    ],
                    device=input_ids.device,
                )
            return torch.cat([input_ids, completion_ids], dim=-1)

        with patch.object(trainer.model, "generate", side_effect=fake_generate):
            trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None
        assert trainer.state.log_history[-1]["tools/call_frequency"] == pytest.approx(1 / 2)
        assert trainer.state.log_history[-1]["tools/failure_frequency"] == pytest.approx(0.0)

        for n, param in previous_trainable_params.items():
            new_param = trainer.model.get_parameter(n)
            assert not torch.equal(param, new_param), f"Parameter {n} has not changed."
