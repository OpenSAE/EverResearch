# Copyright 2020-2026 The HuggingFace Team. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# Same model class as peft_qwen3_for_causal_lm.py, with different (random) LoRA weights.

from peft import LoraConfig, get_peft_model
from transformers import Qwen3ForCausalLM

from .._common import SEED, check_transformers_version, push_to_hub, set_seed, smoke_test


check_transformers_version()

# A different seed from peft_qwen3_for_causal_lm.py, so this adapter's weights differ from that one's.
set_seed(SEED + 1)

BASE = "trl-internal-testing/tiny-Qwen3ForCausalLM"

model = Qwen3ForCausalLM.from_pretrained(BASE, dtype="auto")
# Otherwise lora_B is zeroed and the adapter is the identity.
model = get_peft_model(model, LoraConfig(init_lora_weights=False))
smoke_test(model, None)
push_to_hub(model, None, None, "tiny", "2")
