# Copyright 2020-2026 The HuggingFace Team. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import glob
import json
import os
import subprocess
from types import SimpleNamespace
from unittest.mock import patch

import pytest
import torch
from accelerate import Accelerator
from safetensors.torch import load_file
from transformers import (
    AutoModelForCausalLM,
    AutoProcessor,
    AutoTokenizer,
    BitsAndBytesConfig,
    is_bitsandbytes_available,
)
from transformers.testing_utils import backend_device_count, torch_device
from transformers.utils import is_peft_available

from trl.generation.vllm_client import (
    _DEFAULT_GENERATION_CONCURRENCY,
    VLLMClient,
    parse_generate_logprobs,
    parse_logprobs,
)
from trl.generation.vllm_generation import VLLMGeneration, extract_logprobs
from trl.import_utils import is_requests_available, is_vllm_available

from .testing_utils import (
    TrlTestCase,
    kill_process,
    require_3_accelerators,
    require_bitsandbytes,
    require_peft,
    require_requests,
    require_torch_multi_accelerator,
    require_vision,
    require_vllm,
)


if is_bitsandbytes_available():
    import bitsandbytes as bnb

if is_peft_available():
    from peft import LoraConfig, get_peft_model
    from peft.tuners.lora import LoraLayer

if is_requests_available():
    import requests


if is_vllm_available():
    from vllm import LLM, SamplingParams

# The `vllm serve` settings required by TRL, as documented in the vLLM integration guide.
VLLM_SERVE_TRL_ARGS = [
    "--weight-transfer-config",
    '{"backend": "nccl"}',
    "--logprobs-mode",
    "processed_logprobs",
    "--max-logprobs",
    "-1",
    # vLLM's default 0.9 leaves a 24 GB GPU too little room for the weight-sync receive buffers
    "--gpu-memory-utilization",
    "0.5",
]
# From vLLM 0.30.0, the multimodal endpoints are only served with this flag, which earlier versions reject.
if is_vllm_available(min_version="0.30.0"):
    VLLM_SERVE_TRL_ARGS.append("--enable-scale-out")
# From vLLM 0.34.0, the KV cache is sized after warmup by default, which leaves too little of half a 24 GB GPU for it
if is_vllm_available(min_version="0.34.0"):
    VLLM_SERVE_TRL_ARGS.append("--disable-extensible-kv-cache")


@require_requests
class TestConnectionPoolSize(TrlTestCase):
    @pytest.mark.parametrize("scheme", ["http", "https"])
    def test_pool_capacity_covers_default_concurrency(self, scheme):
        with (
            patch("trl.generation.vllm_client.is_vllm_available", return_value=True),
            patch.object(VLLMClient, "check_server"),
            patch.object(VLLMClient, "_get", return_value={"data": [{"id": "test-model"}]}),
        ):
            client = VLLMClient(host="127.0.0.1")

        with client.session:
            url = f"{scheme}://127.0.0.1:8000"
            adapter = client.session.get_adapter(url)
            pool = adapter.poolmanager.connection_from_url(url)
            # Retain enough connections for the default generation concurrency.
            assert pool.pool.maxsize >= _DEFAULT_GENERATION_CONCURRENCY


@require_requests
class TestResetPrefixCache(TrlTestCase):
    def test_empty_response_body(self):
        # Before vLLM 0.26.0 (vllm-project/vllm#46893), `/reset_prefix_cache` answers with an empty body.
        response = requests.Response()
        response.status_code = 200
        response._content = b""
        with (
            patch("trl.generation.vllm_client.is_vllm_available", return_value=True),
            patch.object(VLLMClient, "check_server"),
            patch.object(VLLMClient, "_get", return_value={"data": [{"id": "test-model"}]}),
        ):
            client = VLLMClient(host="127.0.0.1")

        with (
            patch("trl.generation.vllm_client._HAS_RESET_PREFIX_CACHE_SUCCESS", False),
            patch.object(client.session, "post", return_value=response),
        ):
            client.reset_prefix_cache()


@require_requests
class TestMissingServerSettings(TrlTestCase):
    @staticmethod
    def make_client():
        with (
            patch("trl.generation.vllm_client.is_vllm_available", return_value=True),
            patch.object(VLLMClient, "check_server"),
            patch.object(VLLMClient, "_get", return_value={"data": [{"id": "test-model"}]}),
        ):
            return VLLMClient(host="127.0.0.1")

    @staticmethod
    def make_response(status_code, body=None):
        response = requests.Response()
        response.status_code = status_code
        response._content = json.dumps(body).encode() if body is not None else b""
        return response

    def server_info(self, weight_transfer_config):
        return self.make_response(200, {"vllm_config": {"weight_transfer_config": weight_transfer_config}})

    def test_get_server_info(self):
        client = self.make_client()
        response = self.server_info(weight_transfer_config={"backend": "nccl"})
        with patch.object(client.session, "get", return_value=response):
            assert client.get_server_info() == {"weight_transfer_config": {"backend": "nccl"}}

    def test_init_communicator_without_dev_mode(self):
        client = self.make_client()
        with patch.object(client.session, "get", return_value=self.make_response(404)):
            with pytest.raises(RuntimeError, match="VLLM_SERVER_DEV_MODE=1"):
                client.init_communicator()

    def test_init_communicator_without_weight_transfer_config(self):
        client = self.make_client()
        response = self.server_info(weight_transfer_config=None)
        with patch.object(client.session, "get", return_value=response):
            with pytest.raises(RuntimeError, match="--weight-transfer-config"):
                client.init_communicator()

    @require_vision
    def test_image_features_without_scale_out(self):
        from PIL import Image

        client = self.make_client()
        with patch.object(client.session, "post", return_value=self.make_response(404)):
            with pytest.raises(RuntimeError, match="--enable-scale-out"):
                client.image_features([[Image.new("RGB", (8, 8))]])


class TestParseLogprobs(TrlTestCase):
    def test_completion_logprobs_sorted_by_probability(self):
        logprobs = {
            "tokens": ["token_id:11", "token_id:5"],
            "token_logprobs": [-0.2, -1.1],
            "top_logprobs": [{"token_id:11": -0.2, "token_id:99": -0.1}, {"token_id:5": -1.1}],
        }

        all_logprobs, all_token_ids = parse_logprobs([logprobs])

        assert all_token_ids == [[[99, 11], [5]]]
        assert all_logprobs == [[[-0.1, -0.2], [-1.1]]]

    def test_chat_logprobs(self):
        logprobs = {
            "content": [
                {
                    "token": "token_id:7",
                    "logprob": -0.5,
                    "top_logprobs": [
                        {"token": "token_id:7", "logprob": -0.5},
                        {"token": "token_id:3", "logprob": -0.4},
                    ],
                }
            ]
        }

        all_logprobs, all_token_ids = parse_logprobs([logprobs])

        assert all_token_ids == [[[3, 7]]]
        assert all_logprobs == [[[-0.4, -0.5]]]

    def test_returns_none_when_logprobs_missing(self):
        assert parse_logprobs([None]) == (None, None)


class TestParseGenerateLogprobs(TrlTestCase):
    def test_generate_logprobs_sorted_by_probability(self):
        logprobs = {
            "content": [
                {
                    "token_id": 7,
                    "logprob": -0.5,
                    "rank": 2,
                    "top_logprobs": [
                        {"token_id": 7, "logprob": -0.5, "rank": 2},
                        {"token_id": 3, "logprob": -0.4, "rank": 1},
                    ],
                }
            ]
        }

        all_logprobs, all_token_ids = parse_generate_logprobs([logprobs])

        assert all_token_ids == [[[3, 7]]]
        assert all_logprobs == [[[-0.4, -0.5]]]

    def test_returns_none_when_logprobs_missing(self):
        assert parse_generate_logprobs([None]) == (None, None)


class TestExtractLogprobs(TrlTestCase):
    def test_extract_logprobs_sorts_by_rank_and_replaces_nan(self):
        all_outputs = [
            SimpleNamespace(
                outputs=[
                    SimpleNamespace(
                        logprobs=[
                            {
                                11: SimpleNamespace(rank=1, logprob=-0.2),
                                99: SimpleNamespace(rank=0, logprob=-0.1),
                                42: SimpleNamespace(rank=2, logprob=float("nan")),
                            },
                            {
                                5: SimpleNamespace(rank=0, logprob=-1.1),
                            },
                        ]
                    )
                ]
            ),
            SimpleNamespace(
                outputs=[
                    SimpleNamespace(
                        logprobs=[
                            {
                                3: SimpleNamespace(rank=1, logprob=-0.5),
                                7: SimpleNamespace(rank=0, logprob=-0.4),
                            }
                        ]
                    )
                ]
            ),
        ]

        all_logprobs, all_token_ids = extract_logprobs(all_outputs)

        assert all_token_ids == [
            [[99, 11, 42], [5]],
            [[7, 3]],
        ]
        assert all_logprobs == [
            [[-0.1, -0.2, None], [-1.1]],
            [[-0.4, -0.5]],
        ]

    def test_extract_logprobs_returns_none_token_ids_when_logprobs_missing(self):
        all_outputs = [SimpleNamespace(outputs=[SimpleNamespace(logprobs=None)])]

        all_logprobs, all_token_ids = extract_logprobs(all_outputs)

        assert all_logprobs is None
        assert all_token_ids is None


@require_torch_multi_accelerator
@require_vllm
@pytest.mark.xdist_group("vllm_server")
class TestVLLMClientServer(TrlTestCase):
    model_id = "Qwen/Qwen2.5-1.5B"

    @classmethod
    def setup_class(cls):
        # We want the server to run on accelerator 1, so we set VISIBLE_DEVICES to "1"
        env = os.environ.copy()
        VISIBLE_DEVICES = "ZE_AFFINITY_MASK" if torch_device == "xpu" else "CUDA_VISIBLE_DEVICES"
        env[VISIBLE_DEVICES] = "1"  # Restrict to accelerator 1
        env["VLLM_SERVER_DEV_MODE"] = "1"

        # Start the server process
        cls.server_process = subprocess.Popen(["vllm", "serve", cls.model_id, *VLLM_SERVE_TRL_ARGS], env=env)

        # Initialize the client
        cls.client = VLLMClient(connection_timeout=240, host="localhost")
        cls.client.init_communicator()

    def test_generate(self):
        prompts = ["Hello, AI!", "Tell me a joke"]
        outputs = self.client.generate(prompts)
        prompt_ids = outputs["prompt_ids"]
        completion_ids = outputs["completion_ids"]

        # Check that the outputs are lists
        assert isinstance(prompt_ids, list)
        assert isinstance(completion_ids, list)

        # Check that the number of sequences are equal to the number of prompts
        assert len(prompt_ids) == len(prompts)
        assert len(completion_ids) == len(prompts)

        # Check that the sequences are lists of integers
        for seq in prompt_ids:
            assert all(isinstance(tok, int) for tok in seq)
        for seq in completion_ids:
            assert all(isinstance(tok, int) for tok in seq)

    def test_generate_with_logprobs_none(self):
        outputs = self.client.generate(["Hello, AI!"], logprobs=None)

        assert isinstance(outputs["prompt_ids"], list)
        assert isinstance(outputs["completion_ids"], list)
        assert outputs["logprobs"] is None
        assert outputs["logprob_token_ids"] is None

    def test_chat(self):
        messages = [[{"role": "user", "content": "Hello, AI!"}], [{"role": "user", "content": "Tell me a joke"}]]
        outputs = self.client.chat(messages)
        prompt_ids = outputs["prompt_ids"]
        completion_ids = outputs["completion_ids"]

        # Check that the outputs are lists
        assert isinstance(prompt_ids, list)
        assert isinstance(completion_ids, list)

        # Check that the number of sequences are equal to the number of messages
        assert len(prompt_ids) == len(messages)
        assert len(completion_ids) == len(messages)

        # Check that the sequences are lists of integers
        for seq in prompt_ids:
            assert all(isinstance(tok, int) for tok in seq)
        for seq in completion_ids:
            assert all(isinstance(tok, int) for tok in seq)

    def test_chat_with_logprobs_none(self):
        outputs = self.client.chat([[{"role": "user", "content": "Hello, AI!"}]], logprobs=None)

        assert isinstance(outputs["prompt_ids"], list)
        assert isinstance(outputs["completion_ids"], list)
        assert outputs["logprobs"] is None
        assert outputs["logprob_token_ids"] is None

    def test_chat_with_tools(self):
        def multiply(a: int, b: int) -> int:
            """
            Multiplies two integers.

            Args:
                a: The first integer.
                b: The second integer.

            Returns:
                The product of the two integers.
            """
            return a * b

        messages = [[{"role": "user", "content": "What is 3 multiplied by 4?"}]]
        outputs = self.client.chat(messages, tools=[multiply])

        # Decode prompt and check that "Multiplies two integers." is in the prompt.
        tokenizer = AutoTokenizer.from_pretrained(self.model_id)
        decoded_prompt = tokenizer.decode(outputs["prompt_ids"][0])
        assert "Multiplies two integers." in decoded_prompt

    def test_generate_with_token_ids(self):
        tokenizer = AutoTokenizer.from_pretrained(self.model_id)
        prompts = ["Hello, AI!", "Tell me a joke"]
        prompt_token_ids = tokenizer(prompts)["input_ids"]
        outputs = self.client.generate(prompt_token_ids)
        prompt_ids = outputs["prompt_ids"]
        completion_ids = outputs["completion_ids"]

        # Check that the outputs are lists
        assert isinstance(prompt_ids, list)
        assert isinstance(completion_ids, list)

        # Check that the number of sequences are equal to the number of prompts
        assert len(prompt_ids) == len(prompts)
        assert len(completion_ids) == len(prompts)

        # Check that prompt_ids match the input token IDs
        assert prompt_ids == prompt_token_ids

        # Check that the sequences are lists of integers
        for seq in prompt_ids:
            assert all(isinstance(tok, int) for tok in seq)
        for seq in completion_ids:
            assert all(isinstance(tok, int) for tok in seq)

    def test_generate_with_params(self):
        prompts = ["Hello, AI!", "Tell me a joke"]
        completion_ids = self.client.generate(prompts, n=2, repetition_penalty=0.9, temperature=0.8, max_tokens=32)[
            "completion_ids"
        ]

        # Check that the output is a list
        assert isinstance(completion_ids, list)

        # Check that the number of generated sequences is 2 times the number of prompts
        assert len(completion_ids) == 2 * len(prompts)

        # Check that the generated sequences are lists of integers
        for seq in completion_ids:
            assert all(isinstance(tok, int) for tok in seq)

        # Check that the length of the generated sequences is less than or equal to 32
        for seq in completion_ids:
            assert len(seq) <= 32

    def test_update_model_params(self):
        model = AutoModelForCausalLM.from_pretrained(self.model_id, device_map=torch_device)
        self.client.update_model_params(model)

    def test_reset_prefix_cache(self):
        # Test resetting the prefix cache
        self.client.reset_prefix_cache()

    @pytest.mark.xfail(reason="Importing `bitsandbytes` causes issues, see vllm-project/vllm#32793")
    def test_logprobs_match_with_non_default_sampling(self):
        prompts = ["Hello, AI!", "Tell me a joke"]
        # Use non-default sampling parameters (especially temperature) to ensure vLLM applies logprob processing. With
        # default sampling, raw and processed logprobs are identical, so mismatches would not be detected.
        temperature = 0.7
        repetition_penalty = 1.05
        top_p = 0.9
        max_tokens = 8
        seed = 1234
        num_logprobs = 5

        server_outputs = self.client.generate(
            prompts,
            temperature=temperature,
            repetition_penalty=repetition_penalty,
            top_p=top_p,
            max_tokens=max_tokens,
            logprobs=num_logprobs,
            generation_kwargs={"seed": seed},
        )
        os.environ["VLLM_WORKER_MULTIPROC_METHOD"] = "spawn"
        llm = LLM(
            model=self.model_id,
            tensor_parallel_size=1,
            gpu_memory_utilization=0.2,
            max_model_len=128,
            logprobs_mode="processed_logprobs",
        )

        sampling_params = SamplingParams(
            temperature=temperature,
            repetition_penalty=repetition_penalty,
            top_p=top_p,
            max_tokens=max_tokens,
            logprobs=num_logprobs,
            seed=seed,
        )
        colocate_outputs = llm.generate(prompts, sampling_params=sampling_params, use_tqdm=False)
        colocate_prompt_ids = [output.prompt_token_ids for output in colocate_outputs]
        colocate_completion_ids = [
            list(output.token_ids) for outputs in colocate_outputs for output in outputs.outputs
        ]
        colocate_logprobs, colocate_logprob_token_ids = extract_logprobs(colocate_outputs)

        # Generation correctness: prompt and completion IDs match between server and colocate
        assert server_outputs["prompt_ids"] == colocate_prompt_ids
        assert server_outputs["completion_ids"] == colocate_completion_ids

        server_logprobs = server_outputs["logprobs"]
        server_logprob_token_ids = server_outputs["logprob_token_ids"]

        # Shape: both should be (num_sequences, seq_len, num_logprobs) with multiple logprobs per token
        assert len(server_logprobs) == len(prompts)
        assert len(server_logprob_token_ids) == len(prompts)
        for seq_lps in server_logprobs:
            for token_lps in seq_lps:
                assert len(token_lps) > 1, "Expected multiple logprobs per token when logprobs > 0"

        # Value correctness: server extraction matches colocate extraction via extract_logprobs
        assert server_logprob_token_ids == colocate_logprob_token_ids
        for server_seq, colocate_seq in zip(server_logprobs, colocate_logprobs, strict=True):
            assert len(server_seq) == len(colocate_seq)
            for server_token_lps, colocate_token_lps in zip(server_seq, colocate_seq, strict=True):
                assert server_token_lps == pytest.approx(colocate_token_lps, rel=1e-6, abs=1e-6)

        # Ordering: logprobs at each position should be sorted descending
        for seq_lps in server_logprobs:
            for token_lps in seq_lps:
                assert token_lps == sorted(token_lps, reverse=True), "Logprobs should be sorted descending"

        # Sampled token presence: the actual completion token should appear in the logprob token IDs
        for seq_idx, (completion_seq, token_ids_seq) in enumerate(
            zip(server_outputs["completion_ids"], server_logprob_token_ids, strict=True)
        ):
            for pos, (sampled_id, lp_ids) in enumerate(zip(completion_seq, token_ids_seq, strict=True)):
                assert sampled_id in lp_ids, (
                    f"Sampled token {sampled_id} not found in logprob token IDs {lp_ids} "
                    f"at sequence {seq_idx}, position {pos}"
                )

    @classmethod
    def teardown_class(cls):
        # Close the client
        cls.client.close_communicator()

        # vLLM x pytest (or Popen) seems not to handle process termination well. To avoid zombie processes, we need to
        # kill the server process and its children explicitly.
        kill_process(cls.server_process)


@require_torch_multi_accelerator
@pytest.mark.skipif(
    not is_vllm_available(min_version="0.30.0"),
    reason="`/inference/v1/generate`, which returns the candidate sets, needs `--enable-scale-out` (vLLM >= 0.30)",
)
@pytest.mark.xdist_group("vllm_server")
class TestVLLMClientServerSamplingMask(TrlTestCase):
    model_id = "Qwen/Qwen2.5-1.5B"

    @classmethod
    def setup_class(cls):
        env = os.environ.copy()
        VISIBLE_DEVICES = "ZE_AFFINITY_MASK" if torch_device == "xpu" else "CUDA_VISIBLE_DEVICES"
        env[VISIBLE_DEVICES] = "1"  # Restrict to accelerator 1
        env["VLLM_SERVER_DEV_MODE"] = "1"
        cls.server_process = subprocess.Popen(
            ["vllm", "serve", cls.model_id, *VLLM_SERVE_TRL_ARGS, "--return-sampling-mask"], env=env
        )
        cls.client = VLLMClient(connection_timeout=240, host="localhost")

    def test_generate_with_sampling_mask(self):
        tokenizer = AutoTokenizer.from_pretrained(self.model_id)
        prompt_token_ids = tokenizer(["Hello, AI!", "Tell me a joke"])["input_ids"]
        outputs = self.client.generate(prompt_token_ids, n=2, top_k=10, max_tokens=8, return_sampling_mask=True)

        assert len(outputs["sampling_mask"]) == len(outputs["completion_ids"]) == 4
        for completion_ids, sampling_mask in zip(outputs["completion_ids"], outputs["sampling_mask"], strict=True):
            assert len(sampling_mask) == len(completion_ids)
            for token_id, candidates in zip(completion_ids, sampling_mask, strict=True):
                assert token_id in candidates
                assert len(candidates) <= 10

    @classmethod
    def teardown_class(cls):
        kill_process(cls.server_process)


# Same as above but using base_url to instantiate the client.
@require_torch_multi_accelerator
@require_vllm
@pytest.mark.xdist_group("vllm_server")
class TestVLLMClientServerBaseURL(TrlTestCase):
    model_id = "Qwen/Qwen2.5-1.5B"

    @classmethod
    def setup_class(cls):
        # We want the server to run on accelerator 1, so we set VISIBLE_DEVICES to "1"
        env = os.environ.copy()
        VISIBLE_DEVICES = "ZE_AFFINITY_MASK" if torch_device == "xpu" else "CUDA_VISIBLE_DEVICES"
        env[VISIBLE_DEVICES] = "1"  # Restrict to accelerator 1
        env["VLLM_SERVER_DEV_MODE"] = "1"

        # Start the server process
        cls.server_process = subprocess.Popen(["vllm", "serve", cls.model_id, *VLLM_SERVE_TRL_ARGS], env=env)

        # Initialize the client
        cls.client = VLLMClient(base_url="http://localhost:8000", connection_timeout=240)
        cls.client.init_communicator()

    def test_generate(self):
        prompts = ["Hello, AI!", "Tell me a joke"]
        outputs = self.client.generate(prompts)
        prompt_ids = outputs["prompt_ids"]
        completion_ids = outputs["completion_ids"]

        # Check that the outputs are lists
        assert isinstance(prompt_ids, list)
        assert isinstance(completion_ids, list)

        # Check that the number of sequences are equal to the number of prompts
        assert len(prompt_ids) == len(prompts)
        assert len(completion_ids) == len(prompts)

        # Check that the sequences are lists of integers
        for seq in prompt_ids:
            assert all(isinstance(tok, int) for tok in seq)
        for seq in completion_ids:
            assert all(isinstance(tok, int) for tok in seq)

    def test_generate_with_logprobs_none(self):
        outputs = self.client.generate(["Hello, AI!"], logprobs=None)

        assert isinstance(outputs["prompt_ids"], list)
        assert isinstance(outputs["completion_ids"], list)
        assert outputs["logprobs"] is None
        assert outputs["logprob_token_ids"] is None

    def test_chat(self):
        messages = [[{"role": "user", "content": "Hello, AI!"}], [{"role": "user", "content": "Tell me a joke"}]]
        outputs = self.client.chat(messages)
        prompt_ids = outputs["prompt_ids"]
        completion_ids = outputs["completion_ids"]

        # Check that the outputs are lists
        assert isinstance(prompt_ids, list)
        assert isinstance(completion_ids, list)

        # Check that the number of sequences are equal to the number of messages
        assert len(prompt_ids) == len(messages)
        assert len(completion_ids) == len(messages)

        # Check that the sequences are lists of integers
        for seq in prompt_ids:
            assert all(isinstance(tok, int) for tok in seq)
        for seq in completion_ids:
            assert all(isinstance(tok, int) for tok in seq)

    def test_chat_with_logprobs_none(self):
        outputs = self.client.chat([[{"role": "user", "content": "Hello, AI!"}]], logprobs=None)

        assert isinstance(outputs["prompt_ids"], list)
        assert isinstance(outputs["completion_ids"], list)
        assert outputs["logprobs"] is None
        assert outputs["logprob_token_ids"] is None

    def test_chat_with_tools(self):
        def multiply(a: int, b: int) -> int:
            """
            Multiplies two integers.

            Args:
                a: The first integer.
                b: The second integer.

            Returns:
                The product of the two integers.
            """
            return a * b

        messages = [[{"role": "user", "content": "What is 3 multiplied by 4?"}]]
        outputs = self.client.chat(messages, tools=[multiply])

        # Decode prompt and check that "Multiplies two integers." is in the prompt.
        tokenizer = AutoTokenizer.from_pretrained(self.model_id)
        decoded_prompt = tokenizer.decode(outputs["prompt_ids"][0])
        assert "Multiplies two integers." in decoded_prompt

    def test_generate_with_token_ids(self):
        tokenizer = AutoTokenizer.from_pretrained(self.model_id)
        prompts = ["Hello, AI!", "Tell me a joke"]
        prompt_token_ids = tokenizer(prompts)["input_ids"]
        outputs = self.client.generate(prompt_token_ids)
        prompt_ids = outputs["prompt_ids"]
        completion_ids = outputs["completion_ids"]

        # Check that the outputs are lists
        assert isinstance(prompt_ids, list)
        assert isinstance(completion_ids, list)

        # Check that the number of sequences are equal to the number of prompts
        assert len(prompt_ids) == len(prompts)
        assert len(completion_ids) == len(prompts)

        # Check that prompt_ids match the input token IDs
        assert prompt_ids == prompt_token_ids

        # Check that the sequences are lists of integers
        for seq in prompt_ids:
            assert all(isinstance(tok, int) for tok in seq)
        for seq in completion_ids:
            assert all(isinstance(tok, int) for tok in seq)

    def test_generate_with_params(self):
        prompts = ["Hello, AI!", "Tell me a joke"]
        completion_ids = self.client.generate(prompts, n=2, repetition_penalty=0.9, temperature=0.8, max_tokens=32)[
            "completion_ids"
        ]

        # Check that the output is a list
        assert isinstance(completion_ids, list)

        # Check that the number of generated sequences is 2 times the number of prompts
        assert len(completion_ids) == 2 * len(prompts)

        # Check that the generated sequences are lists of integers
        for seq in completion_ids:
            assert all(isinstance(tok, int) for tok in seq)

        # Check that the length of the generated sequences is less than or equal to 32
        for seq in completion_ids:
            assert len(seq) <= 32

    def test_update_model_params(self):
        model = AutoModelForCausalLM.from_pretrained(self.model_id, device_map=torch_device)
        self.client.update_model_params(model)

    def test_reset_prefix_cache(self):
        # Test resetting the prefix cache
        self.client.reset_prefix_cache()

    @classmethod
    def teardown_class(cls):
        # Close the client
        cls.client.close_communicator()

        # vLLM x pytest (or Popen) seems not to handle process termination well. To avoid zombie processes, we need to
        # kill the server process and its children explicitly.
        kill_process(cls.server_process)


@require_3_accelerators
@require_vllm
@pytest.mark.xdist_group("vllm_server")
class TestVLLMClientServerTP(TrlTestCase):
    model_id = "Qwen/Qwen2.5-1.5B"

    @classmethod
    def setup_class(cls):
        # We want the server to run on accelerator 1 and 2, so we set VISIBLE_DEVICES to "1,2"
        env = os.environ.copy()
        VISIBLE_DEVICES = "ZE_AFFINITY_MASK" if torch_device == "xpu" else "CUDA_VISIBLE_DEVICES"
        env[VISIBLE_DEVICES] = "1,2"  # Restrict to accelerator 1 and 2
        env["VLLM_SERVER_DEV_MODE"] = "1"

        # Start the server process
        cls.server_process = subprocess.Popen(
            ["vllm", "serve", cls.model_id, "--tensor-parallel-size", "2", *VLLM_SERVE_TRL_ARGS],
            env=env,
        )

        # Initialize the client
        cls.client = VLLMClient(connection_timeout=240, host="localhost")
        cls.client.init_communicator()

    def test_generate(self):
        prompts = ["Hello, AI!", "Tell me a joke"]
        outputs = self.client.generate(prompts)
        prompt_ids = outputs["prompt_ids"]
        completion_ids = outputs["completion_ids"]

        # Check that the outputs are lists
        assert isinstance(prompt_ids, list)
        assert isinstance(completion_ids, list)

        # Check that the number of sequences are equal to the number of prompts
        assert len(prompt_ids) == len(prompts)
        assert len(completion_ids) == len(prompts)

        # Check that the sequences are lists of integers
        for seq in prompt_ids:
            assert all(isinstance(tok, int) for tok in seq)
        for seq in completion_ids:
            assert all(isinstance(tok, int) for tok in seq)

    def test_generate_with_logprobs_none(self):
        outputs = self.client.generate(["Hello, AI!"], logprobs=None)

        assert isinstance(outputs["prompt_ids"], list)
        assert isinstance(outputs["completion_ids"], list)
        assert outputs["logprobs"] is None
        assert outputs["logprob_token_ids"] is None

    def test_chat(self):
        messages = [[{"role": "user", "content": "Hello, AI!"}], [{"role": "user", "content": "Tell me a joke"}]]
        outputs = self.client.chat(messages)
        prompt_ids = outputs["prompt_ids"]
        completion_ids = outputs["completion_ids"]

        # Check that the outputs are lists
        assert isinstance(prompt_ids, list)
        assert isinstance(completion_ids, list)

        # Check that the number of sequences are equal to the number of messages
        assert len(prompt_ids) == len(messages)
        assert len(completion_ids) == len(messages)

        # Check that the sequences are lists of integers
        for seq in prompt_ids:
            assert all(isinstance(tok, int) for tok in seq)
        for seq in completion_ids:
            assert all(isinstance(tok, int) for tok in seq)

    def test_chat_with_logprobs_none(self):
        outputs = self.client.chat([[{"role": "user", "content": "Hello, AI!"}]], logprobs=None)

        assert isinstance(outputs["prompt_ids"], list)
        assert isinstance(outputs["completion_ids"], list)
        assert outputs["logprobs"] is None
        assert outputs["logprob_token_ids"] is None

    def test_chat_with_tools(self):
        def multiply(a: int, b: int) -> int:
            """
            Multiplies two integers.

            Args:
                a: The first integer.
                b: The second integer.

            Returns:
                The product of the two integers.
            """
            return a * b

        messages = [[{"role": "user", "content": "What is 3 multiplied by 4?"}]]
        outputs = self.client.chat(messages, tools=[multiply])

        # Decode prompt and check that "Multiplies two integers." is in the prompt.
        tokenizer = AutoTokenizer.from_pretrained(self.model_id)
        decoded_prompt = tokenizer.decode(outputs["prompt_ids"][0])
        assert "Multiplies two integers." in decoded_prompt

    def test_generate_with_token_ids(self):
        tokenizer = AutoTokenizer.from_pretrained(self.model_id)
        prompts = ["Hello, AI!", "Tell me a joke"]
        prompt_token_ids = tokenizer(prompts)["input_ids"]
        outputs = self.client.generate(prompt_token_ids)
        prompt_ids = outputs["prompt_ids"]
        completion_ids = outputs["completion_ids"]

        # Check that the outputs are lists
        assert isinstance(prompt_ids, list)
        assert isinstance(completion_ids, list)

        # Check that the number of sequences are equal to the number of prompts
        assert len(prompt_ids) == len(prompts)
        assert len(completion_ids) == len(prompts)

        # Check that prompt_ids match the input token IDs
        assert prompt_ids == prompt_token_ids

        # Check that the sequences are lists of integers
        for seq in prompt_ids:
            assert all(isinstance(tok, int) for tok in seq)
        for seq in completion_ids:
            assert all(isinstance(tok, int) for tok in seq)

    def test_generate_with_params(self):
        prompts = ["Hello, AI!", "Tell me a joke"]
        completion_ids = self.client.generate(prompts, n=2, repetition_penalty=0.9, temperature=0.8, max_tokens=32)[
            "completion_ids"
        ]

        # Check that the output is a list
        assert isinstance(completion_ids, list)

        # Check that the number of generated sequences is 2 times the number of prompts
        assert len(completion_ids) == 2 * len(prompts)

        # Check that the generated sequences are lists of integers
        for seq in completion_ids:
            assert all(isinstance(tok, int) for tok in seq)

        # Check that the length of the generated sequences is less than or equal to 32
        for seq in completion_ids:
            assert len(seq) <= 32

    def test_update_model_params(self):
        model = AutoModelForCausalLM.from_pretrained(self.model_id, device_map=torch_device)
        self.client.update_model_params(model)

    def test_reset_prefix_cache(self):
        # Test resetting the prefix cache
        self.client.reset_prefix_cache()

    @classmethod
    def teardown_class(cls):
        # Close the client
        cls.client.close_communicator()

        # vLLM x pytest (or Popen) seems not to handle process termination well. To avoid zombie processes, we need to
        # kill the server process and its children explicitly.
        kill_process(cls.server_process)


@require_torch_multi_accelerator
@require_vllm
@pytest.mark.xdist_group("vllm_server")
class TestVLLMClientServerDeviceParameter(TrlTestCase):
    """Test the device parameter functionality in init_communicator."""

    model_id = "Qwen/Qwen2.5-1.5B"

    @classmethod
    def setup_class(cls):
        # We want the server to run on accelerator 1, so we set VISIBLE_DEVICES to "1"
        env = os.environ.copy()
        VISIBLE_DEVICES = "ZE_AFFINITY_MASK" if torch_device == "xpu" else "CUDA_VISIBLE_DEVICES"
        env[VISIBLE_DEVICES] = "1"  # Restrict to accelerator 1
        env["VLLM_SERVER_DEV_MODE"] = "1"

        # Start the server process
        cls.server_process = subprocess.Popen(["vllm", "serve", cls.model_id, *VLLM_SERVE_TRL_ARGS], env=env)

    def test_init_communicator_with_device_int(self):
        """Test init_communicator with integer device parameter."""
        client = VLLMClient(connection_timeout=240, host="localhost")
        client.init_communicator(device=0)  # Explicitly specify device 0

        # Test basic functionality
        prompts = ["Hello, AI!"]
        outputs = client.generate(prompts)
        prompt_ids = outputs["prompt_ids"]
        completion_ids = outputs["completion_ids"]
        assert isinstance(prompt_ids, list)
        assert len(prompt_ids) == len(prompts)
        assert isinstance(completion_ids, list)
        assert len(completion_ids) == len(prompts)

        client.close_communicator()

    def test_init_communicator_with_device_string(self):
        """Test init_communicator with string device parameter."""
        client = VLLMClient(connection_timeout=240, host="localhost")
        client.init_communicator(device=0)  # Explicitly specify device as string

        # Test basic functionality
        prompts = ["Hello, AI!"]
        outputs = client.generate(prompts)["completion_ids"]
        assert isinstance(outputs, list)
        assert len(outputs) == len(prompts)

        client.close_communicator()

    def test_init_communicator_with_torch_device(self):
        """Test init_communicator with torch.device object."""
        import torch

        client = VLLMClient(connection_timeout=240, host="localhost")
        device = torch.device(0)
        client.init_communicator(device=device)  # Explicitly specify torch.device object

        # Test basic functionality
        prompts = ["Hello, AI!"]
        outputs = client.generate(prompts)["completion_ids"]
        assert isinstance(outputs, list)
        assert len(outputs) == len(prompts)

        client.close_communicator()

    @classmethod
    def teardown_class(cls):
        # vLLM x pytest (or Popen) seems not to handle process termination well. To avoid zombie processes, we need to
        # kill the server process and its children explicitly.
        kill_process(cls.server_process)


@require_peft
@require_torch_multi_accelerator
@require_vllm
@pytest.mark.xdist_group("vllm_server")
class TestVLLMClientServerPEFT(TrlTestCase):
    model_id = "Qwen/Qwen2.5-0.5B-Instruct"

    @classmethod
    def setup_class(cls):
        # We want the server to run on accelerator 1, so we set VISIBLE_DEVICES to "1"
        env = os.environ.copy()
        VISIBLE_DEVICES = "ZE_AFFINITY_MASK" if torch_device == "xpu" else "CUDA_VISIBLE_DEVICES"
        env[VISIBLE_DEVICES] = "1"  # Restrict to accelerator 1
        env["VLLM_SERVER_DEV_MODE"] = "1"

        # Start the server process
        cls.server_process = subprocess.Popen(["vllm", "serve", cls.model_id, *VLLM_SERVE_TRL_ARGS], env=env)

    @pytest.mark.parametrize("load_in_4bit", [False, pytest.param(True, marks=require_bitsandbytes)])
    def test_sync_weights_sends_merged_lora_weights(self, load_in_4bit):
        quantization_config = (
            BitsAndBytesConfig(load_in_4bit=True, bnb_4bit_compute_dtype=torch.bfloat16) if load_in_4bit else None
        )
        model = AutoModelForCausalLM.from_pretrained(
            self.model_id, dtype=torch.float32, quantization_config=quantization_config, device_map=torch_device
        )
        # Non-zero adapters, so that the merged weights differ from the base ones
        model = get_peft_model(model, LoraConfig(target_modules=["o_proj", "down_proj"], init_lora_weights=False))
        tokenizer = AutoTokenizer.from_pretrained(self.model_id)
        vllm_generation = VLLMGeneration(model, Accelerator(), tokenizer, mode="server", server_host="localhost")

        # The weights the server must hold: the base weights, dequantized if 4-bit, with the LoRA deltas merged in, in
        # the server's dtype
        expected = {}
        with torch.no_grad():
            for name, module in model.named_modules():
                if isinstance(module, LoraLayer):
                    weight = module.get_base_layer().weight
                    if load_in_4bit:
                        weight = bnb.functional.dequantize_4bit(weight.data, weight.quant_state)
                    merged = weight + module.get_delta_weight("default")
                    expected[name.removeprefix("base_model.model.") + ".weight"] = merged.to(torch.bfloat16).cpu()

        vllm_generation.sync_weights()
        # A mixed-precision forward pass between two syncs, as in training: bitsandbytes casts the biases of a 4-bit
        # layer to the input dtype in place in it
        with torch.no_grad(), torch.autocast(torch_device, dtype=torch.bfloat16):
            model(**tokenizer("Hello, AI!", return_tensors="pt").to(torch_device))
        vllm_generation.sync_weights()
        vllm_generation.vllm_client.close_communicator()

        # Read the weights back from the server
        response = requests.post(
            "http://localhost:8000/collective_rpc", json={"method": "save_sharded_state", "args": [self.tmp_dir]}
        )
        response.raise_for_status()
        received = {}
        for path in glob.glob(os.path.join(self.tmp_dir, "*.safetensors")):
            received.update(load_file(path))
        for name, weight in expected.items():
            assert torch.equal(received[name], weight), f"The server holds a {name} that is not the merged weight."

    @classmethod
    def teardown_class(cls):
        # vLLM x pytest (or Popen) seems not to handle process termination well. To avoid zombie processes, we need to
        # kill the server process and its children explicitly.
        kill_process(cls.server_process)


@require_vllm
@require_vision
@pytest.mark.xdist_group("vllm_server")
class TestVLLMClientServerVLM(TrlTestCase):
    model_id = "Qwen/Qwen2.5-VL-3B-Instruct"

    @classmethod
    def setup_class(cls):
        # Run the server on the last visible accelerator, since the test process may hold memory on the first one
        env = os.environ.copy()
        VISIBLE_DEVICES = "ZE_AFFINITY_MASK" if torch_device == "xpu" else "CUDA_VISIBLE_DEVICES"
        env[VISIBLE_DEVICES] = str(backend_device_count(torch_device) - 1)
        env["VLLM_SERVER_DEV_MODE"] = "1"

        # Start the server process, with smaller images and context so its memory profiling fits a 24 GB GPU
        args = ["--mm-processor-kwargs", '{"max_pixels": 1003520}', "--max-model-len", "4096"]
        cls.server_process = subprocess.Popen(["vllm", "serve", cls.model_id, *VLLM_SERVE_TRL_ARGS, *args], env=env)

        # Initialize the client (no communicator needed for generation-only tests)
        cls.client = VLLMClient(connection_timeout=240, host="localhost")

    def test_generate_from_token_ids_and_images(self):
        """Images alongside token IDs: process the images, then generate from the trainer's own tokenization."""
        from PIL import Image

        processor = AutoProcessor.from_pretrained(self.model_id)
        image = Image.new("RGB", (64, 64), color="blue")
        messages = [
            [
                {
                    "role": "user",
                    "content": [{"type": "image", "image": image}, {"type": "text", "text": "What colour is it?"}],
                }
            ]
        ]
        prompt_ids = processor.apply_chat_template(
            conversation=messages, add_generation_prompt=True, tokenize=True, return_dict=True
        )["input_ids"][0]
        prompt_ids = prompt_ids.tolist() if hasattr(prompt_ids, "tolist") else list(prompt_ids)

        features = self.client.image_features([[image]])
        outputs = self.client.generate(prompts=[prompt_ids], features=features, n=2, max_tokens=16)

        assert len(outputs["completion_ids"]) == 2
        assert outputs["prompt_ids"] == [prompt_ids]
        assert all(isinstance(tok, int) for tok in outputs["completion_ids"][0])

        # Continuing from a longer sequence reuses the same features, as the tool calling loop does
        continued = [prompt_ids + outputs["completion_ids"][0] + [151644, 872, 198]]
        outputs = self.client.generate(prompts=continued, features=features, n=2, max_tokens=16)

        assert len(outputs["completion_ids"]) == 2

    def test_generate_from_token_ids_without_images(self):
        """`None` entries let a batch mix multimodal and text-only prompts."""
        from PIL import Image

        processor = AutoProcessor.from_pretrained(self.model_id)
        image = Image.new("RGB", (64, 64), color="red")
        messages = [
            [{"role": "user", "content": [{"type": "image", "image": image}, {"type": "text", "text": "Colour?"}]}]
        ]
        image_prompt_ids = processor.apply_chat_template(
            conversation=messages, add_generation_prompt=True, tokenize=True, return_dict=True
        )["input_ids"][0]
        image_prompt_ids = image_prompt_ids.tolist() if hasattr(image_prompt_ids, "tolist") else list(image_prompt_ids)
        text_ids = processor.tokenizer("The capital of France is", add_special_tokens=False).input_ids

        features = self.client.image_features([[image], None])
        outputs = self.client.generate(prompts=[image_prompt_ids, text_ids], features=features, max_tokens=8)

        assert features[1] is None
        assert len(outputs["completion_ids"]) == 2

    def test_chat_with_images(self):
        from PIL import Image

        image1 = Image.new("RGB", (64, 64), color="red")
        image2 = Image.new("RGB", (64, 64), color="blue")
        image3 = Image.new("RGB", (64, 64), color="green")
        messages = [
            [
                {
                    "role": "user",
                    "content": [
                        {"type": "image", "image": image1},
                        {"type": "image", "image": image2},
                        {"type": "text", "text": "What are the differences between these two images?"},
                    ],
                }
            ],
            [
                {
                    "role": "user",
                    "content": [
                        {"type": "image", "image": image3},
                        {"type": "text", "text": "What is the color of this image?"},
                    ],
                }
            ],
        ]
        outputs = self.client.chat(messages, max_tokens=64)
        prompt_ids = outputs["prompt_ids"]
        completion_ids = outputs["completion_ids"]

        assert len(prompt_ids) == 2
        assert len(completion_ids) == 2
        assert all(isinstance(tok, int) for tok in prompt_ids[0])
        assert all(isinstance(tok, int) for tok in completion_ids[0])

    def test_chat_with_mixed_images(self):
        """Test a batch where one prompt has an image and the other does not."""
        from PIL import Image

        image = Image.new("RGB", (64, 64), color="red")
        messages = [
            [
                {
                    "role": "user",
                    "content": [{"type": "image", "image": image}, {"type": "text", "text": "Describe this image."}],
                }
            ],
            [
                {
                    "role": "user",
                    "content": [{"type": "text", "text": "What is 1+1?"}],
                }
            ],
        ]
        outputs = self.client.chat(messages, max_tokens=64)
        prompt_ids = outputs["prompt_ids"]
        completion_ids = outputs["completion_ids"]

        assert len(prompt_ids) == 2
        assert len(completion_ids) == 2
        assert all(isinstance(tok, int) for tok in prompt_ids[0])
        assert all(isinstance(tok, int) for tok in prompt_ids[1])
        assert all(isinstance(tok, int) for tok in completion_ids[0])
        assert all(isinstance(tok, int) for tok in completion_ids[1])

    @classmethod
    def teardown_class(cls):
        kill_process(cls.server_process)
