# Copyright 2020-2026 The HuggingFace Team. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import contextlib
import threading
import time
from collections import Counter

import torch
from accelerate.logging import get_logger

from ..import_utils import is_vllm_available
from .async_vllm_client import AsyncVLLMClient


if is_vllm_available():
    from vllm.utils.network_utils import get_ip, get_open_port

# vLLM 0.28.0 (vllm-project/vllm#50902) replaced the static `NCCLWeightTransferEngine.trainer_init` /
# `trainer_send_weights` with a stateful trainer engine and moved `packed` from the per-update info to the init info.
# The rendezvous and packed-broadcast helpers the statics were built on are still exposed, so they are called directly.
_HAS_STATEFUL_TRAINER_ENGINE = is_vllm_available(min_version="0.28.0")
if _HAS_STATEFUL_TRAINER_ENGINE:
    from vllm.distributed.weight_transfer.nccl_common import trainer_init as open_trainer_endpoint
    from vllm.distributed.weight_transfer.packed_tensor import packed_nccl_broadcast_producer
elif is_vllm_available():
    from vllm.distributed.weight_transfer.nccl_engine import NCCLTrainerSendWeightsArgs, NCCLWeightTransferEngine


logger = get_logger(__name__)


class WeightTransferClient:
    """Streams the trainer's weights into the vLLM server over NCCL.

    Each transfer runs its NCCL side on a daemon thread while the HTTP request that drives the server stays on the main
    thread: NCCL has no timeout and cannot be interrupted, so a failure surfaces as the HTTP error rather than a hang,
    and the abandoned thread dies with the process.

    Args:
        vllm_client ([`AsyncVLLMClient`]):
            Client for the vLLM server that receives the weights.
        weight_update_info (`dict`):
            Names, dtypes and shapes of the parameters to send. The server sizes its receive buffers from it, so it
            must describe exactly what [`send_weights`] streams.
        compute_dtype (`str`, *optional*):
            Dtype the trainer's forward runs in under mixed precision (`"bfloat16"` or `"float16"`). The server's dtype
            is checked against it rather than against the fp32 master weights.
    """

    def __init__(
        self,
        vllm_client: AsyncVLLMClient,
        weight_update_info: dict,
        compute_dtype: str | None = None,
    ):
        if not is_vllm_available():
            raise ImportError("vLLM is required to use WeightTransferClient. Install it with: pip install vllm")
        self.vllm = vllm_client
        self.compute_dtype = compute_dtype
        self._weight_update_info = weight_update_info
        if not _HAS_STATEFUL_TRAINER_ENGINE:
            self._weight_update_info = {**weight_update_info, "packed": True}
        self.model_update_group = None

    def init_weight_transfer(self) -> None:
        self.vllm.wait_for_server_ready()
        # Trainer and server precisions should agree: the precision gap between the two biases the importance ratio
        # https://huggingface.co/papers/2510.26788
        train_dtype = self.compute_dtype or Counter(self._weight_update_info["dtype_names"]).most_common(1)[0][0]
        vllm_dtype = self.vllm.get_dtype().removeprefix("torch.")
        if vllm_dtype != train_dtype:
            logger.warning(
                f"The vLLM server serves in {vllm_dtype} but the trainer computes in {train_dtype}. Set `dtype` (or "
                f"`bf16`/`fp16`) in `AsyncGRPOConfig` to match, or start the server with `--dtype {train_dtype}`."
            )
        inference_world_size = self.vllm.get_world_size()
        world_size = inference_world_size + 1
        master_address = get_ip()
        master_port = get_open_port()
        init_info = {
            "master_address": master_address,
            "master_port": master_port,
            "rank_offset": 1,
            "world_size": world_size,
        }
        if _HAS_STATEFUL_TRAINER_ENGINE:
            init_info["packed"] = True

        error: list[BaseException] = []

        def trainer_init():
            try:
                if _HAS_STATEFUL_TRAINER_ENGINE:
                    self.model_update_group = open_trainer_endpoint(init_info)
                else:
                    self.model_update_group = NCCLWeightTransferEngine.trainer_init(init_info)
            except BaseException as exc:  # noqa: BLE001
                error.append(exc)

        thread = threading.Thread(target=trainer_init, daemon=True)
        thread.start()
        try:
            self.vllm.init_weight_transfer_engine(init_info)
            thread.join()
            if error:
                raise error[0]
        except Exception as exc:
            raise RuntimeError(
                f"Failed to set up the NCCL weight-transfer group with the vLLM server at {self.vllm.server_url}. "
                "Check that the server was started with `VLLM_SERVER_DEV_MODE=1` and "
                '`--weight-transfer-config \'{"backend":"nccl"}\'`, and that the trainer can reach it on the '
                "port it advertises."
            ) from exc
        logger.info("Initialised weight-transfer NCCL group with vLLM")

    def send_weights(self, iterator) -> None:
        if self.model_update_group is None:
            return
        t0 = time.time()
        # Prepare the workers for the reload; must complete before any weights are sent.
        self.vllm.start_weight_update()
        # The manifest is collected before FSDP2 upcasts low-precision parameters to fp32, and the server sizes its
        # receive buffers from it, so each tensor is sent in the dtype the manifest declares.
        dtypes = [getattr(torch, dtype_name) for dtype_name in self._weight_update_info["dtype_names"]]
        iterator = ((name, tensor.to(dtype)) for (name, tensor), dtype in zip(iterator, dtypes, strict=True))

        error: list[BaseException] = []

        def trainer_send_weights():
            try:
                if _HAS_STATEFUL_TRAINER_ENGINE:
                    packed_nccl_broadcast_producer(
                        iterator=iterator, group=self.model_update_group, src=0, post_iter_func=lambda item: item[1]
                    )
                else:
                    NCCLWeightTransferEngine.trainer_send_weights(
                        iterator=iterator,
                        trainer_args=NCCLTrainerSendWeightsArgs(group=self.model_update_group, packed=True),
                    )
            except BaseException as exc:  # noqa: BLE001
                error.append(exc)

        thread = threading.Thread(target=trainer_send_weights, daemon=True)
        thread.start()
        try:
            self.vllm.update_weights(self._weight_update_info)
            thread.join()
            if error:
                raise error[0]
        except Exception as exc:
            # Best-effort: a failure to clean up must not mask the error below.
            with contextlib.suppress(Exception):
                self.vllm.finish_weight_update()
            raise RuntimeError(
                f"Weight sync to the vLLM server at {self.vllm.server_url} failed. The server keeps the partially "
                "updated weights but stays paused, and a new run re-sends every parameter at start-up. If the "
                "underlying error is a CUDA OOM on the server, restart it with a lower `--gpu-memory-utilization`: "
                "receiving a transfer needs a few GB of headroom on top of the weights and the KV cache."
            ) from exc
        self.vllm.finish_weight_update()
        logger.debug(f"[weight_sync] send_weights took {time.time() - t0:.1f}s")

    def pause(self) -> None:
        t0 = time.time()
        self.vllm.pause()
        logger.debug(f"[weight_sync] pause HTTP took {time.time() - t0:.1f}s")

    def resume(self) -> None:
        t0 = time.time()
        self.vllm.resume()
        logger.debug(f"[weight_sync] resume HTTP took {time.time() - t0:.1f}s")

    def destroy(self) -> None:
        if self.model_update_group is None:
            return
        self.model_update_group.group.store = None
        self.model_update_group.group.socket = None
        self.model_update_group = None
