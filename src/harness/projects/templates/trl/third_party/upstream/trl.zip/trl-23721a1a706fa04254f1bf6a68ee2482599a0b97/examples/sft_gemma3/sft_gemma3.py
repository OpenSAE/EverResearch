# Copyright 2020-2026 The HuggingFace Team. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# /// script
# dependencies = [
#     "trl",
#     "Pillow",
#     "trackio",
#     "kernels",
# ]
# ///

"""
Train Gemma-3 on the Codeforces COTS dataset.

torchrun --nproc_per_node 8 examples/sft_gemma3/sft_gemma3.py
"""

from datasets import load_dataset
from transformers import AutoModelForImageTextToText

from trl import SFTConfig, SFTTrainer


def main():
    # Load dataset
    train_dataset = load_dataset("open-r1/codeforces-cots", split="train")
    train_dataset = train_dataset.remove_columns("prompt")

    # Created before the model, so that DeepSpeed ZeRO-3 partitions the weights while they load
    model_id = "google/gemma-3-12b-it"
    training_args = SFTConfig(
        output_dir=f"{model_id}-codeforces-SFT",
        bf16=True,
        max_length=8192,
        per_device_train_batch_size=1,
        gradient_accumulation_steps=8,
        dataset_num_proc=32,
        num_train_epochs=1,
        deepspeed="examples/deepspeed_configs/zero3.json",
    )

    # Load model
    model = AutoModelForImageTextToText.from_pretrained(model_id, attn_implementation="eager", use_kernels=True)

    # Train model
    trainer = SFTTrainer(
        args=training_args,
        model=model,
        train_dataset=train_dataset,
    )
    trainer.train()

    # Push to hub
    trainer.push_to_hub(dataset_name="open-r1/codeforces-cots")

    trainer.end()


if __name__ == "__main__":
    main()
