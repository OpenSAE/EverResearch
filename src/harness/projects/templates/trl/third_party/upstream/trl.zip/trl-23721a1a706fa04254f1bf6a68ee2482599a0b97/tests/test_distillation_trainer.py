# Copyright 2020-2026 The HuggingFace Team. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import json
import os
from collections import defaultdict
from unittest.mock import patch

import pytest
import torch
import torch.nn.functional as F
import transformers
from accelerate.utils import set_seed
from accelerate.utils.memory import release_memory
from datasets import Dataset, DatasetDict, IterableDatasetDict, load_dataset
from packaging.version import Version
from transformers import AutoConfig, AutoModelForCausalLM, BitsAndBytesConfig
from transformers.testing_utils import torch_device
from transformers.utils import is_peft_available

from trl import DistillationConfig, DistillationTrainer
from trl.experimental.gkd.gkd_trainer import GKDTrainer
from trl.trainer.distillation_trainer import _chunked_divergence_loss

from .testing_utils import (
    TrlTestCase,
    require_bitsandbytes,
    require_peft,
    require_response_parsing,
    require_torch_accelerator,
    require_vision,
    require_vllm,
)


def multiply_tool(a: int, b: int) -> int:
    """
    Multiplies two integers.

    Args:
        a: The first integer.
        b: The second integer.

    Returns:
        The product of the two integers.
    """
    return a * b


def record(key: str, value):
    """Append `value` under `key` to the file `TRL_TEST_RECORD` names.

    Tools and environments run in the rollout worker's process, so they report what they see through a file rather than
    through the test's variables.
    """
    with open(os.environ["TRL_TEST_RECORD"], "a") as f:
        f.write(json.dumps([key, value]) + "\n")


def recorded(path: str) -> dict[str, list]:
    """Read back what [`record`] wrote to `path`, as `{key: [value, ...]}`."""
    records = defaultdict(list)
    with open(path) as f:
        for line in f:
            key, value = json.loads(line)
            records[key].append(value)
    return records


class ScriptedTurns:
    """Answers each prompt with a completion written as text, in place of the model's generation.

    The k-th first turn of a prompt gets `first_turns[k % len(first_turns)]`, and a turn after a tool result gets
    `after_tool`. Call it with a prompt's token ids, or patch [`~ScriptedTurns.generate`] in for the model's
    `generate`.

    Args:
        tokenizer ([`~transformers.PreTrainedTokenizerBase`]):
            Tokenizer of the model.
        first_turns (`list[str]` or `Callable[[str], list[str]]`):
            Completions of the first turn, or a function of the prompt's text returning them.
        after_tool (`str`, *optional*, defaults to `"Done!<|im_end|>"`):
            Completion of a turn after a tool result.
        tool_response_marker (`str`, *optional*, defaults to `"<tool_response>"`):
            Text the chat template renders a tool result with, which tells the turns apart.

    Attributes:
        turns_after_tool (`int`):
            Number of turns answered after a tool result.
    """

    def __init__(self, tokenizer, first_turns, after_tool="Done!<|im_end|>", tool_response_marker="<tool_response>"):
        self.tokenizer = tokenizer
        self.first_turns = first_turns
        self.after_tool = after_tool
        self.tool_response_marker = tool_response_marker
        self.seen = defaultdict(int)
        self.turns_after_tool = 0

    def __call__(self, prompt_ids: list[int]) -> list[int]:
        prompt = self.tokenizer.decode(prompt_ids)
        if self.tool_response_marker in prompt:
            self.turns_after_tool += 1
            text = self.after_tool
        else:
            first_turns = self.first_turns(prompt) if callable(self.first_turns) else self.first_turns
            text = first_turns[self.seen[prompt] % len(first_turns)]
            self.seen[prompt] += 1
        return self.tokenizer(text, add_special_tokens=False).input_ids

    def generate(self, input_ids, attention_mask, **kwargs):
        """Answer a batch of left-padded prompts as `generate` does: each prompt followed by its completion,
        right-padded."""
        completions = [self(ids[mask.bool()].tolist()) for ids, mask in zip(input_ids, attention_mask, strict=True)]
        width = max(len(ids) for ids in completions)
        completion_ids = [ids + [self.tokenizer.pad_token_id] * (width - len(ids)) for ids in completions]
        return torch.cat([input_ids, torch.tensor(completion_ids, device=input_ids.device)], dim=-1)


class CounterEnvironment:
    def reset(self, **kwargs):
        record("reset_counter", kwargs)
        return "Count."

    def increment(self, step: int) -> int:
        """
        Increment the internal counter.

        Args:
            step: Value to add to the counter.

        Returns:
            The updated counter value.
        """
        record("increment", step)
        return step


class EchoEnvironment:
    def reset(self, **kwargs):
        record("reset_echo", kwargs)
        return "Echo."

    def shout(self, text: str) -> str:
        """
        Shout the given text.

        Args:
            text: Text to shout.

        Returns:
            The text in upper case.
        """
        record("shout", text)
        return text.upper()


class ZipEnvironment:
    def reset(self, **kwargs):
        return "Give the zip code."

    def submit(self, answer: str) -> str:
        """
        Submit the zip code.

        Args:
            answer: The zip code.

        Returns:
            A confirmation.
        """
        record("zip", answer)
        return "ok"


class CountEnvironment:
    def reset(self, **kwargs):
        return "Count."

    def submit(self, answer: int) -> str:
        """
        Submit the count.

        Args:
            answer: The count.

        Returns:
            A confirmation.
        """
        record("count", answer)
        return "ok"


class IncrementEnvironment:
    def reset(self, **kwargs):
        self._counter = 0

    def increment(self, step: int) -> int:
        """
        Increment the internal counter.

        Args:
            step: Value to add to the counter.

        Returns:
            The updated counter value.
        """
        self._counter += step
        return self._counter


class StartedCounterEnvironment:
    # Reads its start from a dataset column, keeps its state across turns, and scores the rollout from it
    def reset(self, start: int, **kwargs):
        self._counter = start
        return f" The counter starts at {start}."

    def increment(self, step: int) -> int:
        """
        Increment the internal counter.

        Args:
            step: Value to add to the counter, must be positive.

        Returns:
            The updated counter value.
        """
        if step <= 0:
            raise ValueError("`step` must be positive.")
        self._counter += step
        return self._counter

    def get_reward(self) -> float:
        return float(self._counter)


class DocumentEnvironment:
    def reset(self, length: int, **kwargs):
        self._length = length

    def read(self) -> str:
        """
        Read the document.

        Returns:
            The content of the document.
        """
        return "lorem " * self._length


class PropertyEnvironment:
    def __init__(self):
        self.is_reset = False

    def reset(self, **kwargs):
        self.is_reset = True

    @property
    def reward(self) -> float:
        if self.is_reset:
            raise RuntimeError("`reward` must not be evaluated while discovering tools")
        return 0.0

    def echo(self, text: str) -> str:
        """
        Echo the text back.

        Args:
            text: Text to echo.

        Returns:
            The text, unchanged.
        """
        return text


class ScoredEnvironment:  # owns its reward
    def reset(self, **kwargs): ...

    def act(self, x: int) -> int:
        """
        Act.

        Args:
            x: A value.

        Returns:
            The value.
        """
        return x

    def get_reward(self) -> float:
        return 1.0


if is_peft_available():
    from peft import LoraConfig, PrefixTuningConfig, get_peft_model


def _reference_chunked_divergence(
    student_hidden,
    teacher_hidden,
    student_w,
    teacher_w,
    completion_mask,
    beta,
    num_items_in_batch=None,
    s_bias=None,
    t_bias=None,
    s_scale=1.0,
    t_scale=1.0,
    s_softcap=None,
    t_softcap=None,
    temperature=1.0,
):
    """Naive full-vocab reference for `_chunked_divergence_loss`: project the whole batch at once (no chunking) and
    build the JSD straight from the definition, so it shares neither the chunking nor `F.kl_div`'s argument order."""
    # Op order mirrors the loss's chunk body: matmul, + bias, * scale, softcap, / temperature.
    student_logits = student_hidden.float() @ student_w.float().t()
    teacher_logits = teacher_hidden.float() @ teacher_w.float().t()
    if s_bias is not None:
        student_logits = student_logits + s_bias.float()
    if t_bias is not None:
        teacher_logits = teacher_logits + t_bias.float()
    if s_scale != 1.0:
        student_logits = student_logits * s_scale
    if s_softcap is not None:
        student_logits = s_softcap * torch.tanh(student_logits / s_softcap)
    if t_scale != 1.0:
        teacher_logits = teacher_logits * t_scale
    if t_softcap is not None:
        teacher_logits = t_softcap * torch.tanh(teacher_logits / t_softcap)
    student_logits = student_logits / temperature
    teacher_logits = teacher_logits / temperature
    student_log_probs = torch.log_softmax(student_logits, dim=-1)
    teacher_log_probs = torch.log_softmax(teacher_logits, dim=-1)
    student_probs, teacher_probs = student_log_probs.exp(), teacher_log_probs.exp()

    if beta == 0.0:  # forward KL: KL(teacher || student)
        per_element = teacher_probs * (teacher_log_probs - student_log_probs)
    elif beta == 1.0:  # reverse KL: KL(student || teacher)
        per_element = student_probs * (student_log_probs - teacher_log_probs)
    else:  # generalized JSD against the mixture M = (1 - beta) * student + beta * teacher
        beta_t = student_log_probs.new_tensor(beta)
        mixture_log_probs = torch.logaddexp(student_log_probs + torch.log1p(-beta_t), teacher_log_probs + beta_t.log())
        per_element = beta * (teacher_probs * (teacher_log_probs - mixture_log_probs)) + (1 - beta) * (
            student_probs * (student_log_probs - mixture_log_probs)
        )

    per_token = per_element.sum(dim=-1) * completion_mask  # (B, K)
    denom = completion_mask.sum() if num_items_in_batch is None else num_items_in_batch
    return per_token.sum() / denom


@require_torch_accelerator
class TestChunkedDivergenceLoss(TrlTestCase):
    """Unit tests for the memory-efficient chunked JSD loss (`_chunked_divergence_loss`)."""

    @pytest.fixture(autouse=True, params=[(4, 5)])
    def small_chunks(self, request):
        with (
            patch("trl.kernels.chunked_divergence.TOKEN_CHUNK_SIZE", request.param[0]),
            patch("trl.kernels.chunked_divergence.VOCAB_CHUNK_SIZE", request.param[1]),
        ):
            yield

    def _inputs(self, B=2, K=6, H=8, V=17, n_masked=3, seed=0, device=torch_device):
        g = torch.Generator(device).manual_seed(seed)
        student_hidden = torch.randn(B, K, H, generator=g, device=device)
        teacher_hidden = torch.randn(B, K, H, generator=g, device=device)
        student_w = torch.randn(V, H, generator=g, device=device)
        teacher_w = torch.randn(V, H, generator=g, device=device)
        completion_mask = torch.ones(B, K, device=device)
        completion_mask.reshape(-1)[torch.randperm(B * K, generator=g, device=device)[:n_masked]] = 0
        return student_hidden, teacher_hidden, student_w, teacher_w, completion_mask

    # CPU tensors stand in for an accelerator without Triton (e.g. Trainium): TRL does not target CPU training
    @pytest.mark.parametrize("device", [torch_device, "cpu"])
    @pytest.mark.parametrize("beta", [0.0, 0.5, 1.0])
    def test_matches_naive_full_vocab(self, beta, device):
        sh, th, sw, tw, mask = self._inputs(device=device)
        loss, _, n_valid = _chunked_divergence_loss(sh, th, sw, tw, mask, beta)
        expected = _reference_chunked_divergence(sh, th, sw, tw, mask, beta)
        torch.testing.assert_close(loss, expected)
        assert n_valid.item() == int(mask.sum().item())

    def test_bf16_hidden_fp32_weight(self):
        """A bf16 hidden state against an fp32 `lm_head` weight projects without a dtype mismatch."""
        sh, th, sw, tw, mask = self._inputs()
        loss, _, _ = _chunked_divergence_loss(sh.bfloat16(), th.bfloat16(), sw, tw, mask, beta=0.5)
        expected = _reference_chunked_divergence(sh.bfloat16().float(), th.bfloat16().float(), sw, tw, mask, beta=0.5)
        torch.testing.assert_close(loss, expected, atol=2e-2, rtol=2e-2)

    def test_different_teacher_student_hidden_sizes(self):
        # Teacher and student may have different hidden widths; only the vocabulary must match.
        g = torch.Generator(torch_device).manual_seed(2)
        B, K, V = 2, 5, 13
        sh, th = (
            torch.randn(B, K, 8, generator=g, device=torch_device),
            torch.randn(B, K, 12, generator=g, device=torch_device),
        )
        sw, tw = (
            torch.randn(V, 8, generator=g, device=torch_device),
            torch.randn(V, 12, generator=g, device=torch_device),
        )
        mask = torch.ones(B, K, device=torch_device)
        mask[1, -1] = 0
        loss, _, _ = _chunked_divergence_loss(sh, th, sw, tw, mask, beta=0.5)
        expected = _reference_chunked_divergence(sh, th, sw, tw, mask, beta=0.5)
        torch.testing.assert_close(loss, expected)

    @pytest.mark.parametrize("beta", [0.0, 0.5, 1.0])
    def test_applies_logit_scale_and_softcapping(self, beta):
        # Per-model `logit_scale` (Cohere) / `final_logit_softcapping` (Gemma) must be applied before the softmax.
        sh, th, sw, tw, mask = self._inputs()
        loss, _, _ = _chunked_divergence_loss(
            sh,
            th,
            sw,
            tw,
            mask,
            beta,
            student_logit_scale=0.7,
            teacher_logit_scale=1.3,
            student_final_logit_softcapping=50.0,
            teacher_final_logit_softcapping=30.0,
        )
        expected = _reference_chunked_divergence(
            sh, th, sw, tw, mask, beta, s_scale=0.7, t_scale=1.3, s_softcap=50.0, t_softcap=30.0
        )
        torch.testing.assert_close(loss, expected)

    @pytest.mark.parametrize("beta", [0.0, 0.5, 1.0])
    def test_applies_temperature(self, beta):
        # Softmax temperature softens both distributions before the divergence.
        sh, th, sw, tw, mask = self._inputs()
        loss, _, _ = _chunked_divergence_loss(sh, th, sw, tw, mask, beta, temperature=2.0)
        expected = _reference_chunked_divergence(sh, th, sw, tw, mask, beta, temperature=2.0)
        torch.testing.assert_close(loss, expected)

    @pytest.mark.parametrize("beta", [0.0, 0.5, 1.0])
    def test_applies_lm_head_bias(self, beta):
        # An `lm_head` bias must be added to each chunk's logits (after the projection, before the softmax).
        sh, th, sw, tw, mask = self._inputs()
        g = torch.Generator(torch_device).manual_seed(3)
        s_bias = torch.randn(sw.size(0), generator=g, device=torch_device)
        t_bias = torch.randn(tw.size(0), generator=g, device=torch_device)
        loss, _, _ = _chunked_divergence_loss(
            sh, th, sw, tw, mask, beta, student_lm_head_bias=s_bias, teacher_lm_head_bias=t_bias
        )
        expected = _reference_chunked_divergence(sh, th, sw, tw, mask, beta, s_bias=s_bias, t_bias=t_bias)
        torch.testing.assert_close(loss, expected)

    def test_beta_1_is_reverse_kl(self):
        sh, th, sw, tw, mask = self._inputs()
        loss, _, _ = _chunked_divergence_loss(sh, th, sw, tw, mask, beta=1.0)
        # Hand-rolled reverse KL: sum_x p_s * (log p_s - log p_t) over valid positions, normalized by n_valid.
        student_log_probs = torch.log_softmax(sh @ sw.t(), dim=-1)
        teacher_log_probs = torch.log_softmax(th @ tw.t(), dim=-1)
        per_token = (student_log_probs.exp() * (student_log_probs - teacher_log_probs)).sum(dim=-1) * mask
        expected = per_token.sum() / mask.sum()
        torch.testing.assert_close(loss, expected)

    @pytest.mark.parametrize("beta", [0.0, 0.5, 1.0])
    def test_parity_with_gkd(self, beta):
        # Identity lm_head so hidden states are the logits, then compare against GKD's full-vocab JSD (sum reduction).
        B, K, V = 2, 5, 11
        g = torch.Generator(torch_device).manual_seed(1)
        student_logits = torch.randn(B, K, V, generator=g, device=torch_device)
        teacher_logits = torch.randn(B, K, V, generator=g, device=torch_device)
        eye = torch.eye(V, device=torch_device)
        mask = torch.ones(B, K, device=torch_device)
        mask[0, -1] = 0
        labels = torch.where(mask.bool(), torch.ones_like(mask, dtype=torch.long), torch.full_like(mask, -100).long())
        loss, _, _ = _chunked_divergence_loss(
            student_logits, teacher_logits, eye, eye, mask, beta, num_items_in_batch=1
        )
        gkd = GKDTrainer.generalized_jsd_loss(
            student_logits, teacher_logits, labels=labels, beta=beta, reduction="sum"
        )
        torch.testing.assert_close(loss, gkd)

    def test_masked_positions_ignored(self):
        sh, th, sw, tw, mask = self._inputs()
        loss_a, _, _ = _chunked_divergence_loss(sh, th, sw, tw, mask, beta=0.5)
        # Perturbing the hidden states at masked positions only must not change the loss.
        masked = mask.reshape(-1) == 0
        sh2, th2 = sh.clone().reshape(-1, sh.size(-1)), th.clone().reshape(-1, th.size(-1))
        sh2[masked] += 5.0
        th2[masked] += 5.0
        loss_b, _, _ = _chunked_divergence_loss(sh2.view_as(sh), th2.view_as(th), sw, tw, mask, beta=0.5)
        torch.testing.assert_close(loss_a, loss_b)

    def test_grads_flow_and_zero_at_masked(self):
        sh, th, sw, tw, mask = self._inputs()
        sh = sh.clone().requires_grad_(True)
        loss, _, _ = _chunked_divergence_loss(sh, th, sw, tw, mask, beta=0.5)
        loss.backward()
        grad = sh.grad.reshape(-1, sh.size(-1))
        valid = mask.reshape(-1) != 0
        assert (grad[valid].abs().sum(dim=-1) > 0).all()  # valid positions receive gradient
        assert torch.equal(grad[~valid], torch.zeros_like(grad[~valid]))  # masked positions get none

    @pytest.mark.parametrize("beta", [0.0, 0.3, 0.5, 1.0])
    @pytest.mark.parametrize(
        ("temperature", "scale", "softcap"), [(1.0, 1.0, None), (0.7, 1.0, None), (1.0, 0.5, 3.0), (2.0, 1.0, 3.0)]
    )
    def test_backward_matches_reference(self, beta, temperature, scale, softcap):
        # The chunked backward must match a naive full-vocab autograd backward, not merely be non-null. Only the student
        # carries gradient (the teacher is a fixed target), so compare the student hidden + lm_head.
        sh, th, sw, tw, mask = self._inputs()
        kwargs = {"temperature": temperature}
        sh_c, sw_c = sh.clone().requires_grad_(True), sw.clone().requires_grad_(True)
        loss_c, _, _ = _chunked_divergence_loss(
            sh_c,
            th,
            sw_c,
            tw,
            mask,
            beta,
            student_logit_scale=scale,
            student_final_logit_softcapping=softcap,
            **kwargs,
        )
        loss_c.backward()

        sh_r, sw_r = sh.clone().requires_grad_(True), sw.clone().requires_grad_(True)
        loss_r = _reference_chunked_divergence(
            sh_r, th, sw_r, tw, mask, beta, s_scale=scale, s_softcap=softcap, **kwargs
        )
        loss_r.backward()

        torch.testing.assert_close(sh_c.grad, sh_r.grad, atol=1e-5, rtol=1e-5)
        torch.testing.assert_close(sw_c.grad, sw_r.grad, atol=1e-5, rtol=1e-5)

    @pytest.mark.parametrize("dtype", [torch.bfloat16, torch.float16])
    @pytest.mark.parametrize("beta", [0.0, 0.5, 1.0])
    @pytest.mark.parametrize("use_autocast", [False, True])
    def test_low_precision_backward_matches_reference(self, dtype, beta, use_autocast):
        # A close scalar loss can hide gradient errors from rounded logits.
        sh, th, sw, tw, mask = self._inputs(H=64)
        logit_std = 10.0 if beta == 0.5 else 30.0
        sw, tw = sw * (logit_std / 64**0.5), tw * (logit_std / 64**0.5)
        input_dtype = torch.float32 if use_autocast else dtype
        sh, th = sh.to(input_dtype).requires_grad_(), th.to(input_dtype).requires_grad_()
        sw, tw = sw.to(input_dtype).requires_grad_(), tw.to(input_dtype).requires_grad_()
        s_bias = torch.linspace(-1.0, 1.0, sw.size(0), device=torch_device, requires_grad=True)
        t_bias = torch.linspace(1.0, -1.0, tw.size(0), device=torch_device, requires_grad=True)
        with torch.autocast(torch_device, dtype=dtype, enabled=use_autocast):
            loss, entropy, _ = _chunked_divergence_loss(
                sh, th, sw, tw, mask, beta, student_lm_head_bias=s_bias, teacher_lm_head_bias=t_bias
            )
        loss.backward()

        sh_r, sw_r = sh.detach().clone().requires_grad_(), sw.detach().clone().requires_grad_()
        s_bias_r = s_bias.detach().clone().requires_grad_()
        expected = _reference_chunked_divergence(
            sh_r.to(dtype),
            th.detach().to(dtype),
            sw_r.to(dtype),
            tw.detach().to(dtype),
            mask,
            beta,
            s_bias=s_bias_r,
            t_bias=t_bias.detach(),
        )
        expected.backward()
        torch.testing.assert_close(loss, expected, atol=1e-5, rtol=1e-5)
        logits = sh.detach().to(dtype).float() @ sw.detach().to(dtype).float().t() + s_bias.detach()
        log_probs = logits.log_softmax(dim=-1)
        expected_entropy = (-(log_probs.exp() * log_probs).sum(dim=-1) * mask).sum()
        torch.testing.assert_close(entropy, expected_entropy, atol=1e-5, rtol=1e-5)
        for actual, reference in ((sh.grad, sh_r.grad), (sw.grad, sw_r.grad), (s_bias.grad, s_bias_r.grad)):
            assert torch.isfinite(actual).all()
            relative_error = (actual.float() - reference.float()).abs().max() / reference.float().abs().max()
            assert relative_error < 0.01
        assert th.grad is None and tw.grad is None and t_bias.grad is None

    @pytest.mark.parametrize("small_chunks", [(4, 2053)], indirect=True)
    def test_jsd_underflow_across_blocks(self):
        sh, th, sw, tw, mask = self._inputs(B=1, K=3, H=1, V=2053, n_masked=1)
        sh.fill_(1.0)
        th.fill_(1.0)
        sw.fill_(-120.0)
        tw.fill_(-120.0)
        sw[:2, 0] = torch.tensor([0.0, 1.0], device=torch_device)
        tw[:2, 0] = torch.tensor([1.0, 0.0], device=torch_device)
        sh.requires_grad_()
        loss, entropy, _ = _chunked_divergence_loss(sh, th, sw, tw, mask, beta=0.5)
        expected = _reference_chunked_divergence(sh, th, sw, tw, mask, beta=0.5)
        torch.testing.assert_close(loss, expected)
        assert torch.isfinite(entropy)
        loss.backward()
        assert torch.isfinite(sh.grad).all()

    def test_fully_masked_batch_keeps_graph(self):
        # With every position masked the loss is 0, but backward must still touch every trainable student param
        # (hidden states, lm_head weight and bias) — otherwise DDP/FSDP synchronization hangs at the all-reduce.
        sh, th, sw, tw, _ = self._inputs()
        sh, sw = sh.clone().requires_grad_(True), sw.clone().requires_grad_(True)
        s_bias = torch.zeros(sw.size(0), device=torch_device, requires_grad=True)
        mask = torch.zeros(sh.size(0), sh.size(1), device=torch_device)
        loss, _, n_valid = _chunked_divergence_loss(sh, th, sw, tw, mask, beta=0.5, student_lm_head_bias=s_bias)
        assert n_valid.item() == 0
        assert torch.isfinite(loss)
        loss.backward()  # must not raise: the graph stays connected through the student hidden states + lm_head
        assert sh.grad is not None and sw.grad is not None and s_bias.grad is not None
        assert torch.count_nonzero(sh.grad) == 0
        assert torch.count_nonzero(sw.grad) == 0
        assert torch.count_nonzero(s_bias.grad) == 0


class TestDistillationTrainer(TrlTestCase):
    def test_init_minimal(self):
        # Instantiate with only model, teacher_model and train_dataset.
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")
        DistillationTrainer(
            model="trl-internal-testing/tiny-Qwen3ForCausalLM",
            teacher_model="trl-internal-testing/tiny-Qwen3MoeForCausalLM",
            train_dataset=dataset,
        )

    def test_train(self):
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")

        training_args = DistillationConfig(
            output_dir=self.tmp_dir,
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            report_to="none",
        )
        trainer = DistillationTrainer(
            model="trl-internal-testing/tiny-Qwen3ForCausalLM",
            teacher_model="trl-internal-testing/tiny-Qwen3MoeForCausalLM",
            args=training_args,
            train_dataset=dataset,
        )

        previous_trainable_params = {n: param.clone() for n, param in trainer.model.named_parameters()}

        trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None

        # The student entropy metric is logged (item 61).
        assert any("entropy" in entry for entry in trainer.state.log_history)

        # Check that the params have changed
        for n, param in previous_trainable_params.items():
            new_param = trainer.model.get_parameter(n)
            assert not torch.equal(param, new_param), f"Parameter {n} has not changed."

    def test_saved_model_keeps_its_router_config(self):
        # Regression test for https://github.com/huggingface/trl/issues/8102
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")
        training_args = DistillationConfig(
            output_dir=self.tmp_dir,
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            max_steps=1,  # running the training loop once is enough
            report_to="none",
        )
        trainer = DistillationTrainer(
            model="trl-internal-testing/tiny-Qwen3MoeForCausalLM",
            teacher_model="trl-internal-testing/tiny-Qwen3MoeForCausalLM",
            args=training_args,
            train_dataset=dataset,
        )
        trainer.train()
        trainer.save_model()

        # Saved with the router config it was loaded with
        config = AutoConfig.from_pretrained(self.tmp_dir)
        assert config.output_router_logits is False
        assert config.router_aux_loss_coef == 0.001

    @pytest.mark.parametrize("config_name", ["standard_prompt_only", "conversational_prompt_only"])
    def test_train_dataset_format(self, config_name):
        # Both the standard (plain-text prompt) and conversational (chat-message prompt) prompt-only formats train end
        # to end: the student generates on-policy completions, the teacher scores them.
        dataset = load_dataset("trl-internal-testing/zen", config_name, split="train")

        training_args = DistillationConfig(
            output_dir=self.tmp_dir,
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            report_to="none",
        )
        trainer = DistillationTrainer(
            model="trl-internal-testing/tiny-Qwen3ForCausalLM",
            teacher_model="trl-internal-testing/tiny-Qwen3MoeForCausalLM",
            args=training_args,
            train_dataset=dataset,
        )

        trainer.train()

        # The point of this test is only that both prompt-only formats are accepted and train end to end: a full step
        # ran and every parameter stayed finite. See `test_train` for the params-changed assertion.
        assert trainer.state.log_history[-1]["train_loss"] is not None
        assert all(torch.isfinite(param).all() for param in trainer.model.parameters())

    @pytest.mark.xfail(
        condition=Version(transformers.__version__) < Version("5.0.0"),
        reason="Tool parsing is not supported in transformers versions below 5.0.0",
        strict=True,
    )
    @require_response_parsing
    def test_train_with_tools(self):
        # A `multiply_tool` is exposed and generation is mocked to deterministically emit, for the batch of 3 prompts,
        # one valid tool call, one invalid tool call (wrong argument name), and one non-tool completion. This exercises
        # the tool-calling loop (execution + `tool_mask`) without relying on the tiny model to emit valid calls.
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")

        training_args = DistillationConfig(
            output_dir=self.tmp_dir,
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            max_completion_length=128,
            report_to="none",
        )
        trainer = DistillationTrainer(
            model="trl-internal-testing/tiny-Qwen3MoeForCausalLM",
            teacher_model="trl-internal-testing/tiny-Qwen3MoeForCausalLM",
            args=training_args,
            train_dataset=dataset,
            tools=[multiply_tool],
        )

        def fake_generate(input_ids, **kwargs):
            if input_ids.shape[0] == 3:  # first call
                # fmt: off
                completion_ids = torch.tensor(
                    [
                        # '<tool_call>\n{"name": "multiply_tool", "arguments": {"a": 3, "b": 4}}\n</tool_call><|im_end|>'
                        [151657, 198, 4913, 606, 788, 330, 64648, 22785, 497, 330, 16370, 788, 5212, 64, 788, 220, 18, 11, 330, 65, 788, 220, 19, 11248, 151658, 151645],
                        # an invalid tool call with wrong argument name
                        # '<tool_call>\n{"name": "multiply_tool", "arguments": {"a": 3, "c": 4}}\n</tool_call><|im_end|>'
                        [151657, 198, 4913, 606, 788, 330, 64648, 22785, 497, 330, 16370, 788, 5212, 64, 788, 220, 18, 11, 330, 66, 788, 220, 19, 11248, 151658, 151645],
                        # "I don't know any tool<|im_end|>"
                        [40, 1513, 944, 1414, 894, 5392, 151645, 151643, 151643, 151643, 151643, 151643, 151643, 151643, 151643, 151643, 151643, 151643, 151643, 151643, 151643, 151643, 151643, 151643, 151643, 151643],
                    ],
                    device=input_ids.device,
                )
                # fmt: on
            else:  # second call will only have two inputs in the batch, because two examples have a tool call.
                completion_ids = torch.tensor(
                    [
                        # 'Done!<|im_end|>'
                        [17453, 0, 151645],
                        # 'Done!<|im_end|>'
                        [17453, 0, 151645],
                    ],
                    device=input_ids.device,
                )
            return torch.cat([input_ids, completion_ids], dim=-1)

        with patch.object(trainer.model, "generate", side_effect=fake_generate):
            trainer.train()

        # Self-distillation gives a near-zero teacher signal, so we assert the tool-calling loop ran end to end and the
        # loss stayed finite rather than params-changed (see `test_train_dataset_format`). The tool metrics confirm the
        # loop executed: 2 of 3 completions were tool calls, and 1 of those 2 failed (wrong argument name).
        train_loss = trainer.state.log_history[-1]["train_loss"]
        assert train_loss is not None
        assert torch.isfinite(torch.tensor(train_loss))
        assert trainer.state.log_history[-1]["tools/call_frequency"] is not None
        assert trainer.state.log_history[-1]["tools/call_frequency"] == pytest.approx(2 / 3)
        assert trainer.state.log_history[-1]["tools/failure_frequency"] is not None
        assert trainer.state.log_history[-1]["tools/failure_frequency"] == pytest.approx(1 / 2)

    @pytest.mark.xfail(
        condition=Version(transformers.__version__) < Version("5.0.0"),
        reason="Tool parsing is not supported in transformers versions below 5.0.0",
        strict=True,
    )
    @require_response_parsing
    def test_max_tool_calling_iterations_skips_last_turn_tool_calls(self):
        # The model calls the tool on every turn. With max_tool_calling_iterations=1, the first turn's call runs, and
        # the call in the turn generated after its result is kept in the completion but never executed.
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")

        training_args = DistillationConfig(
            output_dir=self.tmp_dir,
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            max_completion_length=128,
            max_tool_calling_iterations=1,
            max_steps=1,
            logging_steps=1,
            log_completions=True,
            report_to="none",
        )
        trainer = DistillationTrainer(
            model="trl-internal-testing/tiny-Qwen3MoeForCausalLM",
            teacher_model="trl-internal-testing/tiny-Qwen3MoeForCausalLM",
            args=training_args,
            train_dataset=dataset,
            tools=[multiply_tool],
        )

        def fake_generate(input_ids, **kwargs):
            # fmt: off
            # '<tool_call>\n{"name": "multiply_tool", "arguments": {"a": 3, "b": 4}}\n</tool_call><|im_end|>'
            tool_call_ids = [151657, 198, 4913, 606, 788, 330, 64648, 22785, 497, 330, 16370, 788, 5212, 64, 788, 220, 18, 11, 330, 65, 788, 220, 19, 11248, 151658, 151645]
            # fmt: on
            completion_ids = torch.tensor([tool_call_ids] * input_ids.shape[0], device=input_ids.device)
            return torch.cat([input_ids, completion_ids], dim=-1)

        with patch.object(trainer.model, "generate", side_effect=fake_generate):
            trainer.train()

        assert trainer.state.log_history[0]["tools/call_frequency"] == pytest.approx(1.0)  # one executed call each
        completions = Dataset.from_parquet(os.path.join(self.tmp_dir, "completions", "completions_00001.parquet"))
        for completion in completions["completion"]:  # completions are logged as decoded text
            assert completion.count("<tool_response>") == 1  # only the first turn's tool call was executed
            assert completion.endswith("</tool_call>")  # the last turn's tool call was not executed

    def test_train_stops_on_every_eos_token_id(self):
        # Phi-3.5 ends a turn with `<|end|>`, which only its generation config declares as eos, not its tokenizer
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")

        training_args = DistillationConfig(
            output_dir=self.tmp_dir,
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            report_to="none",
        )
        trainer = DistillationTrainer(
            model="trl-internal-testing/tiny-Phi3ForCausalLM-3.5",
            teacher_model="trl-internal-testing/tiny-Phi3ForCausalLM-3.5",
            args=training_args,
            train_dataset=dataset,
        )
        assert 32007 in trainer.generation_config.eos_token_id  # `<|end|>`

        def fake_generate(input_ids, **kwargs):
            # 'Blue<|end|>and green': the turn ends on `<|end|>`, and generation goes on after it
            completion_ids = torch.tensor([[10924, 32007, 322, 7933]] * input_ids.shape[0], device=input_ids.device)
            return torch.cat([input_ids, completion_ids], dim=-1)

        with patch.object(trainer.model, "generate", side_effect=fake_generate):
            trainer.train()

        # Completions are cut after `<|end|>` and count as terminated, not clipped
        assert trainer.state.log_history[-1]["completions/mean_length"] == 2.0
        assert trainer.state.log_history[-1]["completions/clipped_ratio"] == 0.0

    def test_trust_remote_code(self):
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")
        model_id = "trl-internal-testing/tiny-RemoteForCausalLM"

        with pytest.raises(ValueError, match="custom code"):
            DistillationTrainer(
                model=model_id,
                teacher_model=model_id,
                args=DistillationConfig(output_dir=self.tmp_dir, report_to="none"),
                train_dataset=dataset,
            )

        trainer = DistillationTrainer(
            model=model_id,
            teacher_model=model_id,
            args=DistillationConfig(output_dir=self.tmp_dir, report_to="none", trust_remote_code=True),
            train_dataset=dataset,
        )
        assert type(trainer.model).__name__ == "RemoteForCausalLM"

    def test_train_with_eval(self):
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only")

        training_args = DistillationConfig(
            output_dir=self.tmp_dir,
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            per_device_eval_batch_size=3,  # reduce the batch size to reduce memory usage
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            eval_strategy="steps",
            eval_steps=2,
            report_to="none",
        )
        trainer = DistillationTrainer(
            model="trl-internal-testing/tiny-Qwen3ForCausalLM",
            teacher_model="trl-internal-testing/tiny-Qwen3MoeForCausalLM",
            args=training_args,
            train_dataset=dataset["train"],
            eval_dataset=dataset["test"],
        )

        trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None
        assert trainer.state.log_history[0]["eval_loss"] is not None

    def test_train_with_iterable_dataset(self):
        # Iterable (streaming) datasets have no length, so `max_steps` is required.
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train", streaming=True)

        training_args = DistillationConfig(
            output_dir=self.tmp_dir,
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            max_steps=4,
            report_to="none",
        )
        trainer = DistillationTrainer(
            model="trl-internal-testing/tiny-Qwen3ForCausalLM",
            teacher_model="trl-internal-testing/tiny-Qwen3MoeForCausalLM",
            args=training_args,
            train_dataset=dataset,
        )

        # Iterable datasets force `dispatch_batches=False` so the stream can be sharded per process.
        assert trainer.args.accelerator_config.dispatch_batches is False

        trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None

    def test_iterable_dataset_requires_dispatch_batches_false(self):
        # `dispatch_batches=True` is incompatible with iterable datasets (see get_train_dataloader).
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train", streaming=True)

        training_args = DistillationConfig(
            output_dir=self.tmp_dir, accelerator_config={"dispatch_batches": True}, report_to="none"
        )
        with pytest.raises(ValueError, match="Iterable datasets require `dispatch_batches=False`"):
            DistillationTrainer(
                model="trl-internal-testing/tiny-Qwen3ForCausalLM",
                teacher_model="trl-internal-testing/tiny-Qwen3MoeForCausalLM",
                args=training_args,
                train_dataset=dataset,
            )

    def test_iterable_dataset_forces_num_workers_zero(self):
        # Multiple workers would shard and interleave the stream, breaking the generation-batch ordering that
        # `_prepare_inputs` relies on, so `dataloader_num_workers` is forced to 0 for iterable datasets.
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train", streaming=True)

        training_args = DistillationConfig(
            output_dir=self.tmp_dir, dataloader_num_workers=4, max_steps=1, report_to="none"
        )
        trainer = DistillationTrainer(
            model="trl-internal-testing/tiny-Qwen3ForCausalLM",
            teacher_model="trl-internal-testing/tiny-Qwen3MoeForCausalLM",
            args=training_args,
            train_dataset=dataset,
        )

        assert trainer.args.dataloader_num_workers == 0

    def test_iterable_eval_keeps_map_style_train_workers(self):
        # A map-style train set keeps its workers even when the eval set is iterable; the single-worker restriction is
        # scoped to the iterable eval loader and not persisted.
        train_dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")
        eval_dataset = load_dataset(
            "trl-internal-testing/zen", "conversational_prompt_only", split="test", streaming=True
        )

        training_args = DistillationConfig(
            output_dir=self.tmp_dir,
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            per_device_eval_batch_size=3,  # reduce the batch size to reduce memory usage
            dataloader_num_workers=4,
            report_to="none",
        )
        trainer = DistillationTrainer(
            model="trl-internal-testing/tiny-Qwen3ForCausalLM",
            teacher_model="trl-internal-testing/tiny-Qwen3MoeForCausalLM",
            args=training_args,
            train_dataset=train_dataset,
            eval_dataset=eval_dataset,
        )

        assert trainer.args.dataloader_num_workers == 4  # not disabled by the iterable eval set
        assert trainer.get_train_dataloader().num_workers == 4  # map-style train keeps its workers
        assert trainer.get_eval_dataloader().num_workers == 0  # iterable eval loader uses a single worker
        assert trainer.args.dataloader_num_workers == 4  # override is scoped, not persisted

    @pytest.mark.parametrize("train_dataset_type", ["dataset", "iterable_dataset"])
    def test_init_with_train_dataset(self, train_dataset_type):
        streaming = "iterable" in train_dataset_type
        train_dataset = load_dataset(
            "trl-internal-testing/zen", "conversational_prompt_only", split="train", streaming=streaming
        )

        # Iterable (streaming) datasets have no length, so `max_steps` is required.
        training_args = DistillationConfig(output_dir=self.tmp_dir, max_steps=4 if streaming else -1, report_to="none")

        trainer = DistillationTrainer(
            model="trl-internal-testing/tiny-Qwen3ForCausalLM",
            teacher_model="trl-internal-testing/tiny-Qwen3MoeForCausalLM",
            args=training_args,
            train_dataset=train_dataset,
        )
        assert trainer.train_dataset is train_dataset

    @pytest.mark.parametrize(
        "eval_dataset_type",
        [
            "dataset",
            "iterable_dataset",
            "dataset_dict",
            "iterable_dataset_dict",
            "dict_of_dataset",
            "dict_of_iterable_dataset",
            "none",
        ],
    )
    def test_init_with_eval_dataset(self, eval_dataset_type):
        train_dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")

        if eval_dataset_type == "none":
            eval_dataset = None
        else:
            streaming = "iterable" in eval_dataset_type
            eval_split = load_dataset(
                "trl-internal-testing/zen", "conversational_prompt_only", split="test", streaming=streaming
            )
            if eval_dataset_type in ("dataset", "iterable_dataset"):
                eval_dataset = eval_split
            elif eval_dataset_type in ("dataset_dict", "iterable_dataset_dict"):
                dataset_dict_cls = IterableDatasetDict if streaming else DatasetDict
                eval_dataset = dataset_dict_cls({"data1": eval_split, "data2": eval_split})
            else:  # "dict_of_dataset" or "dict_of_iterable_dataset"
                eval_dataset = {"data1": eval_split, "data2": eval_split}

        training_args = DistillationConfig(output_dir=self.tmp_dir, report_to="none")
        trainer = DistillationTrainer(
            model="trl-internal-testing/tiny-Qwen3ForCausalLM",
            teacher_model="trl-internal-testing/tiny-Qwen3MoeForCausalLM",
            args=training_args,
            train_dataset=train_dataset,
            eval_dataset=eval_dataset,
        )

        if eval_dataset_type == "none":
            assert trainer.eval_dataset is None
        elif isinstance(trainer.eval_dataset, dict):
            assert set(trainer.eval_dataset.keys()) == {"data1", "data2"}
        else:
            assert trainer.eval_dataset is eval_dataset

    @pytest.mark.parametrize(
        "eval_dataset_type",
        [
            "dataset",
            "iterable_dataset",
            "dataset_dict",
            "iterable_dataset_dict",
            "dict_of_dataset",
            "dict_of_iterable_dataset",
        ],
    )
    def test_evaluate_with_eval_dataset(self, eval_dataset_type):
        # `evaluate` accepts a dataset passed directly, not only an `eval_dataset` set at init. Iterable datasets passed
        # this way must still be configured for the iterable path, since they are absent at init.
        train_dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")

        streaming = "iterable" in eval_dataset_type
        eval_split = load_dataset(
            "trl-internal-testing/zen", "conversational_prompt_only", split="test", streaming=streaming
        )
        if eval_dataset_type in ("dataset", "iterable_dataset"):
            eval_dataset = eval_split
        elif eval_dataset_type in ("dataset_dict", "iterable_dataset_dict"):
            dataset_dict_cls = IterableDatasetDict if streaming else DatasetDict
            eval_dataset = dataset_dict_cls({"data1": eval_split, "data2": eval_split})
        else:  # "dict_of_dataset" or "dict_of_iterable_dataset"
            eval_dataset = {"data1": eval_split, "data2": eval_split}

        training_args = DistillationConfig(
            output_dir=self.tmp_dir,
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            per_device_eval_batch_size=3,  # reduce the batch size to reduce memory usage
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            report_to="none",
        )
        trainer = DistillationTrainer(
            model="trl-internal-testing/tiny-Qwen3ForCausalLM",
            teacher_model="trl-internal-testing/tiny-Qwen3MoeForCausalLM",
            args=training_args,
            train_dataset=train_dataset,
        )

        metrics = trainer.evaluate(eval_dataset=eval_dataset)
        if eval_dataset_type in ("dataset", "iterable_dataset"):
            assert metrics["eval_loss"] is not None
        else:
            assert metrics["eval_data1_loss"] is not None
            assert metrics["eval_data2_loss"] is not None

    def test_train_eval_on_start(self):
        # Evaluation runs before the first training step; the loss must be computable at that point.
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only")
        training_args = DistillationConfig(
            output_dir=self.tmp_dir,
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            per_device_eval_batch_size=3,  # reduce the batch size to reduce memory usage
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            eval_strategy="steps",
            eval_steps=2,
            eval_on_start=True,
            report_to="none",
        )
        trainer = DistillationTrainer(
            model="trl-internal-testing/tiny-Qwen3ForCausalLM",
            teacher_model="trl-internal-testing/tiny-Qwen3MoeForCausalLM",
            args=training_args,
            train_dataset=dataset["train"],
            eval_dataset=dataset["test"],
        )
        trainer.train()

    def test_train_beta_non_zero(self):
        # `beta` is the JSD interpolation coefficient (0 = forward KL, 1 = reverse KL); an intermediate value exercises
        # the generalized-JSD-against-the-mixture branch of the loss end to end.
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")
        training_args = DistillationConfig(
            output_dir=self.tmp_dir,
            beta=0.5,
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            report_to="none",
        )
        trainer = DistillationTrainer(
            model="trl-internal-testing/tiny-Qwen3ForCausalLM",
            teacher_model="trl-internal-testing/tiny-Qwen3MoeForCausalLM",
            args=training_args,
            train_dataset=dataset,
        )

        trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None

    def test_train_with_pad_to_multiple_of(self):
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")

        training_args = DistillationConfig(
            output_dir=self.tmp_dir,
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            pad_to_multiple_of=8,
            report_to="none",
        )
        trainer = DistillationTrainer(
            model="trl-internal-testing/tiny-Qwen3ForCausalLM",
            teacher_model="trl-internal-testing/tiny-Qwen3MoeForCausalLM",
            args=training_args,
            train_dataset=dataset,
        )

        trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None

    def test_train_with_additional_generation_kwargs(self):
        """Test that training works with additional generation kwargs."""
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")

        training_args = DistillationConfig(
            output_dir=self.tmp_dir,
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            report_to="none",
            top_p=0.9,
            top_k=10,
            min_p=0.01,
            repetition_penalty=1.1,
        )

        trainer = DistillationTrainer(
            model="trl-internal-testing/tiny-Qwen3ForCausalLM",
            teacher_model="trl-internal-testing/tiny-Qwen3MoeForCausalLM",
            args=training_args,
            train_dataset=dataset,
        )

        trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None

    def test_train_with_generation_kwargs(self):
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")

        training_args = DistillationConfig(
            output_dir=self.tmp_dir,
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            # Pass gen kwargs
            generation_kwargs={"do_sample": True, "top_k": 50, "num_beams": 2, "length_penalty": -0.1},
            report_to="none",
        )
        trainer = DistillationTrainer(
            model="trl-internal-testing/tiny-Qwen3ForCausalLM",
            teacher_model="trl-internal-testing/tiny-Qwen3MoeForCausalLM",
            args=training_args,
            train_dataset=dataset,
        )

        trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None

    def test_train_with_chat_template_kwargs(self):
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")

        training_args = DistillationConfig(
            output_dir=self.tmp_dir,
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            report_to="none",
            chat_template_kwargs={"enable_thinking": False},
        )
        trainer = DistillationTrainer(
            model="trl-internal-testing/tiny-Qwen3ForCausalLM",
            teacher_model="trl-internal-testing/tiny-Qwen3MoeForCausalLM",
            args=training_args,
            train_dataset=dataset,
        )

        trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None

    def test_train_multiple_dataloader_workers(self):
        # Pytest/CI often starts background threads before tests run. With Python 3.12, using the default "fork" start
        # method in a multi-threaded process emits a DeprecationWarning and may deadlock.
        #
        # We force "spawn" here to make multiprocessing safe under pytest when DataLoader workers are enabled. This is
        # test-environment–specific and not required by the training logic itself.
        #
        # This means the test does not cover "fork". However, "spawn" is stricter (requires full picklability and clean
        # state) and avoids fork-after-threads issues that pytest cannot reliably test anyway. Fork-specific behavior,
        # if needed, should be tested in a clean process outside pytest.
        torch.multiprocessing.set_start_method("spawn", force=True)

        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")

        training_args = DistillationConfig(
            output_dir=self.tmp_dir,
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            dataloader_num_workers=2,  # use multiple dataloader workers
            report_to="none",
        )
        trainer = DistillationTrainer(
            model="trl-internal-testing/tiny-Qwen3ForCausalLM",
            teacher_model="trl-internal-testing/tiny-Qwen3MoeForCausalLM",
            args=training_args,
            train_dataset=dataset,
        )

        trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None

    def test_train_with_gradient_accumulation(self):
        # Gradient accumulation exercises the `num_items_in_batch` global-token normalizer (#4719) end to end: the loss
        # over the accumulated micro-batches must be reduced by the global valid-token count, not the per-microbatch
        # mean, for the update to be correct.
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")

        training_args = DistillationConfig(
            output_dir=self.tmp_dir,
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            gradient_accumulation_steps=2,  # accumulate over 2 micro-batches
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            report_to="none",
        )
        trainer = DistillationTrainer(
            model="trl-internal-testing/tiny-Qwen3ForCausalLM",
            teacher_model="trl-internal-testing/tiny-Qwen3MoeForCausalLM",
            args=training_args,
            train_dataset=dataset,
        )

        previous_trainable_params = {n: param.clone() for n, param in trainer.model.named_parameters()}

        trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None

        # Check that the params have changed
        for n, param in previous_trainable_params.items():
            new_param = trainer.model.get_parameter(n)
            assert not torch.equal(param, new_param), f"Parameter {n} has not changed."

    @require_vllm
    @require_torch_accelerator
    def test_train_vllm(self):
        """Test that training works with vLLM for on-policy generation (colocate mode)."""
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")

        training_args = DistillationConfig(
            output_dir=self.tmp_dir,
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            report_to="none",
            logging_strategy="no",
            use_vllm=True,
        )

        try:
            trainer = DistillationTrainer(
                model="Qwen/Qwen3-0.6B",  # tiny models are too small for vLLM
                teacher_model="Qwen/Qwen3-0.6B",
                args=training_args,
                train_dataset=dataset,
            )

            # Self-distillation (teacher == student) gives ~zero divergence and thus ~zero gradient, which would make
            # the params-changed check below vacuous. Diverge the teacher so the loss — and the update — clears fp noise.
            torch.manual_seed(0)
            with torch.no_grad():
                for p in trainer.teacher_models[None].parameters():
                    p.add_(0.5 * torch.randn_like(p))

            previous_trainable_params = {n: param.clone() for n, param in trainer.model.named_parameters()}

            trainer.train()

            assert trainer.state.log_history[-1]["train_loss"] is not None

            # Check that the params have changed
            for n, param in previous_trainable_params.items():
                new_param = trainer.model.get_parameter(n)
                assert not torch.equal(param, new_param), f"Parameter {n} has not changed."

        except Exception as e:
            # If vLLM fails to initialize due to hardware constraints or other issues, that's expected
            if any(
                keyword in str(e).lower()
                for keyword in [
                    "outofmemoryerror",
                    "cuda",
                    "memory",
                    "insufficient",
                    "no such device",
                    "free memory",
                    "gpu memory utilization",
                    "decrease gpu memory",
                ]
            ):
                pytest.skip(f"Skipping vLLM training test due to hardware constraints: {e}")
            elif "KeyError" in str(e) and "RANK" in str(e):
                pytest.skip(f"Skipping vLLM training test due to environment setup issues: {e}")
            elif "ValueError" in str(e) and "memory" in str(e).lower():
                pytest.skip(f"Skipping vLLM training test due to memory constraints: {e}")
            else:
                raise

        release_memory(trainer.model, trainer)

    @require_peft
    def test_peft_init_is_seeded(self):
        # Two trainers with the same seed start from the same adapter weights
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")
        adapters = []
        for global_seed in range(2):
            torch.manual_seed(global_seed)  # a different global RNG state, as in two separate runs
            trainer = DistillationTrainer(
                model="trl-internal-testing/tiny-Qwen3ForCausalLM",
                teacher_model="trl-internal-testing/tiny-Qwen3MoeForCausalLM",
                args=DistillationConfig(output_dir=self.tmp_dir, report_to="none"),
                train_dataset=dataset,
                peft_config=LoraConfig(),
            )
            adapters.append({n: p.clone() for n, p in trainer.model.named_parameters() if "lora_A" in n})

        assert adapters[0]
        for n, param in adapters[0].items():
            assert torch.equal(param, adapters[1][n]), f"Parameter {n} differs between the two trainers."

    @require_peft
    def test_train_peft_config(self):
        model = AutoModelForCausalLM.from_pretrained("trl-internal-testing/tiny-Qwen3ForCausalLM", dtype="float32")
        base_param_names = [f"base_model.model.{n}" for n, _ in model.named_parameters()]
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")

        training_args = DistillationConfig(
            output_dir=self.tmp_dir,
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            report_to="none",
        )
        trainer = DistillationTrainer(
            model=model,
            teacher_model="trl-internal-testing/tiny-Qwen3MoeForCausalLM",
            args=training_args,
            train_dataset=dataset,
            peft_config=LoraConfig(),
        )

        previous_trainable_params = {n: param.clone() for n, param in trainer.model.named_parameters()}

        trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None

        # Check that the peft params have changed and the base model params have not changed
        for n, param in previous_trainable_params.items():
            new_param = trainer.model.get_parameter(n)
            if n in base_param_names:  # We expect the base model params to be the same
                torch.testing.assert_close(param, new_param, msg=f"Parameter {n} has changed.")
            elif "base_layer" not in n:  # We expect the peft params to be different (except for the base layer)
                assert not torch.equal(param, new_param), f"Parameter {n} has not changed."

    @require_peft
    @require_bitsandbytes
    def test_train_peft_and_quantization(self):
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")

        training_args = DistillationConfig(
            output_dir=self.tmp_dir,
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            report_to="none",
        )
        quantization_config = BitsAndBytesConfig(
            load_in_4bit=True,
            bnb_4bit_use_double_quant=True,
            bnb_4bit_quant_type="nf4",
            bnb_4bit_compute_dtype=torch.bfloat16,
        )
        trainer = DistillationTrainer(
            model="trl-internal-testing/tiny-Qwen3ForCausalLM",  # identifier, so that the trainer quantizes it
            teacher_model="trl-internal-testing/tiny-Qwen3MoeForCausalLM",
            args=training_args,
            train_dataset=dataset,
            quantization_config=quantization_config,
            peft_config=LoraConfig(),
        )

        # Check that the trainer applied the quantization config when loading the model
        assert trainer.model.base_model.model.is_loaded_in_4bit

        previous_trainable_params = {n: param.clone() for n, param in trainer.model.named_parameters()}

        trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None

        # Check that the peft params have changed, and that they are cast to bfloat16, as recommended by the QLoRA
        # paper. The base model params are not checked: bitsandbytes casts the biases of a Linear4bit in-place during
        # the forward pass, so some of them change in a way that is unrelated to training.
        for n, param in previous_trainable_params.items():
            new_param = trainer.model.get_parameter(n)
            if "lora" in n:  # We expect the peft params to be different
                assert param.dtype == torch.bfloat16, f"Parameter {n} is not in bfloat16."
                assert not torch.equal(param, new_param), f"Parameter {n} has not changed."

    @require_peft
    @require_bitsandbytes
    def test_train_peft_dora_and_quantization(self):
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")

        training_args = DistillationConfig(
            output_dir=self.tmp_dir,
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            report_to="none",
        )
        quantization_config = BitsAndBytesConfig(
            load_in_4bit=True,
            bnb_4bit_use_double_quant=True,
            bnb_4bit_quant_type="nf4",
            bnb_4bit_compute_dtype=torch.bfloat16,
        )
        trainer = DistillationTrainer(
            model="trl-internal-testing/tiny-Qwen3ForCausalLM",  # identifier, so that the trainer quantizes it
            teacher_model="trl-internal-testing/tiny-Qwen3MoeForCausalLM",
            args=training_args,
            train_dataset=dataset,
            quantization_config=quantization_config,
            peft_config=LoraConfig(use_dora=True),
        )

        # Check that the trainer applied the quantization config when loading the model
        assert trainer.model.base_model.model.is_loaded_in_4bit

        previous_trainable_params = {n: param.clone() for n, param in trainer.model.named_parameters()}

        trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None

        # Check that the peft params have changed, and that they are cast to bfloat16, as recommended by the QLoRA
        # paper. The base model params are not checked: bitsandbytes casts the biases of a Linear4bit in-place during
        # the forward pass, so some of them change in a way that is unrelated to training.
        for n, param in previous_trainable_params.items():
            new_param = trainer.model.get_parameter(n)
            # The DoRA magnitude vector is the exception: it must stay in float32, since its optimizer updates can be
            # smaller than bfloat16 can represent, which would otherwise silently freeze it, see #7268
            if "lora_magnitude_vector" in n:
                assert param.dtype == torch.float32, f"Parameter {n} is not in float32."
                assert not torch.equal(param, new_param), f"Parameter {n} has not changed."
            elif "lora" in n:  # We expect the peft params to be different
                assert param.dtype == torch.bfloat16, f"Parameter {n} is not in bfloat16."
                assert not torch.equal(param, new_param), f"Parameter {n} has not changed."

    @require_peft
    def test_train_peft_model(self):
        model = AutoModelForCausalLM.from_pretrained("trl-internal-testing/tiny-Qwen3ForCausalLM", dtype="float32")
        base_param_names = [f"base_model.model.{n}" for n, _ in model.named_parameters()]
        model = get_peft_model(model, LoraConfig())
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")

        training_args = DistillationConfig(
            output_dir=self.tmp_dir,
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            report_to="none",
        )
        trainer = DistillationTrainer(
            model=model,
            teacher_model="trl-internal-testing/tiny-Qwen3MoeForCausalLM",
            args=training_args,
            train_dataset=dataset,
        )

        previous_trainable_params = {n: param.clone() for n, param in trainer.model.named_parameters()}

        trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None

        # Check that the peft params have changed and the base model params have not changed
        for n, param in previous_trainable_params.items():
            new_param = trainer.model.get_parameter(n)
            if n in base_param_names:  # We expect the base model params to be the same
                torch.testing.assert_close(param, new_param, msg=f"Parameter {n} has changed.")
            elif "base_layer" not in n:  # We expect the peft params to be different (except for the base layer)
                assert not torch.equal(param, new_param), f"Parameter {n} has not changed."

    # In practice, this test is the same as `test_train_peft_config`, since gradient checkpointing is enabled by
    # default in `DistillationTrainer`. We keep it as a regression guard: the assert fails if the default ever changes.
    @require_peft
    def test_train_peft_with_gradient_checkpointing(self):
        model = AutoModelForCausalLM.from_pretrained("trl-internal-testing/tiny-Qwen3ForCausalLM", dtype="float32")
        base_param_names = [f"base_model.model.{n}" for n, _ in model.named_parameters()]
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")

        training_args = DistillationConfig(
            output_dir=self.tmp_dir,
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            report_to="none",
        )
        assert training_args.gradient_checkpointing
        trainer = DistillationTrainer(
            model=model,
            teacher_model="trl-internal-testing/tiny-Qwen3MoeForCausalLM",
            args=training_args,
            train_dataset=dataset,
            peft_config=LoraConfig(),
        )

        previous_trainable_params = {n: param.clone() for n, param in trainer.model.named_parameters()}

        trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None

        # Check that the peft params have changed and the base model params have not changed
        for n, param in previous_trainable_params.items():
            new_param = trainer.model.get_parameter(n)
            if n in base_param_names:  # We expect the base model params to be the same
                torch.testing.assert_close(param, new_param, msg=f"Parameter {n} has changed.")
            elif "base_layer" not in n:  # We expect the peft params to be different (except for the base layer)
                assert not torch.equal(param, new_param), f"Parameter {n} has not changed."

    @require_torch_accelerator
    def test_train_with_fp16(self):
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")

        training_args = DistillationConfig(
            output_dir=self.tmp_dir,
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            fp16=True,
            report_to="none",
        )
        trainer = DistillationTrainer(
            model="trl-internal-testing/tiny-Qwen3ForCausalLM",
            teacher_model="trl-internal-testing/tiny-Qwen3MoeForCausalLM",
            args=training_args,
            train_dataset=dataset,
        )

        previous_trainable_params = {n: param.clone() for n, param in trainer.model.named_parameters()}

        trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None

        # Check that the params have changed
        for n, param in previous_trainable_params.items():
            new_param = trainer.model.get_parameter(n)
            assert not torch.equal(param, new_param), f"Parameter {n} has not changed."

    @require_peft
    def test_peft_non_lm_head_target_allowed(self):
        # The lm_head guard must only fire when the adapter actually wraps lm_head. An adapter targeting other modules
        # (here q_proj/v_proj) leaves lm_head as a plain Linear, so the loss reads the real (frozen) head weight and
        # there is nothing to silently drop. Guards against an over-broad regression of the guard.
        model = AutoModelForCausalLM.from_pretrained("trl-internal-testing/tiny-Qwen3ForCausalLM", dtype="float32")
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")
        DistillationTrainer(  # must construct without raising
            model=model,
            teacher_model="trl-internal-testing/tiny-Qwen3MoeForCausalLM",
            args=DistillationConfig(output_dir=self.tmp_dir, report_to="none"),
            train_dataset=dataset,
            peft_config=LoraConfig(target_modules=["q_proj", "v_proj"]),
        )

    @require_peft
    def test_peft_modules_to_save_lm_head_allowed(self):
        # `modules_to_save=["lm_head"]` makes the head a fully trained copy (a ModulesToSaveWrapper, not a tuner layer),
        # so `get_output_embeddings().weight` resolves to the trained weight and the loss trains it correctly. The guard
        # keys on the head being a tuner layer, so this must stay unblocked.
        model = AutoModelForCausalLM.from_pretrained("trl-internal-testing/tiny-Qwen3ForCausalLM", dtype="float32")
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")
        DistillationTrainer(  # must construct without raising
            model=model,
            teacher_model="trl-internal-testing/tiny-Qwen3MoeForCausalLM",
            args=DistillationConfig(output_dir=self.tmp_dir, report_to="none"),
            train_dataset=dataset,
            peft_config=LoraConfig(target_modules=["q_proj", "v_proj"], modules_to_save=["lm_head"]),
        )

    @require_peft
    def test_peft_lm_head_adapter_raises(self):
        # Both loss paths read `lm_head.weight` directly, so a PEFT adapter on the head is silently ignored. Reject it.
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")
        with pytest.raises(ValueError, match="lm_head"):
            DistillationTrainer(
                model="trl-internal-testing/tiny-Qwen3ForCausalLM",
                teacher_model="trl-internal-testing/tiny-Qwen3MoeForCausalLM",
                args=DistillationConfig(output_dir=self.tmp_dir, report_to="none"),
                train_dataset=dataset,
                peft_config=LoraConfig(target_modules=["q_proj", "lm_head"]),
            )

    @require_peft
    def test_peft_prompt_learning_raises(self):
        # Prompt-learning injects virtual tokens via `PeftModel.forward()`, which the backbone-direct loss bypasses.
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")
        with pytest.raises(ValueError, match="Prompt-learning"):
            DistillationTrainer(
                model="trl-internal-testing/tiny-Qwen3ForCausalLM",
                teacher_model="trl-internal-testing/tiny-Qwen3MoeForCausalLM",
                args=DistillationConfig(output_dir=self.tmp_dir, report_to="none"),
                train_dataset=dataset,
                peft_config=PrefixTuningConfig(num_virtual_tokens=4, task_type="CAUSAL_LM"),
            )

    def test_teacher_vocab_size_mismatch_raises(self):
        # The local-teacher loss compares full next-token distributions, so student and teacher must share a
        # vocabulary. A teacher with a different vocab_size is rejected (use GOLD for cross-tokenizer distillation).
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")
        with pytest.raises(ValueError, match="vocab_size"):
            DistillationTrainer(
                model="trl-internal-testing/tiny-Qwen3ForCausalLM",
                teacher_model="trl-internal-testing/tiny-LlamaForCausalLM-3.2",
                args=DistillationConfig(output_dir=self.tmp_dir, report_to="none"),
                train_dataset=dataset,
            )

    def test_teacher_model_init_kwargs_with_instantiated_teacher_raises(self):
        # `teacher_model_init_kwargs` only applies when the teacher is a model id; passing it alongside an already
        # instantiated teacher is a mistake worth surfacing.
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")
        with pytest.raises(ValueError, match="teacher_model_init_kwargs"):
            DistillationTrainer(
                model="trl-internal-testing/tiny-Qwen3ForCausalLM",
                teacher_model=AutoModelForCausalLM.from_pretrained("trl-internal-testing/tiny-Qwen3ForCausalLM"),
                args=DistillationConfig(
                    output_dir=self.tmp_dir, report_to="none", teacher_model_init_kwargs={"dtype": "float32"}
                ),
                train_dataset=dataset,
            )

    def test_loss_normalizes_by_num_items_in_batch(self):
        # When `num_items_in_batch` is passed (as under gradient accumulation), the divergence loss must be reduced as
        # sum / num_items_in_batch rather than the local per-microbatch mean. See issue #4719. The chunked JSD path
        # must honor `num_items_in_batch`.
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")
        trainer = DistillationTrainer(
            model="trl-internal-testing/tiny-Qwen3ForCausalLM",
            teacher_model="trl-internal-testing/tiny-Qwen3MoeForCausalLM",
            args=DistillationConfig(output_dir=self.tmp_dir, beta=0.5, report_to="none"),
            train_dataset=dataset,
        )

        device = trainer.accelerator.device
        prompt_length, completion_length = 4, 3
        vocab_size = trainer.model.config.vocab_size
        completion_mask = torch.ones(2, completion_length, dtype=torch.long, device=device)
        batch = {
            "prompt_ids": torch.randint(0, vocab_size, (2, prompt_length), device=device),
            "prompt_mask": torch.ones(2, prompt_length, dtype=torch.long, device=device),
            "completion_ids": torch.randint(0, vocab_size, (2, completion_length), device=device),
            "completion_mask": completion_mask,
        }

        # Number of valid (non-masked) completion tokens in the local batch.
        num_valid = completion_mask.sum()

        trainer.model.eval()
        with torch.no_grad():
            loss_mean = trainer.compute_loss(trainer.model, batch)  # num_items_in_batch=None -> local mean
            loss_global = trainer.compute_loss(trainer.model, batch, num_items_in_batch=num_valid)
            loss_double = trainer.compute_loss(trainer.model, batch, num_items_in_batch=num_valid * 2)

        # With num_items_in_batch equal to the local valid-token count, sum/N equals the local mean.
        torch.testing.assert_close(loss_global, loss_mean, rtol=1e-4, atol=1e-6)
        # Doubling the global count exactly halves the loss (sum / num_items is linear in 1/num_items).
        torch.testing.assert_close(loss_double, loss_mean / 2, rtol=1e-4, atol=1e-6)

    def test_compute_loss_matches_full_logit_reference(self):
        # The chunked JSD path must produce the same loss as the full-logit JSD it replaced (the handover). This also
        # checks the wiring: the student stays the student, the teacher the teacher, and only completion positions score.
        # A non-symmetric `beta` (0.25, not 0.5) is used deliberately so a student/teacher swap would change the loss.
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")
        trainer = DistillationTrainer(
            model="trl-internal-testing/tiny-Qwen3ForCausalLM",
            teacher_model="trl-internal-testing/tiny-Qwen3MoeForCausalLM",
            args=DistillationConfig(output_dir=self.tmp_dir, beta=0.25, report_to="none"),
            train_dataset=dataset,
        )

        device = trainer.accelerator.device
        vocab_size = trainer.model.config.vocab_size
        prompt_length, completion_length = 4, 3
        batch = {
            "prompt_ids": torch.randint(0, vocab_size, (2, prompt_length), device=device),
            "prompt_mask": torch.ones(2, prompt_length, dtype=torch.long, device=device),
            "completion_ids": torch.randint(0, vocab_size, (2, completion_length), device=device),
            "completion_mask": torch.ones(2, completion_length, dtype=torch.long, device=device),
        }
        num_valid = batch["completion_mask"].sum()

        trainer.model.eval()
        with torch.no_grad():
            loss = trainer.compute_loss(trainer.model, batch, num_items_in_batch=num_valid)

            # Full-logit reference (the pre-chunking loss): run both models' full forward, take the completion logits,
            # and compute the generalized JSD over the completion positions, normalized by num_items.
            input_ids = torch.cat([batch["prompt_ids"], batch["completion_ids"]], dim=1)
            attention_mask = torch.cat([batch["prompt_mask"], batch["completion_mask"]], dim=1)
            keep = slice(-completion_length - 1, -1)
            s = trainer.model(input_ids=input_ids, attention_mask=attention_mask).logits[:, keep, :]
            t = trainer.teacher_models[None](input_ids=input_ids, attention_mask=attention_mask).logits[:, keep, :]
            slp = torch.log_softmax(s.float(), dim=-1)
            tlp = torch.log_softmax(t.float(), dim=-1)
            beta_t = torch.tensor(0.25)
            mixture = torch.logsumexp(torch.stack([slp + torch.log1p(-beta_t), tlp + torch.log(beta_t)]), dim=0)
            jsd = 0.25 * F.kl_div(mixture, tlp, reduction="none", log_target=True) + 0.75 * F.kl_div(
                mixture, slp, reduction="none", log_target=True
            )
            reference = jsd.sum() / num_valid

        torch.testing.assert_close(loss, reference, rtol=1e-4, atol=1e-6)

    def test_pad_token_id_synced_with_model_config(self):
        # This model's tokenizer has no pad token, so the trainer falls back to the eos token. The model configs must
        # follow: otherwise `Trainer` realigns them at train time and reports it as a change the user did not make.
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")

        training_args = DistillationConfig(output_dir=self.tmp_dir, report_to="none")
        trainer = DistillationTrainer(
            model="trl-internal-testing/tiny-MistralForCausalLM-0.2",
            teacher_model="trl-internal-testing/tiny-MistralForCausalLM-0.2",
            args=training_args,
            train_dataset=dataset,
        )

        pad_token_id = trainer.processing_class.pad_token_id
        assert pad_token_id is not None
        assert trainer.model.config.pad_token_id == pad_token_id
        assert trainer.model.generation_config.pad_token_id == pad_token_id

    def test_train_with_multiple_teachers(self):
        # When `teacher_model` is a dict, each example selects its teacher via its `teacher_id` field, and its
        # completion is scored by that teacher only. With `shuffle_dataset=False`, every batch is [a, b, a, b].
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")
        dataset = dataset.map(lambda example, idx: {"teacher_id": ["a", "b"][idx % 2]}, with_indices=True)

        training_args = DistillationConfig(
            output_dir=self.tmp_dir,
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=4,  # 2 examples per teacher, so a batch mixes both teachers
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            logging_steps=1,
            shuffle_dataset=False,  # keep the [a, b, a, b] batch layout deterministic
            remove_unused_columns=True,  # `teacher_id` must survive column removal
            report_to="none",
        )
        trainer = DistillationTrainer(
            model="trl-internal-testing/tiny-Qwen3ForCausalLM",
            teacher_model={
                "a": "trl-internal-testing/small-Qwen3ForCausalLM",
                "b": "trl-internal-testing/tiny-Qwen3MoeForCausalLM",
            },
            args=training_args,
            train_dataset=dataset,
        )

        previous_trainable_params = {n: param.clone() for n, param in trainer.model.named_parameters()}

        trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None

        # Both teachers score their own share of the completion tokens at every step
        for entry in trainer.state.log_history[:-1]:
            assert entry["teacher/a/token_frac"] + entry["teacher/b/token_frac"] == pytest.approx(1.0)
            assert entry["teacher/a/jsd"] > 0 and entry["teacher/b/jsd"] > 0

        # Check that the params have changed
        for n, param in previous_trainable_params.items():
            new_param = trainer.model.get_parameter(n)
            assert not torch.equal(param, new_param), f"Parameter {n} has not changed."

    def test_train_with_unknown_teacher_raises(self):
        # With a dict `teacher_model`, an example whose `teacher_id` field doesn't match any configured teacher should
        # fail with a clear error.
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")
        dataset = dataset.map(lambda example: {"teacher_id": "unknown"})

        training_args = DistillationConfig(
            output_dir=self.tmp_dir,
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            report_to="none",
        )
        trainer = DistillationTrainer(
            model="trl-internal-testing/tiny-Qwen3ForCausalLM",
            teacher_model={"a": "trl-internal-testing/small-Qwen3ForCausalLM"},
            args=training_args,
            train_dataset=dataset,
        )

        with pytest.raises(ValueError, match="not among the teachers"):
            trainer.train()

    def test_train_with_same_teacher_under_two_ids(self):
        # Splitting the examples between two IDs of the same teacher must train and evaluate like a single teacher:
        # every completion token weighs the same in the loss, whatever its teacher.
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")
        dataset = dataset.map(lambda example, idx: {"teacher_id": ["a", "b"][idx % 2]}, with_indices=True)
        teacher = "trl-internal-testing/small-Qwen3ForCausalLM"

        trainers, eval_losses = [], []
        for teacher_model in [teacher, {"a": teacher, "b": teacher}]:
            training_args = DistillationConfig(
                output_dir=self.tmp_dir,
                learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
                per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
                gradient_accumulation_steps=2,  # normalize the loss across micro-batches routed differently
                max_completion_length=8,  # reduce the completion length to reduce memory usage
                optim="sgd",  # the update stays proportional to the gradient, so rounding differences stay small
                report_to="none",
            )
            trainer = DistillationTrainer(
                model="trl-internal-testing/tiny-Qwen3ForCausalLM",
                teacher_model=teacher_model,
                args=training_args,
                train_dataset=dataset,
                eval_dataset=dataset,
            )
            set_seed(42)  # generation is sampled, so seed right before training to make runs comparable
            trainer.train()
            set_seed(42)
            eval_losses.append(trainer.evaluate()["eval_loss"])
            trainers.append(trainer)

        single, two_ids = trainers
        for n, param in single.model.named_parameters():
            torch.testing.assert_close(two_ids.model.get_parameter(n), param, rtol=1e-5, atol=1e-6)
        assert eval_losses[1] == pytest.approx(eval_losses[0], rel=1e-5)

    def test_config_mapping(self):
        args = DistillationConfig(
            output_dir=self.tmp_dir,
            teacher_model_name_or_path='{"a": "org/a", "b": "org/b"}',
            teacher_model_init_kwargs='{"a": {"dtype": "bfloat16"}}',
        )
        assert args.teacher_model_name_or_path == {"a": "org/a", "b": "org/b"}
        assert args.teacher_model_init_kwargs == {"a": {"dtype": "bfloat16"}}

        args = DistillationConfig(output_dir=self.tmp_dir, teacher_model_name_or_path="org/a")
        assert args.teacher_model_name_or_path == "org/a"

    def test_per_teacher_init_kwargs(self):
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")
        teacher_model = {
            "a": "trl-internal-testing/small-Qwen3ForCausalLM",
            "b": "trl-internal-testing/small-Qwen3ForCausalLM",
        }
        trainer = DistillationTrainer(
            model="trl-internal-testing/tiny-Qwen3ForCausalLM",
            teacher_model=teacher_model,
            args=DistillationConfig(
                output_dir=self.tmp_dir,
                teacher_model_init_kwargs={"a": {"dtype": "bfloat16"}, "b": {"dtype": "float32"}},
                report_to="none",
            ),
            train_dataset=dataset,
        )
        assert trainer.accelerator.unwrap_model(trainer.teacher_models["a"]).dtype == torch.bfloat16
        assert trainer.accelerator.unwrap_model(trainer.teacher_models["b"]).dtype == torch.float32

        with pytest.raises(ValueError, match="unknown teacher IDs"):
            DistillationTrainer(
                model="trl-internal-testing/tiny-Qwen3ForCausalLM",
                teacher_model=teacher_model,
                args=DistillationConfig(
                    output_dir=self.tmp_dir, teacher_model_init_kwargs={"typo": {}}, report_to="none"
                ),
                train_dataset=dataset,
            )

    def test_teacher_vocab_size_mismatch_raises_with_multiple_teachers(self):
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")
        with pytest.raises(ValueError, match="teacher model 'b' has vocab_size"):
            DistillationTrainer(
                model="trl-internal-testing/tiny-Qwen3ForCausalLM",
                teacher_model={
                    "a": "trl-internal-testing/small-Qwen3ForCausalLM",
                    "b": "trl-internal-testing/tiny-LlamaForCausalLM-3.2",
                },
                args=DistillationConfig(output_dir=self.tmp_dir, report_to="none"),
                train_dataset=dataset,
            )

    @pytest.mark.skipif("TRL_TEST_DISTILLATION_CONFIG" not in os.environ, reason="launched by tests/distributed")
    def test_distributed_teacher_routing(self):
        # Each rank holds different teacher IDs, so a teacher may have no rows on a rank. With the same teacher under
        # both IDs, this must match a single ID.
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")
        teacher = "trl-internal-testing/small-Qwen3ForCausalLM"

        trainers = []
        for teacher_model, teacher_ids in [
            ({"a": teacher}, ["a"]),
            ({"a": teacher, "b": teacher}, ["a", "b", "a", "b", "a", "a", "a", "a"]),
        ]:
            training_args = DistillationConfig(
                output_dir=self.tmp_dir,
                learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
                per_device_train_batch_size=4,
                max_completion_length=8,  # reduce the completion length to reduce memory usage
                shuffle_dataset=False,  # keep the per-rank teacher IDs deterministic
                optim="sgd",  # the update stays proportional to the gradient, so rounding differences stay small
                bf16=False,  # DeepSpeed keeps bf16 weights, which round differently once the loss is split per teacher
                save_strategy="no",
                report_to="none",
                **json.loads(os.environ["TRL_TEST_DISTILLATION_CONFIG"]),
            )
            trainer = DistillationTrainer(
                model="trl-internal-testing/tiny-Qwen3ForCausalLM",
                teacher_model=teacher_model,
                args=training_args,
                train_dataset=dataset.add_column(
                    "teacher_id", [teacher_ids[i % len(teacher_ids)] for i in range(len(dataset))]
                ),
            )
            set_seed(42)  # generation is sampled, so seed right before training to make runs comparable
            trainer.train()
            trainers.append(trainer)

        one_id, two_ids = trainers
        assert one_id.accelerator.num_processes == 2
        assert one_id.state.global_step == two_ids.state.global_step
        one_id_params = one_id.accelerator.get_state_dict(one_id.model_wrapped)
        two_ids_params = two_ids.accelerator.get_state_dict(two_ids.model_wrapped)
        # ZeRO-3 consolidates the weights on rank zero.
        if one_id.accelerator.is_main_process:
            for name, param in one_id_params.items():
                torch.testing.assert_close(two_ids_params[name].cpu(), param.cpu(), rtol=1e-5, atol=1e-7, msg=name)

    @pytest.mark.xfail(
        condition=Version(transformers.__version__) < Version("5.2.0"),
        reason="Environment factory support is not available in transformers versions below 5.2.0",
        strict=True,
    )
    @require_response_parsing
    @patch.dict(os.environ, {"TRL_EXPERIMENTAL_SILENCE": "1"})
    def test_train_with_environment_factory(self):
        # In this test, we define a simple tool that increments an internal counter. Regardless of the input prompt,
        # the model will generate 3 completions, 2 of which will be valid tool calls. Among the 2 tool calls, one will
        # succeed and the other will fail (because `reset` is not exposed as a tool).
        dataset = Dataset.from_dict({"prompt": [[{"role": "user", "content": "Play."}]] * 6})

        training_args = DistillationConfig(
            output_dir=self.tmp_dir,
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            max_steps=2,
            report_to="none",
        )

        trainer = DistillationTrainer(
            model="trl-internal-testing/tiny-Qwen3MoeForCausalLM",
            # A different (same-vocab) teacher, so the divergence is not trivially zero
            teacher_model="trl-internal-testing/tiny-Qwen3ForCausalLM",
            args=training_args,
            train_dataset=dataset,
            environment_factory=IncrementEnvironment,
        )

        previous_trainable_params = {n: param.clone() for n, param in trainer.model.named_parameters()}

        script = ScriptedTurns(
            trainer.processing_class,
            first_turns=[
                '<tool_call>\n{"name": "increment", "arguments": {"step": 1}}\n</tool_call><|im_end|>',
                # a call to `reset`, which is not exposed as a tool
                '<tool_call>\n{"name": "reset", "arguments": {"step": 2}}\n</tool_call><|im_end|>',
                "I won't increment<|im_end|>",
            ],
        )
        with patch.object(trainer.model, "generate", script.generate):
            trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None
        assert trainer.state.log_history[-1]["tools/call_frequency"] is not None
        assert trainer.state.log_history[-1]["tools/call_frequency"] == pytest.approx(2 / 3)
        assert trainer.state.log_history[-1]["tools/failure_frequency"] is not None
        assert trainer.state.log_history[-1]["tools/failure_frequency"] == pytest.approx(1 / 2)
        # The failed call is answered with its error, so both tool calls get a next turn at every step
        assert script.turns_after_tool == 2 * trainer.state.global_step
        # Without `get_reward`, no environment score is logged
        assert not any(key.startswith("rewards/") for key in trainer.state.log_history[-1])

        # The tools in the prompt are the environment's public methods: `increment`, not `reset`
        prompts = list(script.seen)
        assert '"name": "increment"' in prompts[0]
        assert '"name": "reset"' not in prompts[0]

        # Check that the params have changed
        for n, param in previous_trainable_params.items():
            new_param = trainer.model.get_parameter(n)
            assert not torch.equal(param, new_param), f"Parameter {n} has not changed."

    @pytest.mark.xfail(
        condition=Version(transformers.__version__) < Version("5.2.0"),
        reason="Environment factory support is not available in transformers versions below 5.2.0",
        strict=True,
    )
    @require_response_parsing
    @patch.dict(os.environ, {"TRL_EXPERIMENTAL_SILENCE": "1"})
    def test_train_with_stateful_environment(self):
        # Each rollout is reset with its `start` column and calls `increment` every turn: start -> +1 -> +3, and the
        # third call is cut by `max_tool_calling_iterations=2`
        dataset = Dataset.from_dict(
            {"prompt": [[{"role": "user", "content": "Count."}]] * 3, "start": [0, 10, 20]},
        )

        training_args = DistillationConfig(
            output_dir=self.tmp_dir,
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            max_tool_calling_iterations=2,
            report_to="none",
        )
        trainer = DistillationTrainer(
            model="trl-internal-testing/tiny-Qwen3MoeForCausalLM",
            teacher_model="trl-internal-testing/tiny-Qwen3ForCausalLM",
            args=training_args,
            train_dataset=dataset,
            environment_factory=StartedCounterEnvironment,
        )

        increment_1 = '<tool_call>\n{"name": "increment", "arguments": {"step": 1}}\n</tool_call><|im_end|>'
        increment_2 = '<tool_call>\n{"name": "increment", "arguments": {"step": 2}}\n</tool_call><|im_end|>'
        script = ScriptedTurns(trainer.processing_class, first_turns=[increment_1], after_tool=increment_2)
        with patch.object(trainer.model, "generate", script.generate):
            trainer.train()

        logged = trainer.state.log_history[-1]
        assert logged["train_loss"] is not None
        # 2 calls run per rollout, the third is cut by `max_tool_calling_iterations`
        assert logged["tools/call_frequency"] == pytest.approx(2.0)
        assert logged["tools/failure_frequency"] == pytest.approx(0.0)
        # The score is logged, never trained on: final counters 3, 13 and 23
        assert logged["rewards/StartedCounterEnvironment/mean"] == pytest.approx(13.0)
        # Only the 3 model turns count as completion tokens: the tool results are masked out of the loss
        num_turn_tokens = len(trainer.processing_class(increment_1, add_special_tokens=False).input_ids)
        assert logged["completions/mean_length"] == pytest.approx(3 * num_turn_tokens)
        # The observation returned by `reset` is appended to the prompt
        assert {prompt.count("The counter starts at") for prompt in script.seen} == {1}

    @pytest.mark.xfail(
        condition=Version(transformers.__version__) < Version("5.2.0"),
        reason="Environment factory support is not available in transformers versions below 5.2.0",
        strict=True,
    )
    @require_response_parsing
    @patch.dict(os.environ, {"TRL_EXPERIMENTAL_SILENCE": "1"})
    def test_train_with_environment_and_tools(self):
        # Rollouts call the standalone tool, `increment` with a rejected step, and `increment`
        dataset = Dataset.from_dict({"prompt": [[{"role": "user", "content": "Count."}]] * 3, "start": [0, 0, 0]})

        training_args = DistillationConfig(
            output_dir=self.tmp_dir,
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            max_steps=1,
            report_to="none",
        )
        trainer = DistillationTrainer(
            model="trl-internal-testing/tiny-Qwen3MoeForCausalLM",
            teacher_model="trl-internal-testing/tiny-Qwen3ForCausalLM",
            args=training_args,
            train_dataset=dataset,
            tools=[multiply_tool],
            environment_factory=StartedCounterEnvironment,
        )

        script = ScriptedTurns(
            trainer.processing_class,
            first_turns=[
                '<tool_call>\n{"name": "multiply_tool", "arguments": {"a": 3, "b": 4}}\n</tool_call><|im_end|>',
                '<tool_call>\n{"name": "increment", "arguments": {"step": -1}}\n</tool_call><|im_end|>',
                '<tool_call>\n{"name": "increment", "arguments": {"step": 1}}\n</tool_call><|im_end|>',
            ],
        )
        with patch.object(trainer.model, "generate", script.generate):
            trainer.train()

        logged = trainer.state.log_history[-1]
        assert logged["tools/call_frequency"] == pytest.approx(1.0)
        # The exception raised by the environment is returned to the model as the tool result, so it gets a next turn
        assert logged["tools/failure_frequency"] == pytest.approx(1 / 3)
        assert script.turns_after_tool == 3 * trainer.state.global_step
        # Only the successful `increment` moved its counter
        assert logged["rewards/StartedCounterEnvironment/mean"] == pytest.approx(1 / 3)
        prompt = next(iter(script.seen))
        assert '"name": "multiply_tool"' in prompt and '"name": "increment"' in prompt

    @pytest.mark.xfail(
        condition=Version(transformers.__version__) < Version("5.2.0"),
        reason="Environment factory support is not available in transformers versions below 5.2.0",
        strict=True,
    )
    @require_response_parsing
    @patch.dict(os.environ, {"TRL_EXPERIMENTAL_SILENCE": "1"})
    def test_environment_episode_capped_by_max_completion_length(self):
        # `max_completion_length` caps the whole episode: an overflowing tool result is dropped, a model turn truncated
        dataset = Dataset.from_dict(
            {"prompt": [[{"role": "user", "content": "Read."}]] * 3, "length": [1000, 1, 1000]},
        )

        training_args = DistillationConfig(
            output_dir=self.tmp_dir,
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            max_completion_length=64,
            max_steps=1,
            report_to="none",
        )
        trainer = DistillationTrainer(
            model="trl-internal-testing/tiny-Qwen3MoeForCausalLM",
            teacher_model="trl-internal-testing/tiny-Qwen3ForCausalLM",
            args=training_args,
            train_dataset=dataset,
            environment_factory=DocumentEnvironment,
        )

        script = ScriptedTurns(
            trainer.processing_class,
            first_turns=['<tool_call>\n{"name": "read", "arguments": {}}\n</tool_call><|im_end|>'],
            after_tool="word " * 100 + "<|im_end|>",
        )
        with patch.object(trainer.model, "generate", script.generate):
            trainer.train()

        logged = trainer.state.log_history[-1]
        assert logged["train_loss"] is not None
        assert logged["tools/call_frequency"] == pytest.approx(1.0)
        # Only the short document fits: that rollout gets a next turn, truncated at the budget
        assert script.turns_after_tool == trainer.state.global_step
        assert logged["completions/clipped_ratio"] == pytest.approx(1 / 3)
        assert logged["completions/max_length"] <= 64

    @pytest.mark.xfail(
        condition=Version(transformers.__version__) < Version("5.2.0"),
        reason="Environment factory support is not available in transformers versions below 5.2.0",
        strict=True,
    )
    @require_response_parsing
    @patch.dict(os.environ, {"TRL_EXPERIMENTAL_SILENCE": "1"})
    def test_train_with_multiple_environments(self, monkeypatch):
        # When `environment_factory` is a dict, each rollout selects its environment via its `environment` field, and
        # only that environment's tools are exposed. Here we build a mixed batch with both environments and check that
        # a tool call from a "counter" example dispatches to the CounterEnvironment's `increment`, while a tool call
        # from an "echo" example dispatches to the EchoEnvironment's `shout`. Every batch holds 2 examples of each
        # environment.
        dataset = Dataset.from_dict(
            {"prompt": [[{"role": "user", "content": "Play."}]] * 4, "environment": ["counter", "echo"] * 2}
        )
        record_path = os.path.join(self.tmp_dir, "record.jsonl")
        monkeypatch.setenv("TRL_TEST_RECORD", record_path)

        training_args = DistillationConfig(
            output_dir=self.tmp_dir,
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=4,  # a batch mixes both environments
            remove_unused_columns=True,  # `environment` must survive column removal
            report_to="none",
        )

        trainer = DistillationTrainer(
            model="trl-internal-testing/tiny-Qwen3MoeForCausalLM",
            teacher_model="trl-internal-testing/tiny-Qwen3ForCausalLM",
            args=training_args,
            train_dataset=dataset,
            environment_factory={"counter": CounterEnvironment, "echo": EchoEnvironment},
        )

        previous_trainable_params = {n: param.clone() for n, param in trainer.model.named_parameters()}

        script = ScriptedTurns(
            trainer.processing_class,
            first_turns=lambda prompt: (
                [
                    # counter example: valid `increment` tool call (only CounterEnvironment exposes it)
                    '<tool_call>\n{"name": "increment", "arguments": {"step": 1}}\n</tool_call><|im_end|>',
                    # counter example: no tool call
                    "I won't<|im_end|>",
                ]
                if "Count." in prompt
                else [
                    # echo example: valid `shout` tool call (only EchoEnvironment exposes it)
                    '<tool_call>\n{"name": "shout", "arguments": {"text": "hi"}}\n</tool_call><|im_end|>',
                    # echo example: no tool call
                    "Done!<|im_end|>",
                ]
            ),
        )
        with patch.object(trainer.model, "generate", script.generate):
            trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None
        # The tool call from the counter example ran `increment` (defined only on CounterEnvironment) and the one from
        # the echo example ran `shout` (defined only on EchoEnvironment): each rollout dispatched to its own tools.
        records = recorded(record_path)
        assert records["increment"]
        assert records["shout"]
        # Half of the rollouts issued a tool call, and every call succeeded.
        assert trainer.state.log_history[-1]["tools/call_frequency"] == pytest.approx(2 / 4)
        assert trainer.state.log_history[-1]["tools/failure_frequency"] == pytest.approx(0.0)
        # Both environments were selected and reset, and `environment` is a control field not forwarded to `reset`.
        assert records["reset_counter"] and records["reset_echo"]
        assert all("environment" not in kwargs for kwargs in records["reset_counter"] + records["reset_echo"])
        # Each rollout is shown only the tool of its own environment
        prompts = list(script.seen)
        assert all(("increment" in prompt) == ("Count." in prompt) for prompt in prompts)
        assert all(("shout" in prompt) == ("Echo." in prompt) for prompt in prompts)

        # Check that the params have changed
        for n, param in previous_trainable_params.items():
            new_param = trainer.model.get_parameter(n)
            assert not torch.equal(param, new_param), f"Parameter {n} has not changed."

    @pytest.mark.xfail(
        condition=Version(transformers.__version__) < Version("5.2.0"),
        reason="Environment factory support is not available in transformers versions below 5.2.0",
        strict=True,
    )
    @require_response_parsing
    @patch.dict(os.environ, {"TRL_EXPERIMENTAL_SILENCE": "1"})
    def test_train_with_multiple_environments_same_tool_name(self, monkeypatch):
        # Two environments expose a `submit` tool with different argument types. Each tool call must be parsed with the
        # schema of its own environment's `submit`: the zip code stays the string "42", the count is the integer 42.
        # Every batch holds 2 examples of each environment.
        dataset = Dataset.from_dict(
            {"prompt": [[{"role": "user", "content": "Play."}]] * 4, "environment": ["zip", "count"] * 2}
        )
        record_path = os.path.join(self.tmp_dir, "record.jsonl")
        monkeypatch.setenv("TRL_TEST_RECORD", record_path)

        training_args = DistillationConfig(
            output_dir=self.tmp_dir,
            per_device_train_batch_size=4,  # a batch mixes both environments
            report_to="none",
        )

        trainer = DistillationTrainer(
            model="trl-internal-testing/tiny-Qwen3MoeForCausalLM",
            teacher_model="trl-internal-testing/tiny-Qwen3ForCausalLM",
            args=training_args,
            train_dataset=dataset,
            environment_factory={"zip": ZipEnvironment, "count": CountEnvironment},
        )

        script = ScriptedTurns(
            trainer.processing_class,
            first_turns=lambda prompt: (
                ['<tool_call>\n{"name": "submit", "arguments": {"answer": "42"}}\n</tool_call><|im_end|>']
                if "zip code" in prompt
                else ['<tool_call>\n{"name": "submit", "arguments": {"answer": 42}}\n</tool_call><|im_end|>']
            ),
        )
        with patch.object(trainer.model, "generate", script.generate):
            trainer.train()

        records = recorded(record_path)
        assert records["zip"] and all(answer == "42" for answer in records["zip"])
        assert records["count"] and all(answer == 42 for answer in records["count"])

    @pytest.mark.xfail(
        condition=Version(transformers.__version__) < Version("5.2.0"),
        reason="Environment factory support is not available in transformers versions below 5.2.0",
        strict=True,
    )
    @require_response_parsing
    @patch.dict(os.environ, {"TRL_EXPERIMENTAL_SILENCE": "1"})
    def test_reset_does_not_receive_teacher_id(self, monkeypatch):
        # When `teacher_model` is a dict, each example selects its teacher via its `teacher_id` field. Like
        # `environment` in multi-environment mode, `teacher_id` is a control field, so it must not reach `reset`.
        dataset = Dataset.from_dict(
            {"prompt": [[{"role": "user", "content": "Play."}]] * 4, "teacher_id": ["a", "b"] * 2}
        )
        record_path = os.path.join(self.tmp_dir, "record.jsonl")
        monkeypatch.setenv("TRL_TEST_RECORD", record_path)

        training_args = DistillationConfig(
            output_dir=self.tmp_dir,
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=4,  # 2 examples per teacher, so a batch mixes both teachers
            remove_unused_columns=True,  # `teacher_id` must survive column removal
            report_to="none",
        )

        trainer = DistillationTrainer(
            model="trl-internal-testing/tiny-Qwen3MoeForCausalLM",
            teacher_model={
                "a": "trl-internal-testing/tiny-Qwen3ForCausalLM",
                "b": "trl-internal-testing/tiny-Qwen3ForCausalLM",
            },
            args=training_args,
            train_dataset=dataset,
            environment_factory=CounterEnvironment,
        )

        previous_trainable_params = {n: param.clone() for n, param in trainer.model.named_parameters()}

        script = ScriptedTurns(
            trainer.processing_class,
            first_turns=['<tool_call>\n{"name": "increment", "arguments": {"step": 1}}\n</tool_call><|im_end|>'],
        )
        with patch.object(trainer.model, "generate", script.generate):
            trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None
        # Every rollout was reset, and `teacher_id` is a control field not forwarded to `reset`.
        records = recorded(record_path)
        assert records["reset_counter"]
        assert all("teacher_id" not in kwargs for kwargs in records["reset_counter"])

        # Check that the params have changed
        for n, param in previous_trainable_params.items():
            new_param = trainer.model.get_parameter(n)
            assert not torch.equal(param, new_param), f"Parameter {n} has not changed."

    @pytest.mark.xfail(
        condition=Version(transformers.__version__) < Version("5.2.0"),
        reason="Environment factory support is not available in transformers versions below 5.2.0",
        strict=True,
    )
    @require_response_parsing
    @patch.dict(os.environ, {"TRL_EXPERIMENTAL_SILENCE": "1"})
    def test_train_with_unknown_environment_raises(self):
        # With a dict `environment_factory`, an example whose `environment` field doesn't match any configured
        # environment should fail with a clear error rather than a bare KeyError mid-rollout.
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")
        dataset = dataset.map(lambda example: {"environment": "unknown"})

        training_args = DistillationConfig(
            output_dir=self.tmp_dir,
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            report_to="none",
        )

        trainer = DistillationTrainer(
            model="trl-internal-testing/tiny-Qwen3MoeForCausalLM",
            teacher_model="trl-internal-testing/tiny-Qwen3ForCausalLM",
            args=training_args,
            train_dataset=dataset,
            environment_factory={"counter": CounterEnvironment},
        )

        with pytest.raises(ValueError, match="not among the environments"):
            trainer.train()

    @pytest.mark.xfail(
        condition=Version(transformers.__version__) < Version("5.2.0"),
        reason="Environment factory support is not available in transformers versions below 5.2.0",
        strict=True,
    )
    @require_response_parsing
    @patch.dict(os.environ, {"TRL_EXPERIMENTAL_SILENCE": "1"})
    def test_tool_discovery_does_not_evaluate_environment_properties(self):
        # Tool discovery must list the environment's methods on its class. `inspect.getmembers` calls `getattr` on
        # every name before applying the predicate, so listing the instance evaluates its properties, and a property
        # may be expensive or have side effects (a Harbor env scores the rollout from one). Here `reward` is inert on
        # a fresh instance and raises once the environment has been reset: the first batch resets the pooled
        # instances, so a second batch that listed the instance would raise before generating anything.
        dataset = Dataset.from_dict({"prompt": [[{"role": "user", "content": "Play."}]] * 6})

        training_args = DistillationConfig(
            output_dir=self.tmp_dir,
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            max_steps=2,  # the first batch resets the pooled instances, the second re-lists their tools
            report_to="none",
        )

        trainer = DistillationTrainer(
            model="trl-internal-testing/tiny-Qwen3MoeForCausalLM",
            teacher_model="trl-internal-testing/tiny-Qwen3ForCausalLM",
            args=training_args,
            train_dataset=dataset,
            environment_factory=PropertyEnvironment,
        )

        # No tool call, so one generation round per rollout.
        script = ScriptedTurns(trainer.processing_class, first_turns=["I won't increment<|im_end|>"])
        with patch.object(trainer.model, "generate", script.generate):
            trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None

    @pytest.mark.xfail(
        condition=Version(transformers.__version__) < Version("5.2.0"),
        reason="Environment factory support is not available in transformers versions below 5.2.0",
        strict=True,
    )
    @require_response_parsing
    @patch.dict(os.environ, {"TRL_EXPERIMENTAL_SILENCE": "1"})
    def test_environment_owned_reward_mixed_environments(self):
        # With a dict `environment_factory`, only some environments may own their reward via `get_reward`. Each such
        # env *class* contributes one reward column (named after its class); a rollout is scored only when its
        # environment is that class, so mixing a reward-owning env with a plain one must not raise. Reward columns are
        # deduplicated by class: two names mapping to the same `get_reward` class share a single column (no
        # double-counting).
        dataset = Dataset.from_dict(
            {
                "prompt": [[{"role": "user", "content": "Play."}]] * 3,
                "environment": ["scored", "scored2", "plain"],
            }
        )

        training_args = DistillationConfig(
            output_dir=self.tmp_dir,
            per_device_train_batch_size=3,  # one batch holds the 3 environments
            report_to="none",
        )
        trainer = DistillationTrainer(
            model="trl-internal-testing/tiny-Qwen3MoeForCausalLM",
            teacher_model="trl-internal-testing/tiny-Qwen3ForCausalLM",
            args=training_args,
            train_dataset=dataset,
            # `scored` and `scored2` both build `ScoredEnvironment`, so they must collapse to a single reward column.
            environment_factory={
                "scored": ScoredEnvironment,
                "scored2": ScoredEnvironment,
                "plain": IncrementEnvironment,
            },
        )

        # No tool call.
        script = ScriptedTurns(trainer.processing_class, first_turns=["I won't increment<|im_end|>"])
        with patch.object(trainer.model, "generate", script.generate):
            trainer.train()

        # Only `ScoredEnvironment` owns a reward, and despite two names mapping to it, a single (deduplicated) env-reward
        # column is logged. It scores only the rollouts bound to `ScoredEnvironment`: an `IncrementEnvironment` rollout
        # is left out instead of raising.
        logged = trainer.state.log_history[-1]
        reward_columns = {key for key in logged if key.startswith("rewards/") and key.endswith("/mean")}
        assert reward_columns == {"rewards/ScoredEnvironment/mean"}
        assert logged["rewards/ScoredEnvironment/mean"] == 1.0

    @pytest.mark.xfail(
        condition=Version(transformers.__version__) < Version("5.2.0"),
        reason="Environment factory support is not available in transformers versions below 5.2.0",
        strict=True,
    )
    @require_response_parsing
    @patch.dict(os.environ, {"TRL_EXPERIMENTAL_SILENCE": "1"})
    def test_async_environment_raises(self):
        # Async environment methods (tools or `get_reward`) are rejected at init
        class AsyncToolEnvironment(IncrementEnvironment):
            async def decrement(self, step: int) -> int:
                """
                Decrement the internal counter.

                Args:
                    step: Value to subtract from the counter.

                Returns:
                    The updated counter value.
                """
                self._counter -= step
                return self._counter

        class AsyncRewardEnvironment(IncrementEnvironment):
            async def get_reward(self) -> float:
                return float(self._counter)

        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_only", split="train")
        training_args = DistillationConfig(output_dir=self.tmp_dir, report_to="none")
        for environment_factory in (AsyncToolEnvironment, AsyncRewardEnvironment):
            with pytest.raises(ValueError, match="Async"):
                DistillationTrainer(
                    model="trl-internal-testing/tiny-Qwen3MoeForCausalLM",
                    teacher_model="trl-internal-testing/tiny-Qwen3ForCausalLM",
                    args=training_args,
                    train_dataset=dataset,
                    environment_factory=environment_factory,
                )


@require_vision
class TestDistillationTrainerVLM(TrlTestCase):
    @pytest.mark.parametrize(
        "model_id",
        [
            pytest.param(
                "trl-internal-testing/tiny-Gemma3ForConditionalGeneration",
                id="gemma3",
                marks=pytest.mark.skipif(
                    Version(transformers.__version__) < Version("4.57.0"),
                    reason="transformers<4.57 Gemma3 image processor can't batch variable-size images",
                ),
            ),
            pytest.param(
                "trl-internal-testing/tiny-Gemma4ForConditionalGeneration",
                id="gemma4",
                marks=pytest.mark.skipif(
                    Version(transformers.__version__) < Version("5.5.0"),
                    reason="Gemma4 models were introduced in transformers-5.5.0",
                ),
            ),
            pytest.param(
                "trl-internal-testing/tiny-Inkling2ForConditionalGeneration",
                id="inkling2",
                marks=[
                    pytest.mark.skipif(
                        Version(transformers.__version__) < Version("5.23.0"),
                        reason="Inkling 2 models were introduced in transformers-5.23.0",
                    ),
                    pytest.mark.xfail(
                        Version(transformers.__version__) < Version("5.24.0.dev0"),
                        reason="transformers < 5.24 loads the dequantized FP8 checkpoint in mixed dtypes "
                        "(huggingface/transformers#50595, huggingface/transformers#50975)",
                        strict=True,
                    ),
                ],
            ),
            pytest.param(
                "trl-internal-testing/tiny-Inkling2LoopForConditionalGeneration",
                id="inkling2-loop",
                marks=pytest.mark.skipif(
                    Version(transformers.__version__) < Version("5.24.0"),
                    reason="Inkling 2 Mini models were introduced in transformers-5.24.0",
                ),
            ),
            pytest.param("trl-internal-testing/tiny-InternVLForConditionalGeneration", id="internvl"),
            pytest.param("trl-internal-testing/tiny-LlavaNextForConditionalGeneration", id="llava-next"),
            pytest.param("trl-internal-testing/tiny-Qwen2_5_VLForConditionalGeneration", id="qwen2.5-vl"),
            pytest.param("trl-internal-testing/tiny-Qwen2VLForConditionalGeneration", id="qwen2-vl"),
            pytest.param(
                "trl-internal-testing/tiny-Qwen3_5ForConditionalGeneration-NoThink",
                id="qwen3.5-nothink",
                marks=pytest.mark.skipif(
                    Version(transformers.__version__) < Version("5.2.0"),
                    reason="Qwen3.5 models were introduced in transformers-5.2.0",
                ),
            ),
            pytest.param(
                "trl-internal-testing/tiny-Qwen3_5MoeForConditionalGeneration-3.6",
                id="qwen3.6-moe",
                marks=pytest.mark.skipif(
                    Version(transformers.__version__) < Version("5.2.0"),
                    reason="Qwen3.5 models were introduced in transformers-5.2.0",
                ),
            ),
            # "trl-internal-testing/tiny-SmolVLMForConditionalGeneration", seems not to support bf16 properly
        ],
    )
    def test_train_vlm(self, model_id):
        dataset = load_dataset("trl-internal-testing/zen-image", "conversational_prompt_only", split="train")

        training_args = DistillationConfig(
            output_dir=self.tmp_dir,
            per_device_train_batch_size=2,  # VLM training is memory intensive, reduce batch size to avoid OOM
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            report_to="none",
        )
        trainer = DistillationTrainer(
            model=model_id,
            teacher_model=model_id,  # self-distillation: no tiny+small VLM fixture pair exists
            args=training_args,
            train_dataset=dataset,
        )
        # A text-only batch would leave the vision tower without gradients, so DDP looks for unused parameters
        assert trainer.args.ddp_find_unused_parameters

        trainer.train()

        # Self-distillation gives a near-zero teacher signal, so we assert the multimodal path ran end to end and the
        # loss stayed finite, rather than params-changed (see `test_train_dataset_format`).
        train_loss = trainer.state.log_history[-1]["train_loss"]
        assert train_loss is not None
        assert torch.isfinite(torch.tensor(train_loss))

    def test_generation_suppresses_image_token(self):
        # Gemma3: its processor's `image_token_id` is not the placeholder token, unlike its config's
        dataset = load_dataset("trl-internal-testing/zen-image", "conversational_prompt_only", split="train")
        training_args = DistillationConfig(output_dir=self.tmp_dir, report_to="none")
        trainer = DistillationTrainer(
            model="trl-internal-testing/tiny-Gemma3ForConditionalGeneration",
            teacher_model="trl-internal-testing/tiny-Gemma3ForConditionalGeneration",
            args=training_args,
            train_dataset=dataset,
        )

        assert trainer.generation_config.suppress_tokens == [trainer.model.config.image_token_id]

    def test_generation_suppresses_vision_start_token(self):
        # transformers<5.3.0 crashes when a completion ends with <|vision_start|> (see #8163)
        dataset = load_dataset("trl-internal-testing/zen-image", "conversational_prompt_only", split="train")
        training_args = DistillationConfig(output_dir=self.tmp_dir, report_to="none")
        trainer = DistillationTrainer(
            model="trl-internal-testing/tiny-Qwen2_5_VLForConditionalGeneration",
            teacher_model="trl-internal-testing/tiny-Qwen2_5_VLForConditionalGeneration",
            args=training_args,
            train_dataset=dataset,
        )

        expected = [trainer.model.config.image_token_id]
        if Version(transformers.__version__) < Version("5.3.0"):
            expected.append(trainer.model.config.vision_start_token_id)
        assert trainer.generation_config.suppress_tokens == expected

    @pytest.mark.parametrize(
        "model_id",
        [
            pytest.param(
                "trl-internal-testing/tiny-Qwen2VLForConditionalGeneration",  # image_grid_thw path
                id="qwen2-vl",
            ),
            pytest.param(
                "trl-internal-testing/tiny-Gemma3ForConditionalGeneration",  # image_position_ids path
                id="gemma3",
                marks=pytest.mark.skipif(
                    Version(transformers.__version__) < Version("4.57.0"),
                    reason="transformers<4.57 Gemma3 image processor can't batch variable-size images",
                ),
            ),
        ],
    )
    def test_train_vlm_gradient_accumulation(self, model_id):
        # With gradient accumulation the packed `pixel_values` are split across micro-batches via `num_images`; train a
        # couple of steps to exercise that path (a missing `num_images` would misalign images and text).
        dataset = load_dataset("trl-internal-testing/zen-image", "conversational_prompt_only", split="train")

        training_args = DistillationConfig(
            output_dir=self.tmp_dir,
            per_device_train_batch_size=2,  # VLM training is memory intensive, reduce batch size to avoid OOM
            gradient_accumulation_steps=2,  # split the packed pixel_values across micro-batches
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            report_to="none",
        )
        trainer = DistillationTrainer(
            model=model_id,
            teacher_model=model_id,  # self-distillation: no tiny+small VLM fixture pair exists
            args=training_args,
            train_dataset=dataset,
        )

        trainer.train()

        train_loss = trainer.state.log_history[-1]["train_loss"]
        assert train_loss is not None
        assert torch.isfinite(torch.tensor(train_loss))

    @pytest.mark.parametrize(
        "model_id",
        [
            pytest.param("trl-internal-testing/tiny-Qwen2_5_VLForConditionalGeneration", id="qwen2.5-vl"),
            pytest.param("trl-internal-testing/tiny-Gemma3ForConditionalGeneration", id="gemma3"),
            pytest.param(
                "trl-internal-testing/tiny-Gemma4ForConditionalGeneration",
                id="gemma4",
                marks=pytest.mark.skipif(
                    Version(transformers.__version__) < Version("5.5.0"),
                    reason="Gemma4 models were introduced in transformers-5.5.0",
                ),
            ),
            pytest.param(
                "trl-internal-testing/tiny-Inkling2ForConditionalGeneration",
                id="inkling2",
                marks=pytest.mark.skipif(
                    Version(transformers.__version__) < Version("5.23.0"),
                    reason="Inkling 2 models were introduced in transformers-5.23.0",
                ),
            ),
            pytest.param(
                "trl-internal-testing/tiny-Inkling2LoopForConditionalGeneration",
                id="inkling2-loop",
                marks=pytest.mark.skipif(
                    Version(transformers.__version__) < Version("5.24.0"),
                    reason="Inkling 2 Mini models were introduced in transformers-5.24.0",
                ),
            ),
        ],
    )
    @require_vllm
    @pytest.mark.skip(reason="We should add a mock for the vLLM server.")
    def test_train_vlm_and_vllm(self, model_id) -> None:
        dataset = load_dataset("trl-internal-testing/zen-image", "conversational_prompt_only", split="train")

        training_args = DistillationConfig(
            output_dir=self.tmp_dir,
            per_device_train_batch_size=2,  # VLM training is memory intensive, reduce batch size to avoid OOM
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            report_to="none",
            use_vllm=True,
            vllm_mode="server",
        )
        trainer = DistillationTrainer(
            model=model_id,
            teacher_model=model_id,  # self-distillation: no tiny+small VLM fixture pair exists
            args=training_args,
            train_dataset=dataset,
        )

        trainer.train()

        # Self-distillation gives a near-zero teacher signal, so we assert the multimodal path ran end to end and the
        # loss stayed finite, rather than params-changed (see `test_train_dataset_format`).
        train_loss = trainer.state.log_history[-1]["train_loss"]
        assert train_loss is not None
        assert torch.isfinite(torch.tensor(train_loss))

    @pytest.mark.xfail(
        condition=Version(transformers.__version__) < Version("5.2.0"),
        reason="Qwen3.5 models were introduced in transformers-5.2.0",
        strict=True,
    )
    @require_response_parsing
    def test_train_with_tools_multimodal_response(self):
        # Test that tools returning images (multimodal responses) work correctly with a VLM.
        # The tool returns a list of content blocks including an image.
        from PIL import Image as PILImage

        def screenshot_tool() -> list:
            """
            Takes a screenshot and returns it.

            Returns:
                A list of content blocks with the screenshot image.
            """
            img = PILImage.new("RGB", (64, 64), color="red")
            return [{"type": "image", "image": img}, {"type": "text", "text": "Here is the screenshot"}]

        dataset = load_dataset("trl-internal-testing/zen-image", "conversational_prompt_only", split="train")

        training_args = DistillationConfig(
            output_dir=self.tmp_dir,
            per_device_train_batch_size=2,  # VLM training is memory intensive, reduce batch size to avoid OOM
            max_completion_length=512,
            report_to="none",
        )
        trainer = DistillationTrainer(
            model="trl-internal-testing/tiny-Qwen3_5ForConditionalGeneration-NoThink",
            teacher_model="trl-internal-testing/tiny-Qwen3_5ForConditionalGeneration-NoThink",
            args=training_args,
            train_dataset=dataset,
            tools=[screenshot_tool],
        )

        def fake_generate(input_ids, **kwargs):
            if input_ids.shape[0] == 2:  # first call
                # fmt: off
                completion_ids = torch.tensor(
                    [
                        # '<tool_call>\n<function=screenshot_tool>\n</function>\n</tool_call><|im_end|>'
                        [248058, 198, 27, 1628, 13744, 30091, 22076, 29, 198, 510, 1628, 29, 198, 248059, 248046],
                        # "I don't know any tool<|im_end|>" + padding
                        [40, 1459, 914, 1366, 866, 5224, 248046, 248044, 248044, 248044, 248044, 248044, 248044, 248044, 248044],
                    ],
                    device=input_ids.device,
                )
                # fmt: on
            else:  # second call: 1 tool call succeeded
                assert "image_grid_thw" in kwargs, "image_grid_thw must be passed to generate"
                assert kwargs["image_grid_thw"].shape[0] == 2, (
                    f"Expected 2 images (1 original + 1 tool-returned), got {kwargs['image_grid_thw'].shape[0]}"
                )
                completion_ids = torch.tensor(
                    [
                        # 'Done!<|im_end|>'
                        [16936, 0, 248046],
                    ],
                    device=input_ids.device,
                )
            return torch.cat([input_ids, completion_ids], dim=-1)

        with patch.object(trainer.model, "generate", side_effect=fake_generate):
            trainer.train()

        # Self-distillation gives a near-zero teacher signal, so we assert the tool-calling loop ran end to end and the
        # loss stayed finite, rather than params-changed (see `test_train_dataset_format`). With a batch of 2, one
        # completion is a tool call (1/2) and it succeeds (0 failures).
        train_loss = trainer.state.log_history[-1]["train_loss"]
        assert train_loss is not None
        assert torch.isfinite(torch.tensor(train_loss))
        assert trainer.state.log_history[-1]["tools/call_frequency"] == pytest.approx(1 / 2)
        assert trainer.state.log_history[-1]["tools/failure_frequency"] == pytest.approx(0.0)

    @pytest.mark.xfail(
        condition=Version(transformers.__version__) < Version("5.2.0"),
        reason="Qwen3.5 models were introduced in transformers-5.2.0",
        strict=True,
    )
    @require_response_parsing
    def test_train_with_tools_text_response_multimodal_prompt(self):
        # Test that tools returning text (non-multimodal response) work correctly with a VLM prompt having images.
        def screenshot_tool() -> str:
            """Simple text-returning tool."""
            return "The image shows a red square."

        dataset = load_dataset("trl-internal-testing/zen-image", "conversational_prompt_only", split="train")

        training_args = DistillationConfig(
            output_dir=self.tmp_dir,
            per_device_train_batch_size=2,  # VLM training is memory intensive, reduce batch size to avoid OOM
            max_completion_length=512,
            report_to="none",
        )
        trainer = DistillationTrainer(
            model="trl-internal-testing/tiny-Qwen3_5ForConditionalGeneration-NoThink",
            teacher_model="trl-internal-testing/tiny-Qwen3_5ForConditionalGeneration-NoThink",
            args=training_args,
            train_dataset=dataset,
            tools=[screenshot_tool],
        )

        def fake_generate(input_ids, **kwargs):
            if input_ids.shape[0] == 2:  # first call
                # fmt: off
                completion_ids = torch.tensor(
                    [
                        # '<tool_call>\n<function=screenshot_tool>\n</function>\n</tool_call><|im_end|>'
                        [248058, 198, 27, 1628, 13744, 30091, 22076, 29, 198, 510, 1628, 29, 198, 248059, 248046],
                        # "I don't know any tool<|im_end|>" + padding
                        [40, 1459, 914, 1366, 866, 5224, 248046, 248044, 248044, 248044, 248044, 248044, 248044, 248044, 248044],
                    ],
                    device=input_ids.device,
                )
                # fmt: on
            else:  # second call after text tool response: original image grid thw should still be present
                assert "image_grid_thw" in kwargs, "image_grid_thw must be passed to generate"
                assert kwargs["image_grid_thw"].shape[0] == 1, (
                    f"Expected 1 original image, got {kwargs['image_grid_thw'].shape[0]}"
                )
                completion_ids = torch.tensor(
                    [
                        # 'Done!<|im_end|>'
                        [16936, 0, 248046],
                    ],
                    device=input_ids.device,
                )
            return torch.cat([input_ids, completion_ids], dim=-1)

        with patch.object(trainer.model, "generate", side_effect=fake_generate):
            trainer.train()

        train_loss = trainer.state.log_history[-1]["train_loss"]
        assert train_loss is not None
        assert torch.isfinite(torch.tensor(train_loss))
        assert trainer.state.log_history[-1]["tools/call_frequency"] == pytest.approx(1 / 2)
        assert trainer.state.log_history[-1]["tools/failure_frequency"] == pytest.approx(0.0)
