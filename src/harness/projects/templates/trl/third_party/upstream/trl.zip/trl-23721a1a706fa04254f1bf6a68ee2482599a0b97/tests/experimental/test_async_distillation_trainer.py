# Copyright 2020-2026 The HuggingFace Team. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import asyncio
import itertools
import json
import math
import multiprocessing as mp
import os
import queue
import time
from collections import OrderedDict, defaultdict
from unittest.mock import patch
from urllib.parse import parse_qs, urlsplit

import numpy as np
import pytest
import requests
import torch
import transformers
from accelerate import PartialState
from datasets import Dataset, load_dataset
from packaging.version import Version
from requests.adapters import BaseAdapter
from safetensors import safe_open
from transformers import AutoModelForCausalLM, AutoTokenizer, TrainerControl
from transformers.testing_utils import torch_device

from trl.experimental.async_distillation import AsyncDistillationConfig, AsyncDistillationTrainer
from trl.experimental.async_distillation import async_distillation_trainer as async_distillation_trainer_module
from trl.experimental.async_distillation import weight_transfer as weight_transfer_module
from trl.experimental.async_distillation.async_distillation_trainer import (
    DataCollatorForRollout,
    TokenBudgetBatcher,
    _add_tail_bucket,
    _chunked_jsd_loss,
    _EpochStopCallback,
    _iter_vllm_named_params,
    _jsd_divergence,
    _narrow_top1_actual_support,
    _reduce_metric,
)
from trl.experimental.async_distillation.async_rollout_worker import (
    AsyncRolloutWorker,
    RolloutSample,
    _AsyncRolloutLoop,
    _parse_teacher_logprobs_at_position,
    _spawn_stop_watcher,
)
from trl.experimental.async_distillation.weight_transfer import WeightTransferClient
from trl.experimental.server_distillation.server_distillation_trainer import (
    _jsd_divergence as _reference_jsd_divergence,
)
from trl.trainer.base_trainer import _BaseTrainer

from ..testing_utils import TrlTestCase, is_ampere_or_newer, is_bf16_supported, require_peft, require_vllm


TEACHER_TOP_K = 4


def _make_teacher_topk(
    vocab_size: int, actual_token_ids: list[int], top_k: int, seed: int
) -> tuple[list[list[int]], list[list[float]]]:
    """Build synthetic per-position teacher candidates, shaped like what `_score_with_teacher` returns.

    Always includes the actual/realized token, matching the real server's guarantee that it's reported regardless of
    rank; otherwise `_narrow_top1_actual_support`'s `beta != 0.0` path would never find it among random candidates and
    silently mask every position out of the loss.
    """
    generator = torch.Generator().manual_seed(seed)
    ids, logprobs = [], []
    for actual_id in actual_token_ids:
        logits = torch.randn(vocab_size, generator=generator)
        log_probs = torch.log_softmax(logits, dim=-1)
        top_logprobs, top_ids = log_probs.topk(top_k)
        top_ids_list, top_logprobs_list = top_ids.tolist(), top_logprobs.tolist()
        if actual_id not in top_ids_list:
            top_ids_list[-1] = actual_id
            top_logprobs_list[-1] = log_probs[actual_id].item()
        ids.append(top_ids_list)
        logprobs.append(top_logprobs_list)
    return ids, logprobs


class _StubRolloutWorker:
    """Minimal rollout worker stub for testing the trainer in isolation, bypassing real vLLM/network."""

    def __init__(self, *, dataset, processing_class, samples_per_weight_sync: int = 10, **kwargs):
        self.rollout_buffer = queue.Queue()
        self.token_allowance = mp.Value("q", 0)
        self._loop_kwargs = {"dataset_start_index": 0, **kwargs}
        self.metrics_queue = queue.Queue()  # drained by the trainer in `log()`; this stub measures nothing
        self._samples_per_weight_sync = samples_per_weight_sync
        self._model_version = 0
        self._vocab_size = len(processing_class)
        self._sample_iter = self._make_sample_iter(processing_class, dataset)

    def _make_sample_iter(self, tokenizer, dataset):
        for idx, row in enumerate(itertools.cycle(dataset)):
            completion = row["completion"]
            prompt_ids = tokenizer.apply_chat_template(
                row["prompt"], tokenize=True, add_generation_prompt=True, return_dict=False
            )
            prompt_completion_ids = tokenizer.apply_chat_template(
                row["prompt"] + completion, tokenize=True, add_generation_prompt=False, return_dict=False
            )
            completion_ids = prompt_completion_ids[len(prompt_ids) :]
            teacher_topk_ids, teacher_topk_logprobs = _make_teacher_topk(
                self._vocab_size, completion_ids, TEACHER_TOP_K, seed=idx
            )
            full_teacher_ids = np.full((len(prompt_ids) + len(completion_ids), TEACHER_TOP_K + 1), -1, dtype=np.int64)
            full_teacher_ids[len(prompt_ids) :, :TEACHER_TOP_K] = teacher_topk_ids
            full_teacher_logprobs = np.full(full_teacher_ids.shape, -np.inf, dtype=np.float32)
            full_teacher_logprobs[len(prompt_ids) :, :TEACHER_TOP_K] = teacher_topk_logprobs
            yield RolloutSample(
                prompt=row["prompt"],
                completion=completion,
                input_ids=np.array(prompt_ids + completion_ids, dtype=np.int64),
                completion_mask=np.array([0] * len(prompt_ids) + [1] * len(completion_ids), dtype=np.int64),
                teacher_topk_ids=full_teacher_ids,
                teacher_topk_logprobs=full_teacher_logprobs,
                model_version=self._model_version,
                teacher_id="default",
                prompt_id=idx,  # `itertools.cycle` keeps counting across epochs, like the real `_repeat_iterator`
                metrics={},
            )

    def _fill_queue(self):
        for _ in range(self._samples_per_weight_sync):
            self.rollout_buffer.put(next(self._sample_iter))

    def start(self):
        self._fill_queue()

    def update_model_version(self, version):
        self._model_version = version
        self._fill_queue()

    def stop(self):
        pass

    def check_health(self, stale_after_s):
        pass


class _StubWeightTransfer:
    """No-op weight transfer for testing the trainer without a real vLLM server."""

    def __init__(self, **kwargs):
        pass

    def init_weight_transfer(self):
        pass

    def pause(self):
        pass

    def send_weights(self, iterator):
        for _ in iterator:  # drain the param stream like the real client does
            pass

    def resume(self):
        pass

    def destroy(self):
        pass


class FakeVLLMServer:
    """The state a vLLM server has and a mocked dict does not, behind the eight paths [`VLLMClient`] uses.

    Configure it after construction (`fake.lora_config = ...`) and before the trainer is built; the trainer probes
    `/server_info` in its constructor. Read `loaded`, `evicted` and `paused` afterwards to see what the trainer did
    from the server's side.

    Attributes:
        lora_config (`dict` or `None`):
            What `/server_info` reports under `lora_config`. `None` is a server started without `--enable-lora`, which
            also makes `/v1/load_lora_adapter` a 404, as it is on the real server.
        data_parallel_size (`int`):
            What `/server_info` reports under `parallel_config`.
        loaded (`OrderedDict[str, str]`):
            Adapter name to path, oldest first. This is the LRU order vLLM's `LRUCacheLoRAModelManager` evicts in.
        evicted (`list[str]`):
            Adapters silently dropped because a load arrived with `loaded` already at `max_loras`. A real server does
            exactly this rather than reject the load, which is why `select_adapter_sync` sizes `--max-loras` for it.
        paused (`bool`):
            Whether `/pause` has been called more recently than `/resume`.
        requests (`list[str]`):
            Every path this server was asked, in order.
        on_load (`callable`, *optional*):
            Called as `on_load(name, path)` the moment a load is accepted, before the response is returned — the one
            place a test can observe the trainer's state *at* load time (e.g. that `model_version` has not moved yet).
    """

    url = "http://fake-vllm"  # a scheme and a host, never bound to anything

    def __init__(self, *, lora_config=None, data_parallel_size=1, max_model_len=2048, dtype="torch.bfloat16"):
        self.lora_config = lora_config
        self.data_parallel_size = data_parallel_size
        self.max_model_len = max_model_len
        self.dtype = dtype
        self.loaded: OrderedDict[str, str] = OrderedDict()
        self.evicted: list[str] = []
        self.paused = False
        self.on_load = None
        self.requests: list[str] = []  # every path asked of this server, in order

    def dispatch(self, method: str, path: str, query: dict, body) -> tuple[int, object]:
        """Answer one request. Returns `(status_code, json_payload)`."""
        self.requests.append(path)
        if path == "/health":
            return 200, {}
        if path == "/server_info":
            return 200, {
                "vllm_config": {
                    "lora_config": self.lora_config,
                    "parallel_config": {
                        "data_parallel_size": self.data_parallel_size,
                        "tensor_parallel_size": 1,
                        "world_size": 1,
                    },
                    "model_config": {"dtype": self.dtype},
                }
            }
        if path == "/v1/models":
            return 200, {
                "data": [{"id": "base", "max_model_len": self.max_model_len}, *({"id": name} for name in self.loaded)]
            }
        if path == "/get_world_size":
            include_dp = query.get("include_dp", ["true"])[0].lower() != "false"
            return 200, {"world_size": self.data_parallel_size if include_dp else 1}
        if path == "/pause":
            self.paused = True
            return 200, {}
        if path == "/resume":
            self.paused = False
            return 200, {}
        if path == "/v1/load_lora_adapter":
            return self._load(body["lora_name"], body["lora_path"], body.get("load_inplace", False))
        if path == "/v1/unload_lora_adapter":
            if self.lora_config is None:
                return 404, {"detail": "Not Found"}
            self.loaded.pop(body["lora_name"], None)
            return 200, "Success"
        return 404, {"detail": f"no route for {method} {path}"}

    def _load(self, name: str, path: str, load_inplace: bool) -> tuple[int, object]:
        # Without `--enable-lora` (and `VLLM_ALLOW_RUNTIME_LORA_UPDATING=1`) the endpoint is not registered at all.
        if self.lora_config is None:
            return 404, {"detail": "Not Found"}
        # `_check_load_lora_adapter_request`: a repeated name is rejected unless the caller asked to load in place.
        if name in self.loaded and not load_inplace:
            return 400, {
                "error": {
                    "message": f"The lora adapter '{name}' has already been loaded. If you want to load the adapter "
                    "in place, set 'load_inplace' to True.",
                    "type": "InvalidUserInput",
                }
            }
        # `add_lora` validates eagerly: the engine reads the directory before the request is answered, so a path the
        # server cannot see is a 404 here, not a 200 followed by an engine death.
        if not os.path.isfile(os.path.join(path, "adapter_config.json")):
            return 404, {"error": {"message": f"Loading lora {name} failed: No adapter found for {path}"}}
        # `LRUCacheLoRAModelManager.add_adapter`: at capacity the oldest adapter is removed, silently.
        if name not in self.loaded and len(self.loaded) >= self.lora_config["max_loras"]:
            self.evicted.append(self.loaded.popitem(last=False)[0])
        self.loaded.pop(name, None)  # re-insert at the end: a load touches the LRU order
        self.loaded[name] = path
        if self.on_load is not None:
            self.on_load(name, path)
        return 200, f"Success: LoRA adapter '{name}' added successfully."


class FakeVLLMTransport(BaseAdapter):
    """A `requests` transport that delivers to a [`FakeVLLMServer`] instead of a socket."""

    def __init__(self, server: FakeVLLMServer):
        super().__init__()
        self.server = server

    def send(self, request, **kwargs):
        url = urlsplit(request.url)
        body = json.loads(request.body) if request.body else None
        status, payload = self.server.dispatch(request.method, url.path, parse_qs(url.query), body)
        response = requests.Response()
        response.status_code = status
        response.url = request.url
        response.request = request
        response.headers["Content-Type"] = "application/json"
        response._content = json.dumps(payload).encode()
        response.encoding = "utf-8"
        return response

    def close(self):
        pass


@pytest.fixture
def fake_vllm(monkeypatch) -> FakeVLLMServer:
    """A [`FakeVLLMServer`] that every `requests` call to `FakeVLLMServer.url` reaches, for this test only.

    It swaps the transport for one URL, leaves every other request untouched, and is undone by `monkeypatch` when the
    test ends.
    """
    server = FakeVLLMServer()
    transport = FakeVLLMTransport(server)
    real_get_adapter = requests.Session.get_adapter

    def get_adapter(self, url):
        return transport if url.startswith(FakeVLLMServer.url) else real_get_adapter(self, url)

    monkeypatch.setattr(requests.Session, "get_adapter", get_adapter)
    return server


@pytest.fixture(autouse=True)
def stub_weight_transfer(monkeypatch):
    monkeypatch.setattr(async_distillation_trainer_module, "WeightTransferClient", _StubWeightTransfer)


@pytest.fixture(autouse=True)
def stub_rollout_worker(monkeypatch):
    monkeypatch.setattr(async_distillation_trainer_module, "AsyncRolloutWorker", _StubRolloutWorker)


def _rollout_sample(length: int, top_k: int = TEACHER_TOP_K, teacher_id: str = "default", prompt_id: int = 0) -> dict:
    # First token is a prompt token (completion_mask 0, empty teacher candidates); the rest are completion tokens.
    teacher_topk_ids = np.full((length, top_k + 1), -1, dtype=np.int64)
    teacher_topk_ids[1:, :top_k] = np.arange(top_k)
    teacher_topk_logprobs = np.full((length, top_k + 1), -np.inf, dtype=np.float32)
    teacher_topk_logprobs[1:, :top_k] = -np.arange(top_k) - 0.1
    return {
        "input_ids": np.arange(length, dtype=np.int64),
        "completion_mask": np.array([0] + [1] * (length - 1), dtype=np.int64),
        "teacher_topk_ids": teacher_topk_ids,
        "teacher_topk_logprobs": teacher_topk_logprobs,
        "teacher_id": teacher_id,
        "prompt_id": prompt_id,
        "metrics": {},
    }


class TestPackingAwareBatching:
    """Packing/collation is pure scheduling/tensorization (ported from async_grpo's batchers, unchanged), so these
    run without a GPU. The teacher-candidate padding in the collator is new and is the focus here.
    """

    def test_token_budget_batcher_respects_budget_and_fills_every_row(self):
        source = (_rollout_sample(3) for _ in range(100))
        batcher = TokenBudgetBatcher(source, num_processes=2, token_budget=8, metrics=defaultdict(list))

        micro_batches = list(itertools.islice(iter(batcher), 5))
        assert len(micro_batches) == 5
        for groups in micro_batches:
            assert len(groups) == 2
            assert all(len(group) > 0 for group in groups)
            assert all(sum(len(s["input_ids"]) for s in group) <= 8 for group in groups)

    def test_collator_pads_teacher_candidates_and_masks_prompt_positions(self):
        collator = DataCollatorForRollout(pad_token_id=0, num_processes=1)
        a = _rollout_sample(3)  # input_ids [0, 1, 2]; position 0 is prompt (no candidates)
        batch = collator([[[a]]])

        width = (
            TEACHER_TOP_K + 1
        )  # +1 for the sentinel-padded slot (no tail bucket added here; that's compute_loss's job)
        assert batch["teacher_topk_ids"].shape == (1, 3, width)
        assert batch["teacher_topk_logprobs"].shape == (1, 3, width)
        # Prompt position (index 0): every candidate slot is the -1/-inf sentinel.
        assert batch["teacher_topk_ids"][0, 0].tolist() == [-1] * width
        assert torch.isinf(batch["teacher_topk_logprobs"][0, 0]).all()
        # Completion positions (index 1, 2): the real top_k candidates survive, the extra slot is padding.
        assert batch["teacher_topk_ids"][0, 1, :TEACHER_TOP_K].tolist() == list(range(TEACHER_TOP_K))
        assert batch["teacher_topk_ids"][0, 1, TEACHER_TOP_K] == -1

    def test_collator_pads_unequal_rows(self):
        collator = DataCollatorForRollout(pad_token_id=0, num_processes=2)
        a = _rollout_sample(3, prompt_id=7)  # input_ids [0, 1, 2]
        b = _rollout_sample(2, prompt_id=8)  # input_ids [0, 1]

        batch = collator([[[a], [b]]])

        assert batch["input_ids"].tolist() == [[0, 1, 2], [0, 1, 0]]  # row b right-padded with pad_token_id
        assert batch["attention_mask"].tolist() == [[1, 1, 1], [1, 1, 0]]
        assert batch["completion_mask"].tolist() == [[0, 1, 1], [0, 1, 0]]
        assert batch["global_n_tokens"].tolist() == [3.0, 3.0]  # a: 2 + b: 1 completion tokens
        assert batch["global_n_forward_tokens"].tolist() == [5.0, 5.0]  # every token forwarded, prompts included
        assert batch["mean_seq_len"].tolist() == [2.5, 2.5]

        # Sample and packing metrics are aggregated here on rank 0, not broadcast with the batch and reduced back.
        assert collator.metrics["sample/forwarded_tokens_mean"] == [2.5]
        assert collator.metrics["sample/trained_tokens_mean"] == [1.5]
        assert collator.metrics["batch/masked_token_frac"] == [(2, 5)]  # the two prompt tokens earn no gradient
        assert collator.metrics["batch/samples_per_row"] == [1.0]
        assert collator.metrics["batch/row_tokens_max"] == [3.0]
        assert collator.metrics["batch/row_imbalance"] == [9 / 6.5]  # Σ Lᵢ² of 9 and 4, against their mean
        assert collator.metrics["batch/pad_frac"] == [(1, 6)]  # the one slot row b was padded with
        assert "batch/row_fill_frac" not in collator.metrics  # no budget passed, so nothing to fill

        # The prompts behind this micro-batch, accumulated for `_EpochStopCallback` to count epochs with.
        assert collator.prompts_trained == {7, 8}

    def test_collator_packs_teacher_id_per_token_for_mopd(self):
        # Packing concatenates samples from different teachers into one row, so compute_loss can only attribute a
        # token's jsd/teacher_entropy to a teacher if the id is broadcast across that sample's own tokens here.
        collator = DataCollatorForRollout(pad_token_id=0, num_processes=1, teacher_id_to_idx={"math": 0, "code": 1})
        batch = collator([[[_rollout_sample(3, teacher_id="math"), _rollout_sample(2, teacher_id="code")]]])

        assert batch["teacher_id_idx"].tolist() == [[0, 0, 0, 1, 1]]

        single = DataCollatorForRollout(pad_token_id=0, num_processes=1)
        assert "teacher_id_idx" not in single([[[_rollout_sample(3)]]])


class TestMetricReduction:
    """The value's shape and the key's suffix are the whole reduction API; nothing is registered or configured."""

    @pytest.mark.parametrize(
        ("key", "values", "expected"),
        [
            ("perf/fwd_bwd_s", [1.0, 2.0, 6.0], 3.0),  # gauge -> window mean
            ("sample/dropped_stale_count", [1.0, 1.0, 1.0], 3.0),  # counter -> sum of the pushed deltas
            ("sample/forwarded_tokens_max", [3.0, 9.0, 5.0], 9.0),
            # A `max`/`min` WORD, not a suffix, so the upstream spellings reduce correctly too...
            ("completions/max_length", [3.0, 9.0, 5.0], 9.0),
            ("completions/min_length", [3.0, 9.0, 5.0], 3.0),
            # ... while a name that merely contains those letters stays a gauge.
            ("perf/maximal_s", [2.0, 4.0], 3.0),
            # Rates reduce as Σnum / Σden. These two windows ran at 1 and 100 tok/s; meaning the ratios would report
            # 50.5, the defect that made `training_tok/s` unusable.
            ("perf/wall_clock_forwarded_tokens_per_s", [(100.0, 100.0), (100.0, 1.0)], 200 / 101),
        ],
    )
    def test_reduces_by_shape_and_name(self, key, values, expected):
        assert _reduce_metric(key, values) == pytest.approx(expected)

    def test_rate_with_zero_denominator_is_nan(self):
        assert math.isnan(_reduce_metric("perf/wall_clock_forwarded_tokens_per_s", [(0.0, 0.0)]))


def _position(*entries):
    """A vLLM `prompt_logprobs[i]` entry: `{token_id: {"logprob": ..., "rank": ...}}`, JSON keys are strings."""
    return {str(token_id): {"logprob": logprob, "rank": rank} for token_id, logprob, rank in entries}


class TestParseTeacherLogprobs:
    """vLLM's `prompt_logprobs` mapping is unordered; parsing sorts it by rank and drops NaNs."""

    @pytest.mark.parametrize(
        ("position", "expected_ids", "expected_logprobs"),
        [
            (_position((9, -2.0, 3), (5, -0.1, 1), (1, -1.0, 2)), [5, 1, 9], [-0.1, -1.0, -2.0]),
            # The realized token is reported whatever its rank, on top of the requested top-k. Truncating back to k
            # (as `VLLMClient.get_sequence_logprobs` does for the sync trainers) would drop it here, zeroing the
            # teacher signal at that position for beta=1.0.
            (_position((5, -0.1, 1), (1, -1.0, 2), (9, -8.0, 4242)), [5, 1, 9], [-0.1, -1.0, -8.0]),
            # NaN reflects an invalid score, not a padding slot, so the candidate is dropped rather than sentinelled.
            (_position((5, -0.1, 1), (1, float("nan"), 2), (9, -2.0, 3)), [5, 9], [-0.1, -2.0]),
            # A position vLLM scored nothing for yields the same empty pair as a masked-out prompt position.
            (None, [], []),
            ({}, [], []),
        ],
    )
    def test_parses_position(self, position, expected_ids, expected_logprobs):
        ids, logprobs = _parse_teacher_logprobs_at_position(position)
        assert ids == expected_ids
        assert logprobs == pytest.approx(expected_logprobs)


def _rollout_loop(**kwargs):
    # `_AsyncRolloutLoop.__init__` only sets up state (no vLLM or teacher connection happens here).
    tokenizer = kwargs.get("processing_class") or AutoTokenizer.from_pretrained(
        "trl-internal-testing/tiny-Qwen2ForCausalLM-2.5"
    )
    kwargs = {
        "model_name": "test",
        "dataset": Dataset.from_dict({"prompt": ["hi"]}),
        "processing_class": tokenizer,
        "eos_token_ids": [tokenizer.eos_token_id],
        "rollout_buffer": mp.Queue(),
        "model_version_value": mp.Value("i", 0),
        "token_allowance": mp.Value("q", 10**12),
        "heartbeat_value": mp.Value("d", 0.0),
        "failed_event": mp.Event(),
        "exception_info_queue": mp.Queue(),
        "metrics_queue": mp.Queue(),
        **kwargs,
    }
    return _AsyncRolloutLoop(**kwargs)


@pytest.fixture
def fake_vllm_server():
    """A vLLM server that serves both the student and the teacher: the student always answers with the same two tokens."""
    from aiohttp import web
    from aiohttp.test_utils import TestServer

    async def completions(request):
        payload = await request.json()
        if "prompt_logprobs" in payload:  # the teacher scoring the sequence
            return web.json_response(
                {"choices": [{"prompt_logprobs": [_position((7, -0.5, 1))] * len(payload["prompt"])}]}
            )
        return web.json_response({"choices": [{"token_ids": [7, 8]}]})

    async def models(request):
        return web.json_response({"data": [{"id": "m", "max_model_len": 1000}]})

    app = web.Application()
    app.router.add_post("/v1/completions", completions)
    app.router.add_get("/v1/models", models)
    return TestServer(app)


class TestTokenAllowance:
    def test_generation_stops_at_the_allowance(self, fake_vllm_server):
        # Every sample has the same length, so the number of rollouts the allowance admits is exact
        PartialState()
        dataset = Dataset.from_dict({"prompt": [[{"role": "user", "content": "hi"}]]})
        loop = _rollout_loop(dataset=dataset, token_allowance=mp.Value("q", 1))

        def drain():
            return [loop.rollout_buffer.get(timeout=5) for _ in range(loop.rollout_buffer.qsize())]

        async def settled(worker, expected):
            deadline = time.monotonic() + 10
            while loop.rollout_buffer.qsize() < expected:
                if worker.done():
                    worker.result()  # raises the worker's error instead of timing out
                assert time.monotonic() < deadline, (
                    f"{loop.rollout_buffer.qsize()} samples queued, expected {expected}"
                )
                await asyncio.sleep(0.01)
            await asyncio.sleep(0.3)  # nothing more is generated
            assert loop.rollout_buffer.qsize() == expected

        async def run():
            async with fake_vllm_server as server:
                url = str(server.make_url("")).rstrip("/")
                loop.vllm_server_url = url
                loop.teacher_server_urls = {"default": url}
                stop_event = asyncio.Event()
                worker = asyncio.create_task(loop._run_loops(stop_event))
                # Any allowance above 0 admits the first rollout
                await settled(worker, 1)
                sample_tokens = len(drain()[0].input_ids)
                # The allowance now has room for 2.5 more rollouts: the worker starts 3 and stops there
                loop._token_allowance.value = sample_tokens + sample_tokens * 5 // 2
                await settled(worker, 3)
                stop_event.set()
                await worker

        try:
            loop._loop.run_until_complete(run())
        finally:
            loop._loop.close()


def _scoring_loop(tokenizer, teacher_server_urls, teacher_max_model_lens=None):
    loop = _rollout_loop(
        processing_class=tokenizer,
        teacher_server_urls=teacher_server_urls,
        teacher_top_k=TEACHER_TOP_K,
        vllm_server_timeout=30,
    )
    # Normally resolved from each teacher server's /v1/models in _run_loops, which these tests never reach
    loop.teacher_model_names = {teacher_id: f"{teacher_id}-model" for teacher_id in teacher_server_urls}
    loop.teacher_max_model_lens = teacher_max_model_lens or dict.fromkeys(teacher_server_urls, 32768)
    return loop


ONE_TEACHER = {"default": "http://default:8001"}
TWO_TEACHERS = {"math": "http://math:8002", "code": "http://code:8003"}


class TestWorkerMetrics:
    """The worker's payload has the same shape as the trainer's sink, so draining it in `log()` is an append."""

    def _loop(self, teacher_server_urls=ONE_TEACHER, maxsize=0):
        return _rollout_loop(teacher_server_urls=teacher_server_urls, metrics_queue=mp.Queue(maxsize=maxsize))

    def test_counters_and_rates_ride_along_and_reset(self):
        loop = self._loop()
        loop._counters["rollout/vllm_retry_count"] += 2
        loop._rates["rollout/score_s"][0] += 3.0
        loop._rates["rollout/score_s"][1] += 2
        loop._push_metrics({"rollout/concurrency": 4.0})

        assert loop._metrics_queue.get(timeout=5) == {
            "rollout/concurrency": 4.0,
            "rollout/vllm_retry_count": 2.0,
            "rollout/score_s": (3.0, 2.0),
        }
        # Counters and rates carry deltas, so what one push reported must not ride along on the next.
        loop._push_metrics({})
        assert loop._metrics_queue.get(timeout=5) == {}

    def test_push_never_blocks_when_the_trainer_stops_draining(self):
        loop = self._loop(maxsize=1)
        for _ in range(50):
            loop._push_metrics({"rollout/concurrency": 1.0})  # drops rather than stalling generation

    @pytest.mark.parametrize(
        ("teacher_server_urls", "ends_on_eos", "clipped", "per_teacher"),
        [
            (ONE_TEACHER, True, 0.0, False),  # ends on eos: the model stopped on its own
            (TWO_TEACHERS, False, 1.0, True),  # ends mid-sentence: cut off by max_completion_length
        ],
    )
    def test_rollout_push_reports_the_completion_and_the_teacher_call(
        self, teacher_server_urls, ends_on_eos, clipped, per_teacher
    ):
        loop = self._loop(teacher_server_urls)
        completion_ids = [7, 8, loop.eos_token_ids[0] if ends_on_eos else 9]
        loop._push_rollout_metrics(completion_ids=completion_ids, teacher_id="math", score_s=0.25, duration_s=1.5)
        payload = loop._metrics_queue.get(timeout=5)

        assert payload["rollout/duration_s"] == 1.5
        assert payload["completions/mean_length"] == (3.0, 1.0)
        assert payload["completions/max_length"] == 3.0
        assert payload["completions/clipped_ratio"] == (clipped, 1.0)
        # Only a completion that ended on EOS counts in the terminated lengths, as in GRPO
        assert ("completions/mean_terminated_length" in payload) is ends_on_eos
        if ends_on_eos:
            assert payload["completions/mean_terminated_length"] == (3.0, 1.0)
            assert payload["completions/min_terminated_length"] == payload["completions/max_terminated_length"] == 3.0
        assert payload["rollout/score_s"] == (0.25, 1.0)
        # A per-teacher latency series only exists under MOPD; with one teacher the blended mean is the whole story.
        assert ("teacher/math/score_s" in payload) is per_teacher


class TestMultiTeacherRouting:
    """A single configured teacher scores every row regardless of `teacher_id` (plain on-policy distillation).

    Multiple teachers enable MOPD: each row's `teacher_id` column selects among them; a missing or unmapped
    `teacher_id` is a configuration error, not a silent fallback. Each request must carry the URL *and* the served
    model id of the teacher it routes to, since `/v1/completions` names the model it addresses and every teacher serves
    its own, and the sequence must fit that teacher's `max_model_len`.
    """

    def _run(self, teacher_server_urls, *teacher_ids, teacher_max_model_lens=None):
        """Score one row per `teacher_ids` entry (`None` = no `teacher_id` column) and return the requests sent."""
        tokenizer = AutoTokenizer.from_pretrained("trl-internal-testing/tiny-Qwen2ForCausalLM-2.5")
        loop = _scoring_loop(tokenizer, teacher_server_urls, teacher_max_model_lens)
        requests = []

        async def fake_generate_one_turn(prompt_ids):
            return [7]

        async def fake_post(base_url, path, payload, timeout):
            requests.append((base_url, payload))
            # vLLM scores every token of the sequence it was handed, not just the completion region.
            return {"choices": [{"prompt_logprobs": [_position((7, -0.5, 1))] * len(payload["prompt"])}]}

        loop._generate_one_turn = fake_generate_one_turn
        loop._post = fake_post

        rows = [
            {"prompt": [{"role": "user", "content": "hi"}], **({} if tid is None else {"teacher_id": tid})}
            for tid in teacher_ids
        ]
        samples = [asyncio.run(loop._generate_and_score_one(i, row)) for i, row in enumerate(rows)]
        return samples, requests

    @pytest.mark.parametrize("teacher_id", ["whatever", None])
    def test_single_teacher_scores_every_row(self, teacher_id):
        samples, requests = self._run(ONE_TEACHER, teacher_id)
        assert [url for url, _ in requests] == ["http://default:8001"]
        assert [payload["model"] for _, payload in requests] == ["default-model"]
        assert [sample.teacher_id for sample in samples] == ["default"]

    def test_each_row_is_addressed_to_its_own_teacher(self):
        samples, requests = self._run(TWO_TEACHERS, "code", "math")
        assert [url for url, _ in requests] == ["http://code:8003", "http://math:8002"]
        assert [payload["model"] for _, payload in requests] == ["code-model", "math-model"]
        # The routed id rides along on the sample so the collator can tag every token with it (MOPD metrics).
        assert [sample.teacher_id for sample in samples] == ["code", "math"]

    def test_only_the_student_request_is_salted_by_model_version(self):
        tokenizer = AutoTokenizer.from_pretrained("trl-internal-testing/tiny-Qwen2ForCausalLM-2.5")
        loop = _scoring_loop(tokenizer, ONE_TEACHER)
        loop._model_version_value.value = 3
        requests = []

        async def fake_post(base_url, path, payload, timeout):
            requests.append(payload)
            if "prompt_logprobs" in payload:
                return {"choices": [{"prompt_logprobs": [_position((7, -0.5, 1))] * len(payload["prompt"])}]}
            return {"choices": [{"token_ids": [7]}]}

        loop._post = fake_post
        asyncio.run(loop._generate_and_score_one(0, {"prompt": [{"role": "user", "content": "hi"}]}))
        assert [payload.get("cache_salt") for payload in requests] == ["v3", None]

    def test_scores_only_the_completion_region(self):
        (sample,), ((_, payload),) = self._run(ONE_TEACHER, None)
        n_prompt = len(sample.input_ids) - int(sample.completion_mask.sum())
        assert payload["prompt"] == sample.input_ids.tolist()
        assert payload["prompt_logprobs"] == TEACHER_TOP_K
        assert (sample.teacher_topk_ids[:n_prompt] == -1).all()
        assert (sample.teacher_topk_ids[n_prompt:, 0] == 7).all()
        assert (sample.teacher_topk_ids[n_prompt:, 1:] == -1).all()

    @pytest.mark.parametrize(("teacher_id", "match"), [(None, "teacher_id=None"), ("unknown", "teacher_id='unknown'")])
    def test_multi_teacher_raises_on_unroutable_row(self, teacher_id, match):
        with pytest.raises(ValueError, match=match):
            self._run(TWO_TEACHERS, teacher_id)

    def test_raises_when_the_teacher_has_no_room_to_score_the_sequence(self):
        (sample,), _ = self._run(ONE_TEACHER, None)
        sequence_length = len(sample.input_ids)
        # Scoring asks for one throwaway token past the sequence, so a teacher needs one more position than its length.
        # Each row is checked against its own teacher's limit: math has room for this sequence, code does not.
        max_model_lens = {"math": sequence_length + 1, "code": sequence_length}
        self._run(TWO_TEACHERS, "math", teacher_max_model_lens=max_model_lens)
        with pytest.raises(ValueError, match="'code'.*--max-model-len"):
            self._run(TWO_TEACHERS, "code", teacher_max_model_lens=max_model_lens)

    def test_skips_the_length_check_when_the_teacher_does_not_report_max_model_len(self):
        # Only vLLM adds `max_model_len` to `/v1/models`
        _, requests = self._run(ONE_TEACHER, None, teacher_max_model_lens={"default": None})
        assert [url for url, _ in requests] == ["http://default:8001"]


class TestBetaRange:
    """beta must be a valid generalized-JSD interpolation coefficient in [0.0, 1.0], matching
    `DistillationTrainer`/`GKDConfig`'s own bounds; values outside that range are never meaningful.
    """

    @pytest.mark.parametrize("beta", [-0.1, 1.1, 2.0])
    def test_out_of_range_beta_raises(self, beta):
        with pytest.raises(ValueError, match=r"beta must be in \[0.0, 1.0\]"):
            AsyncDistillationConfig(output_dir="/tmp/unused", report_to="none", beta=beta)


class TestNarrowTop1ActualSupport:
    """`beta != 0.0` narrows the teacher-reported support to just the candidates the divergence needs, mirroring
    `ServerDistillationTrainer`'s `beta > 0` path exactly, including its `beta == 1.0` special case: for `0 < beta <
    1`, the support is the teacher's own top-1 token plus the completion's actual/realized token (the only two
    identities the wire protocol guarantees a teacher logprob for); at `beta == 1.0` (pure reverse KL, purely
    student-weighted), the teacher's top-1 token is dropped entirely and only the actual token remains.
    """

    def test_top1_and_actual_both_valid_and_distinct(self):
        # position 0: top-1 is token 5, actual (realized) token is 9, found at index 2 of the reported candidates.
        teacher_topk_ids = torch.tensor([[[5, 3, 9, -1]]])
        teacher_topk_logprobs = torch.tensor([[[-0.1, -1.0, -2.0, float("-inf")]]])
        actual_token_ids = torch.tensor([[9]])
        valid_mask_wide = teacher_topk_ids != -1

        narrow_ids, narrow_logps, mask = _narrow_top1_actual_support(
            teacher_topk_ids, teacher_topk_logprobs, actual_token_ids, valid_mask_wide, beta=0.5
        )
        assert narrow_ids.tolist() == [[[5, 9]]]
        assert narrow_logps.squeeze().tolist() == pytest.approx([-0.1, -2.0])
        assert mask.tolist() == [[[True, True]]]

    def test_actual_token_same_as_top1_is_deduplicated(self):
        # The realized token IS the teacher's top-1 choice: the second (actual) slot must be masked out, not
        # double-counted, since it's the same token as the first (top-1) slot.
        teacher_topk_ids = torch.tensor([[[5, 3, 9, -1]]])
        teacher_topk_logprobs = torch.tensor([[[-0.1, -1.0, -2.0, float("-inf")]]])
        actual_token_ids = torch.tensor([[5]])
        valid_mask_wide = teacher_topk_ids != -1

        narrow_ids, _, mask = _narrow_top1_actual_support(
            teacher_topk_ids, teacher_topk_logprobs, actual_token_ids, valid_mask_wide, beta=0.5
        )
        assert narrow_ids.tolist() == [[[5, 5]]]
        assert mask.tolist() == [[[True, False]]]

    def test_actual_token_missing_from_reported_candidates(self):
        # The realized token never appears among the teacher's reported candidates at all (e.g. a low-probability
        # token the server didn't report); the actual slot must be masked out, not silently given a wrong logprob.
        teacher_topk_ids = torch.tensor([[[5, 3, -1, -1]]])
        teacher_topk_logprobs = torch.tensor([[[-0.1, -1.0, float("-inf"), float("-inf")]]])
        actual_token_ids = torch.tensor([[42]])
        valid_mask_wide = teacher_topk_ids != -1

        narrow_ids, _, mask = _narrow_top1_actual_support(
            teacher_topk_ids, teacher_topk_logprobs, actual_token_ids, valid_mask_wide, beta=0.5
        )
        assert narrow_ids.tolist() == [[[5, 42]]]
        assert mask.tolist() == [[[True, False]]]

    def test_top1_missing_but_actual_present(self):
        # No usable teacher signal at all for the top-1 slot (e.g. every candidate was NaN server-side), but the
        # actual token still happens to be present among the (otherwise-invalid) reported candidates.
        teacher_topk_ids = torch.tensor([[[-1, 9, -1, -1]]])
        teacher_topk_logprobs = torch.tensor([[[float("-inf"), -2.0, float("-inf"), float("-inf")]]])
        actual_token_ids = torch.tensor([[9]])
        valid_mask_wide = teacher_topk_ids != -1

        _, _, mask = _narrow_top1_actual_support(
            teacher_topk_ids, teacher_topk_logprobs, actual_token_ids, valid_mask_wide, beta=0.5
        )
        assert mask.tolist() == [[[False, True]]]

    def test_beta_one_drops_teacher_top1_entirely(self):
        # Pure reverse KL is purely student-weighted: the teacher's top-1 token (5) must not appear in the support
        # at all, even though it's valid and distinct from the actual token (9) - only width-1 support remains.
        teacher_topk_ids = torch.tensor([[[5, 3, 9, -1]]])
        teacher_topk_logprobs = torch.tensor([[[-0.1, -1.0, -2.0, float("-inf")]]])
        actual_token_ids = torch.tensor([[9]])
        valid_mask_wide = teacher_topk_ids != -1

        narrow_ids, narrow_logps, mask = _narrow_top1_actual_support(
            teacher_topk_ids, teacher_topk_logprobs, actual_token_ids, valid_mask_wide, beta=1.0
        )
        assert narrow_ids.shape[-1] == 1
        assert narrow_ids.tolist() == [[[9]]]
        assert narrow_logps.squeeze().item() == pytest.approx(-2.0)
        assert mask.tolist() == [[[True]]]

    def test_beta_one_actual_token_missing(self):
        # Pure reverse KL, but the actual token isn't among the teacher's reported candidates: the lone support
        # slot must be masked out (no usable teacher signal at all), not silently wrong.
        teacher_topk_ids = torch.tensor([[[5, 3, -1, -1]]])
        teacher_topk_logprobs = torch.tensor([[[-0.1, -1.0, float("-inf"), float("-inf")]]])
        actual_token_ids = torch.tensor([[42]])
        valid_mask_wide = teacher_topk_ids != -1

        narrow_ids, _, mask = _narrow_top1_actual_support(
            teacher_topk_ids, teacher_topk_logprobs, actual_token_ids, valid_mask_wide, beta=1.0
        )
        assert narrow_ids.tolist() == [[[42]]]
        assert mask.tolist() == [[[False]]]

    def test_narrow_support_feeds_add_tail_bucket_and_jsd_divergence_without_error(self):
        # End-to-end sanity: the narrow support's shape/dtype/mask conventions must be exactly what
        # `_add_tail_bucket`/`_jsd_divergence` (shared with the beta=0.0 path) expect.
        teacher_topk_ids = torch.tensor([[[5, 3, 9, -1], [7, -1, -1, -1]]])
        teacher_topk_logprobs = torch.tensor(
            [[[-0.1, -1.0, -2.0, float("-inf")], [-0.05, float("-inf"), float("-inf"), float("-inf")]]]
        )
        actual_token_ids = torch.tensor([[9, 7]])
        valid_mask_wide = teacher_topk_ids != -1

        narrow_ids, teacher_logps, mask = _narrow_top1_actual_support(
            teacher_topk_ids, teacher_topk_logprobs, actual_token_ids, valid_mask_wide, beta=0.5
        )
        student_logps_full = torch.log_softmax(torch.randn(1, 2, 32), dim=-1)
        student_logps = student_logps_full.gather(-1, narrow_ids.clamp_min(0))
        neg_inf = torch.full((), float("-inf"))
        student_logps = torch.where(mask, student_logps, neg_inf)
        teacher_logps = torch.where(mask, teacher_logps, neg_inf)

        student_full, support_mask = _add_tail_bucket(student_logps, mask)
        teacher_full, _ = _add_tail_bucket(teacher_logps, mask)
        jsd = _jsd_divergence(student_full, teacher_full, beta=0.5, support_mask=support_mask)
        assert torch.isfinite(jsd).all()
        # Individual per-slot terms can be negative (e.g. student_prob(x) * (log student(x) - log teacher(x)) when
        # student(x) < teacher(x)); only the per-token sum across the support dimension (the actual KL/JSD) is
        # guaranteed non-negative (Gibbs' inequality).
        assert (jsd.sum(dim=-1) >= -1e-5).all()

    def test_narrow_support_beta_one_feeds_add_tail_bucket_and_jsd_divergence_without_error(self):
        # Same end-to-end sanity check, but for the width-1 beta==1.0 support.
        teacher_topk_ids = torch.tensor([[[5, 3, 9, -1], [7, -1, -1, -1]]])
        teacher_topk_logprobs = torch.tensor(
            [[[-0.1, -1.0, -2.0, float("-inf")], [-0.05, float("-inf"), float("-inf"), float("-inf")]]]
        )
        actual_token_ids = torch.tensor([[9, 7]])
        valid_mask_wide = teacher_topk_ids != -1

        narrow_ids, teacher_logps, mask = _narrow_top1_actual_support(
            teacher_topk_ids, teacher_topk_logprobs, actual_token_ids, valid_mask_wide, beta=1.0
        )
        student_logps_full = torch.log_softmax(torch.randn(1, 2, 32), dim=-1)
        student_logps = student_logps_full.gather(-1, narrow_ids.clamp_min(0))
        neg_inf = torch.full((), float("-inf"))
        student_logps = torch.where(mask, student_logps, neg_inf)
        teacher_logps = torch.where(mask, teacher_logps, neg_inf)

        student_full, support_mask = _add_tail_bucket(student_logps, mask)
        teacher_full, _ = _add_tail_bucket(teacher_logps, mask)
        jsd = _jsd_divergence(student_full, teacher_full, beta=1.0, support_mask=support_mask)
        assert torch.isfinite(jsd).all()
        # Individual per-slot terms can be negative (e.g. student_prob(x) * (log student(x) - log teacher(x)) when
        # student(x) < teacher(x)); only the per-token sum across the support dimension (the actual KL/JSD) is
        # guaranteed non-negative (Gibbs' inequality).
        assert (jsd.sum(dim=-1) >= -1e-5).all()

    def test_padded_positions_keep_forward_and_backward_finite(self):
        # Adapted from ServerDistillationTrainer's own `TestServerReverseKLPaddingMask` test: a ragged batch where
        # one sample's completion is shorter than another's, so some positions are all -inf sentinels (masked out
        # via has_teacher_signal in compute_loss, but this checks the loss math itself, given already-neutralized
        # padding, never leaks -inf/NaN into the backward pass).
        teacher_topk_ids = torch.tensor([[[5, 3, 9, -1], [-1, -1, -1, -1]], [[5, 3, 9, -1], [7, 2, 4, -1]]])
        teacher_topk_logprobs = torch.tensor(
            [
                [[-0.1, -1.0, -2.0, float("-inf")], [float("-inf")] * 4],
                [[-0.1, -1.0, -2.0, float("-inf")], [-0.05, -1.2, -2.5, float("-inf")]],
            ]
        )
        actual_token_ids = torch.tensor([[9, 0], [9, 7]])
        valid_mask_wide = teacher_topk_ids != -1

        for beta in (0.5, 1.0):
            narrow_ids, teacher_logps, mask = _narrow_top1_actual_support(
                teacher_topk_ids, teacher_topk_logprobs, actual_token_ids, valid_mask_wide, beta=beta
            )
            raw_student = torch.randn(2, 2, 32, requires_grad=True)
            student_log_probs_full = torch.log_softmax(raw_student, dim=-1)
            student_logps = student_log_probs_full.gather(-1, narrow_ids.clamp_min(0))
            neg_inf = torch.full((), float("-inf"))
            student_logps = torch.where(mask, student_logps, neg_inf)
            teacher_logps = torch.where(mask, teacher_logps, neg_inf)

            student_full, support_mask = _add_tail_bucket(student_logps, mask)
            teacher_full, _ = _add_tail_bucket(teacher_logps, mask)
            jsd = _jsd_divergence(student_full, teacher_full, beta=beta, support_mask=support_mask)
            assert torch.isfinite(jsd).all(), f"beta={beta}"

            # The fully-masked position (sample 0, position 1) must not contribute -inf/NaN gradient once summed
            # and backpropagated, mirroring compute_loss's has_teacher_signal exclusion of such positions.
            has_teacher_signal = mask.any(dim=-1)
            loss = jsd.sum(dim=-1)[has_teacher_signal].sum()
            loss.backward()
            assert torch.isfinite(raw_student.grad).all(), f"beta={beta}"


class TestSparseGeneralizedJSDMatchesFullVocabReference:
    """Compares our sparse top-k pipeline (`_add_tail_bucket` + `_jsd_divergence`) against a plain dense-vocabulary
    generalized-JSD computation — `ServerDistillationTrainer`'s own `_jsd_divergence`, called with `support_mask=None`
    so it takes its dense `F.kl_div` branch instead of the masked/sparse one. Feeding our pipeline the *full*
    vocabulary as its "top-k" support (`top_k = vocab_size`) leaves ~0 residual mass for the tail bucket, so the two
    must match up to that negligible epsilon, not just approximately.
    """

    def test_forward_kl_matches_full_vocab_generalized_jsd_loss(self):
        torch.manual_seed(0)
        batch, seq_len, vocab_size = 2, 5, 32
        student_logits = torch.randn(batch, seq_len, vocab_size)
        teacher_logits = torch.randn(batch, seq_len, vocab_size)

        student_log_probs_full = torch.log_softmax(student_logits, dim=-1)
        teacher_log_probs_full = torch.log_softmax(teacher_logits, dim=-1)

        reference_jsd = _reference_jsd_divergence(student_log_probs_full, teacher_log_probs_full, beta=0.0)
        reference = reference_jsd.sum() / (batch * seq_len)  # batchmean, matching this test's own reduction below

        # Simulate what the async worker/collator produce, but with the full vocabulary as the "top-k" support so
        # nothing is truncated (see class docstring for why this is a valid dense reference).
        teacher_topk_logprobs, teacher_topk_ids = teacher_log_probs_full.topk(vocab_size, dim=-1)

        student_support_logps = student_log_probs_full.gather(-1, teacher_topk_ids)
        valid_mask = torch.ones_like(teacher_topk_ids, dtype=torch.bool)

        student_log_probs, support_mask = _add_tail_bucket(student_support_logps, valid_mask)
        teacher_log_probs, _ = _add_tail_bucket(teacher_topk_logprobs, valid_mask)

        jsd = _jsd_divergence(student_log_probs, teacher_log_probs, beta=0.0, support_mask=support_mask)
        ours = jsd.sum() / max(jsd.shape[0] * jsd.shape[1], 1)  # batchmean, matching the reference's reduction

        torch.testing.assert_close(ours, reference)


class TestPerTeacherStats:
    """MOPD's per-teacher breakdown: `_chunked_jsd_loss` returns a `(count, jsd_sum, teacher_entropy_sum)` triple per
    teacher, which `compute_loss` turns into `teacher/{id}/jsd`. Packing concatenates several teachers' tokens into one
    row and then splits that row into fixed-size chunks, so the partition has to survive a teacher's positions being
    spread across chunk boundaries.
    """

    NUM_POSITIONS, HIDDEN_SIZE, VOCAB_SIZE, NUM_TEACHERS = 10, 8, 32, 2

    def _run(self, teacher_id_idx, chunk_size):
        generator = torch.Generator().manual_seed(0)
        hidden = torch.randn(self.NUM_POSITIONS, self.HIDDEN_SIZE, generator=generator)
        lm_head_weight = torch.randn(self.VOCAB_SIZE, self.HIDDEN_SIZE, generator=generator)
        actual_token_ids = torch.randint(self.VOCAB_SIZE, (self.NUM_POSITIONS,), generator=generator).tolist()
        ids, logprobs = _make_teacher_topk(self.VOCAB_SIZE, actual_token_ids, TEACHER_TOP_K, seed=0)
        target_ids = torch.tensor(ids)

        return _chunked_jsd_loss(
            hidden,
            lm_head_weight,
            None,
            1.0,
            None,
            target_ids,
            torch.tensor(logprobs),
            torch.ones_like(target_ids, dtype=torch.bool),
            0.0,
            1.0,
            True,
            teacher_id_idx,
            self.NUM_TEACHERS,
            chunk_size,
        )

    @pytest.mark.parametrize("chunk_size", [3, 256])
    def test_stats_partition_the_batch_by_teacher(self, chunk_size):
        teacher_id_idx = torch.tensor([0, 1, 1, 0, 0, 1, 0, 1, 1, 0])
        _, jsd_sum, _, teacher_entropy_sum, per_teacher_stats = self._run(teacher_id_idx, chunk_size)

        counts, jsd_sums, entropy_sums = per_teacher_stats.view(self.NUM_TEACHERS, 3).T
        torch.testing.assert_close(counts, torch.bincount(teacher_id_idx).float())
        torch.testing.assert_close(jsd_sums.sum(), jsd_sum)
        torch.testing.assert_close(entropy_sums.sum(), teacher_entropy_sum)

    def test_chunking_does_not_move_tokens_between_teachers(self):
        teacher_id_idx = torch.tensor([0, 1, 1, 0, 0, 1, 0, 1, 1, 0])
        chunked = self._run(teacher_id_idx, 3)[-1]
        whole = self._run(teacher_id_idx, self.NUM_POSITIONS)[-1]

        torch.testing.assert_close(chunked, whole)

    def test_single_teacher_reports_no_breakdown(self):
        per_teacher_stats = self._run(None, 3)[-1]

        assert not per_teacher_stats.any()


@pytest.mark.skipif(
    not is_ampere_or_newer() and torch_device != "xpu" and torch.version.hip is None,
    reason="Flash Attention requires Ampere or newer GPU, XPU, or ROCm",
)
class TestAsyncDistillationTrainer(TrlTestCase):
    def test_init_minimal(self):
        model_id = "trl-internal-testing/tiny-Qwen2ForCausalLM-2.5"
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_completion", split="train")
        AsyncDistillationTrainer(
            model=model_id,
            train_dataset=dataset,
        )

    def _train_one_step_and_save(self, fsdp=False):
        model_id = "trl-internal-testing/tiny-Qwen2ForCausalLM-2.5"
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_completion", split="train")

        training_args = AsyncDistillationConfig(
            output_dir=self.tmp_dir,
            max_steps=1,
            save_steps=1,
            per_device_train_batch_size=3,
            teacher_top_k=TEACHER_TOP_K,
            max_completion_length=8,
            vllm_server_timeout=5.0,
            token_budget=160,
            fsdp=fsdp,
            report_to="none",
        )
        trainer = AsyncDistillationTrainer(
            model=model_id,
            args=training_args,
            train_dataset=dataset,
        )
        trainer.train()
        return trainer

    @pytest.mark.skipif(not is_bf16_supported(), reason="test requires bf16 support")
    def test_checkpoint_keeps_master_dtype_without_fsdp(self):
        trainer = self._train_one_step_and_save()

        assert trainer.model.dtype == torch.float32
        checkpoint = os.path.join(self.tmp_dir, "checkpoint-1")
        with safe_open(os.path.join(checkpoint, "model.safetensors"), "pt") as f:
            assert {f.get_slice(key).get_dtype() for key in f.keys()} == {"F32"}
        with open(os.path.join(checkpoint, "config.json")) as f:
            assert json.load(f)["dtype"] == "float32"

    @pytest.mark.skipif("TRL_TEST_FSDP_OUTPUT_DIR" not in os.environ, reason="launched by tests/distributed")
    def test_fsdp_checkpoint_body(self):
        self.tmp_dir = os.environ["TRL_TEST_FSDP_OUTPUT_DIR"]
        trainer = self._train_one_step_and_save(fsdp=True)
        assert trainer.is_fsdp_enabled

    @pytest.mark.parametrize(
        ("model_id", "instantiated"),
        [
            pytest.param("trl-internal-testing/tiny-Qwen2ForCausalLM-2.5", False, id="qwen2.5"),
            # an already instantiated model
            pytest.param("trl-internal-testing/tiny-Qwen2ForCausalLM-2.5", True, id="qwen2.5-instantiated"),
            # MoE: the load-balancing loss is on
            pytest.param("trl-internal-testing/tiny-Qwen3MoeForCausalLM", False, id="qwen3-moe"),
        ],
    )
    def test_train(self, model_id, instantiated):
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_completion", split="train")
        model = model_id
        if instantiated:
            model = AutoModelForCausalLM.from_pretrained(
                model_id, dtype="float32", device_map=None, attn_implementation="eager"
            )

        training_args = AsyncDistillationConfig(
            output_dir=self.tmp_dir,
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=3,
            teacher_top_k=TEACHER_TOP_K,
            max_completion_length=8,
            vllm_server_timeout=5.0,  # short timeout so test fails fast if queue runs dry
            token_budget=160,
            logging_steps=1,
            report_to="none",
        )
        trainer = AsyncDistillationTrainer(
            model=model,
            args=training_args,
            train_dataset=dataset,
        )
        if instantiated:
            assert trainer.model is model
            assert trainer.model.config._attn_implementation.startswith("kernels-community/")

        previous_trainable_params = {n: param.clone() for n, param in trainer.model.named_parameters()}

        trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None
        assert trainer.rollout_worker.token_allowance.value > trainer._rollout_dataset.consumed_tokens > 0
        if "Moe" in model_id:
            # The MoE config declares a `router_aux_loss_coef`, so the load-balancing loss is on by default
            aux_losses = [log["aux_loss"] for log in trainer.state.log_history if "aux_loss" in log]
            assert aux_losses and all(math.isfinite(aux) and aux > 0 for aux in aux_losses)

        for n, param in previous_trainable_params.items():
            new_param = trainer.model.get_parameter(n)
            assert not torch.equal(param, new_param), f"Parameter {n} has not changed."

    def test_train_vlm(self):
        # Gemma3 refuses FlashAttention, which its language model takes instead (#8400)
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_completion", split="train")
        training_args = AsyncDistillationConfig(
            output_dir=self.tmp_dir,
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=3,
            teacher_top_k=TEACHER_TOP_K,
            max_completion_length=8,
            vllm_server_timeout=5.0,  # short timeout so test fails fast if queue runs dry
            token_budget=160,
            logging_steps=1,
            report_to="none",
        )
        trainer = AsyncDistillationTrainer(
            model="trl-internal-testing/tiny-Gemma3ForConditionalGeneration",
            args=training_args,
            train_dataset=dataset,
        )
        language_model = trainer.model.get_decoder()
        assert language_model.config._attn_implementation.startswith("kernels-community/")
        previous_trainable_params = {n: param.clone() for n, param in language_model.named_parameters()}

        trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None
        for n, param in previous_trainable_params.items():
            new_param = language_model.get_parameter(n)
            assert not torch.equal(param, new_param), f"Parameter {n} has not changed."

    @pytest.mark.skipif(
        Version(transformers.__version__) < Version("4.57.0"),
        reason="Qwen3-VL series were introduced in transformers-4.57.0",
    )
    def test_train_vlm_text_only_data(self):
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_completion", split="train")
        training_args = AsyncDistillationConfig(
            output_dir=self.tmp_dir,
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=3,
            teacher_top_k=TEACHER_TOP_K,
            max_completion_length=8,
            vllm_server_timeout=5.0,  # short timeout so test fails fast if queue runs dry
            token_budget=160,
            logging_steps=1,
            report_to="none",
            model_init_kwargs={"dtype": "float32"},
        )
        trainer = AsyncDistillationTrainer(
            model="trl-internal-testing/tiny-Qwen3VLForConditionalGeneration",
            args=training_args,
            train_dataset=dataset,
        )

        previous_trainable_params = {n: param.clone() for n, param in trainer.model.named_parameters()}

        trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None

        # Check that the params have changed, except the frozen vision tower
        for n, param in previous_trainable_params.items():
            new_param = trainer.model.get_parameter(n)
            if n.startswith("model.visual"):
                assert not new_param.requires_grad, f"Param {n} is trainable"
                torch.testing.assert_close(param, new_param, rtol=1e-12, atol=1e-12, msg=f"Param {n} is updated")
            else:
                assert not torch.equal(param, new_param), f"Param {n} is not updated"

    @pytest.mark.skipif(
        Version(transformers.__version__) < Version("4.57.0"),
        reason="Qwen3-VL series were introduced in transformers-4.57.0",
    )
    def test_init_vlm_from_name(self):
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_completion", split="train")
        trainer = AsyncDistillationTrainer(
            model="trl-internal-testing/tiny-Qwen3VLForConditionalGeneration",
            args=AsyncDistillationConfig(output_dir=self.tmp_dir, report_to="none"),
            train_dataset=dataset,
        )
        assert isinstance(trainer.model, transformers.Qwen3VLForConditionalGeneration)

    def test_router_aux_loss_coef_on_a_dense_model_raises(self):
        model_id = "trl-internal-testing/tiny-Qwen2ForCausalLM-2.5"
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_completion", split="train")
        with pytest.raises(ValueError, match="not a Mixture-of-Experts model"):
            AsyncDistillationTrainer(
                model=model_id,
                args=AsyncDistillationConfig(output_dir=self.tmp_dir, router_aux_loss_coef=0.01, report_to="none"),
                train_dataset=dataset,
            )

    def test_resume_from_checkpoint(self):
        # Checks that ignore_data_skip is True and that resume doesn't crash. The rollout-state file itself is
        # covered by TestRolloutStateCheckpoint.
        model_id = "trl-internal-testing/tiny-Qwen3ForCausalLM"
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_completion", split="train")

        def build_trainer(**overrides):
            args = AsyncDistillationConfig(
                output_dir=self.tmp_dir,
                per_device_train_batch_size=3,
                teacher_top_k=TEACHER_TOP_K,
                max_completion_length=8,
                token_budget=160,
                vllm_server_timeout=5.0,
                report_to="none",
                **overrides,
            )
            return AsyncDistillationTrainer(
                model=model_id,
                args=args,
                train_dataset=dataset,
            )

        # First run: train for 2 steps, which saves a checkpoint at step 1.
        trainer = build_trainer(max_steps=2, save_steps=1)
        assert trainer.args.ignore_data_skip is True
        trainer.train()

        checkpoint_dir = os.path.join(self.tmp_dir, "checkpoint-1")
        assert os.path.isfile(os.path.join(checkpoint_dir, "trainer_state.json"))

        # Second run: resume from the step-1 checkpoint.
        build_trainer(max_steps=3).train(resume_from_checkpoint=checkpoint_dir)

    @pytest.mark.parametrize("beta", [0.25, 0.5, 0.75, 1.0])
    def test_train_with_nonzero_beta(self, beta):
        # Adapted from ServerDistillationTrainer's own `test_reverse_kl_finite_grad_with_ragged_batch`: a real
        # training run through the narrow top-1 + actual-token support path (including the beta==1.0 special case),
        # checking grad_norm/loss stay finite throughout, not just that training completes.
        model_id = "trl-internal-testing/tiny-Qwen2ForCausalLM-2.5"
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_completion", split="train")

        training_args = AsyncDistillationConfig(
            output_dir=self.tmp_dir,
            learning_rate=0.1,
            per_device_train_batch_size=3,
            teacher_top_k=TEACHER_TOP_K,
            max_completion_length=8,
            vllm_server_timeout=5.0,
            token_budget=160,
            beta=beta,
            report_to="none",
        )
        trainer = AsyncDistillationTrainer(
            model=model_id,
            args=training_args,
            train_dataset=dataset,
        )
        trainer.train()

        log_history = [rec for rec in trainer.state.log_history if "grad_norm" in rec]
        assert log_history, "Expected at least one grad_norm log entry during training"
        for record in log_history:
            assert math.isfinite(record["grad_norm"]), f"grad_norm={record['grad_norm']} leaked -inf into backward"
            assert math.isfinite(record["loss"])


def _checkpoint_trainer(output_dir, dataset_start_index=0):
    model_id = "trl-internal-testing/tiny-Qwen2ForCausalLM-2.5"
    dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_completion", split="train")
    trainer = AsyncDistillationTrainer(
        model=model_id,
        args=AsyncDistillationConfig(output_dir=output_dir, report_to="none"),
        train_dataset=dataset,
    )
    trainer.rollout_worker._loop_kwargs["dataset_start_index"] = dataset_start_index
    return trainer


@pytest.mark.skipif(
    not is_ampere_or_newer() and torch_device != "xpu" and torch.version.hip is None,
    reason="Flash Attention requires Ampere or newer GPU, XPU, or ROCm",
)
class TestEpochStop(TrlTestCase):
    """`num_train_epochs` stops after N full passes over the PROMPTS, counted as distinct prompt ids.

    The count spans a resume: the worker restarts `prompt_id` at 0, so the prompts trained before the checkpoint ride
    in `_prompts_before_resume` and are added back here, or a resumed run would train `num_train_epochs` more passes on
    top of the ones already done.
    """

    @pytest.mark.parametrize(
        ("trained", "before_resume", "should_stop"),
        [
            ({0, 1, 2}, 0, False),
            ({0, 1, 2, 3}, 0, True),
            ({0, 1}, 2, True),  # a resumed run reaches the target counting the checkpoint's prompts
            (set(), 4, True),  # ... and reaches it having trained nothing of its own
        ],
    )
    def test_stops_once_the_prompt_target_is_reached(self, trained, before_resume, should_stop):
        trainer = _checkpoint_trainer(self.tmp_dir)
        trainer._trained_prompts = trained
        trainer._prompts_before_resume = before_resume
        control = TrainerControl()

        _EpochStopCallback(trainer, target_prompts=4).on_step_end(trainer.args, None, control)

        assert control.should_training_stop is should_stop
        assert control.should_save is should_stop  # the final step is saved, as when training reaches `max_steps`


class TestRolloutStartIndex(TrlTestCase):
    def test_rollout_loop_skips_to_start_index(self):
        loop = _rollout_loop(
            dataset=Dataset.from_dict({"prompt": [f"row_{i}" for i in range(10)]}), dataset_start_index=3
        )
        _prompt_id, row = next(loop._repeat_iterator())
        assert row["prompt"] == "row_3"


@pytest.mark.skipif(
    not is_ampere_or_newer() and torch_device != "xpu" and torch.version.hip is None,
    reason="Flash Attention requires Ampere or newer GPU, XPU, or ROCm",
)
class TestRolloutStateCheckpoint(TrlTestCase):
    """Prompt-index checkpoint/resume logic, on a real trainer whose rollout worker is stood in (it needs vLLM)."""

    def _trainer_at_step_5(self, trained_prompts, dataset_start_index=0):
        trainer = _checkpoint_trainer(self.tmp_dir, dataset_start_index)
        trainer.state.global_step = 5
        trainer._trained_prompts = trained_prompts
        return trainer

    @pytest.mark.parametrize(
        ("trained_prompts", "dataset_start_index", "expected"),
        [
            ({0, 1, 2, 3, 4}, 10, 15),  # dataset_start_index(10) + first_untrained(5)
            # Prompt 2 was never trained (its rollout was dropped as stale), so the cursor stops there: it gets
            # re-generated on resume instead of being silently skipped.
            ({0, 1, 3, 4, 5}, 0, 2),
        ],
    )
    def test_save_checkpoint_writes_rollout_state(self, trained_prompts, dataset_start_index, expected):
        trainer = self._trainer_at_step_5(trained_prompts, dataset_start_index=dataset_start_index)

        with patch.object(_BaseTrainer, "_save_checkpoint"):
            trainer._save_checkpoint(trainer.model, None)

        with open(os.path.join(self.tmp_dir, "checkpoint-5", "rollout_state.json"), encoding="utf-8") as f:
            assert json.load(f)["prompt_index"] == expected

    def test_save_checkpoint_writes_rollout_state_before_the_hub_push(self):
        # `super()._save_checkpoint` is what uploads the checkpoint folder under `hub_strategy="checkpoint"`, so the
        # file has to exist by the time it runs. Writing it from an `on_save` callback would not: `Trainer` fires
        # `on_save` only after `_save_checkpoint` returns, leaving the Hub copy without it.
        trainer = self._trainer_at_step_5({0, 1})
        written_before_super = []

        def record(*_args, **_kwargs):
            written_before_super.append(
                os.path.isfile(os.path.join(self.tmp_dir, "checkpoint-5", "rollout_state.json"))
            )

        with patch.object(_BaseTrainer, "_save_checkpoint", side_effect=record):
            trainer._save_checkpoint(trainer.model, None)

        assert written_before_super == [True]

    def test_inner_training_loop_sets_dataset_start_index_from_file(self):
        checkpoint_dir = os.path.join(self.tmp_dir, "checkpoint-10")
        os.makedirs(checkpoint_dir)
        with open(os.path.join(checkpoint_dir, "rollout_state.json"), "w", encoding="utf-8") as f:
            json.dump({"prompt_index": 77, "model_version": 42}, f)

        trainer = _checkpoint_trainer(self.tmp_dir)
        trainer._trained_prompts = {1, 2, 3}  # a prior run's ids, which the reset has to drop

        with patch.object(_BaseTrainer, "_inner_training_loop", return_value=None):
            trainer._inner_training_loop(resume_from_checkpoint=checkpoint_dir)

        assert trainer.rollout_worker._loop_kwargs["dataset_start_index"] == 77
        # Epochs are counted in prompts trained, so a resumed run has to pick that count up too, or it would train
        # `num_train_epochs` more passes on top of the ones already done.
        assert trainer._prompts_before_resume == 77
        # The worker restarts `prompt_id` at 0, so ids left over from an earlier run would collide with this one's.
        assert trainer._trained_prompts == set()
        # Adapter names are derived from `model_version`, so restarting it at 0 would republish a different adapter
        # under a name a still-running vLLM server already holds, and strand the previous run's directories outside
        # the eviction window.
        assert trainer.model_version == 42
        assert trainer.rollout_worker._model_version == 42

    def test_inner_training_loop_defaults_model_version_for_old_checkpoints(self):
        # Checkpoints written before `model_version` was serialized must still resume, restarting numbering at 0.
        checkpoint_dir = os.path.join(self.tmp_dir, "checkpoint-10")
        os.makedirs(checkpoint_dir)
        with open(os.path.join(checkpoint_dir, "rollout_state.json"), "w", encoding="utf-8") as f:
            json.dump({"prompt_index": 5}, f)

        trainer = _checkpoint_trainer(self.tmp_dir)
        trainer.model_version = 7  # a version the resume has to reset, not the 0 `__init__` starts from

        with patch.object(_BaseTrainer, "_inner_training_loop", return_value=None):
            trainer._inner_training_loop(resume_from_checkpoint=checkpoint_dir)

        assert trainer.model_version == 0


class TestRolloutRequestModel(TrlTestCase):
    def _loop(self, lora_name):
        return _rollout_loop(model_name="Qwen/Qwen3-4B", lora_name=lora_name)

    def test_dense_runs_request_the_base_model(self):
        assert self._loop(None)._request_model == "Qwen/Qwen3-4B"

    def test_adapter_runs_request_the_versioned_adapter(self):
        # In vLLM's API an adapter *is* a model name: naming the base model would silently serve the base model.
        loop = self._loop("trl-policy")
        assert loop._request_model == "trl-policy-v0"
        loop._model_version_value.value = 3
        assert loop._request_model == "trl-policy-v3"


# A LoRA-capable server, as reported by `/server_info`. `max_loras` covers the `max_staleness + 1` servable policy
# versions plus the one being loaded, for the tests' default `max_staleness=1`.
SERVER_LORA_CONFIG = {"max_lora_rank": 32, "max_loras": 3}


@pytest.mark.skipif(
    not is_ampere_or_newer() and torch_device != "xpu" and torch.version.hip is None,
    reason="Flash Attention requires Ampere or newer GPU, XPU, or ROCm",
)
@require_peft
class TestAsyncDistillationTrainerPeft(TrlTestCase):
    """The trainer against a `FakeVLLMServer`: its real `VLLMClient` sends real requests, the wire is faked.

    Nothing here is patched. The trainer probes, loads, pauses, resumes and unloads through `VLLMClient` exactly as it
    does in production, and the assertions read what the server saw — `fake.loaded`, `fake.evicted`, `fake.paused`.
    """

    model_id = "trl-internal-testing/tiny-Qwen2ForCausalLM-2.5"

    def _lora_config(self, **kwargs):
        from peft import LoraConfig

        kwargs.setdefault("target_modules", ["q_proj", "v_proj"])
        kwargs.setdefault("r", 8)
        return LoraConfig(**kwargs)

    def _build(
        self,
        fake: FakeVLLMServer,
        peft_config,
        lora_config=None,
        data_parallel_size=1,
        weight_transfer=_StubWeightTransfer,
        rollout_worker=_StubRolloutWorker,
        **config_kwargs,
    ):
        """Build a trainer against `fake`, configured to look like a server started with the given flags.

        `weight_transfer` is the class the trainer builds for a merged sync. `rollout_worker` is the class the trainer
        builds as its worker: the real `AsyncRolloutWorker` is cheap until `start()` and useful for reading what it was
        told.
        """
        fake.lora_config = lora_config
        fake.data_parallel_size = data_parallel_size
        dataset = load_dataset("trl-internal-testing/zen", "conversational_prompt_completion", split="train")
        config_kwargs.setdefault("max_staleness", 1)
        args = AsyncDistillationConfig(
            output_dir=self.tmp_dir,
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=3,
            teacher_top_k=TEACHER_TOP_K,
            max_completion_length=8,
            token_budget=160,
            vllm_server_base_url=fake.url,
            vllm_server_timeout=5.0,
            report_to="none",
            **config_kwargs,
        )
        with (
            patch.object(async_distillation_trainer_module, "WeightTransferClient", weight_transfer),
            patch.object(async_distillation_trainer_module, "AsyncRolloutWorker", rollout_worker),
        ):
            return AsyncDistillationTrainer(
                model=self.model_id, args=args, train_dataset=dataset, peft_config=peft_config
            )

    def test_train_peft_config(self, fake_vllm):
        trainer = self._build(fake_vllm, self._lora_config())
        previous_params = {n: p.clone() for n, p in trainer.model.named_parameters()}

        trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None
        for name, param in previous_params.items():
            new_param = trainer.model.get_parameter(name)
            if "lora_" in name:
                assert not torch.equal(param, new_param), f"Adapter parameter {name} has not changed."
            else:
                assert torch.equal(param, new_param), f"Base parameter {name} has changed."

    @pytest.mark.parametrize("target_modules", [["q_proj", "lm_head"], r".*_head$"])
    def test_lora_on_the_head_is_refused(self, fake_vllm, target_modules):
        # The chunked divergence path reads `lm_head.weight`, which on a PEFT-wrapped head is the base weight: the
        # adapter delta would be silently dropped from every student logprob. The regex case is why the check is on
        # the module and not on `target_modules` — that string never contains "lm_head".
        with pytest.raises(ValueError, match="lm_head"):
            self._build(fake_vllm, self._lora_config(target_modules=target_modules), lora_config=SERVER_LORA_CONFIG)

    def test_a_misconfigured_server_raises_at_init(self, fake_vllm):
        # The probe runs on rank 0 only, so its error is broadcast and raised on every rank: raising on rank 0 alone
        # would leave the other ranks waiting in the collective that shares the sync mode.
        with pytest.raises(ValueError, match="--max-lora-rank"):
            self._build(fake_vllm, self._lora_config(r=16), lora_config={"max_lora_rank": 8, "max_loras": 3})

    @pytest.mark.parametrize(("lora_config", "expected"), [(SERVER_LORA_CONFIG, "trl-policy"), (None, None)])
    def test_the_rollout_worker_is_told_the_vllm_adapter_name(self, fake_vllm, lora_config, expected):
        # In vLLM's API an adapter *is* a model name: a rollout request that does not name it is served by the base
        # model, silently, and distilled against the teacher as if it were the student. The real worker is built here
        # (it spawns nothing until `start()`) to read the `lora_name` the trainer hands it.
        trainer = self._build(
            fake_vllm, self._lora_config(), lora_config=lora_config, rollout_worker=AsyncRolloutWorker
        )
        assert trainer.rollout_worker._loop_kwargs.get("lora_name") == expected

    # --- adapter sync, as the server sees it -----------------------------------------------------------------------

    def test_adapter_sync_loads_the_adapter_before_bumping_the_version(self, fake_vllm):
        trainer = self._build(fake_vllm, self._lora_config(), lora_config=SERVER_LORA_CONFIG)
        version_at_load = []
        fake_vllm.on_load = lambda name, path: version_at_load.append(trainer.model_version)

        trainer._sync_weight()

        # The rollout worker derives the adapter it requests from `model_version`, so the version must move only
        # once the adapter it names exists on the server.
        assert version_at_load == [0]
        assert trainer.model_version == 1
        assert trainer.rollout_worker._model_version == 1
        assert list(fake_vllm.loaded) == ["trl-policy-v1"]
        path = fake_vllm.loaded["trl-policy-v1"]
        assert os.path.isfile(os.path.join(path, "adapter_config.json"))
        # The server resolves the path in its own process, with its own cwd, possibly on another host. vLLM reads a
        # path it cannot resolve as a Hub repo id, so a relative one dies inside the engine.
        assert os.path.isabs(path)
        assert fake_vllm.paused is False  # paused for the publish, resumed after

    @pytest.mark.parametrize(
        ("max_staleness", "max_loras", "servable_after_five"),
        [(1, 3, ["trl-policy-v4", "trl-policy-v5"]), (4, 6, [f"trl-policy-v{v}" for v in range(1, 6)])],
    )
    def test_adapter_sync_keeps_max_staleness_plus_one_versions_servable(
        self, fake_vllm, max_staleness, max_loras, servable_after_five
    ):
        # In-flight requests may still name any of the last `max_staleness + 1` versions; vLLM resolves `lora_path`
        # lazily inside the engine, so deleting one of those directories kills the engine with an `HFValidationError`
        # rather than 404ing.
        trainer = self._build(
            fake_vllm,
            self._lora_config(),
            lora_config={"max_lora_rank": 32, "max_loras": max_loras},
            max_staleness=max_staleness,
        )

        for _ in range(5):
            trainer._sync_weight()

        assert list(fake_vllm.loaded) == servable_after_five
        # The server never had to evict one itself: the `--max-loras` bound left room for the load-then-unload.
        assert fake_vllm.evicted == []
        # The files lag the unload by one sync, so one more directory than the servable set survives on disk.
        newest_deleted = 5 - (max_staleness + 1) - 1
        for version in range(1, 6):
            exists = os.path.isdir(os.path.join(trainer._lora_dir, f"trl-policy-v{version}"))
            assert exists is (version > newest_deleted), f"trl-policy-v{version}"

    # --- merged fallback ---------------------------------------------------------------------------------------

    def test_merged_sync_sends_base_names_only(self, fake_vllm):
        sent = []

        class _RecordingWeightTransfer(_StubWeightTransfer):
            def send_weights(self, iterator):
                sent.extend(name for name, _ in iterator)

        trainer = self._build(
            fake_vllm, self._lora_config(modules_to_save=["lm_head"]), weight_transfer=_RecordingWeightTransfer
        )
        trainer._sync_weight()

        assert sent
        forbidden = (
            "lora_",
            "base_model.model.",
            ".base_layer",
            "original_module",
            "modules_to_save",
            "_checkpoint_wrapped_module.",
        )
        for name in sent:
            assert not any(token in name for token in forbidden), name
        # `modules_to_save` keeps a trainable copy and the frozen original side by side. Only the copy is sent, under
        # the base checkpoint's name — sending both would repeat that name and desync the packed transfer.
        assert len(sent) == len(set(sent))

    @require_vllm  # the merged path builds the real `WeightTransferClient`, whose constructor requires vLLM
    def test_vllm_manifest_and_streaming_iter_agree_element_for_element(self, fake_vllm):
        # The server sizes its receive buffers from the manifest, so a name present in one and not the other
        # desyncs the transfer. The real `WeightTransferClient` is built here; it only touches the network on
        # `init_weight_transfer`, which is not called.
        trainer = self._build(
            fake_vllm,
            self._lora_config(modules_to_save=["lm_head"]),
            lora_config=None,
            weight_transfer=WeightTransferClient,
        )
        manifest = trainer.weight_transfer._weight_update_info

        assert manifest["names"] == [name for name, _ in trainer._streaming_iter()]
        assert len(manifest["names"]) == len(manifest["shapes"]) == len(manifest["dtype_names"])
        assert manifest["names"] == [name for name, _ in _iter_vllm_named_params(trainer.model)]

    def test_merged_sync_and_lora_bias_raises(self, fake_vllm):
        # The merged sync sends vLLM the base weights with the LoRA deltas merged in, which can't express a LoRA bias
        with pytest.raises(ValueError, match="LoRA adapters without `lora_bias` only"):
            self._build(fake_vllm, self._lora_config(lora_bias=True))

    def test_merged_sync_sends_merged_lora_weights(self, fake_vllm):
        from peft.tuners.lora import LoraLayer

        sent = {}

        class _RecordingWeightTransfer(_StubWeightTransfer):
            def send_weights(self, iterator):
                sent.update((name, tensor.clone()) for name, tensor in iterator)

        # Non-zero adapters, so that the merged weights differ from the base ones
        trainer = self._build(
            fake_vllm, self._lora_config(init_lora_weights=False), weight_transfer=_RecordingWeightTransfer
        )
        lora_layers = {
            name.removeprefix("base_model.model.") + ".weight": module
            for name, module in trainer.model.named_modules()
            if isinstance(module, LoraLayer)
        }
        base_weights = {name: module.get_base_layer().weight.clone() for name, module in lora_layers.items()}
        trainer._sync_weight()

        for name, module in lora_layers.items():
            # vLLM gets the base weight with the adapter merged in, and the training model keeps its base weight
            expected = base_weights[name] + module.get_delta_weight("default")
            assert torch.equal(sent[name], expected.to(sent[name].dtype)), name
            assert torch.equal(module.get_base_layer().weight, base_weights[name]), name


def _tensors_handed_to_producer(info, stream):
    """Return the tensors `send_weights` passes to the packed NCCL producer.

    The producer itself is replaced so the test does not open an NCCL group. `model_update_group` is set only so
    `send_weights` does not return before touching the iterator.
    """
    # `send_weights` logs through accelerate, which raises until a state exists, even for a debug record.
    PartialState()

    class _Server:
        server_url = "http://127.0.0.1:9"

        def start_weight_update(self):
            return None

        def update_weights(self, update_info):
            return None

        def finish_weight_update(self):
            return None

    client = WeightTransferClient(_Server(), info)
    client.model_update_group = object()
    sent = []

    def capture_iterator(*, iterator, trainer_args):
        sent.extend(iterator)

    def capture_packed(*, iterator, group, src, post_iter_func):
        sent.extend((name, post_iter_func((name, tensor))) for name, tensor in iterator)

    if weight_transfer_module._HAS_STATEFUL_TRAINER_ENGINE:
        patcher = patch.object(weight_transfer_module, "packed_nccl_broadcast_producer", capture_packed)
    else:
        patcher = patch.object(
            weight_transfer_module.NCCLWeightTransferEngine, "trainer_send_weights", capture_iterator
        )
    with patcher:
        client.send_weights(iter(stream))
    return sent


@require_vllm  # WeightTransferClient's constructor requires vLLM
class TestVLLMManifestWeightStream:
    def test_send_weights_streams_in_the_manifest_dtype(self):
        model = torch.nn.Sequential(
            torch.nn.Linear(3, 1, bias=False, dtype=torch.bfloat16),
            torch.nn.Linear(3, 1, bias=False, dtype=torch.bfloat16),
        ).to(torch_device)
        original = [(name, param.detach().clone()) for name, param in _iter_vllm_named_params(model)]
        info = {
            "names": [name for name, _ in original],
            "dtype_names": [str(tensor.dtype).split(".")[-1] for _, tensor in original],
            "shapes": [list(tensor.shape) for _, tensor in original],
        }
        # Accelerate upcasts low-precision FSDP2 parameters to fp32 after the manifest is collected.
        model.to(dtype=torch.float32)
        streamed = [(name, param.detach()) for name, param in _iter_vllm_named_params(model)]

        sent = _tensors_handed_to_producer(info, streamed)

        assert [(name, tensor.dtype, list(tensor.shape)) for name, tensor in sent] == [
            (name, torch.bfloat16, list(tensor.shape)) for name, tensor in original
        ]
        for (_, sent_tensor), (_, original_tensor) in zip(sent, original, strict=True):
            assert torch.equal(sent_tensor, original_tensor)


def _start_stop_watcher_and_exit(stop_event):
    _spawn_stop_watcher(_rollout_loop(teacher_server_urls=ONE_TEACHER), stop_event)
    time.sleep(0.5)  # let the watcher start before the process exits


class TestStopWatcher:
    def test_stop_event_can_be_set_after_the_worker_exited(self):
        # A worker that dies (e.g. on an exception) leaves its stop watcher behind, and the trainer's `stop()` then
        # sets the stop event
        ctx = mp.get_context("spawn")
        stop_event = ctx.Event()
        worker = ctx.Process(target=_start_stop_watcher_and_exit, args=(stop_event,))
        worker.start()
        worker.join(timeout=60)
        # In a process rather than a thread, so a hanging `set()` can be killed and the test fails instead of hanging
        setter = ctx.Process(target=stop_event.set)
        setter.start()
        setter.join(timeout=10)
        hung = setter.is_alive()
        setter.kill()
        assert not hung

    def test_watcher_exits_once_the_stop_event_is_set(self):
        # `_child_main` sets the stop event and joins the watcher when `run()` returns or raises
        stop_event = mp.get_context("spawn").Event()
        watcher = _spawn_stop_watcher(_rollout_loop(teacher_server_urls=ONE_TEACHER), stop_event)
        stop_event.set()
        watcher.join(timeout=5)
        assert not watcher.is_alive()
