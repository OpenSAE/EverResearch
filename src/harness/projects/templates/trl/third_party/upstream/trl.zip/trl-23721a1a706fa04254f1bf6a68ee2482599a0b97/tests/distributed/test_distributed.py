# Copyright 2020-2026 The HuggingFace Team. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import json
import os
import subprocess
from pathlib import Path

import pytest
import torch
import transformers
from datasets import load_dataset
from huggingface_hub import snapshot_download
from packaging.version import Version
from safetensors import safe_open
from transformers import AutoModelForCausalLM, AutoModelForSequenceClassification

from trl import (
    DistillationConfig,
    DistillationTrainer,
    DPOConfig,
    DPOTrainer,
    GRPOConfig,
    GRPOTrainer,
    KTOConfig,
    KTOTrainer,
    RewardConfig,
    RewardTrainer,
    RLOOConfig,
    RLOOTrainer,
    SFTConfig,
    SFTTrainer,
)
from trl.trainer.utils import add_fused_lm_head

from ..testing_utils import MODEL_REVISIONS, TrlTestCase, require_torch_multi_accelerator


ROOT = Path(__file__).resolve().parents[2]


def run_command(command: list[str], env: dict[str, str]) -> None:
    result = subprocess.run(command, env=env, cwd=ROOT)
    assert result.returncode == 0


@pytest.fixture
def get_launch_args(lazy_shared_datadir):
    def _get_launch_args(config_name):
        if config_name == "ddp":
            return []
        if config_name == "fsdp2":
            return ["--fsdp", "--fsdp_config", str(lazy_shared_datadir / "fsdp2.json")]
        return ["--deepspeed", str(lazy_shared_datadir / f"{config_name}.json")]

    return _get_launch_args


@require_torch_multi_accelerator
class TestDistributed(TrlTestCase):
    @pytest.mark.parametrize(
        "config",
        [
            "ddp",
            pytest.param(
                "zero2",
                marks=pytest.mark.xfail(
                    Version(transformers.__version__) == Version("5.1.0"),
                    reason="Upstream incompatibility: deepspeed and transformers==5.1.0 (see transformers#43780)",
                ),
            ),
            pytest.param(
                "zero3",
                marks=pytest.mark.xfail(
                    Version(transformers.__version__) == Version("5.1.0"),
                    reason="Upstream incompatibility: deepspeed and transformers==5.1.0 (see transformers#43780)",
                ),
            ),
        ],
    )
    def test_distillation_multi_teacher(self, config, lazy_shared_datadir):
        config_kwargs = {}
        if config in ("zero2", "zero3"):
            deepspeed_config = json.loads((lazy_shared_datadir / f"{config}.json").read_text())
            if config == "zero3":
                deepspeed_config["zero_optimization"]["stage3_gather_16bit_weights_on_model_save"] = True
            config_kwargs = {"deepspeed": deepspeed_config}
        run_command(
            [
                "torchrun",
                "--nproc_per_node",
                "2",
                "-m",
                "pytest",
                "tests/test_distillation_trainer.py",
                "-k",
                "test_distributed_teacher_routing",
                "-x",
                "-q",
                "-p",
                "no:cacheprovider",
            ],
            {**os.environ, "TRL_TEST_DISTILLATION_CONFIG": json.dumps(config_kwargs)},
        )

    @pytest.mark.parametrize(
        "test_file", ["test_async_grpo_trainer.py", "experimental/test_async_distillation_trainer.py"]
    )
    def test_async_checkpoint_saved_in_compute_dtype(self, test_file):
        run_command(
            [
                "torchrun",
                "--nproc_per_node",
                "2",
                "-m",
                "pytest",
                f"tests/{test_file}",
                "-k",
                "test_fsdp_checkpoint_body",
                "-x",
                "-q",
                "-p",
                "no:cacheprovider",
            ],
            {**os.environ, "TRL_TEST_FSDP_OUTPUT_DIR": self.tmp_dir},
        )

        checkpoint = os.path.join(self.tmp_dir, "checkpoint-1")
        with safe_open(os.path.join(checkpoint, "model.safetensors"), "pt") as f:
            assert {f.get_slice(key).get_dtype() for key in f.keys()} == {"BF16"}
        with open(os.path.join(checkpoint, "config.json")) as f:
            assert json.load(f)["dtype"] == "bfloat16"
        assert AutoModelForCausalLM.from_pretrained(checkpoint, dtype="auto").dtype == torch.bfloat16
        master = torch.load(os.path.join(checkpoint, "pytorch_model_fsdp.bin"), map_location="cpu", weights_only=True)
        assert {tensor.dtype for tensor in master.values() if tensor.is_floating_point()} == {torch.float32}

    @pytest.mark.skipif(
        Version(transformers.__version__) < Version("5.19.0"), reason="expert parallelism needs transformers>=5.19.0"
    )
    def test_async_grpo_expert_parallel(self):
        run_command(
            [
                "torchrun",
                "--nproc_per_node",
                "2",
                "-m",
                "pytest",
                "tests/test_async_grpo_trainer.py",
                "-k",
                "test_train_expert_parallel_body",
                "-x",
                "-q",
                "-p",
                "no:cacheprovider",
            ],
            {**os.environ, "TRL_TEST_EP_OUTPUT_DIR": self.tmp_dir},
        )

    @pytest.mark.skipif(
        Version(transformers.__version__) < Version("5.19.0"), reason="expert parallelism needs transformers>=5.19.0"
    )
    def test_async_grpo_expert_parallel_lora(self):
        run_command(
            [
                "torchrun",
                "--nproc_per_node",
                "2",
                "-m",
                "pytest",
                "tests/test_async_grpo_trainer.py",
                "-k",
                "test_train_expert_parallel_lora_body",
                "-x",
                "-q",
                "-p",
                "no:cacheprovider",
            ],
            {**os.environ, "TRL_TEST_EP_OUTPUT_DIR": self.tmp_dir},
        )

    @pytest.mark.skipif(
        Version(transformers.__version__) < Version("5.19.0"), reason="expert parallelism needs transformers>=5.19.0"
    )
    def test_async_grpo_expert_parallel_merged_lora_sync(self):
        run_command(
            [
                "torchrun",
                "--nproc_per_node",
                "2",
                "-m",
                "pytest",
                "tests/test_async_grpo_trainer.py",
                "-k",
                "test_expert_parallel_merged_sync_sends_merged_lora_weights_body",
                "-x",
                "-q",
                "-p",
                "no:cacheprovider",
            ],
            {**os.environ, "TRL_TEST_EP_OUTPUT_DIR": self.tmp_dir},
        )

    @pytest.mark.parametrize(
        "config",
        [
            "ddp",
            pytest.param(
                "zero2",
                marks=pytest.mark.xfail(
                    Version(transformers.__version__) == Version("5.1.0"),
                    reason="Upstream incompatibility: deepspeed and transformers==5.1.0 (see transformers#43780)",
                ),
            ),
            pytest.param(
                "zero3",
                marks=pytest.mark.xfail(
                    Version(transformers.__version__) == Version("5.1.0"),
                    reason="Upstream incompatibility: deepspeed and transformers==5.1.0 (see transformers#43780)",
                ),
            ),
            "fsdp2",
        ],
    )
    def test_sft(self, config, get_launch_args):
        # fmt: off
        run_command(
            [
                "torchrun", "--nproc_per_node", "2", "trl/scripts/sft.py", *get_launch_args(config),
                "--output_dir", self.tmp_dir,
                "--model_name_or_path", "trl-internal-testing/tiny-Qwen2ForCausalLM-2.5",
                "--model_revision", MODEL_REVISIONS["trl-internal-testing/tiny-Qwen2ForCausalLM-2.5"],
                "--dataset_name", "trl-internal-testing/zen",
                "--dataset_config", "standard_language_modeling",
            ],
            os.environ.copy(),
        )
        # fmt: on

    @pytest.mark.parametrize(
        "config",
        [
            "ddp",
            pytest.param(
                "zero2",
                marks=pytest.mark.xfail(
                    Version(transformers.__version__) == Version("5.1.0"),
                    reason="Upstream incompatibility: deepspeed and transformers==5.1.0 (see transformers#43780)",
                ),
            ),
            pytest.param(
                "zero3",
                marks=pytest.mark.xfail(
                    Version(transformers.__version__) == Version("5.1.0"),
                    reason="Upstream incompatibility: deepspeed and transformers==5.1.0 (see transformers#43780)",
                ),
            ),
            "fsdp2",
        ],
    )
    def test_sft_nll_loss(self, config, get_launch_args):
        # fmt: off
        run_command(
            [
                "torchrun", "--nproc_per_node", "2", "trl/scripts/sft.py", *get_launch_args(config),
                "--output_dir", self.tmp_dir,
                "--model_name_or_path", "trl-internal-testing/tiny-Qwen2ForCausalLM-2.5",
                "--model_revision", MODEL_REVISIONS["trl-internal-testing/tiny-Qwen2ForCausalLM-2.5"],
                "--dataset_name", "trl-internal-testing/zen",
                "--dataset_config", "standard_language_modeling",
                "--loss_type", "nll",
            ],
            os.environ.copy(),
        )
        # fmt: on

    @pytest.mark.parametrize(
        "config",
        [
            "ddp",
            pytest.param(
                "zero2",
                marks=pytest.mark.xfail(
                    Version(transformers.__version__) == Version("5.1.0"),
                    reason="Upstream incompatibility: deepspeed and transformers==5.1.0 (see transformers#43780)",
                ),
            ),
            pytest.param(
                "zero3",
                marks=pytest.mark.xfail(
                    Version(transformers.__version__) == Version("5.1.0"),
                    reason="Upstream incompatibility: deepspeed and transformers==5.1.0 (see transformers#43780)",
                ),
            ),
            "fsdp2",
        ],
    )
    def test_dpo(self, config, get_launch_args):
        # fmt: off
        run_command(
            [
                "torchrun", "--nproc_per_node", "2", "trl/scripts/dpo.py", *get_launch_args(config),
                "--output_dir", self.tmp_dir,
                "--model_name_or_path", "trl-internal-testing/tiny-Qwen2ForCausalLM-2.5",
                "--model_revision", MODEL_REVISIONS["trl-internal-testing/tiny-Qwen2ForCausalLM-2.5"],
                "--dataset_name", "trl-internal-testing/zen",
                "--dataset_config", "standard_preference",
            ],
            os.environ.copy(),
        )
        # fmt: on

    @pytest.mark.parametrize(
        "config",
        [
            "ddp",
            pytest.param(
                "zero2",
                marks=pytest.mark.xfail(
                    Version(transformers.__version__) == Version("5.1.0"),
                    reason="Upstream incompatibility: deepspeed and transformers==5.1.0 (see transformers#43780)",
                ),
            ),
            pytest.param(
                "zero3",
                marks=pytest.mark.xfail(
                    Version(transformers.__version__) == Version("5.1.0"),
                    reason="Upstream incompatibility: deepspeed and transformers==5.1.0 (see transformers#43780)",
                ),
            ),
            "fsdp2",
        ],
    )
    def test_dpo_precompute_ref_log_probs(self, config, get_launch_args):
        # `--eval_strategy epoch` passes an eval dataset, so reference log-probs are precomputed for both the train and
        # eval splits (two passes), which is what previously broke multi-GPU precompute (fingerprint cache mismatch, and
        # a corrupted ZeRO-3 parameter coordinator from re-initializing DeepSpeed on the policy model per pass).
        # fmt: off
        run_command(
            [
                "torchrun", "--nproc_per_node", "2", "trl/scripts/dpo.py", *get_launch_args(config),
                "--output_dir", self.tmp_dir,
                "--model_name_or_path", "trl-internal-testing/tiny-Qwen2ForCausalLM-2.5",
                "--model_revision", MODEL_REVISIONS["trl-internal-testing/tiny-Qwen2ForCausalLM-2.5"],
                "--dataset_name", "trl-internal-testing/zen",
                "--dataset_config", "standard_preference",
                "--precompute_ref_log_probs",
                "--eval_strategy", "epoch",
            ],
            os.environ.copy(),
        )
        # fmt: on

    @pytest.mark.parametrize(
        "config",
        [
            "ddp",
            pytest.param(
                "zero2",
                marks=pytest.mark.xfail(
                    Version(transformers.__version__) == Version("5.1.0"),
                    reason="Upstream incompatibility: deepspeed and transformers==5.1.0 (see transformers#43780)",
                ),
            ),
            pytest.param(
                "zero3",
                marks=pytest.mark.xfail(
                    Version(transformers.__version__) == Version("5.1.0"),
                    reason="Upstream incompatibility: deepspeed and transformers==5.1.0 (see transformers#43780)",
                ),
            ),
            "fsdp2",
        ],
    )
    def test_kto_precompute_ref_log_probs(self, config, get_launch_args):
        # fmt: off
        run_command(
            [
                "torchrun", "--nproc_per_node", "2", "trl/scripts/kto.py", *get_launch_args(config),
                "--output_dir", self.tmp_dir,
                "--model_name_or_path", "trl-internal-testing/tiny-Qwen2ForCausalLM-2.5",
                "--model_revision", MODEL_REVISIONS["trl-internal-testing/tiny-Qwen2ForCausalLM-2.5"],
                "--dataset_name", "trl-internal-testing/zen",
                "--dataset_config", "standard_unpaired_preference",
                "--precompute_ref_log_probs",
                "--eval_strategy", "epoch",
            ],
            os.environ.copy(),
        )
        # fmt: on

    @pytest.mark.parametrize(
        "config",
        [
            "ddp",
            pytest.param(
                "zero2",
                marks=pytest.mark.xfail(
                    Version(transformers.__version__) == Version("5.1.0"),
                    reason="Upstream incompatibility: deepspeed and transformers==5.1.0 (see transformers#43780)",
                ),
            ),
            pytest.param(
                "zero3",
                marks=pytest.mark.xfail(
                    Version(transformers.__version__) == Version("5.1.0"),
                    reason="Upstream incompatibility: deepspeed and transformers==5.1.0 (see transformers#43780)",
                ),
            ),
            "fsdp2",
        ],
    )
    def test_sft_dataset_streaming(self, config, get_launch_args):
        # fmt: off
        run_command(
            [
                "torchrun", "--nproc_per_node", "2", "trl/scripts/sft.py", *get_launch_args(config),
                "--output_dir", self.tmp_dir,
                "--model_name_or_path", "trl-internal-testing/tiny-Qwen2ForCausalLM-2.5",
                "--model_revision", MODEL_REVISIONS["trl-internal-testing/tiny-Qwen2ForCausalLM-2.5"],
                "--dataset_name", "trl-internal-testing/zen",
                "--dataset_config", "standard_language_modeling",
                "--dataset_streaming",
                "--max_steps", "3",
            ],
            os.environ.copy(),
        )
        # fmt: on

    @pytest.mark.parametrize(
        "config",
        [
            "ddp",
            pytest.param(
                "zero2",
                marks=pytest.mark.xfail(
                    condition=Version("2.10") <= Version(torch.__version__)
                    and Version(transformers.__version__) < Version("5.1.0"),
                    reason="ZeRO 2 + PEFT was failing before transformers 5.1.0 on torch 2.10; see #4884",
                ),
            ),
            pytest.param(
                "zero3",
                marks=pytest.mark.xfail(
                    condition=Version("2.10") <= Version(torch.__version__)
                    and Version(transformers.__version__) < Version("5.1.0"),
                    reason="ZeRO 3 + PEFT was failing before transformers 5.1.0 on torch 2.10; see #4884",
                ),
            ),
            "fsdp2",
        ],
    )
    def test_sft_peft(self, config, get_launch_args):
        # fmt: off
        run_command(
            [
                "torchrun", "--nproc_per_node", "2", "trl/scripts/sft.py", *get_launch_args(config),
                "--output_dir", self.tmp_dir,
                "--model_name_or_path", "trl-internal-testing/tiny-Qwen2ForCausalLM-2.5",
                "--model_revision", MODEL_REVISIONS["trl-internal-testing/tiny-Qwen2ForCausalLM-2.5"],
                "--dataset_name", "trl-internal-testing/zen",
                "--dataset_config", "standard_language_modeling",
                "--use_peft",
            ],
            os.environ.copy(),
        )
        # fmt: on

    @pytest.mark.parametrize(
        "config",
        [
            "ddp",
            pytest.param(
                "zero2",
                marks=pytest.mark.xfail(
                    Version(transformers.__version__) == Version("5.1.0"),
                    reason="Upstream incompatibility: deepspeed and transformers==5.1.0 (see transformers#43780)",
                ),
            ),
            pytest.param(
                "zero3",
                marks=pytest.mark.xfail(
                    Version(transformers.__version__) == Version("5.1.0"),
                    reason="Upstream incompatibility: deepspeed and transformers==5.1.0 (see transformers#43780)",
                ),
            ),
            "fsdp2",
        ],
    )
    def test_reward(self, config, get_launch_args):
        # fmt: off
        run_command(
            [
                "torchrun", "--nproc_per_node", "2", "trl/scripts/reward.py", *get_launch_args(config),
                "--output_dir", self.tmp_dir,
                "--model_name_or_path", "trl-internal-testing/tiny-Qwen2ForCausalLM-2.5",
                "--model_revision", MODEL_REVISIONS["trl-internal-testing/tiny-Qwen2ForCausalLM-2.5"],
                "--dataset_name", "trl-internal-testing/zen",
                "--dataset_config", "conversational_implicit_prompt_preference",
            ],
            os.environ.copy(),
        )
        # fmt: on

    @pytest.mark.parametrize(
        "config",
        [
            "ddp",
            pytest.param(
                "zero2",
                marks=pytest.mark.xfail(
                    Version(transformers.__version__) == Version("5.1.0"),
                    reason="Upstream incompatibility: deepspeed and transformers==5.1.0 (see transformers#43780)",
                ),
            ),
            pytest.param(
                "zero3",
                marks=pytest.mark.xfail(
                    Version("5.0.0") <= Version(transformers.__version__) < Version("5.5.4"),
                    reason="ZeRO-3 fails with transformers >= 5.0.0 and < 5.5.4 (fixed in transformers#45414), see #4899",
                    strict=True,
                ),
            ),
            pytest.param(
                "fsdp2",
                marks=pytest.mark.skipif(
                    Version("5.4.0") <= Version(transformers.__version__) < Version("5.6.0"),
                    reason="Upstream issue: NaN weights on non-rank-0 FSDP processes (see #5386 and transformers#45050)",
                ),
            ),
        ],
    )
    def test_rloo(self, config, get_launch_args):
        reward_model_id = "trl-internal-testing/tiny-Qwen2ForSequenceClassification-2.5"
        # Local snapshot of the pinned reward model: by name, it would load from the Hub `main` (#8532)
        reward_model_path = snapshot_download(reward_model_id, revision=MODEL_REVISIONS[reward_model_id])
        # fmt: off
        run_command(
            [
                "torchrun", "--nproc_per_node", "2", "trl/scripts/rloo.py", *get_launch_args(config),
                "--output_dir", self.tmp_dir,
                "--model_name_or_path", "trl-internal-testing/tiny-Qwen2ForCausalLM-2.5",
                "--model_revision", MODEL_REVISIONS["trl-internal-testing/tiny-Qwen2ForCausalLM-2.5"],
                "--dataset_name", "trl-internal-testing/zen",
                "--dataset_config", "conversational_prompt_only",
                "--reward_model_name_or_path", reward_model_path,
            ],
            os.environ.copy(),
        )
        # fmt: on

    @pytest.mark.parametrize(
        "config",
        [
            "ddp",
            pytest.param(
                "zero2",
                marks=pytest.mark.xfail(
                    Version(transformers.__version__) == Version("5.1.0"),
                    reason="Upstream incompatibility: deepspeed and transformers==5.1.0 (see transformers#43780)",
                ),
            ),
            pytest.param(
                "zero3",
                marks=pytest.mark.xfail(
                    Version("5.0.0") <= Version(transformers.__version__) < Version("5.5.4"),
                    reason="ZeRO-3 fails with transformers >= 5.0.0 and < 5.5.4 (fixed in transformers#45414), see #4899",
                    strict=True,
                ),
            ),
            "fsdp2",
        ],
    )
    def test_grpo(self, config, get_launch_args):
        reward_model_id = "trl-internal-testing/tiny-Qwen2ForSequenceClassification-2.5"
        # Local snapshot of the pinned reward model: by name, it would load from the Hub `main` (#8532)
        reward_model_path = snapshot_download(reward_model_id, revision=MODEL_REVISIONS[reward_model_id])
        # fmt: off
        run_command(
            [
                "torchrun", "--nproc_per_node", "2", "trl/scripts/grpo.py", *get_launch_args(config),
                "--output_dir", self.tmp_dir,
                "--model_name_or_path", "trl-internal-testing/tiny-Qwen2ForCausalLM-2.5",
                "--model_revision", MODEL_REVISIONS["trl-internal-testing/tiny-Qwen2ForCausalLM-2.5"],
                "--dataset_name", "trl-internal-testing/zen",
                "--dataset_config", "conversational_prompt_only",
                "--reward_model_name_or_path", reward_model_path,
            ],
            os.environ.copy(),
        )
        # fmt: on


@require_torch_multi_accelerator
class TestModelParallel:
    def test_fused_lm_head(self):
        """With the model split across two devices, the fused LM head matches the model on a single device."""
        model_id = "trl-internal-testing/tiny-Qwen3ForCausalLM"
        # The layout documented for naive pipeline parallelism: layers split across devices, `lm_head` on device 0
        device_map = {
            "model.embed_tokens": 0,
            "model.layers.0": 0,
            "model.layers.1": 1,
            "model.norm": 1,
            "model.rotary_emb": 1,
            "lm_head": 0,
        }
        model = AutoModelForCausalLM.from_pretrained(model_id, device_map={"": 0})
        model_split = AutoModelForCausalLM.from_pretrained(model_id, device_map=device_map)
        add_fused_lm_head(model, outputs=("log_probs", "entropy"))
        add_fused_lm_head(model_split, outputs=("log_probs", "entropy"))
        input_ids = torch.randint(0, model.config.vocab_size, (2, 16), device=model.device)
        labels = input_ids.masked_fill(torch.arange(16, device=model.device) < 4, -100)

        out = model(input_ids=input_ids, labels=labels, fused_lm_head=True)
        out_split = model_split(input_ids=input_ids, labels=labels, fused_lm_head=True)

        torch.testing.assert_close(out_split["log_probs"], out["log_probs"])
        torch.testing.assert_close(out_split["entropy"], out["entropy"])
        out_split["loss"].backward()
        assert all(param.grad is not None for param in model_split.parameters())

    def test_train_sft(self, tmp_path):
        """A model split across two devices trains, since `Trainer` doesn't wrap it in `nn.DataParallel`."""
        model_id = "trl-internal-testing/tiny-Qwen3ForCausalLM"
        # The layout documented for naive pipeline parallelism: layers split across devices, `lm_head` on device 0
        device_map = {
            "model.embed_tokens": 0,
            "model.layers.0": 0,
            "model.layers.1": 1,
            "model.norm": 1,
            "model.rotary_emb": 1,
            "lm_head": 0,
        }
        model = AutoModelForCausalLM.from_pretrained(model_id, dtype="float32", device_map=device_map)
        dataset = load_dataset("trl-internal-testing/zen", "standard_language_modeling", split="train")

        training_args = SFTConfig(output_dir=str(tmp_path), report_to="none")
        trainer = SFTTrainer(model=model, args=training_args, train_dataset=dataset)

        previous_trainable_params = {n: param.clone() for n, param in trainer.model.named_parameters()}

        trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None

        # Check that the params have changed
        for n, param in previous_trainable_params.items():
            new_param = trainer.model.get_parameter(n)
            assert not torch.equal(param, new_param), f"Parameter {n} has not changed."

    def test_train_distillation(self, tmp_path):
        """A student and a teacher split across two devices train with the chunked divergence loss."""
        # The layout documented for naive pipeline parallelism: layers split across devices, `lm_head` on device 0
        device_map = {
            "model.embed_tokens": 0,
            "model.layers.0": 0,
            "model.layers.1": 1,
            "model.norm": 1,
            "model.rotary_emb": 1,
            "lm_head": 0,
        }
        model = AutoModelForCausalLM.from_pretrained(
            "trl-internal-testing/tiny-Qwen3ForCausalLM", dtype="float32", device_map=device_map
        )
        teacher_model = AutoModelForCausalLM.from_pretrained(
            "trl-internal-testing/tiny-Qwen3MoeForCausalLM", dtype="float32", device_map=device_map
        )
        dataset = load_dataset("trl-internal-testing/zen", "standard_prompt_only", split="train")

        training_args = DistillationConfig(
            output_dir=str(tmp_path),
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            report_to="none",
        )
        trainer = DistillationTrainer(
            model=model, teacher_model=teacher_model, args=training_args, train_dataset=dataset
        )

        previous_trainable_params = {n: param.clone() for n, param in trainer.model.named_parameters()}

        trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None

        # Check that the params have changed
        for n, param in previous_trainable_params.items():
            new_param = trainer.model.get_parameter(n)
            assert not torch.equal(param, new_param), f"Parameter {n} has not changed."

    def test_train_distillation_heads_on_different_devices(self, tmp_path):
        """The chunked divergence loss needs the student and teacher heads on the same device, so training refuses."""
        # The layout documented for naive pipeline parallelism: layers split across devices, `lm_head` on device 0
        device_map = {
            "model.embed_tokens": 0,
            "model.layers.0": 0,
            "model.layers.1": 1,
            "model.norm": 1,
            "model.rotary_emb": 1,
            "lm_head": 0,
        }
        model = AutoModelForCausalLM.from_pretrained(
            "trl-internal-testing/tiny-Qwen3ForCausalLM", dtype="float32", device_map=device_map
        )
        # An untied teacher, so its head can sit on another device than its embeddings
        teacher_model = AutoModelForCausalLM.from_pretrained(
            "trl-internal-testing/tiny-Qwen3ForCausalLM", dtype="float32", device_map={"model": 0, "lm_head": 1}
        )
        dataset = load_dataset("trl-internal-testing/zen", "standard_prompt_only", split="train")

        training_args = DistillationConfig(
            output_dir=str(tmp_path),
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            report_to="none",
        )
        trainer = DistillationTrainer(
            model=model, teacher_model=teacher_model, args=training_args, train_dataset=dataset
        )

        with pytest.raises(ValueError, match="Place both on the same device"):
            trainer.train()

    def test_train_dpo(self, tmp_path):
        """A model split across two devices trains, since `Trainer` doesn't wrap it in `nn.DataParallel`."""
        model_id = "trl-internal-testing/tiny-Qwen3ForCausalLM"
        # The layout documented for naive pipeline parallelism: layers split across devices, `lm_head` on device 0
        device_map = {
            "model.embed_tokens": 0,
            "model.layers.0": 0,
            "model.layers.1": 1,
            "model.norm": 1,
            "model.rotary_emb": 1,
            "lm_head": 0,
        }
        model = AutoModelForCausalLM.from_pretrained(model_id, dtype="float32", device_map=device_map)
        dataset = load_dataset("trl-internal-testing/zen", "standard_preference", split="train")

        training_args = DPOConfig(
            output_dir=str(tmp_path),
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            report_to="none",
        )
        trainer = DPOTrainer(model=model, args=training_args, train_dataset=dataset)

        previous_trainable_params = {n: param.clone() for n, param in trainer.model.named_parameters()}

        trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None

        # Check that the params have changed
        for n, param in previous_trainable_params.items():
            new_param = trainer.model.get_parameter(n)
            assert not torch.equal(param, new_param), f"Parameter {n} has not changed."

    def test_train_kto(self, tmp_path):
        """A model split across two devices trains, since `Trainer` doesn't wrap it in `nn.DataParallel`."""
        model_id = "trl-internal-testing/tiny-Qwen3ForCausalLM"
        # The layout documented for naive pipeline parallelism: layers split across devices, `lm_head` on device 0
        device_map = {
            "model.embed_tokens": 0,
            "model.layers.0": 0,
            "model.layers.1": 1,
            "model.norm": 1,
            "model.rotary_emb": 1,
            "lm_head": 0,
        }
        model = AutoModelForCausalLM.from_pretrained(model_id, dtype="float32", device_map=device_map)
        dataset = load_dataset("trl-internal-testing/zen", "standard_unpaired_preference", split="train")

        training_args = KTOConfig(
            output_dir=str(tmp_path),
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            report_to="none",
        )
        trainer = KTOTrainer(model=model, args=training_args, train_dataset=dataset)

        previous_trainable_params = {n: param.clone() for n, param in trainer.model.named_parameters()}

        trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None

        # Check that the params have changed
        for n, param in previous_trainable_params.items():
            new_param = trainer.model.get_parameter(n)
            assert not torch.equal(param, new_param), f"Parameter {n} has not changed."

    def test_train_reward(self, tmp_path):
        """A model split across two devices trains, since `Trainer` doesn't wrap it in `nn.DataParallel`."""
        model_id = "trl-internal-testing/tiny-Qwen3ForCausalLM"
        # The layout documented for naive pipeline parallelism: layers split across devices, `score` on device 0
        device_map = {
            "model.embed_tokens": 0,
            "model.layers.0": 0,
            "model.layers.1": 1,
            "model.norm": 1,
            "model.rotary_emb": 1,
            "score": 0,
        }
        model = AutoModelForSequenceClassification.from_pretrained(
            model_id, num_labels=1, dtype="float32", device_map=device_map
        )
        dataset = load_dataset("trl-internal-testing/zen", "standard_implicit_prompt_preference", split="train")

        training_args = RewardConfig(output_dir=str(tmp_path), report_to="none")
        trainer = RewardTrainer(model=model, args=training_args, train_dataset=dataset)

        previous_trainable_params = {n: param.clone() for n, param in trainer.model.named_parameters()}

        trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None

        # Check that the params have changed
        for n, param in previous_trainable_params.items():
            new_param = trainer.model.get_parameter(n)
            assert not torch.equal(param, new_param), f"Parameter {n} has not changed."

    def test_train_grpo(self, tmp_path):
        """A model split across two devices trains, since `Trainer` doesn't wrap it in `nn.DataParallel`."""
        model_id = "trl-internal-testing/tiny-Qwen3ForCausalLM"
        # The layout documented for naive pipeline parallelism: layers split across devices, `lm_head` on device 0
        device_map = {
            "model.embed_tokens": 0,
            "model.layers.0": 0,
            "model.layers.1": 1,
            "model.norm": 1,
            "model.rotary_emb": 1,
            "lm_head": 0,
        }
        model = AutoModelForCausalLM.from_pretrained(model_id, dtype="float32", device_map=device_map)
        dataset = load_dataset("trl-internal-testing/zen", "standard_prompt_only", split="train")

        training_args = GRPOConfig(
            output_dir=str(tmp_path),
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            num_generations=3,  # reduce the number of generations to reduce memory usage
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            report_to="none",
        )
        trainer = GRPOTrainer(
            model=model,
            reward_funcs="trl-internal-testing/tiny-Qwen2ForSequenceClassification-2.5",
            args=training_args,
            train_dataset=dataset,
        )

        previous_trainable_params = {n: param.clone() for n, param in trainer.model.named_parameters()}

        trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None

        # Check that the params have changed
        for n, param in previous_trainable_params.items():
            new_param = trainer.model.get_parameter(n)
            assert not torch.equal(param, new_param), f"Parameter {n} has not changed."

    def test_train_rloo(self, tmp_path):
        """A model split across two devices trains, since `Trainer` doesn't wrap it in `nn.DataParallel`."""
        model_id = "trl-internal-testing/tiny-Qwen3ForCausalLM"
        # The layout documented for naive pipeline parallelism: layers split across devices, `lm_head` on device 0
        device_map = {
            "model.embed_tokens": 0,
            "model.layers.0": 0,
            "model.layers.1": 1,
            "model.norm": 1,
            "model.rotary_emb": 1,
            "lm_head": 0,
        }
        model = AutoModelForCausalLM.from_pretrained(model_id, dtype="float32", device_map=device_map)
        dataset = load_dataset("trl-internal-testing/zen", "standard_prompt_only", split="train")

        training_args = RLOOConfig(
            output_dir=str(tmp_path),
            learning_rate=0.1,  # use higher lr because gradients are tiny and default lr can stall updates
            per_device_train_batch_size=3,  # reduce the batch size to reduce memory usage
            num_generations=3,  # reduce the number of generations to reduce memory usage
            max_completion_length=8,  # reduce the completion length to reduce memory usage
            report_to="none",
        )
        trainer = RLOOTrainer(
            model=model,
            reward_funcs="trl-internal-testing/tiny-Qwen2ForSequenceClassification-2.5",
            args=training_args,
            train_dataset=dataset,
        )

        previous_trainable_params = {n: param.clone() for n, param in trainer.model.named_parameters()}

        trainer.train()

        assert trainer.state.log_history[-1]["train_loss"] is not None

        # Check that the params have changed
        for n, param in previous_trainable_params.items():
            new_param = trainer.model.get_parameter(n)
            assert not torch.equal(param, new_param), f"Parameter {n} has not changed."
