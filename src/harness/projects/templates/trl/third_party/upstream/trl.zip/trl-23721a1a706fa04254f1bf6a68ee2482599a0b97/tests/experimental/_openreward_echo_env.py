# Copyright 2020-2026 The HuggingFace Team. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Spawn target for `tests/experimental/test_openreward.py`.

Implements a minimal, deterministic Open Reward Standard environment so the adapter can be exercised end-to-end without
hitting the network. The same definition is also published as a Hugging Face Space at
`trl-internal-testing/openreward-echo-env` for the optional integration test.

The model is given a target string and must call `echo(text=...)` with exactly that string. Reward is `1.0` on match,
`0.0` otherwise; the episode finishes on a correct echo.
"""

from openreward.environments import (
    Environment,
    JSONObject,
    ListToolsOutput,
    Server,
    TextBlock,
    ToolOutput,
    ToolSpec,
    tool,
)
from pydantic import BaseModel


TRAIN_TASKS: list[JSONObject] = [
    {"id": "echo-0", "target": "hello"},
    {"id": "echo-1", "target": "world"},
    {"id": "echo-2", "target": "trl"},
    {"id": "echo-3", "target": "openreward"},
]


class EchoTaskSpec(BaseModel):
    id: str
    target: str
    failure_reward: float = 0.0


class EchoParams(BaseModel):
    text: str


class HintParams(BaseModel):
    """Parameters for the optional hint tool (session-only via ``list_task_tools``)."""

    pass


class EchoEnvironment(Environment):
    """Tiny deterministic ORS env: echo the target string to win."""

    def __init__(self, task_spec: JSONObject = {}, secrets: dict[str, str] = {}):  # noqa: B006 - signature dictated by openreward.environments.Environment
        super().__init__(task_spec)
        self.config = EchoTaskSpec.model_validate(task_spec)

    @classmethod
    def list_splits(cls) -> list[str]:
        return ["train"]

    @classmethod
    def list_tasks(cls, split: str) -> list[JSONObject]:
        if split != "train":
            raise ValueError(f"unknown split: {split}")
        return TRAIN_TASKS

    def get_prompt(self) -> list[TextBlock]:
        return [
            TextBlock(
                type="text",
                text=f"Call the `echo` tool with text='{self.config.target}' to win.",
            )
        ]

    def list_task_tools(self) -> ListToolsOutput:
        """Expose ``hint`` only on GET /task_tools (merged into ``session.list_tools()``)."""
        return ListToolsOutput(
            tools=[
                ToolSpec(
                    name="hint",
                    description="Cheap hint for tests exercising ORS /task_tools discovery.",
                    input_schema=HintParams.model_json_schema(),
                )
            ]
        )

    @tool
    async def echo(self, params: EchoParams) -> ToolOutput:
        """Submit a string. Reward 1.0 + finished if it matches the target.

        Args:
            text: The string to echo back.
        """
        correct = params.text == self.config.target
        return ToolOutput(
            blocks=[
                TextBlock(
                    type="text",
                    text="match" if correct else f"no match (got {params.text!r})",
                )
            ],
            reward=1.0 if correct else self.config.failure_reward,
            finished=correct,
        )

    @tool(shared=False)
    async def hint(self, params: HintParams) -> ToolOutput:
        """Session-advertised helper (spec comes from ``list_task_tools``)."""
        return ToolOutput(blocks=[TextBlock(text="try echo(text=...)")])


if __name__ == "__main__":
    import os

    import uvicorn

    # Serve on the socket bound by the test fixture
    uvicorn.run(Server([EchoEnvironment]).app, fd=int(os.environ["FD"]), access_log=False)
