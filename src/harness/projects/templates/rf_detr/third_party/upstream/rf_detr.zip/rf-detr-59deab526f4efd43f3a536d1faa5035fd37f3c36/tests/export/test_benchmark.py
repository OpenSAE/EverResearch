# ------------------------------------------------------------------------
# RF-DETR
# Copyright (c) 2025 Roboflow. All Rights Reserved.
# Licensed under the Apache License, Version 2.0 [see LICENSE for details]
# ------------------------------------------------------------------------
"""Regression tests for the shared latency and memory benchmark helpers."""

from __future__ import annotations

import ast
import hashlib
import json
import sys
import threading
from collections.abc import Callable
from contextlib import contextmanager
from pathlib import Path
from types import SimpleNamespace
from typing import Any
from unittest.mock import Mock, call

import numpy as np
import pytest
import supervision as sv
import torch
from PIL import Image

from rfdetr.assets.coco_classes import COCO_CLASSES
from rfdetr.export._benchmark import (
    BenchmarkConfig,
    BenchmarkResult,
    BenchmarkRows,
    _artifact_size_mb,
    _decode_batch,
    _measure_cuda,
    _result_row,
    _sampled_delta_mb,
    _tile_batch,
    cpu_brand,
    export_cached,
    im_predict,
    measure_latency,
    measure_memory,
    parity,
    time_folder,
    visualize_detections,
)


class TestMeasureLatency:
    """Check timer dispatch, sample counts, and result statistics."""

    def test_wall_clock_counts_warmups_and_returns_statistics(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """The wall-clock path excludes warmups and returns population statistics."""
        clock = Mock(side_effect=[10.0, 10.002, 11.0, 11.006])
        monkeypatch.setattr("rfdetr.export._benchmark.time.perf_counter", clock)
        call = Mock()

        result = measure_latency(call, label="cpu", device="cpu", warmup=2, runs=2)

        assert call.call_count == 4
        assert clock.call_count == 4
        assert result.label == "cpu"
        assert result.mean_ms == pytest.approx(4.0, abs=1e-9)
        assert result.std_ms == pytest.approx(2.0, abs=1e-9)
        assert result.fps == pytest.approx(250.0)

    def test_cuda_events_include_warmups_and_synchronize_each_sample(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """CUDA timing orders events around each call and synchronizes before reading elapsed time."""
        order: list[str] = []
        start = Mock()
        end = Mock()
        start.record.side_effect = lambda _stream: order.append("start")
        end.record.side_effect = lambda _stream: order.append("end")
        start.elapsed_time.side_effect = [1.0, 3.0]
        event_factory = Mock(side_effect=[start, end])
        synchronize = Mock(side_effect=lambda _device: order.append("sync"))
        call = Mock(side_effect=lambda: order.append("call"))
        monkeypatch.setattr(torch.cuda, "Event", event_factory)
        monkeypatch.setattr(torch.cuda, "synchronize", synchronize)
        monkeypatch.setattr(torch.cuda, "current_stream", Mock())

        timings = _measure_cuda(call, warmup=2, runs=2, device=torch.device("cuda"))

        expected = ["call", "call", "sync", "start", "call", "end", "sync", "start", "call", "end", "sync"]
        assert order == expected
        assert event_factory.call_count == 2
        assert all(call.kwargs == {"enable_timing": True} for call in event_factory.call_args_list)
        assert call.call_count == 4
        assert synchronize.call_count == 3
        assert [call.args for call in start.elapsed_time.call_args_list] == [(end,), (end,)]
        assert timings == [1.0, 3.0]

    def test_cuda_events_and_synchronize_target_the_requested_device(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Events record on the requested device's stream and every synchronize targets that same device.

        With ``"cuda:1"`` while GPU 0 is current, bare ``synchronize()`` and default-stream events would time GPU 0's
        idle stream instead of the work launched on GPU 1.
        """
        device = torch.device("cuda", 1)
        stream = Mock()
        current_stream = Mock(return_value=stream)
        synchronize = Mock()
        event = Mock()
        event.elapsed_time.return_value = 1.0
        monkeypatch.setattr(torch.cuda, "Event", Mock(return_value=event))
        monkeypatch.setattr(torch.cuda, "synchronize", synchronize)
        monkeypatch.setattr(torch.cuda, "current_stream", current_stream)

        _measure_cuda(Mock(), warmup=1, runs=1, device=device)

        assert synchronize.call_args_list == [call(device), call(device)]
        assert current_stream.call_args_list == [call(device)]
        assert event.record.call_args_list == [call(stream), call(stream)]

    @pytest.mark.parametrize(
        "device",
        [
            "cuda",
            "cuda:0",
            pytest.param(torch.device("cuda", 1), id="torch-device-cuda-1"),
        ],
    )
    def test_any_cuda_device_selects_the_cuda_event_timer(
        self, device: str | torch.device, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Every CUDA spelling routes to the CUDA-event timer with the parsed device.

        ``"cuda:0"`` used to miss an exact ``== "cuda"`` match and fall through to the wall-clock timer, which returns
        after the asynchronous kernel launch and reports a falsely low latency.
        """
        measure_cuda = Mock(return_value=[1.0])
        monkeypatch.setattr("rfdetr.export._benchmark._measure_cuda", measure_cuda)
        fn = Mock()

        measure_latency(fn, label="gpu", device=device, warmup=0, runs=1)

        measure_cuda.assert_called_once_with(fn, 0, 1, torch.device(device))

    @pytest.mark.parametrize("device", ["cpu", "mps", pytest.param(torch.device("cpu"), id="torch-device-cpu")])
    def test_non_cuda_device_selects_the_wall_clock_timer(
        self, device: str | torch.device, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Any non-CUDA device, string or ``torch.device``, times with ``perf_counter``.

        Non-CUDA runtimes block the calling thread, so there is no stream to synchronize and the wall clock is exact.
        """
        wall_clock = Mock(return_value=[1.0])
        monkeypatch.setattr("rfdetr.export._benchmark._measure_wall_clock", wall_clock)
        fn = Mock()

        measure_latency(fn, label="host", device=device, warmup=0, runs=1)

        wall_clock.assert_called_once_with(fn, 0, 1)

    def test_unparseable_device_string_is_rejected(self) -> None:
        """A device string torch cannot parse raises instead of silently timing with the wall clock.

        A typo such as ``"gpu"`` previously took the wall-clock path and reported a launch-only number.
        """
        with pytest.raises(RuntimeError, match="device string: gpu"):
            measure_latency(Mock(), label="typo", device="gpu", warmup=0, runs=1)

    @pytest.mark.parametrize(
        ("warmup", "runs"),
        [pytest.param(-1, 1, id="negative-warmup"), pytest.param(0, 0, id="zero-runs")],
    )
    def test_invalid_sample_counts_raise(self, warmup: int, runs: int) -> None:
        """Negative warmups and empty measurement sets must be rejected."""
        with pytest.raises(ValueError, match="warmup|runs"):
            measure_latency(lambda: None, label="invalid", warmup=warmup, runs=runs)

    def test_zero_mean_latency_has_infinite_fps(self) -> None:
        """A zero-duration sample maps to infinite FPS without division failure."""
        assert BenchmarkResult("instant", 0.0, 0.0).fps == float("inf")

    def test_measure_latency_keeps_every_timed_call(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """The result carries each call's time, with the mean and standard deviation computed from the same list."""
        monkeypatch.setattr("rfdetr.export._benchmark._measure_wall_clock", Mock(return_value=[1.0, 3.0]))

        result = measure_latency(Mock(), label="host", device="cpu", warmup=0, runs=2)

        assert result.timings_ms == (1.0, 3.0)
        assert (result.mean_ms, result.std_ms) == (pytest.approx(2.0), pytest.approx(1.0))

    def test_median_ignores_one_slow_call(self) -> None:
        """One slow call moves the mean but not the median, which is why the winners are chosen by the median."""
        result = BenchmarkResult("host", 22.0, 38.0, (1.0, 2.0, 3.0, 4.0, 100.0))

        assert result.median_ms == 3.0

    def test_p95_interpolates_between_the_nearest_ranks(self) -> None:
        """The 95th percentile of five calls lies between the fourth and the slowest."""
        result = BenchmarkResult("host", 22.0, 38.0, (1.0, 2.0, 3.0, 4.0, 100.0))

        assert result.p95_ms == pytest.approx(80.8)

    def test_median_without_timings_raises(self) -> None:
        """A result built without per-call timings has no median, and says so instead of returning ``nan``."""
        with pytest.raises(ValueError, match="no per-call timings"):
            BenchmarkResult("host", 1.0, 0.0).median_ms

    def test_p95_without_timings_raises(self) -> None:
        """A result built without per-call timings has no 95th percentile, and says so instead of returning ``nan``."""
        with pytest.raises(ValueError, match="no per-call timings"):
            BenchmarkResult("host", 1.0, 0.0).p95_ms


def _stepping_reader(readings: list[int]) -> tuple[Callable[[], int], threading.Event]:
    """Build a memory reader that walks *readings* once, then repeats the last value forever.

    The returned event is set once only the final value remains, which lets a test block until the
    sampler has definitely consumed every interesting reading — without that handshake the watcher
    thread's timing decides which values it sees, and any peak assertion becomes a race.

    Args:
        readings: Byte values to hand out in order; the last one is repeated indefinitely.

    Returns:
        The reader callable and the event marking the sequence exhausted.

    Examples:
        >>> read, exhausted = _stepping_reader([1, 2])
        >>> read(), read(), read()
        (1, 2, 2)
        >>> exhausted.is_set()
        True
    """
    remaining = list(readings)
    exhausted = threading.Event()
    lock = threading.Lock()

    def read() -> int:
        with lock:
            if len(remaining) > 1:
                return remaining.pop(0)
            exhausted.set()
            return remaining[0]

    return read, exhausted


class TestSampledDelta:
    """Check how net and peak growth are derived from a stream of memory readings."""

    def test_peak_exceeds_net_when_memory_is_released_inside_the_block(self) -> None:
        """Memory allocated and freed inside the block raises ``peak_mb`` but not ``delta_mb``.

        This is the case an endpoint-only reading cannot see, and the reason the sampler exists: a CoreML load was
        measured peaking 141 MB above where it settled, all of it compile scratch released before the block closed. A
        regression here silently reports the settled figure as though it were the cost of bringing the runtime up.
        """
        read, exhausted = _stepping_reader([100_000_000, 180_000_000, 120_000_000])

        with contextmanager(_sampled_delta_mb)(read) as result:
            assert exhausted.wait(timeout=5.0), "sampler never consumed the seeded readings"

        assert result.peak_mb == pytest.approx(80.0)
        assert result.delta_mb == pytest.approx(20.0)
        assert result.samples >= 2

    def test_net_is_negative_when_the_block_ends_below_its_baseline(self) -> None:
        """A block ending with less memory in use reports a negative ``delta_mb`` and zero ``peak_mb``.

        Observed for real when the OS reclaimed an earlier section's Neural Engine buffers during a later section's
        bracket. The negative value is information, not an error, so it must survive to the caller rather than being
        clamped away.
        """
        read, exhausted = _stepping_reader([100_000_000, 40_000_000])

        with contextmanager(_sampled_delta_mb)(read) as result:
            assert exhausted.wait(timeout=5.0), "sampler never consumed the seeded readings"

        assert result.delta_mb == pytest.approx(-60.0)
        assert result.peak_mb == pytest.approx(0.0)

    def test_watcher_thread_is_joined_before_the_block_returns(self) -> None:
        """The sampler thread is stopped and joined on exit, leaking nothing into later tests.

        A daemon thread left polling would keep calling into a torn-down mock for the rest of the session, producing
        failures attributed to whichever test ran next.
        """
        read, _exhausted = _stepping_reader([1_000_000, 2_000_000])

        with contextmanager(_sampled_delta_mb)(read):
            pass

        assert [t for t in threading.enumerate() if t.name == "measure_memory"] == []


class TestMeasureMemory:
    """Check host and device reader wiring, including exceptional block exit."""

    def test_host_delta_is_recorded_when_block_raises(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """The host memory sample is finalized while the original block error propagates.

        Export cells raise often while a notebook is being written, and the partially filled result is what tells the
        author how far the runtime got before failing.
        """
        process = Mock()
        process.memory_info.side_effect = lambda: SimpleNamespace(rss=5_000_000)
        monkeypatch.setattr("psutil.Process", Mock(return_value=process))

        with pytest.raises(RuntimeError, match="benchmark block failed"):
            with measure_memory() as result:
                raise RuntimeError("benchmark block failed")

        assert result.delta_mb == pytest.approx(0.0)

    def test_host_path_without_psutil_names_the_extra(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Entering the host-memory block without ``psutil`` raises an ``ImportError`` naming ``rfdetr[visual]``.

        ``measure_memory`` is public through ``rfdetr.export.benchmark``, while ``psutil`` is not a core dependency, so
        a plain install must learn which extra to add instead of hitting a bare ``ModuleNotFoundError``.
        """
        monkeypatch.setitem(sys.modules, "psutil", None)

        with pytest.raises(ImportError) as exc_info:
            with measure_memory():
                pass

        assert "pip install 'rfdetr[visual]'" in str(exc_info.value)

    def test_cuda_reads_device_bytes_in_use_with_synchronization(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """The CUDA path derives bytes-in-use from ``mem_get_info`` and synchronizes before reading.

        Without the sync, an async kernel's allocation may not be visible yet, so a TensorRT or ONNX Runtime CUDA row
        would under-report whatever was still in flight.
        """
        synchronize = Mock()
        monkeypatch.setattr(torch.cuda, "synchronize", synchronize)
        monkeypatch.setattr(torch.cuda, "mem_get_info", Mock(return_value=(26_000_000, 50_000_000)))

        with measure_memory(device="cuda") as result:
            pass

        assert synchronize.call_count >= 2
        assert result.delta_mb == pytest.approx(0.0)

    def test_cuda_delta_is_recorded_when_block_raises(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """The CUDA memory sample is finalized while the original block error propagates.

        Mirrors the host case: a failed engine build should still leave a readable result rather than
        an untouched default.
        """
        monkeypatch.setattr(torch.cuda, "synchronize", Mock())
        monkeypatch.setattr(torch.cuda, "mem_get_info", Mock(return_value=(17_000_000, 30_000_000)))

        with pytest.raises(RuntimeError, match="benchmark block failed"):
            with measure_memory(device="cuda") as result:
                raise RuntimeError("benchmark block failed")

        assert result.delta_mb == pytest.approx(0.0)

    def test_cuda_device_index_reaches_synchronize_and_mem_get_info(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """``"cuda:1"`` takes the device reader and reads and synchronizes GPU 1, not the current device.

        An exact ``== "cuda"`` match used to send ``"cuda:1"`` to the host RSS reader, which never sees device memory; a
        bare ``mem_get_info()`` would read whichever GPU happens to be current.
        """
        device = torch.device("cuda", 1)
        synchronize = Mock()
        mem_get_info = Mock(return_value=(10_000_000, 20_000_000))
        monkeypatch.setattr(torch.cuda, "synchronize", synchronize)
        monkeypatch.setattr(torch.cuda, "mem_get_info", mem_get_info)

        with measure_memory(device="cuda:1"):
            pass

        assert {recorded.args for recorded in mem_get_info.call_args_list} == {(device,)}
        assert {recorded.args for recorded in synchronize.call_args_list} == {(device,)}


class TestResultRow:
    """Check cookbook results-table row construction, including the FPS derivation."""

    def test_fps_scales_by_batch_size(self) -> None:
        """FPS is images-per-second, so it scales linearly with batch size at fixed per-call latency.

        A batch-4 call that takes proportionally longer than batch-1 must still report the same throughput at both rows;
        only multiplying by ``batch`` before dividing by ``mean_ms`` gives that.
        """
        end2end = BenchmarkResult("onnx", mean_ms=20.0, std_ms=1.0)

        row = _result_row("ONNX", batch=4, config="CUDA EP", forward=None, end2end=end2end, memory_mb=12.5)

        assert row["FPS [img/s] (end2end)"] == pytest.approx(200.0)
        assert row == {
            "Format": "ONNX",
            "Batch": 4,
            "Config": "CUDA EP",
            "forward [ms]": "—",
            "end2end [ms]": "20.00 ± 1.00",
            "FPS [img/s] (end2end)": pytest.approx(200.0),
            "Memory [MB]": "12.5",
        }

    def test_zero_mean_latency_reports_infinite_fps_without_raising(self) -> None:
        """A zero-latency scope routes through ``BenchmarkResult.fps`` and reports ``inf``, never raises.

        Regression guard for the pre-fix formula (``batch * 1000 / scope.mean_ms``), which raised ``ZeroDivisionError``
        on a zero-latency row instead of reporting infinite throughput.
        """
        end2end = BenchmarkResult("instant", mean_ms=0.0, std_ms=0.0)

        row = _result_row("ONNX", batch=4, config="CUDA EP", forward=None, end2end=end2end, memory_mb=None)

        assert row["FPS [img/s] (end2end)"] == float("inf")

    def test_prefers_end2end_scope_over_forward_for_fps(self) -> None:
        """When both scopes are given, FPS is derived from ``end2end``, not ``forward``."""
        forward = BenchmarkResult("forward", mean_ms=5.0, std_ms=0.0)
        end2end = BenchmarkResult("end2end", mean_ms=10.0, std_ms=0.0)

        row = _result_row("ONNX", batch=1, config="CPU", forward=forward, end2end=end2end, memory_mb=None)

        assert row["FPS [img/s] (end2end)"] == pytest.approx(100.0)
        assert row["forward [ms]"] == "5.00 ± 0.00"
        assert row["end2end [ms]"] == "10.00 ± 0.00"

    def test_missing_both_scopes_raises(self) -> None:
        """A row needs at least one timing scope to derive FPS from."""
        with pytest.raises(ValueError, match="needs at least one of forward/end2end"):
            _result_row("ONNX", batch=1, config="CPU", forward=None, end2end=None, memory_mb=None)


class TestTileBatch:
    """Check that tiling repeats one preprocessed image along the batch axis."""

    def test_stacks_copies_along_batch_axis(self) -> None:
        """Tiling a ``(1, C, H, W)`` array *batch* times produces a ``(batch, C, H, W)`` array of copies."""
        single = np.arange(12, dtype=np.float32).reshape(1, 3, 2, 2)

        tiled = _tile_batch(single, batch=3)

        assert tiled.shape == (3, 3, 2, 2)
        for i in range(3):
            np.testing.assert_array_equal(tiled[i], single[0])


class TestDecodeBatch:
    """Check that decoding dispatches once per image in the batch."""

    def test_calls_decode_detections_once_per_image_with_matching_rows(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Each image's boxes/logits row is decoded independently, in batch order."""
        decode = Mock()
        monkeypatch.setattr("rfdetr.export._benchmark.decode_detections", decode)
        boxes = np.arange(2 * 4 * 4, dtype=np.float32).reshape(2, 4, 4)
        logits = np.arange(2 * 4 * 3, dtype=np.float32).reshape(2, 4, 3)

        _decode_batch(boxes, logits, image_size=(640, 480), batch=2, threshold=0.5)

        assert decode.call_count == 2
        for i, call_args in enumerate(decode.call_args_list):
            args, kwargs = call_args
            np.testing.assert_array_equal(args[0], boxes[i])
            np.testing.assert_array_equal(args[1], logits[i])
            assert args[2] == (640, 480)
            assert kwargs == {"threshold": 0.5}


class TestArtifactSizeMb:
    """Check on-disk size summation across single files, directories, and multiple paths."""

    def test_single_file_size(self, tmp_path: Path) -> None:
        """A single file's size in bytes converts to megabytes."""
        file_path = tmp_path / "model.onnx"
        file_path.write_bytes(b"0" * 2_000_000)

        assert _artifact_size_mb(file_path) == pytest.approx(2.0)

    def test_directory_size_is_recursive(self, tmp_path: Path) -> None:
        """A directory's size sums every file it contains, including nested subdirectories."""
        bundle = tmp_path / "model.mlpackage"
        (bundle / "nested").mkdir(parents=True)
        (bundle / "top.bin").write_bytes(b"0" * 1_000_000)
        (bundle / "nested" / "weights.bin").write_bytes(b"0" * 500_000)

        assert _artifact_size_mb(bundle) == pytest.approx(1.5)

    def test_multiple_paths_are_summed(self, tmp_path: Path) -> None:
        """A bundle export passed as several paths (e.g. OpenVINO's ``.xml`` + ``.bin``) sums across all of them."""
        xml_path = tmp_path / "model.xml"
        bin_path = tmp_path / "model.bin"
        xml_path.write_bytes(b"0" * 100_000)
        bin_path.write_bytes(b"0" * 900_000)

        assert _artifact_size_mb(xml_path, bin_path) == pytest.approx(1.0)


class TestCpuBrand:
    """Check the macOS ``sysctl`` probe, its platform guard, and every fallback path.

    The cookbooks print this string in their Host cell before any measurement runs, so a raised exception here aborts
    the whole notebook on the first cell that matters. ``sysctl`` exists only on Darwin, and ``check=False`` does not
    suppress the ``FileNotFoundError`` raised when the binary is absent from ``PATH`` — the guard and the ``OSError``
    handler are what keep the x86/ARM Linux and Windows hosts these notebooks claim to support from crashing.
    """

    def test_returns_stripped_brand_string_on_macos(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """On Darwin the probe runs and its trailing newline is stripped from the reported brand.

        This is the only path that yields a real answer; ``sysctl -n`` always terminates its output with a newline,
        which would otherwise land mid-line in the Host cell's printed summary.
        """
        run = Mock(return_value=SimpleNamespace(stdout="Apple M4 Max\n"))
        monkeypatch.setattr("rfdetr.export._benchmark.platform.system", Mock(return_value="Darwin"))
        monkeypatch.setattr("rfdetr.export._benchmark.subprocess.run", run)

        assert cpu_brand() == "Apple M4 Max"

    def test_skips_the_probe_entirely_on_hosts_without_a_known_source(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """A Windows host returns the fallback without ever invoking ``sysctl``.

        Guarding before the call — rather than relying on the ``OSError`` handler — keeps the common non-macOS case free
        of a doomed subprocess spawn, and is what makes the behaviour deterministic on a host that happens to ship an
        unrelated ``sysctl``.
        """
        run = Mock()
        monkeypatch.setattr("rfdetr.export._benchmark.platform.system", Mock(return_value="Windows"))
        monkeypatch.setattr("rfdetr.export._benchmark.subprocess.run", run)

        assert cpu_brand() == "unknown CPU brand"
        run.assert_not_called()

    def test_reads_the_first_model_name_from_proc_cpuinfo_on_linux(
        self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path
    ) -> None:
        """A Linux host reports the first ``model name`` line of ``/proc/cpuinfo`` without running ``sysctl``."""
        cpuinfo = "processor\t: 0\nmodel name\t: Intel(R) Xeon(R) CPU @ 2.20GHz\nmodel name\t: other\n"
        run = Mock()
        monkeypatch.setattr("rfdetr.export._benchmark.platform.system", Mock(return_value="Linux"))
        monkeypatch.setattr("rfdetr.export._benchmark.subprocess.run", run)
        monkeypatch.setattr("rfdetr.export._benchmark.Path.read_text", Mock(return_value=cpuinfo))

        assert cpu_brand() == "Intel(R) Xeon(R) CPU @ 2.20GHz"
        run.assert_not_called()

    def test_falls_back_when_proc_cpuinfo_has_no_model_name(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """An ARM Linux host lists no ``model name`` and reports the fallback."""
        monkeypatch.setattr("rfdetr.export._benchmark.platform.system", Mock(return_value="Linux"))
        monkeypatch.setattr("rfdetr.export._benchmark.Path.read_text", Mock(return_value="processor\t: 0\n"))

        assert cpu_brand() == "unknown CPU brand"

    def test_falls_back_when_proc_cpuinfo_cannot_be_read(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """An unreadable ``/proc/cpuinfo`` reports the fallback instead of raising."""
        monkeypatch.setattr("rfdetr.export._benchmark.platform.system", Mock(return_value="Linux"))
        monkeypatch.setattr("rfdetr.export._benchmark.Path.read_text", Mock(side_effect=OSError("denied")))

        assert cpu_brand() == "unknown CPU brand"

    def test_falls_back_when_the_sysctl_binary_is_missing(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """A missing ``sysctl`` raises ``FileNotFoundError`` through ``check=False`` and is absorbed.

        Regression guard for the original notebook cells: ``check=False`` only suppresses a non-zero
        exit status, never the failure to spawn at all, so a Darwin host with a trimmed ``PATH``
        crashed the Host cell outright.
        """
        monkeypatch.setattr("rfdetr.export._benchmark.platform.system", Mock(return_value="Darwin"))
        monkeypatch.setattr("rfdetr.export._benchmark.subprocess.run", Mock(side_effect=FileNotFoundError("sysctl")))

        assert cpu_brand() == "unknown CPU brand"

    def test_falls_back_when_the_probe_returns_no_output(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """An empty ``stdout`` reports the fallback rather than a blank brand string.

        ``sysctl -n`` on an unknown key exits non-zero with nothing on stdout; ``check=False`` lets that through as an
        empty string, which would print as an empty pair of parentheses.
        """
        monkeypatch.setattr("rfdetr.export._benchmark.platform.system", Mock(return_value="Darwin"))
        monkeypatch.setattr("rfdetr.export._benchmark.subprocess.run", Mock(return_value=SimpleNamespace(stdout="")))

        assert cpu_brand() == "unknown CPU brand"


class TestVisualizeDetections:
    """Check detection annotation, label sourcing, and optional saving."""

    @pytest.fixture
    def image(self) -> Image.Image:
        """A small solid-color RGB image to annotate."""
        return Image.new("RGB", (64, 48), color=(10, 20, 30))

    @pytest.fixture
    def detections(self) -> sv.Detections:
        """One detection with confidence and class_id set, no ``class_name`` metadata."""
        return sv.Detections(
            xyxy=np.array([[5.0, 5.0, 30.0, 30.0]], dtype=np.float32),
            confidence=np.array([0.9]),
            class_id=np.array([1]),
        )

    def test_annotates_and_displays_valid_detections(
        self, monkeypatch: pytest.MonkeyPatch, image: Image.Image, detections: sv.Detections
    ) -> None:
        """Annotating and displaying valid detections completes without raising."""
        monkeypatch.setattr("rfdetr.export._benchmark.sv.plot_image", Mock())

        visualize_detections(detections, image)

    def test_falls_back_to_coco_classes_for_label_text(
        self, monkeypatch: pytest.MonkeyPatch, image: Image.Image, detections: sv.Detections
    ) -> None:
        """Detections with no ``class_name`` metadata get their label text from ``COCO_CLASSES``."""
        plot_image = Mock()
        monkeypatch.setattr("rfdetr.export._benchmark.sv.plot_image", plot_image)
        label_annotator = Mock(wraps=sv.LabelAnnotator(text_scale=0.6, text_thickness=1, text_padding=4).annotate)
        monkeypatch.setattr(sv.LabelAnnotator, "annotate", lambda self, **kwargs: label_annotator(**kwargs))

        visualize_detections(detections, image)

        expected_label = f"{COCO_CLASSES[1]} 0.90"
        assert label_annotator.call_args.kwargs["labels"] == [expected_label]
        plot_image.assert_called_once()

    @pytest.mark.parametrize("missing", ["class_id", "confidence"])
    def test_missing_labelling_array_raises(self, missing: str, image: Image.Image) -> None:
        """Detections without a ``class_id`` or ``confidence`` array cannot be labeled, so the call is rejected up
        front."""
        arrays = {"confidence": np.array([0.9]), "class_id": np.array([1])}
        del arrays[missing]
        detections = sv.Detections(xyxy=np.array([[5.0, 5.0, 30.0, 30.0]], dtype=np.float32), **arrays)

        with pytest.raises(ValueError) as exc_info:
            visualize_detections(detections, image)

        assert "class_id and detections.confidence" in str(exc_info.value)

    def test_saves_annotated_image_when_save_path_given(
        self,
        monkeypatch: pytest.MonkeyPatch,
        image: Image.Image,
        detections: sv.Detections,
        tmp_path: Path,
        capsys: pytest.CaptureFixture[str],
    ) -> None:
        """When ``save_path`` is given, the annotated image is written to disk and the path is announced."""
        monkeypatch.setattr("rfdetr.export._benchmark.sv.plot_image", Mock())
        save_path = tmp_path / "annotated.png"

        visualize_detections(detections, image, save_path=save_path)

        assert save_path.is_file()
        assert str(save_path) in capsys.readouterr().out


class TestParity:
    """Check the raw-output drift summary against a reference runtime."""

    def test_reports_drift_over_confident_queries_only(self) -> None:
        """A drifting low-score query is excluded; only the confident query's drift is reported."""
        ref_logits = np.array([[3.0, -4.0], [-5.0, -6.0]])
        ref_boxes = np.zeros((2, 4))
        logits = ref_logits + np.array([[0.5, 0.5], [9.0, 9.0]])

        summary = parity(ref_boxes, ref_logits, ref_boxes + 0.01, logits)

        assert summary == "max|Δlogit| 0.5000, max|Δbox| 0.01000 over 1 confident queries"

    def test_flattens_leading_batch_axis(self) -> None:
        """A batch-1 ``(1, Q, D)`` input compares like the ``(Q, D)`` one."""
        ref_logits = np.array([[[3.0, -4.0]]])
        ref_boxes = np.zeros((1, 1, 4))

        assert parity(ref_boxes, ref_logits, ref_boxes, ref_logits) == (
            "max|Δlogit| 0.0000, max|Δbox| 0.00000 over 1 confident queries"
        )

    def test_reports_not_measured_when_no_reference_query_is_confident(self) -> None:
        """An empty or low-confidence image gives a readable summary instead of a ``max()`` of an empty array."""
        ref_logits = np.full((1, 3, 2), -9.0)
        ref_boxes = np.zeros((1, 3, 4))

        summary = parity(ref_boxes, ref_logits, ref_boxes, ref_logits)

        assert summary == "no reference query scores above 0.3; drift not measured over 0 confident queries"


class TestBenchmarkRows:
    """Check the row every runtime cookbook builds for its benchmark table."""

    def test_record_reports_images_per_second_for_the_whole_batch(self) -> None:
        """A batch-4 call of 8 ms is 500 images per second, not 125 calls per second.

        Throughput must compare across batch sizes, so the row scales the per-call rate by the batch.
        """
        rows = BenchmarkRows()

        rows.record("ONNX", BenchmarkConfig("CPU EP", "fp32"), 4, BenchmarkResult("call", 8.0, 0.5), 10.0)

        assert rows[0]["FPS [img/s]"] == pytest.approx(500.0)

    def test_record_keeps_the_config_columns_and_the_size(self) -> None:
        """The runtime, precision and quantization of the config become their own columns next to the size."""
        rows = BenchmarkRows()
        config = BenchmarkConfig("CPU", "INT8", "static NNCF")

        rows.record("OpenVINO", config, 1, BenchmarkResult("call", 2.0, 0.1), 3.0, 41.5)

        row = rows[0]
        actual = (row["Runtime"], row["Precision"], row["Quantization"], row["Size [MB]"])
        expected = ("CPU", "INT8", "static NNCF", 41.5)
        assert actual == expected

    def test_record_leaves_the_size_empty_without_an_artifact(self) -> None:
        """A row measured without an exported artifact has no size."""
        rows = BenchmarkRows()

        rows.record("PyTorch", BenchmarkConfig("eager", "fp32"), 1, BenchmarkResult("call", 2.0, 0.1), 3.0)

        assert rows[0]["Size [MB]"] is None


class TestImPredict:
    """Check the ``inference-models`` call every GPU, CPU and Apple cookbook shares."""

    def test_converts_every_prediction_with_the_threshold_and_rgb_order(self) -> None:
        """Each frame's prediction becomes ``sv.Detections``, and the model gets the threshold and the RGB order.

        The cookbooks pass RGB arrays, so a model left at its BGR default would score every row on swapped channels.
        """
        model = Mock(
            return_value=[Mock(to_supervision=Mock(return_value="a")), Mock(to_supervision=Mock(return_value="b"))]
        )
        frames = [np.zeros((2, 2, 3)), np.zeros((2, 2, 3))]

        detections = im_predict(model, frames, 0.4)

        assert detections == ["a", "b"]
        model.assert_called_once_with(frames, confidence=0.4, input_color_format="rgb")


class TestTimeFolder:
    """Check the folder throughput measurement the export cookbooks share."""

    def test_reports_the_median_pass(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Three passes of 1, 2 and 4 seconds report the 2-second pass: 8 images in 2 seconds is 4 images per second."""
        clock = Mock(side_effect=[0.0, 1.0, 10.0, 12.0, 20.0, 24.0])
        monkeypatch.setattr("rfdetr.export._benchmark.time.perf_counter", clock)
        predictor = Mock(predict=Mock(return_value=[None] * 8))

        img_s = time_folder(predictor, Path("images"), 8, 3)

        assert img_s == pytest.approx(4.0)

    def test_runs_one_warm_up_pass_besides_the_timed_ones(self) -> None:
        """Two timed passes make three ``predict`` calls, because the first pass only warms the predictor up."""
        predictor = Mock(predict=Mock(return_value=[None] * 2))

        time_folder(predictor, Path("images"), 2, 2)

        assert predictor.predict.call_count == 3

    def test_passes_the_folder_and_the_keywords_to_predict(self) -> None:
        """``predict`` gets the folder as a string with the caller's keywords."""
        predictor = Mock(predict=Mock(return_value=[None] * 2))

        time_folder(predictor, Path("images"), 2, 1, threshold=0.3, include_source_image=False)

        predictor.predict.assert_called_with("images", threshold=0.3, include_source_image=False)

    def test_rejects_a_pass_with_the_wrong_number_of_results(self) -> None:
        """A folder that gives 3 results where 4 images are expected means a predictor skipped files, so it stops."""
        predictor = Mock(predict=Mock(return_value=[None] * 3))

        with pytest.raises(ValueError, match="expected 4"):
            time_folder(predictor, Path("images"), 4, 1)


class TestExportCached:
    """Check the artifact cache the accuracy and latency cookbooks share."""

    def test_exports_into_the_directory_when_it_holds_no_artifact(self, tmp_path: Path) -> None:
        """An empty cache directory runs the export once with the caller's keywords and returns its artifact."""
        artifact = tmp_path / "onnx" / "model.onnx"
        model = Mock(export=Mock(return_value=artifact))

        result = export_cached(model, tmp_path / "onnx", "*.onnx", format="onnx", batch_size=1)

        assert result == artifact
        model.export.assert_called_once_with(output_dir=str(tmp_path / "onnx"), format="onnx", batch_size=1)

    def test_reuses_the_artifact_that_is_already_cached(self, tmp_path: Path) -> None:
        """A directory that already holds the artifact returns it without exporting again."""
        cached = tmp_path / "trt" / "model.trt"
        cached.parent.mkdir()
        cached.touch()
        model = Mock()

        result = export_cached(model, tmp_path / "trt", "*.trt")

        assert result == cached
        model.export.assert_not_called()

    def test_rejects_a_directory_with_two_matches(self, tmp_path: Path) -> None:
        """Two matching artifacts leave no way to tell which configuration is cached, so the call stops."""
        for name in ("a.trt", "b.trt"):
            (tmp_path / name).touch()

        with pytest.raises(ValueError, match="Ambiguous artifact cache"):
            export_cached(Mock(), tmp_path, "*.trt")

    def test_rejects_an_export_that_does_not_match_the_pattern(self, tmp_path: Path) -> None:
        """An INT8 pattern must not accept the FP16 file the export wrote, so the precision cannot be mixed up."""
        model = Mock(export=Mock(return_value=tmp_path / "model.trt"))

        with pytest.raises(ValueError, match="does not match"):
            export_cached(model, tmp_path, "*_int8.trt")


class TestLatencyCookbook:
    """Check the latency notebook's cache and result identity against real input changes."""

    @staticmethod
    def _cell(cell_id: str) -> str:
        """Read the code of a named notebook cell."""
        notebook = Path(__file__).resolve().parents[2] / "docs/cookbooks/measure-latency.ipynb"
        cells = json.loads(notebook.read_text())["cells"]
        return "".join(next(cell for cell in cells if cell.get("id") == cell_id)["source"])

    def test_cache_signature_changes_with_calibration_and_weights(self, tmp_path: Path) -> None:
        """Changing calibration pixels or model weights cannot reuse an old cache key."""
        package = tmp_path / "package"
        package.mkdir()
        source = package / "__init__.py"
        source.write_text("value = 1")
        calibration = tmp_path / "calibration"
        calibration.mkdir()
        image = calibration / "sample.jpg"
        image.write_bytes(b"first")
        module = torch.nn.Linear(2, 1)
        model = SimpleNamespace(model=SimpleNamespace(model=module))
        package_module = SimpleNamespace(__file__=str(source))
        scope = {
            "RFDETR": object,
            "hashlib": hashlib,
            "json": json,
            "Path": Path,
            "torch": torch,
            "rfdetr": package_module,
            "rfdetr_plus": package_module,
            "provenance": {"torch_version": "test"},
            "NUM_CALIB": 1,
            "NUM_WARMUP": 50,
            "CALIBRATION_DIR": calibration,
            "EXPORTS": {"onnx": ("*.onnx", {})},
        }
        tree = ast.parse(self._cell("6d35247d"))
        definition = next(node for node in tree.body if isinstance(node, ast.FunctionDef))
        exec(compile(ast.Module(body=[definition], type_ignores=[]), "latency notebook", "exec"), scope)
        fingerprint = scope["artifact_signature"]
        before = fingerprint(model)
        image.write_bytes(b"second")
        after_calibration = fingerprint(model)
        module.weight.data.add_(1)

        assert before != after_calibration
        assert after_calibration != fingerprint(model)

    def test_resume_identity_changes_with_runtime_version(self) -> None:
        """A runtime upgrade cannot reuse a measurement attributed to an older version."""
        scope = {"Any": Any, "provenance": {"torch_version": "old"}}
        exec(self._cell("2661e6d5"), scope)
        key = scope["resume_key"]
        row = {"model": "m", "config": "c", "artifact_signature": "a", "torch_version": "old"}
        assert key(row) != key({**row, "torch_version": "new"})

    def test_graph_configuration_keeps_precision(self) -> None:
        """Graph replay retains the underlying TensorRT precision in the output table."""
        import pandas as pd

        scope = {"current": pd.DataFrame({"config": ["tensorrt-fp16-graph", "onnx-int8"]})}
        exec(self._cell("e850c981"), scope)
        assert scope["current"]["precision"].tolist() == ["fp16", "int8"]
        assert scope["current"]["engine"].tolist() == ["tensorrt-graph", "onnx"]
