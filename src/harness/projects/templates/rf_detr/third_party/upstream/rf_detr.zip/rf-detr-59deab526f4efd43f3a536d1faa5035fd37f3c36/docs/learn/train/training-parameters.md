---
description: Complete RF-DETR training parameter reference. Learning rate, batch size, EMA, early stopping, resolution, and hardware configuration.
---

# Training Parameters

This page provides a complete reference of all parameters available when training RF-DETR models.

## Basic Example

```python
from rfdetr import RFDETRMedium

model = RFDETRMedium()

model.train(
    dataset_dir="path/to/dataset",
    epochs=100,
    batch_size="auto",
    lr=1e-4,
    output_dir="output",
)
```

`batch_size="auto"` requires a CUDA-capable GPU because it probes CUDA memory. For CPU or MPS training, provide a concrete integer batch size and use `grad_accum_steps` if memory limits the physical batch.

## Core Parameters

These are the essential parameters for training:

| Parameter                          | Type            | Default    | Description                                                                                                                                                                                                                                                            |
| ---------------------------------- | --------------- | ---------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `dataset_dir`                      | `str`           | Required   | Path to your dataset directory. RF-DETR auto-detects if it's in COCO or YOLO format. See [Dataset Formats](dataset-formats.md).                                                                                                                                        |
| `output_dir`                       | `str`           | `"output"` | Directory where training artifacts (checkpoints, logs) are saved.                                                                                                                                                                                                      |
| `epochs`                           | `int`           | `100`      | Number of full passes over the training dataset. Must be at least 1.                                                                                                                                                                                                   |
| `batch_size`                       | `int or "auto"` | `4`        | Number of samples processed per iteration. Higher values require more GPU memory. Set to `"auto"` to probe the GPU for the largest safe batch size automatically.                                                                                                      |
| `grad_accum_steps`                 | `int`           | `1`        | Accumulates gradients over several mini-batches before each optimizer step. Opt-in: raise it only when memory caps `batch_size` below the nominal effective-batch target you want.                                                                                     |
| `eval_batch_size`                  | `int or None`   | `None`     | Batch size for the validation, test and predict dataloaders. `None` inherits `batch_size`. `no_grad` avoids autograd activation storage, but in-fit evaluation still shares device memory with the model and optimizer state and needs memory for its forward outputs. |
| `auto_batch_target_effective`      | `int`           | `16`       | Only used when `batch_size="auto"`. Global nominal effective-batch target; the probe derives a per-device target before scaling by `devices * num_nodes`.                                                                                                              |
| `auto_batch_max_targets_per_image` | `int`           | `100`      | Only used when `batch_size="auto"`. Synthetic target count per image the probe uses to simulate worst-case matcher/loss memory.                                                                                                                                        |
| `auto_batch_ema_headroom`          | `float`         | `0.7`      | Only used when `batch_size="auto"` and `use_ema=True`. Fraction of the probed batch size reserved as headroom for the EMA model's extra memory use. Must be in `(0, 1]`.                                                                                               |
| `resume`                           | `str`           | `None`     | Path to a saved checkpoint to continue training. Full `.ckpt` files restore model, optimizer, and scheduler state; lightweight best `.pth` files restart optimizer and scheduler state.                                                                                |

### Understanding Batch Size

The **nominal effective batch size** is calculated as:

```
effective_batch_size = batch_size × grad_accum_steps × num_gpus
```

**Set `batch_size` first, `grad_accum_steps` second.** Raise `batch_size` only as far as the selected model, task, resolution, and GPU allow, and leave `grad_accum_steps` at its default of `1` when possible. If hardware memory prevents the physical batch from reaching your nominal target, increase `grad_accum_steps` to recover that target's optimizer-step window. This is not an optimization-equivalent substitute: it splits the window across smaller forward/backward passes, changes microbatch cadence, and a small physical batch tends to leave the GPU under-occupied. On one L4 training `rfdetr-small`, `batch_size=16, grad_accum_steps=1` ran about 27% faster per epoch than `batch_size=4, grad_accum_steps=4` at the same nominal effective batch of 16, with mAP equal within run-to-run noise. That figure is one GPU and one dataset, so treat the direction as the lesson, not the number.

When you trade between the two, use the product `batch_size × grad_accum_steps` as a nominal effective-batch target. Keeping that product constant does not guarantee identical optimization behavior: changing `batch_size` changes the forward/backward microbatch cadence even when the nominal images-per-optimizer-update target is unchanged. Start with `batch_size="auto"` on CUDA when the available memory or workload is uncertain; on CPU or MPS, choose a conservative integer batch size instead.

Configurations reaching a nominal effective batch size of 16 on illustrative hardware:

| GPU      | VRAM    | `batch_size` | `grad_accum_steps` |
| -------- | ------- | ------------ | ------------------ |
| A100     | 40-80GB | 16           | 1                  |
| RTX 4090 | 24GB    | 8            | 2                  |
| RTX 3090 | 24GB    | 8            | 2                  |
| T4       | 16GB    | 4            | 4                  |
| RTX 3070 | 8GB     | 2            | 8                  |

These are illustrative starting configurations from the documented model/workload setup, not capacity guarantees. Actual safe values depend on the model, task, resolution, augmentations, optimizer state, and other workloads on the device. Use `batch_size="auto"` on CUDA or validate a conservative integer batch size before increasing it.

!!! note "The default nominal effective batch is 4, not 16"

    `grad_accum_steps` defaults to `1` (it was `4` in earlier versions), so the defaults give a nominal effective batch of `batch_size × 1 = 4`. If you were relying on the old defaults and want the previous nominal target of 16, set `grad_accum_steps=4` explicitly, then validate the resulting training behavior. Runs using `batch_size="auto"` are unaffected by this default change: the probe sets both values itself.

## Learning Rate Parameters

| Parameter          | Type              | Default   | Description                                                                                                                                                                                                                                                                                                                                                                                                         |
| ------------------ | ----------------- | --------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `lr`               | `float`           | `1e-4`    | Learning rate for most parts of the model.                                                                                                                                                                                                                                                                                                                                                                          |
| `lr_encoder`       | `float`           | `1.5e-4`  | Learning rate specifically for the backbone encoder. Can be set lower than `lr` if you want to fine-tune the encoder more conservatively than the rest of the model.                                                                                                                                                                                                                                                |
| `optimizer`        | `str \| Callable` | `"adamw"` | Optimizer as a native `torch.optim` short name, dotted import path, or callable. Managed short names (native `torch.optim` only, e.g. `"adamw"`, `"sgd"`) have RF-DETR inject `lr`/`weight_decay`; a dotted import path (`"torch.optim.AdamW"`, `"pytorch_optimizer.Lion"`) or callable is built from `optimizer_kwargs` / its own bound arguments only. See [Custom optimizer](customization.md#custom-optimizer). |
| `optimizer_kwargs` | `dict`            | `{}`      | Keyword arguments for the optimizer constructor. Managed short names reserve `params`/`lr`/`weight_decay`/`fused`; explicit import paths take them here; ignored (with a warning) for callables.                                                                                                                                                                                                                    |

!!! tip "Learning rate tips"

    - Start with the default values for fine-tuning
    - If the model doesn't converge, try reducing `lr` by half
    - For training from scratch (not recommended), you may need higher learning rates

### Custom Optimizer Example

```python
model.train(
    dataset_dir="path/to/dataset",
    optimizer="pytorch_optimizer.Lion",  # third-party optimizer by import path (install it yourself)
    optimizer_kwargs={"weight_decouple": True},
)
```

Bare short names resolve to native `torch.optim` optimizers; any other optimizer is given by full dotted import path or a callable, always preserving RF-DETR's parameter groups and layer-wise learning rates.

## Resolution Parameters

| Parameter    | Type  | Default         | Description                                                                                                                                                                                                                                                                                                                                                                                                   |
| ------------ | ----- | --------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `resolution` | `int` | Model-dependent | Input image resolution. Higher values can improve accuracy but require more memory. Each model has its own valid block size: current standard detection checkpoints use multiples of 32, current segmentation checkpoints use multiples of 24 (most variants) or 12 (`RFDETRSegNano`), and the definitive rule is that the resolution must be divisible by `patch_size * num_windows` for the selected model. |

Common resolution values for currently documented checkpoints:

- Detection: `384`, `512`, `576`, `704`
- Segmentation: `312`, `384`, `432`, `504`, `624`, `768`

For example, `RFDETRSegXLarge` uses `624x624`, which is valid because `624` is divisible by `24`.

## Regularization Parameters

| Parameter      | Type    | Default | Description                                                                           |
| -------------- | ------- | ------- | ------------------------------------------------------------------------------------- |
| `weight_decay` | `float` | `1e-4`  | L2 regularization coefficient. Helps prevent overfitting by penalizing large weights. |

## Hardware Parameters

| Parameter                | Type   | Default | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |
| ------------------------ | ------ | ------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `device`                 | `str`  | `None`  | Device to run training on. `None` means auto-detected by PyTorch Lightning. Options: `"cuda"`, `"cpu"`, `"mps"` (Apple Silicon).                                                                                                                                                                                                                                                                                                                                                                                                             |
| `compile`                | `bool` | `False` | **Constructor-only parameter.** Compile the detector with `torch.compile`.                                                                                                                                                                                                                                                                                                                                                                                                                                                                   |
| `cuda_graphs`            | `bool` | `False` | **Constructor-only parameter.** Capture and replay the detection training forward on one CUDA GPU with BF16 precision. Each input shape pays a first-use capture cost and retains graph memory. Unsupported configurations use eager training with a warning. Combined with `compile=True`, replay is delegated to Inductor CUDA graph trees (single-GPU detection, no gradient accumulation); capture errors stop training and require a process restart before retrying eagerly. See [Advanced Training](advanced.md#cuda-graph-training). |
| `gradient_checkpointing` | `bool` | `False` | **Constructor-only parameter** — pass to the model constructor (`RFDETRMedium(gradient_checkpointing=True)`), not to `train()`. Re-computes activations during backprop to reduce memory usage by ~30-40% at the cost of ~20% slower training.                                                                                                                                                                                                                                                                                               |

### Training precision

`amp_dtype` accepts `None`, `"auto"`, `"bf16"`, `"fp16"`, or `"fp8"`, and is the single setting controlling mixed precision. Pass `amp_dtype=None` to train in full FP32. The default `"auto"` picks BF16 on NVIDIA GPUs with native BF16 (Ampere and newer) and FP16 on older ones such as the T4 and V100, where BF16 is only emulated (on a T4, RF-DETR Nano trained about 2x slower in emulated BF16 than in FP16). An explicit `"bf16"` is still honoured on those GPUs, with a warning. FP8 selects Lightning's Transformer Engine precision plugin, which replaces eligible linear and layer-normalization layers while retaining BF16 weights. FP8 requires a Transformer Engine-supported NVIDIA GPU; it is rejected for CPU, MPS, TPU/XLA, FSDP, and DeepSpeed. Use DDP for multi-GPU FP8 training. Hardware support and speedups vary, so benchmark the exact model and GPU before adopting it.

The constructor-only `amp` boolean is deprecated: it is consulted only when `amp_dtype` has its default value `"auto"`, and any non-default `amp_dtype` overrides it. Replace `amp=False` with `amp_dtype=None`.

FP8 requires an explicit integer `batch_size`. Automatic batch sizing probes an unconverted model and is rejected with `amp_dtype="fp8"`; BF16/FP16 retain automatic sizing.

See [Advanced Training — FP8 on NVIDIA CUDA](advanced.md#fp8-training-on-nvidia-cuda) for the `cuda` extra, CUDA-version compatibility, an environment check, and troubleshooting. The extra does not enable FP8 automatically and does not support Apple MPS.

## EMA (Exponential Moving Average)

| Parameter         | Type    | Default | Description                                                                                                                                                                                                                                                                                          |
| ----------------- | ------- | ------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `use_ema`         | `bool`  | `True`  | Enables Exponential Moving Average of weights. Produces a smoothed checkpoint that often improves final performance. See `ema_decay` for the averaging coefficient.                                                                                                                                  |
| `ema_decay`       | `float` | `0.993` | Base EMA decay coefficient; the effective coefficient warms up according to `ema_tau`. Must be in `[0, 1]`. Only used when `use_ema=True`.                                                                                                                                                           |
| `ema_tau`         | `int`   | `100`   | Warm-up time constant in EMA updates. Set to 0 or less to use `ema_decay` directly. Only used when `use_ema=True`.                                                                                                                                                                                   |
| `eval_base_model` | `bool`  | `False` | Validation-only: also evaluate the base model. Validation forwards through one model by default — the EMA weights when `use_ema=True` — instead of two, removing a full model forward pass from every validation batch. Set to `True` to restore the base+EMA comparison. See Evaluation Parameters. |
| `eval_ema_only`   | `bool`  | `False` | **Deprecated (removal in v1.13)** — explicit legacy `True` preserves EMA-only evaluation and explicit legacy `False` preserves base-plus-EMA evaluation; either emits a `FutureWarning`. Omit it in new configs; use `eval_base_model=True` to request the base-model pass.                          |

The first EMA update copies the model weights. For subsequent EMA updates, the effective decay is `ema_decay * (1 - exp(-updates / ema_tau))` when `ema_tau > 0`, where `updates` counts EMA updates including that first copy. The update is `effective_decay * ema + (1 - effective_decay) * weight`. When `ema_tau <= 0`, the effective decay is `ema_decay`. EMA updates occur every `ema_update_interval` optimizer steps, which defaults to 1.

!!! info "What is EMA?"

    EMA maintains a moving average of the model weights throughout training. This smoothed version often generalizes better than the raw weights and is commonly used for the final model.

## Checkpoint Parameters

| Parameter             | Type  | Default | Description                                                                                                                            |
| --------------------- | ----- | ------- | -------------------------------------------------------------------------------------------------------------------------------------- |
| `checkpoint_interval` | `int` | `10`    | Frequency (in epochs) at which model checkpoints are saved. More frequent saves provide better coverage but consume more storage.      |
| `skip_best_epochs`    | `int` | `0`     | Ignore the first N epochs when tracking best checkpoints and early-stopping patience. Useful when fine-tuning from a prior checkpoint. |

### Checkpoint Files

During training, multiple checkpoints are saved:

| File                          | Description                                                  |
| ----------------------------- | ------------------------------------------------------------ |
| `last.ckpt`                   | Most recent full checkpoint (for resuming)                   |
| `checkpoint_<epoch>.ckpt`     | Periodic full checkpoint at an epoch                         |
| `checkpoint_best_ema.pth`     | Best EMA weights; lightweight callback state when available  |
| `checkpoint_best_regular.pth` | Best raw weights; lightweight callback state when available  |
| `checkpoint_best_total.pth`   | Final best model; lightweight callback state when available  |
| `last_ema.pth`                | Final EMA weights; lightweight callback state when available |

Best validation performance uses the task metric for the model family (`best_model_metric="map"`, the default): box mAP for detection, mask mAP for segmentation, and COCO keypoint AP for keypoint models. Set `best_model_metric="mar"` to rank checkpoints by mAR instead: detection and segmentation use box mAR, while keypoint models use keypoint mAR. mAR for detection and segmentation is evaluated using the configured `eval_max_dets` limit; keypoint mAR uses fixed COCO `maxDets=20`.

## Early Stopping Parameters

| Parameter                  | Type                   | Default | Description                                                                              |
| -------------------------- | ---------------------- | ------- | ---------------------------------------------------------------------------------------- |
| `early_stopping`           | `bool`                 | `False` | Enable early stopping based on the validation task metric.                               |
| `early_stopping_patience`  | `int`                  | `10`    | Number of epochs without improvement before stopping.                                    |
| `early_stopping_min_delta` | `float`                | `0.001` | Minimum metric change to qualify as an improvement.                                      |
| `early_stopping_use_ema`   | `bool`                 | `False` | Whether to track improvements using EMA model metrics.                                   |
| `best_model_metric`        | `Literal["map","mar"]` | `"map"` | Metric family for best-checkpoint selection and early stopping — mAP or mAR.             |
| `skip_best_epochs`         | `int`                  | `0`     | Ignore the first N epochs (0..N-1) for best-model selection and early-stopping patience. |

### Early Stopping Example

```python
model.train(
    dataset_dir="path/to/dataset",
    epochs=200,
    batch_size=4,
    early_stopping=True,
    early_stopping_patience=15,
    early_stopping_min_delta=0.005,
    skip_best_epochs=3,
)
```

This configuration will:

- Train for up to 200 epochs
- Ignore epochs 0-2 for best-checkpoint tracking and patience counting
- Stop early if the validation metric doesn't improve by at least 0.005 for 15 consecutive epochs

!!! note "Transfer learning with `pretrain_weights`"

    When fine-tuning from `pretrain_weights`, the pretrained model's epoch-0 validation metric can be artificially high relative to the training trajectory on the new dataset. This causes `checkpoint_best_total.pth` to always contain the untrained pretrained weights and may trigger early stopping prematurely. Use `skip_best_epochs` to defer best-checkpoint selection and patience counting until the model has had time to adapt.

## Logging Parameters

| Parameter     | Type   | Default | Description                                                                                                                                                                                                 |
| ------------- | ------ | ------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `tensorboard` | `bool` | `True`  | Enable TensorBoard logging. Requires `pip install "rfdetr[loggers]"`. If the `tensorboard` package is not installed, training continues with a `UserWarning` and TensorBoard output is silently suppressed. |
| `wandb`       | `bool` | `False` | Enable Weights & Biases logging. Requires `pip install "rfdetr[loggers]"`.                                                                                                                                  |
| `project`     | `str`  | `None`  | Project name for W&B logging.                                                                                                                                                                               |
| `run`         | `str`  | `None`  | Run name for W&B logging. If not specified, W&B assigns a random name.                                                                                                                                      |

### Logging Example

```python
model.train(
    dataset_dir="path/to/dataset",
    epochs=100,
    tensorboard=True,
    wandb=True,
    project="my-detection-project",
    run="experiment-001",
)
```

## Evaluation Parameters

| Parameter                    | Type                                                                           | Default     | Description                                                                                                                                                                                                                                                                                                                                                                                                                                   |
| ---------------------------- | ------------------------------------------------------------------------------ | ----------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `eval_max_dets`              | `int`                                                                          | `500`       | Maximum detections per image for detection/segmentation COCO AP and AR evaluation. Keypoint AP/AR uses fixed COCO `maxDets=20`; lower values speed up detection/segmentation evaluation.                                                                                                                                                                                                                                                      |
| `eval_interval`              | `int`                                                                          | `1`         | Skip the whole COCO validation loop (forward pass, metric compute, EMA forward) on epochs that aren't a multiple of N, to reduce evaluation overhead during long training runs. The final epoch always validates regardless of this setting.                                                                                                                                                                                                  |
| `log_per_class_metrics`      | `bool`                                                                         | `False`     | Log per-class AP metrics to the console and loggers. Enable it to also run the underlying per-class `torchmetrics` computation. Aggregate mAP/mAR and F1 metrics remain available either way.                                                                                                                                                                                                                                                 |
| `eval_backend`               | `Literal["hotcoco","hotcoco_streaming","faster_coco_eval","ufcoco","vernier"]` | `"vernier"` | COCO evaluation backend for detection and segmentation mAP. All of them ship with `rfdetr[train]` and return identical metrics; `"vernier"` additionally requires a box on every annotation, so it cannot evaluate a mask-only run. `"faster_coco_eval"` selects the previous, slower evaluator, `"ufcoco"` selects ultrafast-pycocotools and `"hotcoco"` selects hotcoco; `"hotcoco_streaming"` matches each validation batch as it arrives. |
| `eval_base_model`            | `bool`                                                                         | `False`     | Also evaluate the base model during validation, restoring the base+EMA two-forward comparison. Inert when `use_ema=False`. See [EMA](#ema-exponential-moving-average).                                                                                                                                                                                                                                                                        |
| `eval_ema_only`              | `bool`                                                                         | `False`     | **Deprecated (removal in v1.13)** — legacy compatibility field. Explicit values preserve the old `True`/`False` policies and emit a `FutureWarning`; omit it in new configurations. Use `eval_base_model` for the current opt-in.                                                                                                                                                                                                             |
| `eval_masks_head_resolution` | `bool`                                                                         | `False`     | Segmentation only. Skip upsampling predicted masks to full image resolution during validation, comparing at the mask head's native (lower) resolution instead. `val/segm_mAP` is then not comparable to a full-resolution run. No effect on `RFDETR.predict` output.                                                                                                                                                                          |
| `progress_bar`               | str \| bool \| None                                                            | `None`      | Progress bar style: `"tqdm"`, `"rich"`, or `None`. Legacy booleans are still accepted. `"rich"` leaves each completed epoch's bar in the terminal history instead of overwriting it.                                                                                                                                                                                                                                                          |

### Validation performance

- `log_per_class_metrics=False` is the default. It retains aggregate mAP/mAR and F1/precision/recall while omitting per-class rows and their underlying per-class metric computation. Set it to `True` when per-class reporting is needed.
- `compute_val_loss="auto"` is the default. It computes `val/loss` only when a configured scheduler, checkpoint, or early-stopping callback monitors that key. Set it to `True` to always log validation loss or `False` to disable it; `False` is rejected when a configured consumer monitors `val/loss`. When computed, `val/loss` describes whichever model validation forwards through — the EMA model under the default `eval_base_model=False`, the base model under `eval_base_model=True`.
- `eval_base_model=False` is the default: validation runs **one** forward pass per batch, through the EMA weights when `use_ema=True` and through the base weights otherwise. This removes a full forward pass over the validation set each epoch. `val/mAP_*` and per-class `val/AP/<class>` report the model that was evaluated — the EMA model under the default — so schedulers, early stopping, checkpoint monitors and dashboards keep receiving a real number; `val/ema_*` and `val/ema_AP/<class>` remain available for explicit EMA monitors. The best-checkpoint "regular" track is disabled in this mode, because it saves base weights that were never scored; `checkpoint_best_ema.pth` is promoted to `checkpoint_best_total.pth` instead.
- `eval_base_model=True` restores the previous behaviour: the base model is evaluated under `val/mAP_*`, the EMA model under `val/ema_*`, and both checkpoint tracks run. It costs one extra forward pass per validation batch.
- `eval_interval` controls validation frequency, not the cost of a validation epoch: non-evaluation epochs skip the complete validation loop, while the final epoch always evaluates.
- Lowering `eval_max_dets` can reduce detection/segmentation evaluation work, but it also changes AP and AR semantics. Keypoint evaluation keeps COCO `maxDets=20`.
- Segmentation validation compares masks at full image resolution, so its cost grows with image size. The metric run-length encodes masks on CUDA when they are there and copies only the encoded runs to host memory; masks on any other device are encoded on the CPU. `eval_masks_head_resolution=True` also skips the upsample to full resolution and is still faster, but `val/segm_mAP` is then not comparable to a full-resolution run. On 500 COCO val2017 images upscaled to about 1920x1440, `RFDETRSegMedium` on an RTX 4090 validates in 19.2 s with it and in 24.7 s without.
- `eval_backend` selects the COCO evaluator. The default `"vernier"` ([vernier](https://github.com/NoeFontana/vernier)) ships with `rfdetr[train]`; `"faster_coco_eval"` restores the previous evaluator. Metrics are identical, not merely close: the parity tests compare every aggregate, per-class and class-ID output of every backend for box-only and box-plus-mask evaluation and require exact equality. The knob changes the cost of `compute()`, not the validation forward pass that usually dominates a validation epoch, so it matters most on large validation sets. `"vernier"` is the one backend that requires a box on every annotation, so it cannot evaluate a mask-only run: an `iou_type` without `"bbox"` is rejected when the metric is constructed rather than at `compute()`, so the run fails immediately instead of after a validation epoch. On a synthetic COCO-val-shaped state (5,000 images, 300 detections per image, 80 classes, box-only) one Linux four-core `compute()` took 3.18 s on `hotcoco` against 1.86 s on `vernier`, a ~1.7x speedup; the macOS-CPU figures below were measured on a different machine and are not directly comparable to these. The margin is wider away from that shape: on the 20-class synthetic configuration `vernier` is 2.1-2.3x `hotcoco` on box-only and 5.9-8.6x on box-plus-mask evaluation, at every core count from one to eight. These are single-process timings; under multi-GPU DDP each rank merges the gathered state and runs the whole `compute()` itself, so the ranks evaluate concurrently and the wall-clock saving per validation epoch may differ. Keypoint evaluation uses its own OKS path and is unaffected, as is the ONNX/TensorRT benchmark evaluator.
- `eval_backend="hotcoco"` selects [hotcoco](https://github.com/derekallman/hotcoco), a Rust COCO evaluator. On synthetic COCO-val-shaped state (5,000 images, 36.6k ground-truth boxes, 300 detections per image, 80 classes, `eval_max_dets=500`) one macOS-CPU `compute()` took 6.2 s on `faster_coco_eval` against 1.1 s on `hotcoco`. It ships with `rfdetr[train]` like the other backends.
- `eval_backend="ufcoco"` selects [ultrafast-pycocotools](https://github.com/developer0hye/ultrafast-pycocotools), a Rust evaluator that reproduces pycocotools' precision, recall and score arrays byte for byte. It ships with `rfdetr[train]` like the other backends; pass `eval_backend="ufcoco"` to `model.train(...)` or `model.evaluate(...)`. The selection reaches the validation, train-split and EMA metrics alike, and the parity tests hold it to the same exact equality against `faster_coco_eval` as `hotcoco`, for box-only and box-plus-mask evaluation at `eval_max_dets` 100 and 500.
- `eval_backend="hotcoco_streaming"` runs hotcoco's `StreamingEval`: each validation batch is matched in the validation step, and the end of the epoch only accumulates and summarizes. Metrics are bit-identical to `"hotcoco"`. On synthetic data on an Apple M-series CPU, the end-of-epoch step took 0.025 s instead of 0.238 s for 2,000 images with 300 box detections each, but the whole evaluation took 1.05 s instead of 0.29 s because building the per-batch records costs more than the batch path's array load. For a bbox+segm run (200 images, 100 detections each) the end-of-epoch step took 0.005 s instead of 0.178 s and the whole evaluation 0.66 s instead of 0.71 s. Memory: it keeps the stored evaluation state for the fallback and adds the stream's matching state during the epoch, but skips the full COCO dataset build at the end; peak memory has not been measured. Streaming needs the model's `num_classes` and a single process; under DDP, with a label outside `[0, num_classes]`, or after the metric is pickled mid-epoch, it evaluates in one batch exactly as `"hotcoco"` does and logs why.
- Adding a new `eval_backend` or benchmarking an existing one: see [Advanced Training → COCO Evaluation Backends](advanced.md#coco-evaluation-backends).

## Keypoint Preview Parameters

These parameters apply when training `RFDETRKeypointPreview` on COCO keypoint annotations or Ultralytics YOLO pose labels.

| Parameter                     | Type                  | Default | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 |
| ----------------------------- | --------------------- | ------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `num_keypoints_per_class`     | `list[int]`           | `[17]`  | **Constructor parameter** — pass to `RFDETRKeypointPreview(num_keypoints_per_class=...)`. Keypoint schema by model label slot. A zero entry marks a detection-only class slot; legacy checkpoints may use a background-first `[0, 17]` schema.                                                                                                                                                                                                                                                                                                                                              |
| `keypoint_flip_pairs`         | `list[int]`           | `[]`    | Flat left/right keypoint index pairs used to swap joints after horizontal-flip augmentation. YOLO `flip_idx` metadata is a permutation; RF-DETR converts it to this pair-list form during automatic schema inference when possible — it extracts only symmetric mutual pairs where `flip_idx[i] == j` and `flip_idx[j] == i`. Asymmetric entries and self-mapped keypoints (`flip_idx[i] == i`) are silently omitted; supply `keypoint_flip_pairs` explicitly when your `flip_idx` includes such entries. See the note below for what an empty list means for horizontal-flip augmentation. |
| `keypoint_l1_loss_coef`       | `float`               | `1.0`   | Weight for keypoint coordinate L1 loss in keypoint preview training.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        |
| `keypoint_findable_loss_coef` | `float`               | `1.0`   | Weight for keypoint findable/objectness loss.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               |
| `keypoint_visible_loss_coef`  | `float`               | `1.0`   | Weight for keypoint visibility loss.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        |
| `keypoint_nll_loss_coef`      | `float`               | `1.0`   | Weight for keypoint negative-log-likelihood loss.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           |
| `keypoint_oks_sigmas`         | `list[float] \| None` | `None`  | Per-keypoint OKS sigma values used for COCO AP evaluation. When `None`, 17-keypoint person datasets use the evaluator's standard COCO sigmas and custom keypoint counts use RF-DETR's uniform custom fallback. Pass explicit values, such as schema-inferred sigmas, when you need a specific custom OKS policy.                                                                                                                                                                                                                                                                            |

!!! warning "`keypoint_flip_pairs`: `None` vs `[]` vs a populated list"

    This value is tri-state, and the state — not just the value — controls whether horizontal-flip augmentations run at all, on both the default torchvision-native pipeline (`aug_config=None`) and a custom Albumentations `aug_config`:

    - `None` marks a detection-only pipeline. Horizontal-flip augmentations (torchvision's default flip, or `HorizontalFlip`/`Flip`/`D4` in your `aug_config`) are always kept, since there are no keypoint annotations that a flip could invalidate.
    - `[]` on a keypoint pipeline means no flip pairs are defined. RF-DETR then drops horizontal-flip augmentations rather than flip an image without knowing which keypoints to swap — this is intentional annotation-safety behavior, not a bug, but easy to trip over if you set `keypoint_flip_pairs=[]` yourself without expecting the augmentation to disappear.
    - A populated list on a keypoint pipeline supplies the actual left/right index pairs, so horizontal-flip augmentations run and swap the paired keypoints.

    The current pydantic default for `keypoint_flip_pairs` is `[]`, matching the field definition in `src/rfdetr/config.py`. See `_build_torchvision_pipeline` in `src/rfdetr/datasets/coco.py` for the default-backend gating check, and `AlbumentationsWrapper.from_config` in `src/rfdetr/datasets/transforms.py` for the Albumentations-backend equivalent — both use the same `keypoint_flip_pairs is not None and not keypoint_flip_pairs` check.

Keypoint training also accepts `augmentation_backend="kornia"` on CUDA when Kornia is installed. The default remains `"cpu"`; `"gpu"` is an alias for `"kornia"`, and an explicit `"auto"` can select Kornia on CUDA. The GPU pipeline transforms keypoint coordinates with images and boxes, keeps visibility for joints inside the image, zeroes the x, y and visibility of joints outside the image or with visibility \<= 0, and swaps paired joints after a horizontal flip. With an empty `keypoint_flip_pairs`, it disables horizontal flips, as the CPU backends do.

Kornia follows the default torchvision path's continuous keypoint coordinates (`x` flips to `W - x`). The custom Albumentations path currently flips to `W - 1 - x`, so switching from it can move flipped joints by one pixel. The existing detection-only Kornia box path is unchanged; its box convention differs from the keypoint path's continuous frame. Aligning detection-only boxes would change existing training behaviour and is separate from this keypoint option. The libraries can also sample transforms differently, so this option does not promise identical augmentation distributions or a training-speed gain.

!!! note "OKS sigma values: flat vs per-keypoint"

    `infer_coco_keypoint_schema` and `infer_yolo_keypoint_schema` return a flat sigma of 0.1 for all inferred keypoints, and the keypoint demos pass those values explicitly for custom datasets. If `keypoint_oks_sigmas=None`, COCO person-keypoint evaluation uses the standard 17-keypoint COCO sigmas, while non-17 custom keypoint counts use RF-DETR's uniform custom fallback. Flat custom sigmas are not directly comparable to official COCO benchmark numbers.

## Advanced Parameters

The parameters below are available for fine-grained control over training behaviour. Most users can leave these at their defaults.

### Scheduler and Regularization

| Parameter               | Type              | Default      | Description                                                                                                                                                                                                             |
| ----------------------- | ----------------- | ------------ | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `lr_scheduler`          | `str \| Callable` | `"step"`     | Scheduler preset (`"step"`/`"cosine"`), dotted import path, or callable. See [Custom LR scheduler](customization.md#custom-lr-scheduler).                                                                               |
| `lr_scheduler_kwargs`   | `dict`            | `{}`         | Keyword arguments forwarded to an explicit scheduler; for the managed presets carries `lr_drop` (default 100, epoch of the 10x step drop) and `min_factor` (default 0.0, cosine floor as a fraction of the initial LR). |
| `lr_scheduler_interval` | `str`             | `"step"`     | Stepping cadence for explicit schedulers: `"step"` (per optimizer step) or `"epoch"`. Managed presets always step per step.                                                                                             |
| `lr_scheduler_monitor`  | `str`             | `"val/loss"` | Metric fed to `ReduceLROnPlateau` (stepped once per epoch).                                                                                                                                                             |
| `optimizer`             | `str \| Callable` | `"adamw"`    | Optimizer name, dotted import path, or callable. See [Custom optimizer](customization.md#custom-optimizer).                                                                                                             |
| `optimizer_kwargs`      | `dict`            | `{}`         | Keyword arguments forwarded to the optimizer constructor; ignored (with a warning) for callables.                                                                                                                       |
| `warmup_epochs`         | `float`           | `0.0`        | Epochs of linear LR warmup; must not be negative. For explicit schedulers this prepends a `SequentialLR` warmup ramp (skipped for `ReduceLROnPlateau`).                                                                 |
| `drop_path`             | `float`           | `0.0`        | Stochastic depth drop-path rate applied to the backbone. Higher values add more regularization. Must be in `[0, 1)`.                                                                                                    |

### Runtime and Accelerator

| Parameter              | Type             | Default  | Description                                                                                                                                                              |
| ---------------------- | ---------------- | -------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| `accelerator`          | `str`            | `"auto"` | PyTorch Lightning accelerator selection. `"auto"` picks GPU if available, then MPS, then CPU.                                                                            |
| `seed`                 | `int`            | `None`   | Global random seed for reproducibility. `None` means no fixed seed is set.                                                                                               |
| `fp16_eval`            | `bool`           | `False`  | **Deprecated, no effect.** Evaluation precision follows `amp_dtype`; set `amp_dtype="fp16"` instead. Removed in v1.14.                                                   |
| `compute_val_loss`     | `bool \| "auto"` | `"auto"` | Compute and log validation loss only when a configured consumer monitors `val/loss`. Set `True` to always compute it or `False` to disable it.                           |
| `compute_test_loss`    | `bool`           | `True`   | Compute and log the detection loss during the final test run.                                                                                                            |
| `num_sanity_val_steps` | `int`            | `0`      | PyTorch Lightning sanity-check validation batches run before training starts. `0` disables it (the default); increase to catch val-path errors before a full epoch runs. |

### DataLoader Tuning

| Parameter            | Type          | Default | Description                                                                                                                                                                                                                                                             |
| -------------------- | ------------- | ------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `pin_memory`         | `bool`        | `None`  | Pin host memory in the DataLoader for faster GPU transfers. `None` defers to PyTorch Lightning's default.                                                                                                                                                               |
| `persistent_workers` | `bool`        | `None`  | Keep DataLoader worker processes alive between epochs. `None` defers to PyTorch Lightning's default.                                                                                                                                                                    |
| `prefetch_factor`    | `int`         | `None`  | Number of batches to prefetch per DataLoader worker. `None` uses PyTorch's built-in default.                                                                                                                                                                            |
| `pack_targets`       | `bool`        | `True`  | Concatenate target dicts before crossing the DataLoader worker boundary. See the contract below; set `False` to opt out.                                                                                                                                                |
| `pad_targets_to`     | `int \| None` | `None`  | Pad every training image's targets to this many rows so the loss keeps one tensor shape across batches. `None` keeps the variable-length path CUDA wants; set it on XLA/TPU, where a new per-image box count recompiles the graph. Applies to the training loader only. |

With `pack_targets=True`, train, validation, test, and predict loaders yield batches whose target element is `PackedTargets` whenever packing is lossless. The Lightning `transfer_batch_to_device` hook accepts those batches or an unpacked tuple of target dicts. It materializes each packed field directly into its own independently owned per-sample tensor on the target device, producing the same plain per-sample dict list that training, validation, test, and prediction hooks receive on the unpacked path. Batches that cannot be packed losslessly retain their original tuple of dicts.

With `pad_targets_to` set, only the training loader pads; validation, test and predict keep the real targets, since padded rows would otherwise be counted as ground truth by COCO matching. Padding runs before packing in the collate seam, so a batch with both options set always packs, at the padded shape. It is semantically transparent: the padded columns get a query-independent matcher cost so they cannot displace a real target, and the box losses and `class_error` are masked to the real rows. Segmentation models, keypoint models, and the position-supervised, varifocal and plain focal classification branches (`ia_bce_loss=False`) raise instead of silently including padded rows in the loss — leave `pad_targets_to` unset for those. `pad_targets_to` is incompatible with `augmentation_backend="kornia"`/`"gpu"` (`setup("fit")` raises `ValueError`): the GPU pipeline reconstructs its own real/filler mask from the padded box count and strips it back to a variable row count, undoing the fixed shape. An image whose real ground-truth count exceeds `pad_targets_to` has its extra boxes dropped from training, logged as a warning.

## Complete Parameter Reference

Below is a summary table of all training parameters:

| Parameter                    | Type                                                                           | Default        | Description                                                                                                                                                                                                                  |
| ---------------------------- | ------------------------------------------------------------------------------ | -------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `dataset_dir`                | str                                                                            | Required       | Path to COCO or YOLO formatted dataset with train/valid/test splits.                                                                                                                                                         |
| `output_dir`                 | str                                                                            | "output"       | Directory for checkpoints, logs, and other training artifacts.                                                                                                                                                               |
| `epochs`                     | int                                                                            | 100            | Number of full passes over the dataset; at least 1.                                                                                                                                                                          |
| `batch_size`                 | int or "auto"                                                                  | 4              | Samples per iteration. Set to `"auto"` to let RF-DETR probe the GPU for the largest safe batch size. Balance with `grad_accum_steps`.                                                                                        |
| `grad_accum_steps`           | int                                                                            | 1              | Gradient accumulation steps for effective larger batch sizes.                                                                                                                                                                |
| `eval_batch_size`            | int or None                                                                    | None           | Batch size for validation, test and predict dataloaders. `None` inherits `batch_size`; `no_grad` avoids autograd activation storage, but in-fit evaluation still shares device memory with the model and optimizer state.    |
| `lr`                         | float                                                                          | 1e-4           | Learning rate for the model (excluding encoder).                                                                                                                                                                             |
| `lr_encoder`                 | float                                                                          | 1.5e-4         | Learning rate for the backbone encoder.                                                                                                                                                                                      |
| `resolution`                 | int                                                                            | Model-specific | Input image size (must be divisible by the selected model's `patch_size * num_windows`).                                                                                                                                     |
| `weight_decay`               | float                                                                          | 1e-4           | L2 regularization coefficient.                                                                                                                                                                                               |
| `device`                     | str                                                                            | "cuda"         | Training device: cuda, cpu, or mps.                                                                                                                                                                                          |
| `use_ema`                    | bool                                                                           | True           | Enable Exponential Moving Average of weights.                                                                                                                                                                                |
| `ema_decay`                  | `float`                                                                        | `0.993`        | Base EMA decay coefficient; the effective coefficient warms up according to `ema_tau`. Must be in `[0, 1]`. Only used when `use_ema=True`.                                                                                   |
| `ema_tau`                    | int                                                                            | 100            | EMA warm-up time constant in EMA updates; 0 or less uses `ema_decay` directly.                                                                                                                                               |
| `compile`                    | bool                                                                           | False          | Constructor-only `torch.compile` training optimization.                                                                                                                                                                      |
| `cuda_graphs`                | bool                                                                           | False          | Constructor-only, single-GPU CUDA graph replay for detection training.                                                                                                                                                       |
| `gradient_checkpointing`     | bool                                                                           | False          | Trade compute for memory during backprop.                                                                                                                                                                                    |
| `checkpoint_interval`        | int                                                                            | 10             | Save checkpoint every N epochs.                                                                                                                                                                                              |
| `resume`                     | str                                                                            | None           | Path to checkpoint for resuming training.                                                                                                                                                                                    |
| `tensorboard`                | bool                                                                           | True           | Enable TensorBoard logging.                                                                                                                                                                                                  |
| `wandb`                      | bool                                                                           | False          | Enable Weights & Biases logging.                                                                                                                                                                                             |
| `project`                    | str                                                                            | None           | W&B project name.                                                                                                                                                                                                            |
| `run`                        | str                                                                            | None           | W&B run name.                                                                                                                                                                                                                |
| `early_stopping`             | bool                                                                           | False          | Enable early stopping.                                                                                                                                                                                                       |
| `early_stopping_patience`    | int                                                                            | 10             | Epochs without improvement before stopping.                                                                                                                                                                                  |
| `early_stopping_min_delta`   | float                                                                          | 0.001          | Minimum validation metric change to qualify as improvement.                                                                                                                                                                  |
| `early_stopping_use_ema`     | bool                                                                           | False          | Use EMA model for early stopping metrics.                                                                                                                                                                                    |
| `best_model_metric`          | `Literal["map","mar"]`                                                         | "map"          | Metric family for best-checkpoint selection and early stopping — mAP or mAR.                                                                                                                                                 |
| `eval_max_dets`              | int                                                                            | 500            | Maximum detections per image for detection/segmentation COCO AP and AR evaluation. Keypoint AP/AR uses fixed COCO `maxDets=20`.                                                                                              |
| `eval_interval`              | int                                                                            | 1              | Skip the whole validation loop on epochs not a multiple of N; final epoch always validates.                                                                                                                                  |
| `log_per_class_metrics`      | bool                                                                           | False          | Log per-class AP metrics; enable to run the underlying per-class compute.                                                                                                                                                    |
| `eval_backend`               | `Literal["hotcoco","hotcoco_streaming","faster_coco_eval","ufcoco","vernier"]` | "vernier"      | COCO evaluation backend; `"faster_coco_eval"` selects the previous, slower evaluator, `"ufcoco"` for ultrafast-pycocotools, `"hotcoco"` for hotcoco and `"hotcoco_streaming"` for hotcoco matching each batch as it arrives. |
| `eval_base_model`            | bool                                                                           | False          | Also evaluate the base model during validation (two forward passes). Inert when use_ema=False.                                                                                                                               |
| `eval_ema_only`              | bool                                                                           | False          | Deprecated (removal in v1.13); no-op alias for the default policy. Use `eval_base_model`.                                                                                                                                    |
| `eval_masks_head_resolution` | bool                                                                           | False          | Segmentation only. Compare masks at native (lower) resolution instead of upsampling; not comparable across runs.                                                                                                             |
| `progress_bar`               | str \| bool \| None                                                            | None           | Progress bar style: `"tqdm"`, `"rich"`, or `None`. Legacy booleans are still accepted.                                                                                                                                       |
| `accelerator`                | str                                                                            | "auto"         | PyTorch Lightning accelerator. "auto" selects GPU/MPS/CPU automatically.                                                                                                                                                     |
| `seed`                       | int                                                                            | None           | Random seed for reproducibility. None means no fixed seed.                                                                                                                                                                   |
| `lr_scheduler`               | str \| Callable                                                                | "step"         | Scheduler preset ("step"/"cosine"), dotted import path, or callable.                                                                                                                                                         |
| `lr_scheduler_kwargs`        | dict                                                                           | {}             | Keyword arguments for an explicit scheduler; for the managed presets carries lr_drop (default 100, epoch of the 10x step drop) and min_factor (default 0.0, cosine floor).                                                   |
| `lr_scheduler_interval`      | str                                                                            | "step"         | Explicit-scheduler stepping cadence: "step" or "epoch".                                                                                                                                                                      |
| `lr_scheduler_monitor`       | str                                                                            | "val/loss"     | Metric fed to ReduceLROnPlateau.                                                                                                                                                                                             |
| `warmup_epochs`              | float                                                                          | 0.0            | Number of linear warmup epochs at the start of training; must not be negative.                                                                                                                                               |
| `drop_path`                  | float                                                                          | 0.0            | Stochastic depth drop-path rate for the backbone; in `[0, 1)`.                                                                                                                                                               |
| `compute_val_loss`           | bool \| "auto"                                                                 | "auto"         | Compute validation loss only for a configured `val/loss` consumer; `True` forces it and `False` disables it.                                                                                                                 |
| `compute_test_loss`          | bool                                                                           | True           | Compute and log loss during the test run.                                                                                                                                                                                    |
| `num_sanity_val_steps`       | int                                                                            | 0              | PTL sanity-check validation batches run before training starts. 0 disables it; increase to catch val-path errors early.                                                                                                      |
| `fp16_eval`                  | bool                                                                           | False          | **Deprecated, no effect.** Evaluation precision follows `amp_dtype`; set `amp_dtype="fp16"` instead.                                                                                                                         |
| `pin_memory`                 | bool                                                                           | None           | Pin DataLoader memory. None defers to PyTorch Lightning's default.                                                                                                                                                           |
| `persistent_workers`         | bool                                                                           | None           | Keep DataLoader workers alive between epochs. None uses PTL default.                                                                                                                                                         |
| `prefetch_factor`            | int                                                                            | None           | Number of batches prefetched per worker. None uses PyTorch default.                                                                                                                                                          |
| `pack_targets`               | bool                                                                           | True           | Concatenate target dicts before crossing the DataLoader worker boundary. See DataLoader Tuning; set False to opt out.                                                                                                        |
| `pad_targets_to`             | `int \| None`                                                                  | `None`         | Pad training targets to this many rows, for a shape-stable XLA/TPU graph. See DataLoader Tuning; training loader only.                                                                                                       |
