# ------------------------------------------------------------------------
# RF-DETR
# Copyright (c) 2025 Roboflow. All Rights Reserved.
# Licensed under the Apache License, Version 2.0 [see LICENSE for details]
# ------------------------------------------------------------------------
"""Weighted batch sampling across several datasets.

Training on a mix of datasets (for example hand-labelled, synthetic, and public data) with a plain
:class:`~torch.utils.data.ConcatDataset` samples each source in proportion to its size, so a large public set dominates
every batch. :class:`WeightedMultiSourceBatchSampler` instead fixes the per-source composition of *every* batch, which
keeps the gradient signal from a small high-quality source from being drowned out.
"""

from __future__ import annotations

from collections.abc import Iterator, Sequence
from itertools import pairwise
from math import ceil, frexp, isfinite, ldexp
from typing import Any, Literal, TypeAlias

import torch
from torch.utils.data import ConcatDataset, Sampler

from rfdetr.utilities.distributed import get_rank, get_world_size
from rfdetr.utilities.logger import get_logger

logger = get_logger()

#: Which source defines the length of an epoch — the two named strategies, or the index of a specific source.
EpochLength: TypeAlias = Literal["largest", "smallest"] | int

# Weights are converted to integers on this scale so the largest-remainder allocation below is exact. Float remainders
# would make ties resolve by rounding error (e.g. ``0.6 * 16 - 9`` compares as slightly less than ``0.1 * 16 - 1``).
_WEIGHT_SCALE = 1_000_000


def _validate_and_scale_weights(batch_size: int, weights: Sequence[float]) -> list[int]:
    """Check the allocation inputs and convert the weights to the internal integer scale.

    Args:
        batch_size: Number of samples in one batch.
        weights: Relative sampling weight per source.

    Returns:
        The weights on the ``_WEIGHT_SCALE`` integer scale, in the same order as ``weights``.

    Raises:
        ValueError: If ``batch_size`` is not positive, ``weights`` is empty, any weight is not finite and strictly
            positive, or any weight rounds to zero at 1e-6 precision.

    Example:
        >>> _validate_and_scale_weights(8, [0.6, 0.4])
        [600000, 400000]
    """
    if batch_size < 1:
        raise ValueError(f"batch_size must be >= 1, got {batch_size}")
    if len(weights) == 0:
        raise ValueError("weights must contain at least one source")
    invalid = [(index, weight) for index, weight in enumerate(weights) if not (isfinite(weight) and weight > 0)]
    if invalid:
        raise ValueError(
            f"weights must be finite and strictly positive, got invalid entries at (index, value): {invalid}. "
            "To exclude a source, drop it from the sampler instead of giving it zero weight."
        )

    values = [float(weight) for weight in weights]
    largest = max(values)
    if largest * _WEIGHT_SCALE == float("inf"):
        # A finite weight can still overflow the integer scale (1e308 * 1e6 is inf), which would surface as a bare
        # OverflowError from round(). Only ratios matter, so divide every weight by a power of two large enough to
        # bring the largest back in range. Halving is exact in binary floating point, so the ratios survive
        # unchanged, and the rescale is skipped entirely for weights that never threatened to overflow.
        shift = frexp(largest)[1] - 1
        values = [ldexp(value, -shift) for value in values]
    scaled = [round(value * _WEIGHT_SCALE) for value in values]
    # A weight that survives the positivity check can still round to zero, which the allocation below would silently
    # turn into a full guaranteed slot — the opposite of what such a weight asks for.
    underflowed = [(index, weights[index]) for index, value in enumerate(scaled) if value == 0]
    if underflowed:
        raise ValueError(
            f"weights are too small to be represented at 1e-6 precision, at (index, value): {underflowed}. "
            "A weight is measured relative to the largest one, so this also fires for a weight that is merely "
            "negligible beside its peers. To exclude a source, drop it from the sampler instead of giving it a "
            "negligible weight."
        )
    return scaled


def _rebalance_counts(counts: list[int], remainders: list[int], scaled: list[int], shortfall: int) -> list[int]:
    """Hand back the slots that the one-slot-per-source guarantee over-allocated.

    Slots are reclaimed from the smallest remainders first and no source is ever dropped to zero. A single pass frees
    at most one slot per source, which is not always enough (a dominant weight can be clamped up by more slots than
    there are other sources), so passes repeat until the counts balance. Every pass either reaches the target or
    shrinks a count towards 1, and ``batch_size >= len(counts)`` whenever the clamp fires, so enough slack always
    exists; the empty-``reclaimable`` guard only keeps the loop bounded.

    Args:
        counts: Per-source slot counts, over-allocated by ``-shortfall`` slots.
        remainders: Largest-remainder tie-breaker per source, in the same order as ``counts``.
        scaled: Weights on the ``_WEIGHT_SCALE`` integer scale, in the same order as ``counts``.
        shortfall: Negative number of slots that have to be handed back.

    Returns:
        Balanced per-source slot counts.

    Example:
        >>> _rebalance_counts([3, 1, 1, 1], [600000, 160000, 120000, 120000], [900000, 40000, 30000, 30000], -2)
        [1, 1, 1, 1]
    """
    balanced = list(counts)
    order = sorted(range(len(balanced)), key=lambda index: (remainders[index], scaled[index], index))
    while shortfall < 0:
        reclaimable = [index for index in order if balanced[index] > 1]
        if not reclaimable:
            break
        for index in reclaimable:
            if shortfall == 0:
                break
            balanced[index] -= 1
            shortfall += 1
    return balanced


def compute_source_batch_sizes(batch_size: int, weights: Sequence[float]) -> list[int]:
    """Split a batch across sources in proportion to ``weights``.

    Uses the largest-remainder (Hamilton) method, so the returned counts always sum to ``batch_size`` while staying as
    close as possible to the requested ratios. Every source receives at least one slot when ``batch_size`` is at least
    the number of sources; otherwise the lowest-weighted sources receive zero and are absent from each batch.

    Args:
        batch_size: Number of samples in one batch.
        weights: Relative sampling weight per source. Weights need not sum to 1; they are normalised internally. All
            weights must be finite, strictly positive, and no smaller than ``1e-6``, which is the precision the
            allocation works at.

    Returns:
        Per-source sample counts, in the same order as ``weights``, summing to ``batch_size``.

    Raises:
        ValueError: If ``batch_size`` is not positive, ``weights`` is empty, any weight is not finite and strictly
            positive, or any weight rounds to zero at 1e-6 precision.

    Example:
        >>> compute_source_batch_sizes(16, [0.6, 0.3, 0.1])
        [10, 5, 1]
        >>> compute_source_batch_sizes(8, [0.9, 0.04, 0.03, 0.03])  # the minimum of one slot each costs the leader
        [5, 1, 1, 1]
    """
    scaled = _validate_and_scale_weights(batch_size, weights)
    total = sum(scaled)

    counts: list[int] = []
    remainders: list[int] = []
    for weight in scaled:
        numerator = batch_size * weight
        counts.append(numerator // total)
        remainders.append(numerator % total)

    clamped_indices: set[int] = set()
    if batch_size >= len(weights):
        # Guarantee representation: a source rounded down to zero would never appear in a batch.
        clamped_indices = {index for index, count in enumerate(counts) if count == 0}
        counts = [max(count, 1) for count in counts]

    shortfall = batch_size - sum(counts)
    if shortfall > 0:
        # Hand out the leftover slots to the largest remainders first. Sources the guarantee above
        # already bumped from 0 to 1 are excluded here — including them double-dips the same
        # remainder twice (once for the guarantee, once for the leftover), which silently pulls
        # slots away from the dominant sources the ratio is supposed to favor. Non-clamped sources
        # always outnumber shortfall: shortfall = batch_size - total_floor - len(clamped_indices),
        # and batch_size - total_floor <= len(weights), so shortfall <= len(weights) - len(clamped_indices).
        order = sorted(
            (index for index in range(len(weights)) if index not in clamped_indices),
            key=lambda index: (-remainders[index], -scaled[index], index),
        )
        for index in order[:shortfall]:
            counts[index] += 1
    elif shortfall < 0:
        # The guarantee above over-allocated, so give the surplus slots back.
        counts = _rebalance_counts(counts, remainders, scaled, shortfall)

    # No raise here: sum(counts) == batch_size always holds. _rebalance_counts' reclaimable-empty guard (its only
    # way to return early without hitting the target) requires every count == 1, at which point
    # shortfall == batch_size - len(weights) >= 0 (the clamp above only fires when batch_size >= len(weights)) —
    # so the `while shortfall < 0` loop there has already exited before reaching that guard. A 20,000-case fuzz
    # over weights in [1e-6, 1e6] and batch sizes in [1, 40] found zero violations.
    return counts


def _resolve_distributed_layout(num_replicas: int | None, rank: int | None) -> tuple[int, int]:
    """Resolve the DDP layout, defaulting to the live ``torch.distributed`` process group.

    Defaulting matters: a sampler built with ``num_replicas=1`` inside a DDP run hands every rank the identical batch
    stream, which duplicates gradients silently instead of failing.

    Args:
        num_replicas: Number of DDP processes, or ``None`` to read the world size from ``torch.distributed``.
        rank: Rank of the current process, or ``None`` to read it from ``torch.distributed``.

    Returns:
        The resolved ``(num_replicas, rank)`` pair.

    Raises:
        ValueError: If the resolved ``num_replicas`` is below 1, or the resolved ``rank`` falls outside
            ``[0, num_replicas)``.

    Example:
        >>> _resolve_distributed_layout(4, 3)  # explicit values are used as given, no process group needed
        (4, 3)

    Note:
        ``_resolve_distributed_layout(None, None)`` reads the live ``torch.distributed`` process group, so its
        result depends on the environment (``(1, 0)`` outside DDP) and is intentionally not doctested here.
    """
    resolved_replicas = get_world_size() if num_replicas is None else int(num_replicas)
    resolved_rank = get_rank() if rank is None else int(rank)
    if resolved_replicas < 1:
        raise ValueError(f"num_replicas must be >= 1, got {resolved_replicas}")
    if not 0 <= resolved_rank < resolved_replicas:
        raise ValueError(f"rank must be in [0, {resolved_replicas}), got {resolved_rank}")

    world_size = get_world_size()
    if resolved_replicas == 1 and world_size > 1:
        logger.warning(
            "num_replicas=1 while torch.distributed reports a world size of %d: every rank would iterate the same "
            "batch stream and see the same samples. Leave num_replicas and rank unset to shard across the live "
            "process group.",
            world_size,
        )
    return resolved_replicas, resolved_rank


class WeightedMultiSourceBatchSampler(Sampler[list[int]]):
    """Batch sampler that enforces a fixed per-source ratio in every batch.

    Each yielded batch is a flat list of indices into a :class:`~torch.utils.data.ConcatDataset` whose sub-datasets are
    the sources, composed of :func:`compute_source_batch_sizes` slots per source. Indices are shuffled within a source
    every epoch; a source whose samples run out mid-epoch is reshuffled and reused, so the ratio holds even when the
    sources differ wildly in size.

    Note:
        Unlike torch's ``drop_last``, this sampler never emits a short final batch. Setting ``drop_last=False`` appends
        one extra full batch, recycling source samples, after the driving source has been covered once. At an even
        ``num_replicas`` this extra batch is typically floored away by the per-rank division below, making
        ``drop_last=False`` a no-op there (warned about when it happens).

    Note:
        Has no ``state_dict``/``load_state_dict``: like the default loader path, a mid-epoch checkpoint resume
        replays the epoch from batch 0 against the already-seeded shuffle rather than continuing partway through
        it.

    Under DDP each rank consumes a disjoint stride of the global batch stream (``rank``, ``rank + num_replicas``, ...),
    mirroring :class:`~torch.utils.data.distributed.DistributedSampler`. The number of global batches is truncated to a
    multiple of ``num_replicas`` so every rank runs the same number of steps and no rank stalls in gradient all-reduce.
    ``num_replicas`` and ``rank`` default to the live ``torch.distributed`` process group, so a DDP run shards itself
    without extra wiring; passing them explicitly overrides that.

    Like :class:`~torch.utils.data.distributed.DistributedSampler`, :meth:`set_epoch` must be called at the start of
    each epoch, otherwise every epoch reuses the same shuffle.

    .. note::
        Every rank is assumed to build the sampler over the same sources: the same number of sources, the same size
        per source, in the same order. Ranks exchange nothing; each one replays the whole global batch stream from
        ``source_sizes``, ``weights``, ``seed`` and the epoch, and yields only its own stride of it. A rank that
        disagrees about the source layout therefore builds a *different* stream rather than a disjoint share of one
        stream, and the mismatch is silent — no error, no hang. Deriving the sources from an unsorted directory
        listing, a rank-dependent subsample, or a size limit applied only on rank 0 breaks this assumption.

    Args:
        source_sizes: Number of samples in each source, in ``ConcatDataset`` order. Every source must be non-empty.
        weights: Relative sampling weight per source, in the same order. Normalised internally; must be positive.
        batch_size: Number of samples per batch on a single rank. This is the mini-batch the model sees per forward
            pass, so it is neither multiplied by gradient-accumulation steps nor by the world size.
        drop_last: Whether to omit the extra full batch needed to cover the driving source's remainder. At least one
            batch is always produced (even when the driving source is smaller than its per-batch slot count), so
            ``drop_last=True`` will not reduce an epoch to zero batches for tiny datasets.
        shuffle: Whether to shuffle indices within each source.
        num_replicas: Number of DDP processes participating. ``None`` (the default) reads the world size from the live
            ``torch.distributed`` process group, which is 1 outside DDP; pass an integer to override.
        rank: Rank of the current process, in ``[0, num_replicas)``. ``None`` (the default) reads the rank from the
            live ``torch.distributed`` process group, which is 0 outside DDP; pass an integer to override.
        seed: Base seed shared by all ranks; combined with the epoch to shuffle identically across ranks.
        epoch_length: Which source defines the length of an epoch — ``"largest"`` (every sample of the biggest source
            is seen roughly once per epoch, smaller sources cycle), ``"smallest"`` (the smallest source is seen once
            and larger sources are sub-sampled), or the integer index of a specific source.
        batch_multiple: Round the per-rank batch count down to a multiple of this value. Pass ``grad_accum_steps``
            so every gradient-accumulation window is complete: PTL otherwise fires the optimizer on a short final
            window (Lightning-AI/pytorch-lightning#19987), which the default loader path avoids by padding the
            dataset — padding a batch sampler owns its own batches and cannot use. ``1`` (the default) leaves the
            epoch length untouched.

    Raises:
        ValueError: If the arguments are inconsistent, a source is empty, ``epoch_length`` is invalid, or
            ``batch_multiple`` is below 1 or larger than the epoch it would align.

    Example:
        >>> import torch
        >>> from torch.utils.data import ConcatDataset, DataLoader, TensorDataset
        >>> sources = [TensorDataset(torch.zeros(n)) for n in (500, 200, 40)]
        >>> dataset = ConcatDataset(sources)
        >>> sampler = WeightedMultiSourceBatchSampler.from_concat_dataset(dataset, [0.6, 0.3, 0.1], batch_size=16)
        >>> sampler.source_batch_sizes
        [10, 5, 1]
        >>> loader = DataLoader(dataset, batch_sampler=sampler)
    """

    def __init__(
        self,
        source_sizes: Sequence[int],
        weights: Sequence[float],
        batch_size: int,
        *,
        drop_last: bool = True,
        shuffle: bool = True,
        num_replicas: int | None = None,
        rank: int | None = None,
        seed: int = 0,
        epoch_length: EpochLength = "largest",
        batch_multiple: int = 1,
    ) -> None:
        if len(source_sizes) != len(weights):
            raise ValueError(
                f"source_sizes and weights must have the same length, got {len(source_sizes)} and {len(weights)}"
            )
        if len(source_sizes) == 0:
            raise ValueError("at least one source is required")
        if batch_multiple < 1:
            raise ValueError(f"batch_multiple must be >= 1, got {batch_multiple}")
        empty = [index for index, size in enumerate(source_sizes) if size <= 0]
        if empty:
            raise ValueError(f"every source must be non-empty, got empty sources at indices {empty}")
        resolved_replicas, resolved_rank = _resolve_distributed_layout(num_replicas, rank)

        self.source_sizes = [int(size) for size in source_sizes]
        self.weights = [float(weight) for weight in weights]
        self.batch_size = int(batch_size)
        self.drop_last = bool(drop_last)
        self.shuffle = bool(shuffle)
        self.num_replicas = resolved_replicas
        self.rank = resolved_rank
        self.seed = int(seed)
        self.batch_multiple = int(batch_multiple)
        self.epoch = 0

        self.source_batch_sizes = compute_source_batch_sizes(self.batch_size, self.weights)
        starved = [index for index, count in enumerate(self.source_batch_sizes) if count == 0]
        if starved:
            logger.warning(
                "batch_size=%d is too small to represent every source; sources %s contribute no samples.",
                self.batch_size,
                starved,
            )

        offsets = [0]
        for size in self.source_sizes:
            offsets.append(offsets[-1] + size)
        self._source_offsets = offsets

        self.driving_source = self._resolve_driving_source(epoch_length)
        driving_slots = self.source_batch_sizes[self.driving_source]
        driving_size = self.source_sizes[self.driving_source]
        global_batches = driving_size // driving_slots
        extra_batch_requested = not self.drop_last and driving_size % driving_slots != 0
        if extra_batch_requested:
            global_batches += 1
        if extra_batch_requested and global_batches // self.num_replicas == (global_batches - 1) // self.num_replicas:
            # The floor below discards the extra batch drop_last=False just added, whenever num_replicas divides
            # evenly into the batch count without it (every power-of-two world size, in practice) — the flag then
            # silently has no effect. Documented as a caveat on drop_last rather than raising: recomputing after
            # the rank division would only relocate the same asymmetry, not remove it.
            logger.warning(
                "drop_last=False requested one extra batch to cover source %d's remainder, but num_replicas=%d "
                "divides the per-rank batch count evenly without it, so the extra batch is discarded and "
                "drop_last=False has no effect this epoch.",
                self.driving_source,
                self.num_replicas,
            )
        if global_batches < self.num_replicas:
            # max(1, ...) below guarantees at least one batch per rank even when the driving source cannot fill
            # one full round across all ranks, but every rank then replays that same batch, recycling the driving
            # source itself — the invariant "the driving source is not repeated" (unlike smaller sources) no
            # longer holds. Most likely under a small epoch_length='smallest' source combined with many DDP ranks.
            logger.warning(
                "Source %d (%d samples), driving the epoch, yields only %d global batch(es) but num_replicas=%d: "
                "every rank replays the same batch(es), recycling the driving source instead of seeing each of "
                "its samples once. Consider a larger driving source (epoch_length='largest' or an explicit index) "
                "or fewer replicas.",
                self.driving_source,
                driving_size,
                global_batches,
                self.num_replicas,
            )
        # Truncate to a whole number of rounds so every rank yields the same count; at least one batch is always
        # produced, even for datasets smaller than a single batch.
        self._batches_per_rank = max(1, global_batches // self.num_replicas)
        if self.batch_multiple > 1:
            # Round down so the epoch is a whole number of gradient-accumulation windows. PTL fires the optimizer on
            # a partial window at the tail of an epoch (Lightning-AI/pytorch-lightning#19987); the default loader
            # path avoids that by padding the dataset, which a batch sampler owning its own batches cannot use.
            aligned = (self._batches_per_rank // self.batch_multiple) * self.batch_multiple
            if aligned == 0:
                raise ValueError(
                    f"batch_multiple={self.batch_multiple} exceeds the {self._batches_per_rank} batch(es) this rank "
                    f"yields per epoch, so aligning would leave the epoch empty. Lower batch_multiple (typically "
                    f"grad_accum_steps), lower batch_size, or drive the epoch from a larger source."
                )
            self._batches_per_rank = aligned
        self._global_batches = self._batches_per_rank * self.num_replicas

        driving_coverage = self._global_batches * driving_slots
        if driving_coverage < 0.9 * driving_size:
            # Three stacked floor-divisions (per-source, per-rank, batch_multiple) can each shave off up to one
            # unit, compounding into a meaningfully short epoch with no other signal — the epoch_length docstring's
            # "every sample of the biggest source is seen roughly once" guarantee does not hold below this.
            logger.warning(
                "The driving source (%d, %d samples) is only %.0f%% covered per epoch after per-rank and "
                "batch_multiple rounding (%d of %d samples via %d global batch(es) x %d slot(s)); the rest is "
                "never drawn this epoch. Reseeded every epoch, so no sample is permanently excluded, but the "
                "documented 'seen roughly once per epoch' epoch_length coverage does not hold here.",
                self.driving_source,
                driving_size,
                100.0 * driving_coverage / driving_size,
                driving_coverage,
                driving_size,
                self._global_batches,
                driving_slots,
            )

        self._warn_on_ratio_divergence()
        self._warn_on_source_imbalance()

    @classmethod
    def from_concat_dataset(
        cls,
        dataset: ConcatDataset[Any],
        weights: Sequence[float],
        batch_size: int,
        *,
        drop_last: bool = True,
        shuffle: bool = True,
        num_replicas: int | None = None,
        rank: int | None = None,
        seed: int = 0,
        epoch_length: EpochLength = "largest",
        batch_multiple: int = 1,
    ) -> "WeightedMultiSourceBatchSampler":
        """Build a sampler for a :class:`~torch.utils.data.ConcatDataset`.

        .. note::
            Under DDP every rank must pass an identically laid-out ``dataset``: the same sub-datasets, in the same
            order, with the same lengths (see the cross-rank assumption in the class docstring). Only that layout is
            read here, so sub-datasets that agree in length but differ in content across ranks stay undetected and
            silently break the split of the batch stream.

        Args:
            dataset: Concatenated dataset whose sub-datasets are the sources.
            weights: Relative sampling weight per source, ordered like ``dataset.datasets``.
            batch_size: Number of samples per batch on a single rank.
            drop_last: Whether to omit the extra full batch covering the driving source's remainder; an epoch is
                never reduced to zero batches. See the class docstring.
            shuffle: Whether to shuffle indices within each source.
            num_replicas: Number of DDP processes participating, or ``None`` to read the world size from the live
                ``torch.distributed`` process group.
            rank: Rank of the current process, in ``[0, num_replicas)``, or ``None`` to read it from the live
                ``torch.distributed`` process group.
            seed: Base seed shared by all ranks.
            epoch_length: Source that defines the epoch length; see the class docstring.
            batch_multiple: Round the per-rank batch count down to a multiple of this value; pass
                ``grad_accum_steps``. See the class docstring.

        Returns:
            A sampler whose index space matches ``dataset``.

        Raises:
            ValueError: If ``weights`` does not have one entry per sub-dataset.
        """
        if len(weights) != len(dataset.datasets):
            raise ValueError(
                f"weights must have one entry per sub-dataset, got {len(weights)} for {len(dataset.datasets)} sources"
            )
        boundaries = [0, *dataset.cumulative_sizes]
        source_sizes = [end - start for start, end in pairwise(boundaries)]
        return cls(
            source_sizes,
            weights,
            batch_size,
            drop_last=drop_last,
            shuffle=shuffle,
            num_replicas=num_replicas,
            rank=rank,
            seed=seed,
            epoch_length=epoch_length,
            batch_multiple=batch_multiple,
        )

    def _resolve_driving_source(self, epoch_length: EpochLength) -> int:
        """Return the index of the source whose exhaustion ends an epoch.

        Args:
            epoch_length: ``"largest"``, ``"smallest"``, or an explicit source index.

        Returns:
            Index of the driving source, adjusted when the requested source has no slots in a batch.

        Raises:
            ValueError: If ``epoch_length`` is neither a known keyword nor a valid source index.
        """
        indices = range(len(self.source_sizes))
        if epoch_length == "largest":
            driving = max(indices, key=lambda index: self.source_sizes[index])
        elif epoch_length == "smallest":
            driving = min(indices, key=lambda index: self.source_sizes[index])
        elif isinstance(epoch_length, int) and not isinstance(epoch_length, bool) and epoch_length in indices:
            driving = epoch_length
        else:
            raise ValueError(
                f"epoch_length must be 'largest', 'smallest', or a source index in [0, {len(self.source_sizes)}), "
                f"got {epoch_length!r}"
            )

        if self.source_batch_sizes[driving] == 0:
            fallback = next(index for index, count in enumerate(self.source_batch_sizes) if count > 0)
            logger.warning(
                "Source %d contributes no samples per batch and cannot define the epoch length; using source %d.",
                driving,
                fallback,
            )
            return fallback
        return driving

    def _warn_on_ratio_divergence(self) -> None:
        """Warn when a source's realised share of every batch departs sharply from its requested weight.

        Guaranteeing every source at least one slot (see :func:`compute_source_batch_sizes`) lifts tiny sources above
        their requested share and squeezes the dominant one, so the composition the caller asked for can be rewritten
        without any other signal. A divergence is only reported when it is large both relatively and absolutely, which
        keeps the unavoidable ``1 / batch_size`` granularity quiet for weights that are merely small. Starved sources
        (zero slots per batch) are skipped because the constructor already warns about them.
        """
        relative_tolerance = 2.0
        absolute_tolerance = 0.10
        total_weight = sum(self.weights)
        if not isfinite(total_weight):
            # Weights that individually pass validation can still overflow float64 addition (e.g.
            # two weights of 1e308). compute_source_batch_sizes already rescaled internally and
            # produced a valid allocation; the requested-vs-realised ratio below cannot be computed
            # safely from the raw weights in that case, so skip the heuristic rather than let the
            # eagerly-evaluated ceil(...) logging argument below raise OverflowError.
            return

        divergent: list[tuple[int, float, float]] = []
        for index, count in enumerate(self.source_batch_sizes):
            if count == 0:
                continue
            requested = self.weights[index] / total_weight
            realised = count / self.batch_size
            larger, smaller = max(requested, realised), min(requested, realised)
            if larger - smaller > absolute_tolerance and larger > relative_tolerance * smaller:
                divergent.append((index, requested, realised))
        if not divergent:
            return

        logger.warning(
            "batch_size=%d cannot hold the requested source weights: %s. Every source is guaranteed one slot per "
            "batch, which rewrites the requested ratio; a batch_size of at least %d would leave room for the "
            "smallest weight.",
            self.batch_size,
            "; ".join(
                f"source {index} requested {requested:.1%} but gets {realised:.1%}"
                for index, requested, realised in divergent
            ),
            ceil(total_weight / min(self.weights)),
        )

    def _warn_on_source_imbalance(self) -> None:
        """Warn about every source recycled many times per epoch, which risks overfitting it.

        A starved source (zero slots per batch, possible when ``batch_size`` is below the number of sources) is
        never recycled: its pass count is always ``0.0``, and ``sum(source_batch_sizes) == batch_size >= 1``
        guarantees at least one other source has a positive pass count, so a starved source can never be reported
        here without a separate filter.
        """
        recycle_threshold = 10
        passes = {
            index: (self._global_batches * count) / self.source_sizes[index]
            for index, count in enumerate(self.source_batch_sizes)
        }
        recycled = sorted(
            (index for index, count in passes.items() if count >= recycle_threshold),
            key=lambda index: -passes[index],
        )
        if not recycled:
            return
        logger.warning(
            "%d source(s) recycled 10x or more per epoch, which risks overfitting them. Consider "
            "epoch_length='smallest' or early stopping: %s",
            len(recycled),
            "; ".join(
                f"Source {index} ({self.source_sizes[index]} samples) is repeated ~{passes[index]:.1f} times per "
                f"epoch to fill its {self.source_batch_sizes[index]} slot(s) in every batch"
                for index in recycled
            ),
        )

    def set_epoch(self, epoch: int) -> None:
        """Set the epoch used to seed shuffling.

        Call this before every epoch so the within-source shuffle changes, and changes identically on all ranks.

        Args:
            epoch: Zero-based epoch number.
        """
        self.epoch = int(epoch)

    def __len__(self) -> int:
        """Return the number of batches this rank yields per epoch."""
        return self._batches_per_rank

    def __iter__(self) -> Iterator[list[int]]:
        """Yield batches of dataset indices honouring the per-source ratio.

        Yields:
            Lists of exactly ``batch_size`` indices into the concatenated dataset.
        """
        generator = torch.Generator()
        generator.manual_seed(self.seed + self.epoch)

        # A starved source (zero slots per batch) is never drawn from, so shuffling it would only burn RNG draws.
        streams: list[torch.Tensor] = [
            self._shuffled_indices(index, generator)
            if self.source_batch_sizes[index]
            else torch.empty(0, dtype=torch.long)
            for index in range(len(self.source_sizes))
        ]
        cursors = [0] * len(self.source_sizes)

        def draw(source: int, count: int) -> list[int]:
            picked: list[int] = []
            stream = streams[source]
            while len(picked) < count:
                if cursors[source] >= len(stream):
                    # The source ran out before the epoch ended; reshuffle and keep going so the ratio is preserved.
                    stream = self._shuffled_indices(source, generator)
                    streams[source] = stream
                    cursors[source] = 0
                take = min(count - len(picked), len(stream) - cursors[source])
                picked.extend(stream[cursors[source] : cursors[source] + take].tolist())
                cursors[source] += take
            return picked

        for batch_index in range(self._global_batches):
            # Every rank builds every batch so the shared RNG stream stays aligned across ranks, and each rank yields
            # only its own stride of the global sequence.
            batch = [
                index for source, count in enumerate(self.source_batch_sizes) if count for index in draw(source, count)
            ]
            if self.shuffle:
                order = torch.randperm(len(batch), generator=generator).tolist()
                batch = [batch[position] for position in order]
            if batch_index % self.num_replicas == self.rank:
                yield batch

    def _shuffled_indices(self, source: int, generator: torch.Generator) -> torch.Tensor:
        """Return the source's indices in the concatenated index space, as a tensor.

        Kept as a tensor rather than a Python list: :meth:`__iter__`'s ``draw`` slices this tensor and
        calls ``.tolist()`` only on the drawn slice. Converting the whole source with ``.tolist()`` on
        every reshuffle costs far more than the shuffle itself and holds a full Python list per source
        in memory for the epoch, regardless of how many samples are actually drawn from it.

        Args:
            source: Index of the source.
            generator: RNG shared by all ranks for this epoch.

        Returns:
            One full pass over the source's global indices, as an ``int64`` tensor.
        """
        offset = self._source_offsets[source]
        size = self.source_sizes[source]
        if not self.shuffle:
            return torch.arange(offset, offset + size)
        return torch.randperm(size, generator=generator) + offset
