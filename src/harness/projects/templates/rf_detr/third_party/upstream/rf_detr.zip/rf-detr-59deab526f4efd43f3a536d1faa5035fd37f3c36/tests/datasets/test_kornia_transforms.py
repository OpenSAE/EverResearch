# ------------------------------------------------------------------------
# RF-DETR
# Copyright (c) 2025 Roboflow. All Rights Reserved.
# Licensed under the Apache License, Version 2.0 [see LICENSE for details]
# ------------------------------------------------------------------------
"""Tests for Kornia GPU augmentation pipeline builder and bbox utilities.

All tests in this module are CPU-compatible — Kornia operates on CPU tensors identically to GPU tensors, so no
``@pytest.mark.gpu`` is needed.
"""

from types import SimpleNamespace
from typing import Any

import numpy as np
import pytest
import torch

from rfdetr.config import AugmentationBackend
from rfdetr.datasets import kornia_transforms
from rfdetr.datasets._torchvision import RandomHorizontalFlip
from rfdetr.datasets.aug_configs import (
    AUG_AERIAL,
    AUG_AGGRESSIVE,
    AUG_CONSERVATIVE,
    AUG_INDUSTRIAL,
)
from rfdetr.datasets.coco import make_coco_transforms
from rfdetr.datasets.kornia_transforms import (
    _make_affine,
    build_kornia_pipeline,
    collate_boxes,
    collate_keypoints,
    collate_masks,
    keypoint_horizontal_flip_mask,
    resolve_augmentation_backend,
    resolve_backend_for_build,
    unpack_boxes,
)
from rfdetr.datasets.transforms import AlbumentationsWrapper, Normalize
from tests._markers import _requires_albumentations, _requires_kornia


def _sharpness_sampler_range(transform: torch.nn.Module) -> tuple[float, float]:
    """Read the sampled ``sharpness`` range off a Kornia ``RandomSharpness`` transform.

    This intentionally reads a private Kornia implementation detail (``_param_generator.sampler_dict``) because no
    public equivalent exists: ``RandomSharpness(...).flags`` is empty (verified against the installed Kornia
    version), so the sampled range isn't reachable through any public attribute. If a future Kornia release
    renames or removes ``_param_generator``/``sampler_dict``, this raises a clear, actionable failure instead of a
    raw ``AttributeError``/``KeyError`` deep inside the test body.

    Args:
        transform: A ``kornia.augmentation.RandomSharpness`` instance (or equivalent) built with a sampled range.

    Returns:
        The sampled ``(low, high)`` bounds as floats.
    """
    try:
        sampler = transform._param_generator.sampler_dict["sharpness"]
        return float(sampler.low), float(sampler.high)
    except (AttributeError, KeyError) as exc:
        pytest.fail(
            "Kornia's RandomSharpness no longer exposes the sampled `sharpness` range via the private "
            f"`_param_generator.sampler_dict['sharpness']` path (no public alternative exists): {exc!r}. Update "
            "this helper to match Kornia's new internal parameter-generator shape."
        )


def _only_child(pipeline: torch.nn.Module, class_name: str) -> torch.nn.Module:
    """Return the single child module of ``pipeline`` whose class is named ``class_name``.

    Matching on the class name keeps the optional Kornia package out of the test body's imports.

    Args:
        pipeline: Module whose direct children are searched.
        class_name: Exact class name of the wanted child.

    Returns:
        The one matching child; the assertion fails if there is none or more than one.

    Examples:
        >>> _only_child(torch.nn.Sequential(torch.nn.ReLU(), torch.nn.Tanh()), "Tanh")
        Tanh()
    """
    matches = [child for child in pipeline.children() if child.__class__.__name__ == class_name]
    assert len(matches) == 1, f"Expected exactly 1 {class_name}, found {len(matches)}"
    return matches[0]


def _logged_messages(logger_method: Any) -> list[str]:
    """Render each call recorded on a mocked logger method as its final ``%``-formatted message.

    Args:
        logger_method: A mock standing in for ``logger.warning`` or similar.

    Returns:
        One formatted string per recorded call.

    Examples:
        >>> from unittest.mock import MagicMock
        >>> method = MagicMock()
        >>> _ = method("ignores %s", "fill")
        >>> _ = method("plain")
        >>> _logged_messages(method)
        ['ignores fill', 'plain']
    """
    return [
        call.args[0] % call.args[1:] if len(call.args) > 1 else call.args[0] for call in logger_method.call_args_list
    ]


@_requires_kornia
class TestBuildKorniaPipeline:
    """build_kornia_pipeline returns a valid pipeline for every preset and rejects unknown transform keys."""

    @pytest.mark.parametrize(
        "config",
        [
            pytest.param(AUG_CONSERVATIVE, id="conservative"),
            pytest.param(AUG_AGGRESSIVE, id="aggressive"),
            pytest.param(AUG_AERIAL, id="aerial"),
            pytest.param(AUG_INDUSTRIAL, id="industrial"),
        ],
    )
    def test_each_preset_config(self, config):
        """Each named preset builds a pipeline without errors."""
        assert build_kornia_pipeline(config, 560) is not None, "a preset must build a non-None pipeline"

    @pytest.mark.parametrize(
        ("config", "bad_key"),
        [
            pytest.param({"FooBarTransform": {"p": 0.5}}, "FooBarTransform", id="unknown-only"),
            pytest.param(
                {"HorizontalFlip": {"p": 0.5}, "BogusTransform": {"p": 0.3}}, "BogusTransform", id="known-plus-unknown"
            ),
            # Deliberately out of scope: albumentations shifts additively, Kornia scales multiplicatively.
            pytest.param(
                {"HueSaturationValue": {"hue_shift_limit": 20}}, "HueSaturationValue", id="hue-saturation-value"
            ),
        ],
    )
    def test_unsupported_key_raises_value_error_naming_it(self, config, bad_key):
        """A transform key Kornia cannot build raises ValueError that names the offending key."""
        with pytest.raises(ValueError) as exc_info:
            build_kornia_pipeline(config, 560)

        assert bad_key in str(exc_info.value)

    def test_empty_config_returns_pipeline(self):
        """An empty config dict returns a valid (no-op) pipeline, not None."""
        assert build_kornia_pipeline({}, 560) is not None, "Empty config must still return a pipeline object"

    def test_to_gray_builds_random_grayscale(self):
        """``ToGray`` maps onto ``K.RandomGrayscale`` (issue #1227)."""
        pipeline = build_kornia_pipeline({"ToGray": {"p": 0.5}}, 560)
        transform_names = [child.__class__.__name__ for child in pipeline.children()]
        assert "RandomGrayscale" in transform_names

    def test_to_gray_keeps_three_channels_and_greys(self):
        """``ToGray`` matches Albumentations: grayscale content, still three channels."""
        pipeline = build_kornia_pipeline({"ToGray": {"p": 1.0}}, 560)
        image = torch.rand(1, 3, 32, 32)
        boxes = torch.tensor([[[0.0, 0.0, 10.0, 10.0]]])
        out, _ = pipeline(image, boxes)

        assert out.shape == image.shape, "ToGray must preserve the three-channel shape"
        # A greyscale image has identical values across the channel axis.
        assert torch.allclose(out[:, 0], out[:, 1], atol=1e-5)
        assert torch.allclose(out[:, 1], out[:, 2], atol=1e-5)

    @_requires_albumentations
    def test_to_gray_accepted_by_both_backends(self):
        """The same config is readable by the Albumentations backend too (issue #1227).

        ``ToGray`` resolved on Albumentations via ``getattr`` long before it was a Kornia built-in, so a config that
        worked on one backend raised on the other.
        """
        config = {"ToGray": {"p": 0.5}}
        assert build_kornia_pipeline(config, 560) is not None

        wrappers = AlbumentationsWrapper.from_config(config)
        assert len(wrappers) == 1, (
            "from_config(strict=False) silently drops unresolved transforms, so length must be checked"
        )
        built_names = [t.__class__.__name__ for t in wrappers[0].transform.transforms]
        assert "ToGray" in built_names, f"expected a ToGray transform, got {built_names}"

    def test_to_gray_defaults_p_to_point_five_when_omitted(self):
        """Omitting p resolves to 0.5, matching Albumentations (not Kornia's native 0.1 default)."""
        pipeline = build_kornia_pipeline({"ToGray": {}}, 560)
        to_gray = next(child for child in pipeline.children() if child.__class__.__name__ == "RandomGrayscale")
        assert to_gray.p == pytest.approx(0.5)

    def test_to_gray_p_zero_is_a_no_op(self):
        """p=0.0 never applies: forward pass returns the input unchanged."""
        pipeline = build_kornia_pipeline({"ToGray": {"p": 0.0}}, 560)
        image = torch.rand(1, 3, 32, 32)
        boxes = torch.tensor([[[0.0, 0.0, 10.0, 10.0]]])
        out, _ = pipeline(image, boxes)

        assert torch.equal(out, image), "p=0.0 must never apply ToGray"

    def test_to_gray_ignores_method_and_num_output_channels_on_kornia(self):
        """method/num_output_channels have no Kornia equivalent and are currently ignored there.

        Pins the divergence documented on ``_make_to_gray``: Albumentations honors both, Kornia always uses BT.601
        weights and returns 3 channels. If this is ever fixed, this test should be updated to assert the new (parity)
        behavior instead.
        """
        pipeline = build_kornia_pipeline({"ToGray": {"method": "max", "num_output_channels": 1, "p": 1.0}}, 560)
        image = torch.rand(1, 3, 32, 32)
        boxes = torch.tensor([[[0.0, 0.0, 10.0, 10.0]]])
        out, _ = pipeline(image, boxes)

        assert out.shape == image.shape, "num_output_channels=1 is currently ignored -- output stays 3-channel"
        assert torch.allclose(out[:, 0], out[:, 1], atol=1e-5), "method='max' is currently ignored on Kornia"

    @pytest.mark.parametrize(
        "config",
        [
            pytest.param({"GaussianBlur": {"blur_limit": (3, 7), "p": 0.5}}, id="blur_limit-pair"),
            pytest.param({"GaussianBlur": {"sigma": 1.5, "p": 0.5}}, id="sigma-scalar"),
            pytest.param({"GaussianBlur": {"sigma": (1.5,), "p": 0.5}}, id="sigma-1elem-seq"),
            pytest.param({"GaussNoise": {"std_range": 0.05, "p": 0.5}}, id="std_range-scalar"),
        ],
    )
    def test_scalar_or_pair_range_params_build(self, config):
        """Range params accept a scalar or a pair, as Albumentations does.

        ``_make_rotate`` already accepts either form for ``limit``; these builders used to raise a bare ``TypeError``
        from inside Kornia on a config that is valid for the CPU path.
        """
        assert build_kornia_pipeline(config, 560) is not None

    @pytest.mark.parametrize(
        ("blur_limit", "expected"),
        [
            pytest.param((3, 7), (7, 7), id="odd-upper-bound"),
            pytest.param((3, 6), (7, 7), id="even-upper-bound-rounds-up"),
        ],
    )
    def test_blur_limit_pair_uses_upper_bound(self, blur_limit, expected):
        """A ``(min, max)`` ``blur_limit`` resolves to its upper bound, rounded up to an odd kernel size."""
        pipeline = build_kornia_pipeline({"GaussianBlur": {"blur_limit": blur_limit, "p": 1.0}}, 560)
        transform = next(iter(pipeline.children()))
        assert transform.flags["kernel_size"] == expected

    def test_scalar_std_range_is_used_verbatim(self, mocker) -> None:
        """A scalar ``std_range`` is used as-is, with no per-sample-drift warning emitted."""
        mock_warning = mocker.patch.object(kornia_transforms.logger, "warning")
        pipeline = kornia_transforms.build_kornia_pipeline({"GaussNoise": {"std_range": 0.05, "p": 1.0}}, 560)

        transform = next(iter(pipeline.children()))
        image = torch.ones(1, 3, 16, 16)
        torch.manual_seed(0)
        expected = image + torch.randn_like(image) * 0.05
        torch.manual_seed(0)
        torch.testing.assert_close(transform(image), expected, rtol=1e-4, atol=1e-6)
        mock_warning.assert_not_called()

    def test_hflip_disabled_for_keypoint_pipeline(self, mocker):
        """Keypoint-mode Kornia augmentation drops hflip transforms with a warning."""
        config = {"HorizontalFlip": {"p": 0.5}, "VerticalFlip": {"p": 0.5}}
        warning = mocker.patch.object(kornia_transforms.logger, "warning")

        pipeline = kornia_transforms.build_kornia_pipeline(config, 560, include_keypoints=True)

        transform_names = [child.__class__.__name__ for child in pipeline.children()]
        assert "RandomHorizontalFlip" not in transform_names
        assert "RandomVerticalFlip" in transform_names
        assert warning.called
        assert "HorizontalFlip" in str(warning.call_args)
        image = torch.zeros(1, 3, 16, 16)
        boxes = torch.tensor([[[1.0, 1.0, 8.0, 8.0]]])
        assert len(pipeline(image, boxes)) == 2

    def test_keypoint_pipeline_rejects_unpaired_flip_index(self) -> None:
        """A malformed joint-pair list fails before the first training batch."""
        with pytest.raises(ValueError) as exc_info:
            build_kornia_pipeline({"HorizontalFlip": {"p": 1.0}}, 16, include_keypoints=True, keypoint_flip_pairs=[0])

        assert "even number" in str(exc_info.value)

    # --- pixel-level transforms added for issue #1252 -------------------

    @pytest.mark.parametrize(
        ("name", "params", "expected"),
        [
            pytest.param("Blur", {"blur_limit": 5}, "RandomBoxBlur", id="blur"),
            pytest.param("Sharpen", {"alpha": (0.2, 0.5)}, "RandomSharpness", id="sharpen"),
            pytest.param("Equalize", {}, "RandomEqualize", id="equalize"),
            pytest.param("CLAHE", {"clip_limit": 4.0}, "RandomClahe", id="clahe"),
        ],
    )
    def test_pixel_transforms_map_to_kornia(self, name, params, expected):
        """Each documented pixel-level name builds its Kornia counterpart (issue #1252)."""
        pipeline = build_kornia_pipeline({name: params}, 560)
        assert expected in [child.__class__.__name__ for child in pipeline.children()]

    @pytest.mark.parametrize(
        ("name", "params"),
        [
            pytest.param("Blur", {"blur_limit": (3, 7)}, id="blur"),
            pytest.param("Sharpen", {"alpha": (0.2, 0.5)}, id="sharpen"),
            pytest.param("Equalize", {"p": 0.5}, id="equalize"),
            pytest.param("CLAHE", {"clip_limit": 4.0, "tile_grid_size": (8, 8)}, id="clahe"),
        ],
    )
    @_requires_albumentations
    def test_pixel_transforms_accepted_by_both_backends(self, name, params):
        """The same config builds on either backend, which is the gap issue #1252 reports."""
        config = {name: params}
        assert build_kornia_pipeline(config, 560) is not None

        wrappers = AlbumentationsWrapper.from_config(config)
        assert len(wrappers) == 1, (
            "from_config(strict=False) silently drops unresolved transforms, so length must be checked"
        )
        built = [t.__class__.__name__ for t in wrappers[0].transform.transforms]
        assert name in built, f"expected {name}, got {built}"

    @pytest.mark.parametrize(("blur_limit", "expected"), [(5, 5), (4, 5), ((3, 7), 7), ((3, 6), 7), (2, 3)])
    def test_blur_kernel_is_odd_and_at_least_three(self, blur_limit, expected):
        """Blur resolves its kernel the same way GaussianBlur does: odd, >= 3, upper bound of a pair."""
        pipeline = build_kornia_pipeline({"Blur": {"blur_limit": blur_limit}}, 560)
        transform = next(iter(pipeline.children()))
        assert transform.flags["kernel_size"] == (expected, expected)

    @pytest.mark.parametrize(
        ("config", "expected_message"),
        [
            # A non-degenerate pair the user chose explicitly collapses to one kernel, so it must say so.
            pytest.param({"Blur": {"blur_limit": (3, 5)}}, "Blur", id="blur-fixed-kernel"),
            # Lightness has no Kornia equivalent, so dropping it must be announced.
            pytest.param({"Sharpen": {"lightness": (0.5, 1.0)}}, "lightness", id="sharpen-ignored-lightness"),
            # mode/by_channels/mask are albumentations-only.
            pytest.param({"Equalize": {"by_channels": False}}, "by_channels", id="equalize-ignored-by_channels"),
        ],
    )
    def test_dropped_or_collapsed_options_warn_with_the_option_name(self, mocker, config, expected_message):
        """Building a config that silently collapses a range or drops an option must warn, naming what changed."""
        warning = mocker.patch.object(kornia_transforms.logger, "warning")
        kornia_transforms.build_kornia_pipeline(config, 560)
        assert warning.called
        assert expected_message in str(warning.call_args)

    def test_blur_degenerate_pair_does_not_warn(self, mocker):
        """(5, 5) loses nothing, so it should stay quiet."""
        warning = mocker.patch.object(kornia_transforms.logger, "warning")
        kornia_transforms.build_kornia_pipeline({"Blur": {"blur_limit": (5, 5)}}, 560)
        warning.assert_not_called()

    def test_blur_library_default_pair_logs_at_debug_not_warning(self, mocker):
        """(3, 7) is Albumentations' own Blur default, an expected divergence, so it must stay off WARNING."""
        warning = mocker.patch.object(kornia_transforms.logger, "warning")
        debug = mocker.patch.object(kornia_transforms.logger, "debug")

        kornia_transforms.build_kornia_pipeline({"Blur": {"blur_limit": (3, 7)}}, 560)

        warning.assert_not_called()
        assert debug.called
        assert "Blur" in str(debug.call_args)

    @pytest.mark.parametrize(
        "blur_limit",
        [
            pytest.param([], id="empty-sequence"),
            pytest.param((1, 2, 3), id="three-element-sequence"),
        ],
    )
    def test_blur_kernel_rejects_invalid_sequence_length(self, blur_limit):
        """A sequence that is neither a scalar nor a (min, max) pair must raise, not silently misresolve."""
        with pytest.raises(ValueError) as exc_info:
            build_kornia_pipeline({"Blur": {"blur_limit": blur_limit}}, 560)

        assert "Kernel size parameter must be" in str(exc_info.value)

    def test_sharpen_shifts_alpha_to_kornias_one_pivoted_sharpness_range(self):
        """Albumentations' alpha (0=no-op) is shifted to Kornia's sharpness (1.0=no-op): sharpness = 1.0 + alpha."""
        pipeline = build_kornia_pipeline({"Sharpen": {"alpha": (0.1, 0.4)}}, 560)
        transform = next(iter(pipeline.children()))
        # Kornia keeps sampled ranges on the parameter generator rather than in `flags`; see
        # `_sharpness_sampler_range` for why this reads a private attribute.
        assert _sharpness_sampler_range(transform) == pytest.approx((1.1, 1.4))

    def test_sharpen_default_alpha_sharpens_not_blurs(self):
        """Regression guard: at the default alpha=(0.2, 0.5), Sharpen must raise edge energy, not lower it.

        Kornia's ``sharpness`` is pivoted at 1.0 (0=blur, 1=no-op, >1=sharpen), Albumentations' ``alpha`` at 0. Passing
        ``alpha`` through unshifted (the pre-fix bug) gives (0.2, 0.5), below the no-op point, so a step edge blurs. The
        fixed mapping resolves to ``sharpness=(1.2, 1.5)``, which sharpens.
        """
        size = 16
        img = torch.full((1, 3, size, size), 0.3)
        img[:, :, :, size // 2 :] = 0.7  # a single sharp step edge down the middle column
        boxes = torch.tensor([[[0.0, 0.0, float(size), float(size)]]], dtype=torch.float32)

        pipeline = build_kornia_pipeline({"Sharpen": {"p": 1.0}}, 560)
        img_out, _ = pipeline(img, boxes)

        def edge_energy(x: torch.Tensor) -> float:
            # Exclude the outer 2-pixel ring: Kornia's sharpness leaves border pixels unchanged (see
            # kornia.enhance.adjust.sharpness), so including them would dilute the interior sharpening signal.
            interior = x[:, :, 2:-2, 2:-2]
            return (torch.diff(interior, dim=-1).abs().mean() + torch.diff(interior, dim=-2).abs().mean()).item()

        assert edge_energy(img_out) > edge_energy(img), (
            "Sharpen at the default alpha=(0.2, 0.5) must increase edge energy (sharpen); an unchanged or lower "
            "value means the pivot-point bug regressed (sharpness range fell back to (0.2, 0.5), which blurs)."
        )

    def test_clahe_maps_both_parameters(self):
        """clip_limit and tile_grid_size map straight onto Kornia's clip_limit and grid_size."""
        pipeline = build_kornia_pipeline({"CLAHE": {"clip_limit": (2.0, 6.0), "tile_grid_size": (4, 4)}}, 560)
        transform = next(iter(pipeline.children()))
        assert tuple(transform.flags["grid_size"]) == (4, 4)
        # Unlike Sharpen's sharpness range, RandomClahe exposes its range on a plain public
        # `clip_limit` attribute (set directly from the constructor arg), so no private access needed.
        assert tuple(transform.clip_limit) == pytest.approx((2.0, 6.0))

    @pytest.mark.parametrize(
        "configured,expected",
        [
            pytest.param(None, (1.0, 4.0), id="default"),
            pytest.param(4.0, (1.0, 4.0), id="scalar-default-value"),
            pytest.param(2.0, (1.0, 2.0), id="scalar"),
            pytest.param((1.0, 4.0), (1.0, 4.0), id="pair"),
            pytest.param((2.0, 6.0), (2.0, 6.0), id="pair-non-default"),
        ],
    )
    def test_clahe_scalar_clip_limit_is_a_range_not_a_fixed_value(
        self, configured: float | tuple[float, float] | None, expected: tuple[float, float]
    ) -> None:
        """Albumentations reads a scalar clip_limit as (1, v), so the GPU path must too.

        Passing it through `_as_range` produced the degenerate (v, v), which pins every sample to maximum contrast
        enhancement while the CPU path varies it. 4.0 is the default on both sides, so that divergence applied with no
        user config at all.
        """
        params = {} if configured is None else {"clip_limit": configured}
        pipeline = build_kornia_pipeline({"CLAHE": params}, 560)
        transform = next(iter(pipeline.children()))

        assert tuple(transform.clip_limit) == pytest.approx(expected)

    @pytest.mark.parametrize(
        "configured",
        [
            4.0,
            2.0,
            pytest.param((2.0, 6.0), id="pair"),
            pytest.param([1.0, 4.0], id="list-pair"),
        ],
    )
    @_requires_albumentations
    def test_clahe_clip_limit_matches_albumentations(
        self, configured: float | tuple[float, float] | list[float]
    ) -> None:
        """The contract stated directly: same config, same range on both backends."""
        import albumentations

        pipeline = build_kornia_pipeline({"CLAHE": {"clip_limit": configured}}, 560)
        transform = next(iter(pipeline.children()))
        cpu = albumentations.CLAHE(clip_limit=configured)

        assert tuple(transform.clip_limit) == pytest.approx(tuple(cpu.clip_limit)), (
            f"backends disagree for clip_limit={configured!r}"
        )

    @pytest.mark.parametrize(
        "configured",
        [
            pytest.param([4.0], id="one-list"),
            pytest.param((4.0,), id="one-tuple"),
            pytest.param((1.0, 2.0, 3.0), id="three"),
        ],
    )
    def test_clahe_rejects_sequences_that_albumentations_rejects(
        self, configured: tuple[float, ...] | list[float]
    ) -> None:
        """A one-element sequence is not a scalar.

        Albumentations validates `clip_limit` as a float or an exact 2-tuple and raises on `[4.0]`. Reading it as a
        scalar here would accept a config the CPU backend refuses, which is the divergence this helper exists to remove.
        """
        with pytest.raises(ValueError) as exc_info:
            build_kornia_pipeline({"CLAHE": {"clip_limit": configured}}, 560)

        assert "2-element" in str(exc_info.value)


@_requires_kornia
class TestCollateBoxes:
    """collate_boxes packs variable-length boxes into [B, N_max, 4] with mask."""

    def _make_targets(self, box_counts):
        """Build a list of target dicts with the given per-image box counts.

        Each box is a valid xyxy rectangle within a 100x100 image.
        """
        targets = []
        for n in box_counts:
            boxes = (
                torch.tensor([[10.0, 10.0, 50.0, 50.0]] * n, dtype=torch.float32)
                if n > 0
                else torch.zeros(0, 4, dtype=torch.float32)
            )
            targets.append({"boxes": boxes})
        return targets

    @pytest.mark.parametrize(
        ("box_counts", "expected_boxes_shape", "expected_valid_shape"),
        [
            pytest.param([2, 3], (2, 3, 4), (2, 3), id="two-images-padded-to-max"),
            pytest.param([], (0, 0, 4), (0, 0), id="empty-batch"),
            pytest.param([0], (1, 0, 4), (1, 0), id="image-without-boxes"),
            pytest.param([3], (1, 3, 4), (1, 3), id="single-image"),
        ],
    )
    def test_pads_to_max_box_count(self, box_counts, expected_boxes_shape, expected_valid_shape):
        """Boxes pack into [B, N_max, 4] with a boolean validity mask [B, N_max], including empty batches."""
        boxes_padded, valid = collate_boxes(self._make_targets(box_counts), torch.device("cpu"))

        assert boxes_padded.shape == expected_boxes_shape, f"Expected {expected_boxes_shape}, got {boxes_padded.shape}"
        assert valid.shape == expected_valid_shape, f"Expected valid {expected_valid_shape}, got {valid.shape}"
        assert valid.dtype == torch.bool

    def test_valid_mask_matches_box_count(self):
        """The valid mask has True for real boxes and False for padding."""
        targets = self._make_targets([1, 3])
        _, valid = collate_boxes(targets, torch.device("cpu"))

        # Image 0: 1 real box, 2 padding → [True, False, False]
        assert valid[0].tolist() == [True, False, False], f"Image 0 valid mask wrong: {valid[0].tolist()}"
        # Image 1: 3 real boxes, 0 padding → [True, True, True]
        assert valid[1].tolist() == [True, True, True], f"Image 1 valid mask wrong: {valid[1].tolist()}"


@_requires_kornia
class TestUnpackBoxes:
    """unpack_boxes writes augmented boxes back and removes zero-area entries."""

    def _make_inputs(
        self,
        boxes_aug,
        valid_mask,
        original_targets,
        image_height=100,
        image_width=100,
    ):
        """Return tensors suitable for unpack_boxes."""
        boxes_tensor = torch.tensor(boxes_aug, dtype=torch.float32)
        valid_tensor = torch.tensor(valid_mask, dtype=torch.bool)
        return boxes_tensor, valid_tensor, original_targets, image_height, image_width

    def test_boxes_follow_masks_and_empty_masks_drop_instances(self):
        """Boxes become the tight mask extent; an instance whose mask vanished is dropped; box-only stays."""
        boxes_aug = [[[0.0, 0.0, 90.0, 90.0], [10.0, 10.0, 40.0, 40.0], [50.0, 50.0, 70.0, 70.0]]]
        valid = [[True, True, True]]
        masks_in = torch.zeros(3, 100, 100, dtype=torch.bool)
        masks_in[0, 20:30, 20:60] = True
        masks_in[1, 10:40, 10:40] = True
        masks_aug = torch.zeros(1, 3, 100, 100)
        masks_aug[0, 0, 20:30, 20:60] = 1.0
        targets = [
            {
                "boxes": torch.tensor([[20.0, 20.0, 60.0, 30.0], [10.0, 10.0, 40.0, 40.0], [50.0, 50.0, 70.0, 70.0]]),
                "labels": torch.tensor([1, 2, 3]),
                "area": torch.tensor([400.0, 900.0, 400.0]),
                "iscrowd": torch.tensor([0, 0, 1]),
                "masks": masks_in,
            }
        ]
        boxes_t, valid_t, tgts, height, width = self._make_inputs(boxes_aug, valid, targets)

        result = unpack_boxes(boxes_t, valid_t, tgts, height, width, masks_aug=masks_aug)

        assert result[0]["labels"].tolist() == [1, 3]
        assert result[0]["iscrowd"].tolist() == [0, 1]
        assert result[0]["boxes"].tolist() == [[20.0, 20.0, 60.0, 30.0], [50.0, 50.0, 70.0, 70.0]]
        assert result[0]["masks"].shape == (2, 100, 100)

    def test_all_boxes_removed_after_aug(self):
        """When all augmented boxes are zero-area, output targets have empty boxes."""
        # B=1, N=2: both boxes are zero-area (x1==x2 or y1==y2)
        boxes_aug = [[[10.0, 10.0, 10.0, 10.0], [20.0, 20.0, 20.0, 20.0]]]
        valid = [[True, True]]
        targets = [
            {
                "boxes": torch.tensor([[10.0, 10.0, 50.0, 50.0], [20.0, 20.0, 60.0, 60.0]]),
                "labels": torch.tensor([1, 2]),
                "area": torch.tensor([1600.0, 1600.0]),
                "iscrowd": torch.tensor([0, 0]),
            }
        ]
        boxes_t, valid_t, tgts, image_height, image_width = self._make_inputs(boxes_aug, valid, targets)
        result = unpack_boxes(boxes_t, valid_t, tgts, image_height, image_width)

        assert result[0]["boxes"].shape[0] == 0, (
            f"Expected 0 boxes after zero-area removal, got {result[0]['boxes'].shape[0]}"
        )
        assert result[0]["labels"].shape[0] == 0

    def test_partial_removal(self):
        """Some boxes survive, some removed; labels/area/iscrowd synced."""
        # Box 0: valid, non-zero area; Box 1: zero-area
        boxes_aug = [[[10.0, 10.0, 50.0, 50.0], [30.0, 30.0, 30.0, 30.0]]]
        valid = [[True, True]]
        targets = [
            {
                "boxes": torch.tensor([[10.0, 10.0, 50.0, 50.0], [30.0, 30.0, 70.0, 70.0]]),
                "labels": torch.tensor([1, 2]),
                "area": torch.tensor([1600.0, 1600.0]),
                "iscrowd": torch.tensor([0, 1]),
            }
        ]
        boxes_t, valid_t, tgts, image_height, image_width = self._make_inputs(boxes_aug, valid, targets)
        result = unpack_boxes(boxes_t, valid_t, tgts, image_height, image_width)

        assert result[0]["boxes"].shape[0] == 1, f"Expected 1 surviving box, got {result[0]['boxes'].shape[0]}"
        assert result[0]["labels"].tolist() == [1]

    def test_labels_area_iscrowd_sync(self):
        """When boxes are removed, labels/area/iscrowd entries are also removed."""
        # Box 0: zero-area (removed), Box 1: valid
        boxes_aug = [[[5.0, 5.0, 5.0, 5.0], [10.0, 10.0, 40.0, 40.0]]]
        valid = [[True, True]]
        targets = [
            {
                "boxes": torch.tensor([[5.0, 5.0, 30.0, 30.0], [10.0, 10.0, 40.0, 40.0]]),
                "labels": torch.tensor([7, 9]),
                "area": torch.tensor([625.0, 900.0]),
                "iscrowd": torch.tensor([0, 1]),
            }
        ]
        boxes_t, valid_t, tgts, image_height, image_width = self._make_inputs(boxes_aug, valid, targets)
        result = unpack_boxes(boxes_t, valid_t, tgts, image_height, image_width)

        assert result[0]["labels"].tolist() == [9], (
            f"Expected label [9] after removal of box 0, got {result[0]['labels'].tolist()}"
        )
        assert result[0]["area"].shape[0] == 1
        assert result[0]["iscrowd"].tolist() == [1]

    def test_boxes_clamped_to_image_bounds(self):
        """Boxes outside [0,W]x[0,H] are clamped to image bounds."""
        # Box extends beyond 100x100 image
        boxes_aug = [[[-10.0, -5.0, 120.0, 110.0]]]
        valid = [[True]]
        targets = [
            {
                "boxes": torch.tensor([[0.0, 0.0, 90.0, 90.0]]),
                "labels": torch.tensor([1]),
                "area": torch.tensor([8100.0]),
                "iscrowd": torch.tensor([0]),
            }
        ]
        image_height, image_width = 100, 100
        boxes_t, valid_t, tgts, image_height, image_width = self._make_inputs(
            boxes_aug,
            valid,
            targets,
            image_height,
            image_width,
        )
        result = unpack_boxes(boxes_t, valid_t, tgts, image_height, image_width)

        result_boxes = result[0]["boxes"]
        assert result_boxes.shape[0] == 1, "Clamped box should survive (non-zero area)"
        # Verify clamping: x1>=0, y1>=0, x2<=W, y2<=H
        assert result_boxes[0, 0].item() >= 0.0, "x1 not clamped to >= 0"
        assert result_boxes[0, 1].item() >= 0.0, "y1 not clamped to >= 0"
        assert result_boxes[0, 2].item() <= image_width, f"x2 not clamped to <= {image_width}"
        assert result_boxes[0, 3].item() <= image_height, f"y2 not clamped to <= {image_height}"


@_requires_kornia
class TestRotateFactory:
    """Rotate factory translates limit (scalar or tuple) to K.RandomRotation(degrees=...)."""

    @pytest.mark.parametrize(
        ("limit", "expected"),
        [
            pytest.param(45, (-45.0, 45.0), id="scalar-is-symmetric"),
            pytest.param((90, 90), (90.0, 90.0), id="tuple-is-verbatim"),
        ],
    )
    def test_limit_maps_to_degrees(self, limit, expected):
        """A scalar ``limit`` becomes ``degrees=(-limit, limit)``; a pair is passed through."""
        pipeline = build_kornia_pipeline({"Rotate": {"limit": limit, "p": 1.0}}, 560)

        degrees = _only_child(pipeline, "RandomRotation").flags["degrees"]
        assert (float(degrees[0]), float(degrees[1])) == pytest.approx(expected, abs=0.1)

    def test_flags_include_degrees(self):
        """Rotate factory keeps a legacy degrees entry in Kornia flags for compatibility."""
        pipeline = build_kornia_pipeline({"Rotate": {"limit": 30, "p": 1.0}}, 560)

        assert _only_child(pipeline, "RandomRotation").flags["degrees"] == (-30, 30)


class TestGpuPostprocessFlag:
    """gpu_postprocess flag controls whether aug + normalize appear in CPU pipeline."""

    def test_gpu_postprocess_true_omits_aug_and_normalize_from_train(self):
        """gpu_postprocess=True: train pipeline has no CPU augmentation or Normalize."""
        pipeline_gpu = make_coco_transforms("train", 560, gpu_postprocess=True)
        pipeline_cpu = make_coco_transforms("train", 560, gpu_postprocess=False)

        steps_gpu = pipeline_gpu.transforms
        steps_cpu = pipeline_cpu.transforms

        normalize_gpu = [s for s in steps_gpu if isinstance(s, Normalize)]
        assert len(normalize_gpu) == 0, "gpu_postprocess=True must omit Normalize from train pipeline"

        assert not any(isinstance(s, RandomHorizontalFlip) for s in steps_gpu)
        assert any(isinstance(s, RandomHorizontalFlip) for s in steps_cpu)

    def test_gpu_postprocess_false_includes_aug_and_normalize_from_train(self):
        """gpu_postprocess=False (default): train pipeline includes Normalize."""
        pipeline = make_coco_transforms("train", 560, gpu_postprocess=False)
        steps = pipeline.transforms

        normalize_steps = [s for s in steps if isinstance(s, Normalize)]
        assert len(normalize_steps) > 0, "gpu_postprocess=False must include Normalize in train pipeline"

    def test_val_path_unaffected_by_gpu_postprocess(self):
        """Val pipeline is unchanged regardless of gpu_postprocess value."""
        pipeline_default = make_coco_transforms("val", 560, gpu_postprocess=False)
        pipeline_gpu = make_coco_transforms("val", 560, gpu_postprocess=True)

        # Both should have Normalize (val is never stripped)
        norm_default = [s for s in pipeline_default.transforms if isinstance(s, Normalize)]
        norm_gpu = [s for s in pipeline_gpu.transforms if isinstance(s, Normalize)]

        assert len(norm_default) > 0, "Val pipeline (default) must include Normalize"
        assert len(norm_gpu) > 0, "Val pipeline (gpu_postprocess=True) must include Normalize"

        # Same number of pipeline steps
        assert len(pipeline_default.transforms) == len(pipeline_gpu.transforms), (
            "Val pipeline step count must be identical regardless of gpu_postprocess"
        )


@_requires_kornia
class TestGaussianBlurMinKernel:
    """_make_gaussian_blur enforces kernel_size >= 3 regardless of blur_limit."""

    @pytest.mark.parametrize("blur_limit", [1, 2])
    def test_small_blur_limit_produces_valid_kernel(self, blur_limit):
        """blur_limit below 3 must be clamped so the resulting kernel_size >= 3 (blur_limit=1 once gave (3, 1))."""
        pipeline = build_kornia_pipeline({"GaussianBlur": {"blur_limit": blur_limit, "p": 1.0}}, 560)

        ks = _only_child(pipeline, "RandomGaussianBlur").flags["kernel_size"]
        assert int(ks[0]) >= 3, f"kernel_size[0]={int(ks[0])} must be >= 3"
        assert int(ks[1]) >= 3, f"kernel_size[1]={int(ks[1])} must be >= 3"

    def test_blur_limit_3_unchanged(self):
        """blur_limit=3 (default) passes through without modification."""
        pipeline = build_kornia_pipeline({"GaussianBlur": {"blur_limit": 3, "p": 1.0}}, 560)

        ks = _only_child(pipeline, "RandomGaussianBlur").flags["kernel_size"]
        assert (int(ks[0]), int(ks[1])) == (3, 3)


@_requires_kornia
class TestKorniaPipelineForwardPass:
    """build_kornia_pipeline output passes through without shape/dtype errors."""

    def test_preserves_image_shape_and_box_layout(self):
        """Pipeline output images have same shape as input; boxes shape is [B, N, 4]."""
        pipeline = build_kornia_pipeline({"HorizontalFlip": {"p": 1.0}}, resolution=64)

        batch_size, channels, image_height, image_width = 2, 3, 64, 64
        img = torch.rand(batch_size, channels, image_height, image_width)
        boxes = torch.tensor([[[0.0, 0.0, 32.0, 32.0]], [[10.0, 10.0, 50.0, 50.0]]], dtype=torch.float32)

        img_out, boxes_out = pipeline(img, boxes)

        assert img_out.shape == (batch_size, channels, image_height, image_width), (
            f"Image shape changed: {img_out.shape}"
        )
        assert img_out.dtype == torch.float32
        assert boxes_out.shape == (batch_size, 1, 4), f"Boxes shape wrong: {boxes_out.shape}"

    def test_handles_empty_boxes(self):
        """Pipeline handles a batch where N_max=0 (no boxes) without error."""
        pipeline = build_kornia_pipeline({"HorizontalFlip": {"p": 1.0}}, resolution=32)

        batch_size, channels, image_height, image_width = 2, 3, 32, 32
        img = torch.rand(batch_size, channels, image_height, image_width)
        # [B, 0, 4] — no boxes
        boxes = torch.zeros(batch_size, 0, 4, dtype=torch.float32)

        img_out, boxes_out = pipeline(img, boxes)

        assert img_out.shape == (batch_size, channels, image_height, image_width)
        assert boxes_out.shape == (batch_size, 0, 4)


class TestCollateMasks:
    """collate_masks packs [N_i, H, W] instance masks into [B, N_max, H, W]."""

    def _make_targets_with_masks(self, mask_counts, h=16, w=16):
        """Build target dicts with boolean mask tensors for given instance counts."""
        targets = []
        for n in mask_counts:
            masks = torch.ones(n, h, w, dtype=torch.bool) if n > 0 else torch.zeros(0, h, w, dtype=torch.bool)
            targets.append({"masks": masks, "boxes": torch.zeros(n, 4)})
        return targets

    @pytest.mark.parametrize(
        ("mask_counts", "n_max", "expected_shape"),
        [
            pytest.param([2, 3], 3, (2, 3, 16, 16), id="two-images"),
            pytest.param([0, 0], 0, (2, 0, 16, 16), id="n-max-zero"),
            pytest.param([], 0, (0, 0, 16, 16), id="empty-target-list"),
        ],
    )
    def test_packs_masks_into_float32_batch(self, mask_counts, n_max, expected_shape):
        """Masks pack into a [B, N_max, H, W] float32 tensor, including n_max=0 and an empty target list."""
        targets = self._make_targets_with_masks(mask_counts)
        masks_padded = collate_masks(targets, torch.device("cpu"), n_max=n_max, image_height=16, image_width=16)

        assert masks_padded.shape == expected_shape, f"Expected {expected_shape}, got {masks_padded.shape}"
        assert masks_padded.dtype == torch.float32, f"Expected float32, got {masks_padded.dtype}"

    def test_padding_is_zero(self):
        """Padded slots (beyond real instance count) are filled with zeros."""
        targets = self._make_targets_with_masks([1, 3])  # image 0 padded to 3
        masks_padded = collate_masks(targets, torch.device("cpu"), n_max=3, image_height=16, image_width=16)

        # Image 0: slot 0 real (ones), slots 1-2 zero-padded
        assert masks_padded[0, 0].min() == pytest.approx(1.0), "Real mask slot must be all ones"
        assert masks_padded[0, 1].max() == pytest.approx(0.0), "Padded slot 1 must be all zeros"
        assert masks_padded[0, 2].max() == pytest.approx(0.0), "Padded slot 2 must be all zeros"

    def test_targets_without_masks_key(self):
        """Targets without 'masks' key produce all-zero rows."""
        targets = [{"boxes": torch.zeros(2, 4)}, {"boxes": torch.zeros(1, 4)}]
        masks_padded = collate_masks(targets, torch.device("cpu"), n_max=2, image_height=8, image_width=8)

        assert masks_padded.shape == (2, 2, 8, 8)
        assert masks_padded.max() == pytest.approx(0.0), "Targets without masks key must produce all-zero output"


@_requires_kornia
class TestBuildKorniaPipelineWithMasks:
    """build_kornia_pipeline(with_masks=True) includes mask in data_keys."""

    def test_with_masks_false_is_default(self):
        """with_masks defaults to False; pipeline returns (img, boxes) on call."""
        pipeline = build_kornia_pipeline({"HorizontalFlip": {"p": 1.0}}, resolution=32)
        img = torch.rand(1, 3, 32, 32)
        boxes = torch.tensor([[[0.0, 0.0, 16.0, 16.0]]])
        result = pipeline(img, boxes)
        assert len(result) == 2, f"Detection pipeline must return 2 values, got {len(result)}"

    def test_with_masks_true_returns_three_values(self):
        """with_masks=True: pipeline(img, boxes, masks) returns (img, boxes, masks)."""
        pipeline = build_kornia_pipeline({"HorizontalFlip": {"p": 1.0}}, resolution=32, with_masks=True)
        img = torch.rand(1, 3, 32, 32)
        boxes = torch.tensor([[[0.0, 0.0, 16.0, 16.0]]])
        masks = torch.ones(1, 1, 32, 32, dtype=torch.float32)
        result = pipeline(img, boxes, masks)
        assert len(result) == 3, f"Segmentation pipeline must return 3 values, got {len(result)}"

    def test_with_masks_true_preserves_mask_shape(self):
        """Mask shape [B, N, H, W] is preserved after pipeline pass."""
        pipeline = build_kornia_pipeline({"HorizontalFlip": {"p": 0.0}}, resolution=32, with_masks=True)
        img = torch.rand(2, 3, 32, 32)
        boxes = torch.tensor([[[0.0, 0.0, 16.0, 16.0]], [[8.0, 8.0, 24.0, 24.0]]])
        masks = torch.ones(2, 1, 32, 32, dtype=torch.float32)
        _, _, masks_aug = pipeline(img, boxes, masks)
        assert masks_aug.shape == (2, 1, 32, 32), f"Mask shape must be preserved: {masks_aug.shape}"

    def test_keypoint_pipeline_flips_points_with_boxes_and_masks(self) -> None:
        """A keypoint pipeline transports every geometric target in the same draw."""
        pipeline = build_kornia_pipeline(
            {"HorizontalFlip": {"p": 1.0}},
            16,
            with_masks=True,
            include_keypoints=True,
            with_keypoints=True,
            keypoint_flip_pairs=[0, 1],
        )
        image = torch.zeros(1, 3, 16, 16)
        boxes = torch.tensor([[[2.0, 2.0, 8.0, 8.0]]])
        masks = torch.zeros(1, 1, 16, 16)
        targets = [
            {
                "boxes": boxes[0],
                "labels": torch.tensor([1]),
                "keypoints": torch.tensor([[[3.0, 4.0, 2.0], [6.0, 7.0, 1.0], [0.0, 0.0, 2.0]]]),
            }
        ]
        points, visibility = collate_keypoints(targets, torch.device("cpu"), n_max=1)

        _, boxes_out, _, points_out = pipeline(image, boxes - 0.5, masks, points - 0.5)
        result = unpack_boxes(
            boxes_out + 0.5,
            torch.tensor([[True]]),
            targets,
            16,
            16,
            keypoints_aug=points_out + 0.5,
            keypoint_visibility=visibility,
            keypoint_flip_pairs=[0, 1],
            keypoint_flip_mask=torch.tensor([True]),
        )

        torch.testing.assert_close(
            result[0]["keypoints"], torch.tensor([[[10.0, 7.0, 1.0], [13.0, 4.0, 2.0], [16.0, 0.0, 2.0]]])
        )


@_requires_kornia
class TestKeypointTargetTransport:
    """Keypoints retain visibility and instance alignment through GPU augmentation."""

    def test_horizontal_flip_matches_torchvision_continuous_coordinates_on_boundary(self) -> None:
        """Kornia matches the default CPU backend's continuous keypoint convention."""
        target = {
            "boxes": torch.tensor([[0.0, 2.0, 8.0, 12.0]]),
            "labels": torch.tensor([0]),
            "keypoints": torch.tensor([[[0.0, 8.0, 2.0], [3.0, 8.0, 2.0]]]),
        }
        cpu_flip = RandomHorizontalFlip(p=1.0, keypoint_flip_pairs=[0, 1])
        _, cpu_target = cpu_flip(torch.zeros(3, 16, 16), target)
        pipeline = build_kornia_pipeline(
            {"HorizontalFlip": {"p": 1.0}}, 16, with_masks=True, with_keypoints=True, keypoint_flip_pairs=[0, 1]
        )
        points, visibility = collate_keypoints([target], torch.device("cpu"), 1)
        _, boxes, _, points = pipeline(
            torch.zeros(1, 3, 16, 16), target["boxes"].unsqueeze(0) - 0.5, torch.zeros(1, 1, 16, 16), points - 0.5
        )
        gpu_target = unpack_boxes(
            boxes + 0.5,
            torch.tensor([[True]]),
            [target],
            16,
            16,
            keypoints_aug=points + 0.5,
            keypoint_visibility=visibility,
            keypoint_flip_pairs=[0, 1],
            keypoint_flip_mask=keypoint_horizontal_flip_mask(pipeline, 1, torch.device("cpu")),
        )[0]
        torch.testing.assert_close(cpu_target["keypoints"], torch.tensor([[[13.0, 8.0, 2.0], [16.0, 8.0, 2.0]]]))
        torch.testing.assert_close(gpu_target["keypoints"], cpu_target["keypoints"])

    def test_flip_mask_tracks_each_image(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """A batch can flip one image without relabeling joints in another.

        The pipeline is a real one-flip ``AugmentationSequential`` whose sampled draws are replaced by a known per-image
        pattern, so the mask must follow the draw of each image.
        """
        pipeline = build_kornia_pipeline(
            {"HorizontalFlip": {"p": 0.5}}, 16, with_masks=True, with_keypoints=True, keypoint_flip_pairs=[0, 1]
        )
        draw = SimpleNamespace(name="RandomHorizontalFlip_0", data={"batch_prob": torch.tensor([1.0, 0.0])})
        monkeypatch.setattr(pipeline, "_params", [draw], raising=False)

        assert keypoint_horizontal_flip_mask(pipeline, 2, torch.device("cpu")).tolist() == [True, False]

    def test_flip_mask_tracks_each_image_on_a_real_two_image_kornia_batch(self) -> None:
        """A real ``AugmentationSequential`` batch call swaps joints only for the image it actually flipped."""
        target = {
            "boxes": torch.tensor([[2.0, 2.0, 8.0, 8.0]]),
            "labels": torch.tensor([1]),
            "keypoints": torch.tensor([[[3.0, 4.0, 2.0], [6.0, 7.0, 1.0]]]),
        }
        targets = [target, target]
        points, visibility = collate_keypoints(targets, torch.device("cpu"), n_max=1)
        points = points - 0.5
        boxes = torch.stack([target["boxes"], target["boxes"]]) - 0.5
        image = torch.zeros(2, 3, 16, 16)
        masks = torch.zeros(2, 1, 16, 16)

        mask = None
        for seed in range(10):
            torch.manual_seed(seed)
            pipeline = build_kornia_pipeline(
                {"HorizontalFlip": {"p": 0.5}},
                16,
                with_masks=True,
                include_keypoints=True,
                with_keypoints=True,
                keypoint_flip_pairs=[0, 1],
            )
            _, boxes_aug, _, points_aug = pipeline(image.clone(), boxes.clone(), masks.clone(), points.clone())
            mask = keypoint_horizontal_flip_mask(pipeline, 2, torch.device("cpu"))
            if bool(mask[0]) != bool(mask[1]):
                break
        else:
            raise AssertionError("no seed in range(10) produced differing per-image Kornia flip draws")

        boxes_aug = boxes_aug + 0.5
        points_aug = points_aug + 0.5
        flipped_idx, identity_idx = (0, 1) if mask[0] else (1, 0)
        flipped_target = unpack_boxes(
            boxes_aug[flipped_idx : flipped_idx + 1],
            torch.tensor([[True]]),
            [target],
            16,
            16,
            keypoints_aug=points_aug[flipped_idx : flipped_idx + 1],
            keypoint_visibility=visibility[flipped_idx : flipped_idx + 1],
            keypoint_flip_pairs=[0, 1],
            keypoint_flip_mask=mask[flipped_idx : flipped_idx + 1],
        )[0]
        identity_target = unpack_boxes(
            boxes_aug[identity_idx : identity_idx + 1],
            torch.tensor([[True]]),
            [target],
            16,
            16,
            keypoints_aug=points_aug[identity_idx : identity_idx + 1],
            keypoint_visibility=visibility[identity_idx : identity_idx + 1],
            keypoint_flip_pairs=[0, 1],
            keypoint_flip_mask=mask[identity_idx : identity_idx + 1],
        )[0]

        torch.testing.assert_close(flipped_target["keypoints"], torch.tensor([[[10.0, 7.0, 1.0], [13.0, 4.0, 2.0]]]))
        torch.testing.assert_close(identity_target["keypoints"], target["keypoints"])

    def test_flip_draws_fail_closed_when_kornia_params_are_unavailable(self) -> None:
        """A changed Kornia parameter API cannot silently leave paired joints unswapped.

        A real pipeline holding a horizontal flip that has not run exposes no sampled draws, which is exactly what a
        Kornia release hiding its parameters looks like to the caller.
        """
        pipeline = build_kornia_pipeline(
            {"HorizontalFlip": {"p": 1.0}}, 16, with_masks=True, with_keypoints=True, keypoint_flip_pairs=[0, 1]
        )
        with pytest.raises(RuntimeError) as exc_info:
            keypoint_horizontal_flip_mask(pipeline, 1, torch.device("cpu"))

        assert "horizontal-flip draws" in str(exc_info.value)

    @pytest.mark.parametrize(
        ("config", "expected"),
        [
            pytest.param({"VerticalFlip": {"p": 1.0}}, (3.0, 12.0), id="vertical-flip"),
            pytest.param({"Rotate": {"limit": (90, 90), "p": 1.0}}, (4.0, 13.0), id="rotate-90"),
        ],
    )
    def test_geometric_transforms_use_continuous_coordinates(
        self, config: dict[str, dict[str, Any]], expected: tuple[float, float]
    ) -> None:
        """Flip and rotation agree with the default CPU path's continuous frame."""
        targets = [
            {
                "boxes": torch.tensor([[2.0, 2.0, 8.0, 8.0]]),
                "labels": torch.tensor([1]),
                "keypoints": torch.tensor([[[3.0, 4.0, 2.0]]]),
            }
        ]
        points, visibility = collate_keypoints(targets, torch.device("cpu"), 1)
        pipeline = build_kornia_pipeline(config, 16, with_masks=True, include_keypoints=True, with_keypoints=True)
        _, boxes_aug, _, points_aug = pipeline(
            torch.zeros(1, 3, 16, 16), targets[0]["boxes"].unsqueeze(0) - 0.5, torch.zeros(1, 1, 16, 16), points - 0.5
        )

        result = unpack_boxes(
            boxes_aug + 0.5,
            torch.tensor([[True]]),
            targets,
            16,
            16,
            keypoints_aug=points_aug + 0.5,
            keypoint_visibility=visibility,
        )

        torch.testing.assert_close(result[0]["keypoints"], torch.tensor([[[*expected, 2.0]]]))

    @pytest.mark.parametrize(
        "config",
        [
            pytest.param({"Affine": {"rotate": (90, 90), "p": 1.0}}, id="affine"),
            pytest.param(
                {"ShiftScaleRotate": {"shift_limit": 0.0, "scale_limit": 0.0, "rotate_limit": (90, 90), "p": 1.0}},
                id="shift-scale-rotate",
            ),
        ],
    )
    def test_fixed_rotation_moves_keypoint_to_analytic_position(self, config: dict[str, dict[str, Any]]) -> None:
        """A 90-degree Affine or ShiftScaleRotate turns a joint about the image center.

        With rotation pinned to ``(90, 90)`` and no shift or scale, the joint at ``(10, 12)`` on a 32-pixel image sits
        at ``(-6, -4)`` from the center ``(16, 16)``. Kornia's ``RandomAffine`` maps ``(dx, dy)`` to ``(-dy, dx)``, so
        the joint must land at ``(20, 10)``; an untransformed joint stays at ``(10, 12)``.
        """
        pipeline = build_kornia_pipeline(config, 32, with_masks=True, with_keypoints=True)
        boxes = torch.tensor([[[4.0, 4.0, 20.0, 20.0]]]) - 0.5
        point = torch.tensor([[[10.0, 12.0]]]) - 0.5

        _, _, _, point_out = pipeline(torch.zeros(1, 3, 32, 32), boxes, torch.zeros(1, 1, 32, 32), point)

        torch.testing.assert_close(point_out + 0.5, torch.tensor([[[20.0, 10.0]]]))

    @pytest.mark.parametrize(
        "config",
        [
            pytest.param(
                {"Affine": {"rotate": (0, 0), "translate_percent": (0.25, 0.25), "scale": (1.0, 1.0), "p": 1.0}},
                id="affine",
            ),
            pytest.param(
                {"ShiftScaleRotate": {"shift_limit": 0.25, "scale_limit": 0.0, "rotate_limit": 0, "p": 1.0}},
                id="shift-scale-rotate",
            ),
        ],
    )
    def test_translation_moves_keypoint_by_the_same_offset_as_its_box(self, config: dict[str, dict[str, Any]]) -> None:
        """A pure translation shifts a joint by exactly the offset it shifts the box, within the configured bound.

        The shift is sampled, so the offset is read off the box corner: the joint must move by the same nonzero
        ``(dx, dy)``, and that offset can never exceed ``0.25 * 32 = 8`` pixels on either axis.
        """
        pipeline = build_kornia_pipeline(config, 32, with_masks=True, with_keypoints=True)
        boxes = torch.tensor([[[4.0, 4.0, 20.0, 20.0]]]) - 0.5
        point = torch.tensor([[[10.0, 12.0]]]) - 0.5

        _, boxes_out, _, point_out = pipeline(torch.zeros(1, 3, 32, 32), boxes, torch.zeros(1, 1, 32, 32), point)

        box_offset = boxes_out[0, 0, :2] - boxes[0, 0, :2]
        torch.testing.assert_close(point_out[0, 0] - point[0, 0], box_offset)
        assert 0.5 < box_offset.abs().max() <= 8.0 + 1e-4, f"sampled offset {box_offset.tolist()} is not a real shift"

    @pytest.mark.parametrize(
        "config",
        [
            pytest.param({"Perspective": {"scale": (0.5, 0.5), "p": 1.0}}, id="perspective"),
            pytest.param({"Affine": {"rotate": (90, 90), "p": 1.0}}, id="affine-rotate"),
        ],
    )
    def test_keypoint_lands_on_the_warped_image_marker(self, config: dict[str, dict[str, Any]]) -> None:
        """A one-hot marker pixel and the joint placed on it end up at the same warped position.

        The marker sits at row 26, column 26 where the joint is. After the warp, the brightest pixel of the output image
        must be within one pixel of the transported joint, and that joint must have moved well away from its start so an
        untransformed joint cannot pass.
        """
        pipeline = build_kornia_pipeline(config, 32, with_keypoints=True)
        image = torch.zeros(1, 3, 32, 32)
        image[:, :, 26, 26] = 1.0
        boxes = torch.tensor([[[4.0, 4.0, 28.0, 28.0]]])
        point = torch.tensor([[[26.0, 26.0]]])

        image_out, _, point_out = pipeline(image, boxes, point)

        peak = image_out[0].mean(dim=0).flatten().argmax().item()
        marker_xy = torch.tensor([peak % 32, peak // 32], dtype=torch.float32)
        assert (point_out[0, 0] - point[0, 0]).abs().max() > 2.0, "joint barely moved; the check would be vacuous"
        assert (marker_xy - point_out[0, 0]).abs().max() <= 1.0, (
            f"joint {point_out[0, 0].tolist()} is not on the warped marker pixel {marker_xy.tolist()}"
        )

    def test_collate_keypoints_copies_coordinates_without_frame_shift(self) -> None:
        """Collated joints keep the caller's coordinate frame; any half-pixel shift is the caller's job.

        The data module shifts boxes and joints by ``-0.5`` around the pipeline itself, so the collate step must hand
        over the annotation coordinates untouched and park the visibility values in a separate tensor.
        """
        targets = [
            {"keypoints": torch.tensor([[[3.0, 4.0, 2.0], [6.0, 7.0, 0.0]], [[11.0, 12.0, 2.0], [13.0, 14.0, 1.0]]])}
        ]

        points, visibility = collate_keypoints(targets, torch.device("cpu"), n_max=2)

        torch.testing.assert_close(points, torch.tensor([[[3.0, 4.0], [6.0, 7.0], [11.0, 12.0], [13.0, 14.0]]]))
        torch.testing.assert_close(visibility, torch.tensor([[[2.0, 0.0], [2.0, 1.0]]]))

    def test_dropped_leading_instance_leaves_the_trailing_survivor_keypoints(self) -> None:
        """Dropping the first instance keeps the second instance's own joints, not the first's.

        Instance 0 collapses to zero width while instance 1 stays visible and in bounds, so an unpacker that keeps the
        first ``n_kept`` rows instead of the rows selected by the keep mask returns the wrong joints.
        """
        targets = [
            {
                "boxes": torch.tensor([[1.0, 1.0, 8.0, 8.0], [10.0, 10.0, 14.0, 14.0]]),
                "labels": torch.tensor([1, 2]),
                "keypoints": torch.tensor([[[3.0, 4.0, 2.0], [6.0, 7.0, 2.0]], [[11.0, 12.0, 2.0], [13.0, 14.0, 1.0]]]),
            }
        ]
        _, visibility = collate_keypoints(targets, torch.device("cpu"), n_max=2)
        boxes_aug = torch.tensor([[[1.0, 1.0, 1.0, 8.0], [10.0, 10.0, 14.0, 14.0]]])
        points_aug = torch.tensor([[[3.0, 4.0], [6.0, 7.0], [11.0, 12.0], [13.0, 14.0]]])

        result = unpack_boxes(
            boxes_aug,
            torch.tensor([[True, True]]),
            targets,
            16,
            16,
            keypoints_aug=points_aug,
            keypoint_visibility=visibility,
        )

        torch.testing.assert_close(result[0]["boxes"], torch.tensor([[10.0, 10.0, 14.0, 14.0]]))
        torch.testing.assert_close(result[0]["keypoints"], torch.tensor([[[11.0, 12.0, 2.0], [13.0, 14.0, 1.0]]]))

    @pytest.mark.parametrize(
        ("xy", "visibility"),
        [
            pytest.param((5.0, 6.0), 0.0, id="invisible-but-inside"),
            pytest.param((16.5, 6.0), 2.0, id="visible-but-right-of-image"),
            pytest.param((-0.5, 6.0), 2.0, id="visible-but-left-of-image"),
            pytest.param((5.0, 16.5), 2.0, id="visible-but-below-image"),
            pytest.param((5.0, -0.5), 2.0, id="visible-but-above-image"),
        ],
    )
    def test_invisible_or_outside_joint_is_zeroed_while_its_neighbor_survives(
        self, xy: tuple[float, float], visibility: float
    ) -> None:
        """A joint that is invisible or ends up outside the image is zeroed entirely, x, y and v.

        The instance and its second joint stay valid, so the zeroing must be per joint and must not touch the
        neighboring joint or drop the instance.
        """
        targets = [
            {
                "boxes": torch.tensor([[1.0, 1.0, 8.0, 8.0]]),
                "labels": torch.tensor([1]),
                "keypoints": torch.tensor([[[*xy, visibility], [6.0, 7.0, 2.0]]]),
            }
        ]
        _, visibility_tensor = collate_keypoints(targets, torch.device("cpu"), n_max=1)
        points_aug = torch.tensor([[[*xy], [6.0, 7.0]]])

        result = unpack_boxes(
            torch.tensor([[[1.0, 1.0, 8.0, 8.0]]]),
            torch.tensor([[True]]),
            targets,
            16,
            16,
            keypoints_aug=points_aug,
            keypoint_visibility=visibility_tensor,
        )

        torch.testing.assert_close(result[0]["keypoints"], torch.tensor([[[0.0, 0.0, 0.0], [6.0, 7.0, 2.0]]]))

    def test_joint_on_the_image_border_is_kept(self) -> None:
        """A visible joint exactly on ``x == W`` and ``y == 0`` is inside the closed image and is kept."""
        targets = [{"boxes": torch.tensor([[1.0, 1.0, 8.0, 8.0]]), "labels": torch.tensor([1])}]

        result = unpack_boxes(
            torch.tensor([[[1.0, 1.0, 8.0, 8.0]]]),
            torch.tensor([[True]]),
            targets,
            16,
            16,
            keypoints_aug=torch.tensor([[[16.0, 0.0]]]),
            keypoint_visibility=torch.tensor([[[2.0]]]),
        )

        torch.testing.assert_close(result[0]["keypoints"], torch.tensor([[[16.0, 0.0, 2.0]]]))

    def test_all_instances_dropped_leaves_empty_keypoints(self) -> None:
        """When every box collapses, the target keeps no boxes and no keypoint rows but still reports K joints."""
        targets = [
            {
                "boxes": torch.tensor([[1.0, 1.0, 8.0, 8.0], [10.0, 10.0, 14.0, 14.0]]),
                "labels": torch.tensor([1, 2]),
                "keypoints": torch.tensor([[[3.0, 4.0, 2.0], [6.0, 7.0, 2.0]], [[11.0, 12.0, 2.0], [13.0, 14.0, 1.0]]]),
            }
        ]
        points_aug, visibility = collate_keypoints(targets, torch.device("cpu"), n_max=2)
        boxes_aug = torch.tensor([[[1.0, 1.0, 1.0, 8.0], [10.0, 10.0, 14.0, 10.0]]])

        result = unpack_boxes(
            boxes_aug,
            torch.tensor([[True, True]]),
            targets,
            16,
            16,
            keypoints_aug=points_aug,
            keypoint_visibility=visibility,
        )

        assert result[0]["boxes"].shape == (0, 4)
        assert result[0]["keypoints"].shape == (0, 2, 3)

    def test_unequal_instance_counts_do_not_leak_padded_points(self) -> None:
        """Joint padding follows box padding for a mixed-size batch."""
        targets = [
            {
                "boxes": torch.tensor([[1.0, 1.0, 5.0, 5.0]]),
                "labels": torch.tensor([1]),
                "keypoints": torch.tensor([[[3.0, 3.0, 2.0]]]),
            },
            {
                "boxes": torch.tensor([[2.0, 2.0, 6.0, 6.0], [8.0, 8.0, 12.0, 12.0]]),
                "labels": torch.tensor([2, 3]),
                "keypoints": torch.tensor([[[4.0, 4.0, 1.0]], [[10.0, 10.0, 2.0]]]),
            },
        ]
        boxes, valid = collate_boxes(targets, torch.device("cpu"))
        points, visibility = collate_keypoints(targets, torch.device("cpu"), valid.shape[1])
        result = unpack_boxes(boxes, valid, targets, 16, 16, keypoints_aug=points, keypoint_visibility=visibility)

        assert [item["keypoints"].shape[0] for item in result] == [1, 2]
        torch.testing.assert_close(result[0]["keypoints"], targets[0]["keypoints"])
        torch.testing.assert_close(result[1]["keypoints"], targets[1]["keypoints"])


class TestUnpackBoxesWithMasks:
    """unpack_boxes with masks_aug keeps/removes masks in sync with boxes."""

    def test_masks_filtered_same_as_boxes(self):
        """Box removed → corresponding mask also removed from output."""
        # B=1, N=2: box 0 valid, box 1 zero-area (will be removed)
        boxes_aug = torch.tensor([[[5.0, 5.0, 25.0, 25.0], [30.0, 30.0, 30.0, 30.0]]])
        valid = torch.tensor([[True, True]])
        targets = [
            {
                "boxes": torch.tensor([[5.0, 5.0, 25.0, 25.0], [30.0, 30.0, 60.0, 60.0]]),
                "labels": torch.tensor([1, 2]),
            }
        ]
        # 2 masks: instance 0 = all ones, instance 1 = all twos (distinguishable)
        masks_aug = torch.zeros(1, 2, 8, 8, dtype=torch.float32)
        masks_aug[0, 0] = 1.0
        masks_aug[0, 1] = 1.0  # will be removed with box 1

        result = unpack_boxes(boxes_aug, valid, targets, 100, 100, masks_aug=masks_aug)

        assert "masks" in result[0], "masks key must be present in output target"
        assert result[0]["masks"].shape[0] == 1, f"Expected 1 surviving mask, got {result[0]['masks'].shape[0]}"

    def test_masks_converted_to_bool(self):
        """Float masks > 0.5 threshold converted to bool in output."""
        boxes_aug = torch.tensor([[[5.0, 5.0, 25.0, 25.0]]])
        valid = torch.tensor([[True]])
        targets = [{"boxes": torch.tensor([[5.0, 5.0, 25.0, 25.0]]), "labels": torch.tensor([1])}]
        masks_aug = torch.full((1, 1, 8, 8), 0.8, dtype=torch.float32)  # float, all 0.8

        result = unpack_boxes(boxes_aug, valid, targets, 100, 100, masks_aug=masks_aug)

        assert result[0]["masks"].dtype == torch.bool, f"masks must be bool, got {result[0]['masks'].dtype}"
        assert result[0]["masks"].all(), "All values > 0.5 should be True after thresholding"

    def test_no_masks_aug_leaves_masks_key_unchanged(self):
        """When masks_aug=None, existing masks key in target is preserved as-is."""
        boxes_aug = torch.tensor([[[5.0, 5.0, 25.0, 25.0]]])
        valid = torch.tensor([[True]])
        original_mask = torch.ones(1, 8, 8, dtype=torch.bool)
        targets = [
            {
                "boxes": torch.tensor([[5.0, 5.0, 25.0, 25.0]]),
                "labels": torch.tensor([1]),
                "masks": original_mask,
            }
        ]

        result = unpack_boxes(boxes_aug, valid, targets, 100, 100, masks_aug=None)

        assert "masks" in result[0], "masks key must still be present when masks_aug=None"
        assert result[0]["masks"] is original_mask, "Original masks object must be preserved unchanged"


@_requires_kornia
class TestGaussNoiseStdRangeWarning:
    """_make_gauss_noise warns when the configured std range is non-degenerate (GPU uses a fixed upper-bound std)."""

    @pytest.mark.parametrize(
        ("config", "expected_calls"),
        [
            pytest.param({"std_range": (0.01, 0.05), "p": 0.5}, 1, id="unequal-range-warns"),
            pytest.param({"std_range": (0.05, 0.05), "p": 0.5}, 0, id="degenerate-range-is-silent"),
            # The albumentations default range is non-degenerate, so omitting std_range still warns.
            pytest.param({"p": 0.3}, 1, id="default-range-warns"),
        ],
    )
    def test_warns_only_for_non_degenerate_std_range(self, mocker, config, expected_calls):
        """A non-degenerate std_range emits one divergence warning at build time; an equal-bound range stays silent."""
        mock_warning = mocker.patch.object(kornia_transforms.logger, "warning")
        kornia_transforms._make_gauss_noise(config)

        assert mock_warning.call_count == expected_calls


@_requires_kornia
class TestToGrayDroppedParamsWarning:
    """_make_to_gray warns when passed method/num_output_channels, which have no Kornia equivalent."""

    @pytest.mark.parametrize(
        ("config", "expected_calls"),
        [
            pytest.param({"method": "max", "p": 0.5}, 1, id="method"),
            pytest.param({"num_output_channels": 1, "p": 0.5}, 1, id="num_output_channels"),
            # Only p set matches the CPU path's default behavior, so nothing is dropped.
            pytest.param({"p": 0.5}, 0, id="p-only"),
        ],
    )
    def test_warns_only_when_dropped_params_are_set(self, mocker, config, expected_calls):
        """_make_to_gray warns once per build exactly when method/num_output_channels diverge from Kornia's default."""
        mock_warning = mocker.patch.object(kornia_transforms.logger, "warning")
        kornia_transforms._make_to_gray(config)

        assert mock_warning.call_count == expected_calls


class TestResolveAugmentationBackend:
    """resolve_augmentation_backend maps backend strings to concrete AugmentationBackend members."""

    @pytest.mark.parametrize("value", ["auto", "cpu"])
    def test_falls_back_to_tv_when_no_optional_packages(self, value: str, mocker) -> None:
        """'cpu'/'auto' resolve to torchvision when neither Albumentations nor Kornia is installed."""
        mocker.patch.object(AugmentationBackend, "_is_available", lambda self: self is AugmentationBackend.TV)

        assert resolve_augmentation_backend(value, has_cuda=False) == AugmentationBackend.TV

    @pytest.mark.parametrize(
        ("value", "expected"),
        [
            pytest.param("kornia", "kornia", id="kornia_passthrough"),
            pytest.param("gpu", "kornia", id="gpu_alias_to_kornia"),
            pytest.param("torchvision", "torchvision", id="torchvision_passthrough"),
            pytest.param("tv", "torchvision", id="tv_alias_to_torchvision"),
        ],
    )
    def test_explicit_backend_passthrough_regardless_of_cuda(self, value: str, expected: str) -> None:
        """Explicit concrete backends and their legacy aliases ('gpu', 'tv') resolve regardless of CUDA."""
        assert resolve_augmentation_backend(value, has_cuda=False) == AugmentationBackend(expected)

    def test_albu_passthrough_when_installed(self, mocker) -> None:
        """Explicit legacy 'albu' resolves to ALBU when Albumentations is installed."""
        mocker.patch.object(AugmentationBackend, "_is_available", lambda self: True)
        assert resolve_augmentation_backend("albu", has_cuda=False) == AugmentationBackend.ALBU

    def test_albu_missing_raises_import_error(self, mocker) -> None:
        """Explicit 'albu' fails fast with an install hint when Albumentations is not installed."""
        mocker.patch.object(AugmentationBackend, "_is_available", lambda self: self is not AugmentationBackend.ALBU)

        with pytest.raises(ImportError) as exc_info:
            resolve_augmentation_backend("albu", has_cuda=False)

        assert "rfdetr[augment]" in str(exc_info.value)


class TestResolveBackendForBuild:
    """resolve_backend_for_build combines the GPU readiness fail-fast with backend resolution."""

    def test_resolves_concrete_backend_without_cuda(self) -> None:
        """A concrete non-GPU backend resolves without requiring a CUDA device."""
        assert resolve_backend_for_build("torchvision", has_cuda=False) == AugmentationBackend.TV

    def test_gpu_without_cuda_raises_runtime_error(self) -> None:
        """An explicit GPU request fails fast when no CUDA device is available."""
        with pytest.raises(RuntimeError) as exc_info:
            resolve_backend_for_build("gpu", has_cuda=False)

        assert "CUDA" in str(exc_info.value)

    def test_gpu_without_kornia_raises_import_error(self, mocker) -> None:
        """An explicit GPU request with CUDA but no Kornia fails fast with an install hint."""
        mocker.patch.object(AugmentationBackend, "_is_available", lambda self: self is not AugmentationBackend.KORNIA)

        with pytest.raises(ImportError) as exc_info:
            resolve_backend_for_build("gpu", has_cuda=True)

        assert "rfdetr[augment]" in str(exc_info.value)


@_requires_kornia
class TestPerspectiveFactory:
    """`Perspective` on the Kornia backend (issue #1252).

    Perspective preserves output resolution, and the DataModule carries the batch padding mask through the same Kornia
    sequence. Transforms that resize output remain unsupported because this path only transports fixed-size batches.
    """

    @pytest.mark.parametrize(
        "scale",
        [pytest.param((0.05, 0.2), id="range"), 0.2],
    )
    def test_distribution_divergence_is_always_reported(self, mocker, scale) -> None:
        """The GPU path draws uniformly where the CPU path draws a half-normal, so every config diverges.

        This holds for a scalar too: albumentations reads ``0.2`` as ``sigma`` in ``(0, 0.2)`` and samples
        ``abs(N(0, sigma))``, so even an "exact" request is not the same distribution Kornia produces.
        """
        warn = mocker.patch.object(kornia_transforms.logger, "warning")
        kornia_transforms.build_kornia_pipeline({"Perspective": {"scale": scale}}, 560)

        messages = _logged_messages(warn)
        assert any("Perspective" in m and "abs(N(0, sigma))" in m for m in messages), messages

    def test_keep_size_false_is_refused_not_ignored(self) -> None:
        """keep_size=False changes the output resolution, which this pipeline cannot express."""
        with pytest.raises(ValueError) as exc_info:
            build_kornia_pipeline({"Perspective": {"keep_size": False}}, 560)

        assert "keep_size=False" in str(exc_info.value)

    def test_padding_mask_follows_the_perspective_warp(self) -> None:
        """Batch padding stays an auxiliary mask under the same Perspective parameters as image and boxes."""
        torch.manual_seed(7)
        image = torch.zeros(1, 3, 64, 64)
        image[:, :, :48, :48] = 1.0
        boxes = torch.tensor([[[4.0, 4.0, 44.0, 44.0]]])
        instance_mask = torch.zeros(1, 1, 64, 64)
        instance_mask[:, :, 12:36, 12:36] = 1.0
        padding_mask = torch.ones(1, 1, 64, 64)
        padding_mask[:, :, :48, :48] = 0.0
        auxiliary_masks = torch.cat((instance_mask, padding_mask), dim=1)

        pipeline = build_kornia_pipeline({"Perspective": {"scale": 0.4, "p": 1.0}}, 560, with_masks=True)
        image_aug, boxes_aug, auxiliary_masks_aug = pipeline(image, boxes, auxiliary_masks)
        instance_mask_aug = auxiliary_masks_aug[:, :1]
        padding_mask_aug = auxiliary_masks_aug[:, 1:]

        assert image_aug.shape == image.shape
        assert boxes_aug.shape == boxes.shape
        assert padding_mask_aug.shape == padding_mask.shape
        assert instance_mask_aug.shape == instance_mask.shape
        assert not torch.equal(padding_mask_aug, padding_mask)
        assert not torch.equal(instance_mask_aug, instance_mask)
        bright_pixels = image_aug[:, 0] > 0.99
        assert not padding_mask_aug[:, 0].to(torch.bool)[bright_pixels].any()

    @pytest.mark.parametrize("name", ["RandomCrop", "CenterCrop", "RandomResizedCrop"])
    def test_crop_names_from_1252_remain_unsupported(self, name) -> None:
        """Guard for the reason Perspective ships alone: the crops resize, so they are still rejected."""
        with pytest.raises(ValueError) as exc_info:
            build_kornia_pipeline({name: {"height": 32, "width": 32}}, 560)

        assert "Unknown augmentation key" in str(exc_info.value)


@_requires_kornia
class TestGaussianDefaultsMatchAlbumentations:
    """Unspecified Gaussian defaults must align to Albumentations bounds while documenting known sampling
    differences."""

    @_requires_albumentations
    def test_blur_sigma_default_matches_albumentations(self):
        """An unspecified sigma must equal albumentations' GaussianBlur sigma_limit default."""
        import albumentations

        cpu_default = tuple(albumentations.GaussianBlur().sigma_limit)
        transform = kornia_transforms._make_gaussian_blur({"blur_limit": 3, "p": 0.3})
        gpu_default = tuple(float(v) for v in transform._param_generator.sigma)

        assert gpu_default == pytest.approx(cpu_default), (
            f"unspecified GaussianBlur sigma is {gpu_default} on the GPU path but "
            f"{cpu_default} on the CPU path, so the same config uses different default sigma bounds"
        )

    def test_blur_uses_kornia_default_when_albu_backend_is_unavailable(self, mocker):
        """A GPU-only install keeps Kornia's historic GaussianBlur default."""
        mocker.patch.object(AugmentationBackend, "_is_available", lambda self: self is not AugmentationBackend.ALBU)

        transform = kornia_transforms._make_gaussian_blur({"blur_limit": 3, "p": 0.3})

        assert tuple(float(value) for value in transform._param_generator.sigma) == pytest.approx((0.1, 2.0))

    def test_blur_keeps_explicit_sigma(self):
        """An explicit sigma remains authoritative over backend availability."""
        transform = kornia_transforms._make_gaussian_blur({"blur_limit": 3, "sigma": (1.25, 1.5), "p": 0.3})

        assert tuple(float(value) for value in transform._param_generator.sigma) == pytest.approx((1.25, 1.5))

    @_requires_albumentations
    def test_noise_std_default_matches_albumentations(self) -> None:
        """An unspecified std_range must equal albumentations' GaussNoise std_range default."""
        import albumentations

        cpu_default = tuple(albumentations.GaussNoise().std_range)
        # Kornia takes one std (the range's upper bound), so the default must land on the albumentations upper bound.
        transform = kornia_transforms._make_gauss_noise({"p": 1.0})
        image = torch.ones(1, 3, 16, 16)
        torch.manual_seed(0)
        expected = image + torch.randn_like(image) * cpu_default[1]
        torch.manual_seed(0)

        torch.testing.assert_close(transform(image), expected, rtol=1e-4, atol=1e-6)


def _affine_ranges(transform: Any) -> dict[str, tuple[float, float]]:
    """Read the resolved degrees/translate/scale off a Kornia ``RandomAffine``.

    Like :func:`_sharpness_sampler_range`, this reads a private Kornia detail because no public
    equivalent exists: ``RandomAffine(...).flags`` carries only the resampling options (verified
    against the installed Kornia version), so the geometric ranges are reachable only through the
    parameter generator. A future Kornia release renaming ``_param_generator`` fails here with an
    actionable message rather than a raw ``AttributeError`` inside a test body.

    Examples:
        Requires the optional Kornia dependency, so the examples are skipped where it is unavailable.

        >>> config = {"ShiftScaleRotate": {"p": 1.0}}
        >>> transform = TestShiftScaleRotateFactory()._only_affine(config)  # doctest: +SKIP
        >>> len(_affine_ranges(transform))  # doctest: +SKIP
        3
    """
    generator = getattr(transform, "_param_generator", None)
    if generator is None:
        pytest.fail(
            "Kornia's RandomAffine no longer exposes `_param_generator` (no public alternative "
            "exists for the resolved degrees/translate/scale). Update this helper to match "
            "Kornia's new internal parameter-generator shape."
        )
    resolved = {}
    for key in ("degrees", "translate", "scale"):
        value = getattr(generator, key, None)
        if value is None:
            pytest.fail(
                f"Kornia's RandomAffine parameter generator no longer carries {key!r}. "
                "Update this helper to match Kornia's new internal shape."
            )
        resolved[key] = tuple(float(v) for v in value)
    return resolved


@_requires_kornia
class TestAffinePixelTranslation:
    """Pixel translation must move image and training targets together."""

    def test_fixed_translation_moves_image_boxes_and_masks(self) -> None:
        """The GPU-backend config must not silently discard ``translate_px``."""
        config = {"Affine": {"translate_px": {"x": (4, 4), "y": (0, 0)}, "rotate": 0.0, "scale": 1.0, "p": 1.0}}
        pipeline = build_kornia_pipeline(config, resolution=64, with_masks=True)
        image = torch.arange(64 * 80, dtype=torch.float32).reshape(1, 1, 64, 80) / (64 * 80)
        boxes = torch.tensor([[[30.0, 30.0, 34.0, 34.0]]])
        masks = torch.zeros(1, 2, 64, 80)
        masks[0, 0, 30:34, 30:34] = 1.0
        masks[0, 1, :, 70:] = 1.0

        image_out, boxes_out, masks_out = pipeline(image, boxes, masks)

        expected_image = torch.zeros_like(image)
        expected_image[:, :, :, 4:] = image[:, :, :, :-4]
        expected_masks = torch.zeros_like(masks)
        expected_masks[:, :, :, 4:] = masks[:, :, :, :-4]
        torch.testing.assert_close(image_out, expected_image, rtol=0, atol=1e-5)
        torch.testing.assert_close(boxes_out, torch.tensor([[[34.0, 30.0, 38.0, 34.0]]]), rtol=0, atol=1e-5)
        torch.testing.assert_close(masks_out, expected_masks, rtol=0, atol=0)

    def test_fixed_vertical_translation_moves_image_boxes_and_masks(self) -> None:
        """A pure y-axis shift must move pixels, boxes, and masks down together.

        ``apply_transform`` indexes rows with ``offsets[:, 1:2]`` and columns with ``offsets[:, 0:1]``
        (``_kornia_pixel_affine.py``), while boxes and masks are carried through Kornia's own matrix-based affine
        transform built from the same ``translations`` parameter. A sign or axis mix-up confined to the y-component is
        invisible when every other case in this module fixes ``y=0``, because ``-0`` and ``+0`` index identically;
        isolate the vertical axis here with ``x=0`` so such a divergence cannot hide behind a nonzero horizontal offset.
        """
        config = {"Affine": {"translate_px": {"x": (0, 0), "y": (3, 3)}, "rotate": 0.0, "scale": 1.0, "p": 1.0}}
        pipeline = build_kornia_pipeline(config, resolution=64, with_masks=True)
        image = torch.arange(80 * 64, dtype=torch.float32).reshape(1, 1, 80, 64) / (80 * 64)
        boxes = torch.tensor([[[30.0, 30.0, 34.0, 34.0]]])
        masks = torch.zeros(1, 2, 80, 64)
        masks[0, 0, 30:34, 30:34] = 1.0
        masks[0, 1, 70:, :] = 1.0

        image_out, boxes_out, masks_out = pipeline(image, boxes, masks)

        expected_image = torch.zeros_like(image)
        expected_image[:, :, 3:, :] = image[:, :, :-3, :]
        expected_masks = torch.zeros_like(masks)
        expected_masks[:, :, 3:, :] = masks[:, :, :-3, :]
        torch.testing.assert_close(image_out, expected_image, rtol=0, atol=1e-5)
        torch.testing.assert_close(boxes_out, torch.tensor([[[30.0, 33.0, 34.0, 37.0]]]), rtol=0, atol=1e-5)
        torch.testing.assert_close(masks_out, expected_masks, rtol=0, atol=0)

    @pytest.mark.parametrize(
        "configured,expected",
        [
            pytest.param(3, ((3, 3), (3, 3)), id="scalar-both-axes"),
            pytest.param((-2, 4), ((-2, 4), (-2, 4)), id="range-both-axes"),
            pytest.param({"x": (-2, 4)}, ((-2, 4), (0, 0)), id="x-only"),
            pytest.param({"y": -3}, ((0, 0), (-3, -3)), id="y-only"),
        ],
    )
    def test_integer_parameter_ranges(self, configured: Any, expected: tuple[tuple[int, int], tuple[int, int]]) -> None:
        """The public builder preserves signed, inclusive per-axis pixel ranges."""
        pipeline = build_kornia_pipeline({"Affine": {"translate_px": configured, "p": 1.0}}, resolution=32)
        transform = next(iter(pipeline.children()))
        torch.manual_seed(0)
        sampled = transform.generate_parameters((512, 1, 16, 20))["translations"]
        assert sampled.shape == (512, 2)
        assert sampled[:, 0].min().item() == expected[0][0]
        assert sampled[:, 0].max().item() == expected[0][1]
        assert sampled[:, 1].min().item() == expected[1][0]
        assert sampled[:, 1].max().item() == expected[1][1]
        assert torch.equal(sampled, sampled.round())

    def test_zero_probability_preserves_inputs(self) -> None:
        """``p=0`` keeps the historical no-augmentation behavior."""
        pipeline = build_kornia_pipeline({"Affine": {"translate_px": 4, "p": 0.0}}, resolution=32, with_masks=True)
        image = torch.rand(2, 1, 24, 32)
        boxes = torch.tensor([[[4.0, 5.0, 8.0, 9.0]], [[10.0, 8.0, 16.0, 15.0]]])
        masks = torch.zeros(2, 1, 24, 32)
        masks[:, :, 5:9, 4:8] = 1.0
        image_out, boxes_out, masks_out = pipeline(image, boxes, masks)
        torch.testing.assert_close(image_out, image, rtol=0, atol=0)
        torch.testing.assert_close(boxes_out, boxes, rtol=0, atol=0)
        torch.testing.assert_close(masks_out, masks, rtol=0, atol=0)

    def test_partial_probability_keeps_each_image_and_target_aligned(self) -> None:
        """Kornia's per-image selection must not mix selected and unselected targets."""
        pipeline = build_kornia_pipeline({"Affine": {"translate_px": {"x": 2}, "p": 0.5}}, resolution=12)
        image = torch.zeros(16, 1, 8, 12)
        image[:, :, 3, 3] = 1.0
        boxes = torch.tensor([[[3.0, 3.0, 4.0, 4.0]]]).expand(16, -1, -1).clone()
        torch.manual_seed(3)

        image_out, boxes_out = pipeline(image, boxes)

        selected = boxes_out[:, 0, 0] > 3.5
        assert selected.any() and (~selected).any()
        expected_x = torch.where(selected, 5, 3)
        for batch_index in range(16):
            assert image_out[batch_index, 0, 3, expected_x[batch_index]] == 1
        torch.testing.assert_close(boxes_out[:, 0, 0], expected_x.float(), rtol=0, atol=0)

    def test_no_boxes_still_moves_image_and_padding_mask(self) -> None:
        """A background-only batch does not depend on a populated box tensor."""
        pipeline = build_kornia_pipeline(
            {"Affine": {"translate_px": {"x": -2}, "p": 1.0}}, resolution=8, with_masks=True
        )
        image = torch.arange(8, dtype=torch.float32).reshape(1, 1, 1, 8)
        boxes = torch.empty(1, 0, 4)
        padding = torch.zeros(1, 1, 1, 8)
        padding[:, :, :, 6:] = 1.0

        image_out, boxes_out, padding_out = pipeline(image, boxes, padding)

        torch.testing.assert_close(image_out, torch.tensor([[[[2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 0.0, 0.0]]]]))
        assert boxes_out.shape == (1, 0, 4)
        expected_padding = torch.zeros_like(padding)
        expected_padding[:, :, :, 4:6] = 1.0
        torch.testing.assert_close(padding_out, expected_padding, rtol=0, atol=0)

    @pytest.mark.parametrize(
        "border_mode,interpolation",
        [
            pytest.param(0, 1, id="constant-linear"),
            pytest.param(1, 1, id="replicate-linear"),
            pytest.param(0, 0, id="constant-nearest"),
        ],
    )
    @_requires_albumentations
    def test_fixed_translation_matches_albumentations_geometry(self, border_mode: int, interpolation: int) -> None:
        """Image, box, and mask geometry matches the CPU backend on a non-square input."""
        import albumentations

        config = {
            "translate_px": {"x": (4, 4), "y": (0, 0)},
            "rotate": 0.0,
            "scale": 1.0,
            "shear": 0.0,
            "border_mode": border_mode,
            "interpolation": interpolation,
            "p": 1.0,
        }
        image = np.arange(7 * 9 * 3, dtype=np.uint8).reshape(7, 9, 3)
        object_mask = np.zeros((7, 9), dtype=np.uint8)
        object_mask[2:5, 1:4] = 1
        padding_mask = np.zeros((7, 9), dtype=np.uint8)
        padding_mask[:, 7:] = 1
        cpu = albumentations.Compose(
            [albumentations.Affine(**config)], bbox_params=albumentations.BboxParams(format="pascal_voc")
        )(image=image, bboxes=[(1, 2, 4, 5)], masks=[object_mask, padding_mask])
        pipeline = build_kornia_pipeline({"Affine": config}, resolution=7, with_masks=True)
        image_tensor = torch.from_numpy(image.copy()).permute(2, 0, 1).float().unsqueeze(0) / 255
        boxes = torch.tensor([[[1.0, 2.0, 4.0, 5.0]]])
        masks = torch.from_numpy(np.stack((object_mask, padding_mask))).float().unsqueeze(0)

        image_out, boxes_out, masks_out = pipeline(image_tensor, boxes, masks)

        cpu_image = torch.from_numpy(cpu["image"].copy()).permute(2, 0, 1).float().unsqueeze(0) / 255
        cpu_masks = torch.from_numpy(np.stack(cpu["masks"]).copy()).float().unsqueeze(0)
        torch.testing.assert_close(image_out, cpu_image, rtol=0, atol=1e-5)
        torch.testing.assert_close(boxes_out, torch.tensor([cpu["bboxes"]]), rtol=0, atol=1e-5)
        torch.testing.assert_close(masks_out, cpu_masks, rtol=0, atol=0)

    @pytest.mark.parametrize(
        "translation,other,diagnostic",
        [
            pytest.param(True, {}, "not booleans", id="boolean"),
            pytest.param(1.5, {}, "whole pixels.*got 1.5", id="fractional-pixel"),
            pytest.param((0, 2.5), {}, "whole pixels.*got 2.5", id="fractional-range-bound"),
            pytest.param({"x": 0.5}, {}, "whole pixels.*got 0.5", id="fractional-axis"),
            pytest.param((3, -3), {}, "minimum", id="reversed-range"),
            pytest.param((1, 2, 3), {}, "two-element", id="three-element-range"),
            pytest.param({"z": 4}, {}, "keys", id="wrong-axis"),
            pytest.param(4, {"translate_percent": 0.1}, "either", id="two-translation-units"),
            pytest.param(4, {"rotate": 10}, "got rotate=10", id="nonzero-rotate"),
            pytest.param(4, {"rotate": (-5, 5)}, r"got rotate=\(-5, 5\)", id="nonzero-rotate-range"),
            pytest.param(4, {"shear": 5}, "got shear=5", id="nonzero-shear"),
            pytest.param(4, {"scale": 1.2}, "got scale=1.2", id="nonunit-scalar-scale"),
            pytest.param(4, {"interpolation": 5}, "got interpolation=5", id="unknown-interpolation"),
            pytest.param(4, {"mask_interpolation": 7}, "got mask_interpolation=7", id="unknown-mask-interpolation"),
            pytest.param(4, {"fill_mask": 1}, "requires fill_mask=0", id="unsupported-nonzero-fill-mask"),
            pytest.param(4, {"border_mode": 2}, "got border_mode=2", id="unsupported-reflect-mode"),
            pytest.param(4, {"border_mode": 3}, "got border_mode=3", id="unsupported-wrap-mode"),
            pytest.param(4, {"border_mode": 4}, "got border_mode=4", id="reflected-box-duplication"),
            pytest.param(4, {"fill": 1}, "fill", id="unsupported-nonzero-fill"),
            pytest.param(4, {"fit_output": True}, "fit_output", id="output-shape-change"),
            pytest.param(4, {"scale": {"x": (0.8, 1.2)}}, "scale=1", id="unsupported-axis-scale"),
            pytest.param(4, {"scale": [0.8, 1.2]}, "scale=1", id="nonunit-list-scale"),
            pytest.param(4, {"shear": {"x": 0}}, "shear=0", id="axis-shear-missing-y-defaults-to-one-degree"),
            pytest.param(4, {"fill": np.array([0, 0, 1])}, "fill=0", id="nonzero-array-fill"),
            pytest.param(2**63 - 1, {}, "64-bit", id="int64-overflow"),
            pytest.param(4, {"cval": 1}, "cval=1; use fill instead", id="albumentations-1x-cval"),
            pytest.param(4, {"cval_mask": 1}, "cval_mask=1; use fill_mask instead", id="albumentations-1x-cval-mask"),
            pytest.param(4, {"mode": 2}, "mode=2; use border_mode instead", id="albumentations-1x-mode"),
        ],
    )
    def test_unsupported_pixel_affine_config_fails_at_build(
        self, translation: Any, other: dict[str, Any], diagnostic: str
    ) -> None:
        """Unsupported settings fail before training instead of changing silently."""
        with pytest.raises(ValueError, match=diagnostic):
            build_kornia_pipeline({"Affine": {"translate_px": translation, **other}}, resolution=32)

    @pytest.mark.parametrize(
        "translation,expected",
        [
            pytest.param(4.0, ((4, 4), (4, 4)), id="integral-float"),
            pytest.param(np.int64(3), ((3, 3), (3, 3)), id="numpy-integer"),
            pytest.param({"x": 3.0}, ((3, 3), (0, 0)), id="integral-float-axis"),
            pytest.param((-2.0, np.int32(4)), ((-2, 4), (-2, 4)), id="mixed-integral-range"),
        ],
    )
    def test_integral_offsets_resolve_to_int_bounds(
        self, translation: Any, expected: tuple[tuple[int, int], tuple[int, int]]
    ) -> None:
        """Integral offsets of any numeric type build and resolve to plain ``int`` bounds.

        Albumentations accepts ``4.0`` and NumPy integers for ``translate_px``, so a config that trains on the CPU
        backend must build here too. The bounds must come out as Python ``int`` because ``torch.randint`` rejects a
        float bound at the first forward pass, long after the pipeline was built.
        """
        pipeline = build_kornia_pipeline({"Affine": {"translate_px": translation, "p": 1.0}}, resolution=32)

        bounds = next(iter(pipeline.children())).translation_bounds
        assert bounds == expected
        assert all(type(bound) is int for axis in bounds for bound in axis)

    @pytest.mark.parametrize(
        "options",
        [
            pytest.param({"scale": {"x": 1.0, "y": 1.0}}, id="unit-axis-scale"),
            pytest.param({"scale": {"x": (1.0, 1.0)}}, id="unit-axis-scale-missing-y"),
            pytest.param({"shear": {"x": 0, "y": 0}}, id="zero-axis-shear"),
            pytest.param({"interpolation": 2}, id="cubic-interpolation"),
            pytest.param({"interpolation": 3}, id="area-interpolation"),
            pytest.param({"interpolation": 4}, id="lanczos-interpolation"),
            pytest.param({"mask_interpolation": 1}, id="linear-mask-interpolation"),
            pytest.param({"keep_ratio": True}, id="keep-ratio"),
            pytest.param({"balanced_scale": True}, id="balanced-scale"),
            pytest.param({"rotate_method": "ellipse"}, id="ellipse-rotate-method"),
            pytest.param({"fill": np.zeros(3)}, id="zero-array-fill"),
            pytest.param({"border_mode": 1, "fill": 5}, id="replicate-ignores-fill"),
            pytest.param({"border_mode": 1, "fill_mask": 1}, id="replicate-ignores-fill-mask"),
        ],
    )
    def test_options_without_effect_on_a_pixel_shift_build(self, options: dict[str, Any]) -> None:
        """Albumentations options that cannot change a whole-pixel shift build instead of raising.

        Each option only matters for scaling, rotation, sub-pixel sampling or a constant border; Albumentations accepts
        all of them and returns the same pure shift, so refusing them on Kornia would fail a CPU-valid config on GPU.
        """
        from rfdetr.datasets._kornia_pixel_affine import PixelTranslatedAffine

        pipeline = build_kornia_pipeline({"Affine": {"translate_px": 4, **options, "p": 1.0}}, resolution=32)

        transform = next(iter(pipeline.children()))
        assert isinstance(transform, PixelTranslatedAffine)
        assert transform.translation_bounds == ((4, 4), (4, 4))

    @pytest.mark.parametrize(
        "scale", [pytest.param((1.0, 1.0), id="unit-tuple"), pytest.param([1.0, 1.0], id="unit-list"), 1]
    )
    def test_unit_scale_variants_build_for_translate_px(self, scale: Any) -> None:
        """A semantically unit scale must build regardless of its container type.

        ``scale != (1.0, 1.0)`` previously rejected a list such as ``[1.0, 1.0]`` because Python never treats a list as
        equal to a tuple, even with identical elements, so only the tuple form built successfully. Each parametrized
        value here represents the same no-op scale.
        """
        build_kornia_pipeline({"Affine": {"translate_px": 4, "scale": scale, "p": 1.0}}, resolution=32)


#: Non-square frame shared by the per-image alignment tests, so an x/y axis mix-up cannot cancel out.
_ALIGN_HEIGHT, _ALIGN_WIDTH = 6, 8

#: Per-image ``(tx, ty)`` pixel offsets for a four-image batch. ``_ALIGN_WIDTH=8`` and ``_ALIGN_HEIGHT=6`` make the
#: ``fully-off-frame-*`` cases satisfy ``|t| >= extent`` on the shifted axis, and each case mixes signs across images
#: so a batch-order or per-image mix-up cannot pass.
_ALIGNMENT_OFFSETS = [
    pytest.param([(2, 1), (-3, -2), (0, 0), (4, -1)], id="in-frame-mixed-signs"),
    pytest.param([(0, -1), (0, -3), (1, -2), (-1, -5)], id="negative-y"),
    pytest.param([(6, 0), (-6, 0), (0, 4), (0, -4)], id="partly-off-frame"),
    pytest.param([(8, 0), (-8, 0), (0, 6), (0, -6)], id="fully-off-frame-at-extent"),
    pytest.param([(20, 3), (-9, -2), (2, 25), (-8, -7)], id="fully-off-frame-beyond-extent"),
]

__doctest_requires__ = {"_translated_batch": ["kornia"]}


def _numpy_shift(array: np.ndarray, tx: int, ty: int, border_mode: int) -> np.ndarray:
    """Shift a ``(C, H, W)`` array right by ``tx`` and down by ``ty`` pixels, filling from the border.

    This is the reference for pixel translation: pad by the largest offset (constant zeros for ``border_mode=0``,
    replicated edge for ``border_mode=1``), then slice the shifted window. It shares no indexing code with the
    implementation under test.

    Args:
        array: Channel-first array to shift.
        tx: Horizontal shift in pixels; positive moves content right.
        ty: Vertical shift in pixels; positive moves content down.
        border_mode: ``0`` fills uncovered pixels with zeros, ``1`` replicates the nearest edge pixel.

    Returns:
        The shifted array with the same shape as ``array``.

    Examples:
        >>> row = np.array([[[1, 2, 3, 4]]])
        >>> _numpy_shift(row, 1, 0, 0).tolist()
        [[[0, 1, 2, 3]]]
        >>> _numpy_shift(row, 1, 0, 1).tolist()
        [[[1, 1, 2, 3]]]
        >>> _numpy_shift(row, -9, 0, 0).tolist()
        [[[0, 0, 0, 0]]]
    """
    _, height, width = array.shape
    pad = max(abs(tx), abs(ty))
    padded = np.pad(array, ((0, 0), (pad, pad), (pad, pad)), mode="constant" if border_mode == 0 else "edge")
    return padded[:, pad - ty : pad - ty + height, pad - tx : pad - tx + width]


def _translated_batch(images: torch.Tensor, border_mode: int, offsets: list[tuple[int, int]]) -> tuple[Any, Any, Any]:
    """Build a pixel-translation transform and fix its sampled per-image offsets.

    The transform comes from the public builder, so ``border_mode`` goes through the same mapping as a real config.
    ``generate_parameters`` supplies the full Kornia parameter set for the batch; only ``translations`` is then
    overwritten with ``offsets`` so every case is deterministic and RNG-free while covering offsets (such as
    ``|t| >= W``) that a random draw would rarely produce.

    Args:
        images: Batch the transform will be applied to; only its shape is used here.
        border_mode: Albumentations border mode, ``0`` constant or ``1`` replicate.
        offsets: One ``(tx, ty)`` pixel offset per image in ``images``.

    Returns:
        The transform, its parameter dict, and the per-image affine matrices for ``images``.

    Examples:
        >>> images = torch.zeros(2, 1, 6, 8)
        >>> transform, params, matrix = _translated_batch(images, 1, [(2, -1), (-3, 0)])
        >>> params["translations"].tolist()
        [[2.0, -1.0], [-3.0, 0.0]]
        >>> matrix.shape
        torch.Size([2, 3, 3])
    """
    config = {"Affine": {"translate_px": {"x": (-1, 1), "y": (-1, 1)}, "border_mode": border_mode, "p": 1.0}}
    transform = next(iter(build_kornia_pipeline(config, resolution=_ALIGN_WIDTH, with_masks=True).children()))
    params = transform.generate_parameters(tuple(images.shape))
    params["translations"] = torch.tensor(offsets, dtype=params["translations"].dtype)
    matrix = transform.compute_transformation(images, params, transform.flags)
    return transform, params, matrix


@_requires_kornia
class TestAffinePixelTranslationBatchAlignment:
    """Every image, box, and mask in a batch must move by its own sampled offset, matching a NumPy oracle.

    Border modes ``0`` and ``1`` are constant and replicate fill (Albumentations numbering).
    """

    @pytest.mark.parametrize("border_mode", [0, 1])
    @pytest.mark.parametrize("offsets", _ALIGNMENT_OFFSETS)
    def test_images_match_numpy_shift_per_image(self, offsets: list[tuple[int, int]], border_mode: int) -> None:
        """Each image in a batch is shifted by its own offset, including offsets at or past the frame extent.

        Distinct non-zero pixel values make a wrong source pixel, a swapped axis, or a zero fill that should have been a
        replicated edge (and the reverse) all change the output.
        """
        batch = len(offsets)
        images = torch.arange(1, batch * 3 * _ALIGN_HEIGHT * _ALIGN_WIDTH + 1, dtype=torch.float32).reshape(
            batch, 3, _ALIGN_HEIGHT, _ALIGN_WIDTH
        )
        transform, params, matrix = _translated_batch(images, border_mode, offsets)

        out = transform.apply_transform(images, params, transform.flags, transform=matrix)

        expected = np.stack(
            [_numpy_shift(image, tx, ty, border_mode) for image, (tx, ty) in zip(images.numpy(), offsets)]
        )
        torch.testing.assert_close(out, torch.from_numpy(expected), rtol=0, atol=0)

    @pytest.mark.parametrize("border_mode", [0, 1])
    @pytest.mark.parametrize("offsets", _ALIGNMENT_OFFSETS)
    def test_masks_match_numpy_shift_per_image(self, offsets: list[tuple[int, int]], border_mode: int) -> None:
        """Instance and padding masks move exactly like the image: whole pixels, no interpolation, same border mode.

        Masks are binary, so any interpolation would produce fractional values and any offset disagreement with the
        image would show up as a misaligned mask against the same NumPy oracle.
        """
        batch = len(offsets)
        masks = ((torch.arange(batch * 2 * _ALIGN_HEIGHT * _ALIGN_WIDTH) * 7) % 5 < 2).float()
        masks = masks.reshape(batch, 2, _ALIGN_HEIGHT, _ALIGN_WIDTH)
        transform, params, matrix = _translated_batch(masks, border_mode, offsets)

        out = transform.apply_transform_mask(masks, params, dict(transform.flags), transform=matrix)

        expected = np.stack([_numpy_shift(mask, tx, ty, border_mode) for mask, (tx, ty) in zip(masks.numpy(), offsets)])
        torch.testing.assert_close(out, torch.from_numpy(expected), rtol=0, atol=0)

    @pytest.mark.parametrize("offsets", _ALIGNMENT_OFFSETS)
    def test_boxes_translate_by_per_image_offset(self, offsets: list[tuple[int, int]]) -> None:
        """Boxes shift by their image's offset, so they stay aligned with its pixels even when they leave the frame.

        Clipping or dropping boxes that end up outside the frame is a later stage (see the data-module tests); this
        transform must move all four coordinates unclamped, which is what keeps partly and fully off-frame boxes
        consistent with the shifted image.
        """
        from kornia.geometry.boxes import Boxes

        batch = len(offsets)
        boxes = torch.tensor([[1.0, 1.0, 4.0, 3.0], [5.0, 2.0, 8.0, 5.0]]).expand(batch, -1, -1).clone()
        images = torch.zeros(batch, 1, _ALIGN_HEIGHT, _ALIGN_WIDTH)
        transform, params, matrix = _translated_batch(images, 0, offsets)

        out = transform.apply_transform_box(
            Boxes.from_tensor(boxes, mode="xyxy"), params, transform.flags, transform=matrix
        ).to_tensor(mode="xyxy")

        shifts = torch.tensor([[tx, ty, tx, ty] for tx, ty in offsets], dtype=torch.float32)[:, None, :]
        torch.testing.assert_close(out, boxes + shifts, rtol=0, atol=0)

    @pytest.mark.parametrize("border_mode", [0, 1])
    @pytest.mark.parametrize(
        "offset",
        [
            pytest.param((3, 2), id="positive-both-axes"),
            pytest.param((-2, -3), id="negative-both-axes"),
            pytest.param((-2, 2), id="mixed-signs"),
        ],
    )
    @_requires_albumentations
    def test_in_frame_translation_matches_albumentations(self, offset: tuple[int, int], border_mode: int) -> None:
        """Image, box, and mask geometry matches the CPU backend for in-frame shifts on both axes.

        The box stays fully inside the frame after every shift here: Albumentations clips and filters boxes that leave
        the frame, so parity is only defined for in-frame shifts. Offsets at or past the frame extent are covered
        against the NumPy oracle above, never against Albumentations.
        """
        import albumentations

        tx, ty = offset
        config = {
            "translate_px": {"x": (tx, tx), "y": (ty, ty)},
            "rotate": 0.0,
            "scale": 1.0,
            "shear": 0.0,
            "border_mode": border_mode,
            "interpolation": 1,
            "p": 1.0,
        }
        image = np.arange(7 * 9 * 3, dtype=np.uint8).reshape(7, 9, 3)
        object_mask = np.zeros((7, 9), dtype=np.uint8)
        object_mask[3:5, 3:6] = 1
        padding_mask = np.zeros((7, 9), dtype=np.uint8)
        padding_mask[:, 7:] = 1
        cpu = albumentations.Compose(
            [albumentations.Affine(**config)], bbox_params=albumentations.BboxParams(format="pascal_voc")
        )(image=image, bboxes=[(3, 3, 6, 5)], masks=[object_mask, padding_mask])
        pipeline = build_kornia_pipeline({"Affine": config}, resolution=7, with_masks=True)
        image_tensor = torch.from_numpy(image.copy()).permute(2, 0, 1).float().unsqueeze(0) / 255
        boxes = torch.tensor([[[3.0, 3.0, 6.0, 5.0]]])
        masks = torch.from_numpy(np.stack((object_mask, padding_mask))).float().unsqueeze(0)

        image_out, boxes_out, masks_out = pipeline(image_tensor, boxes, masks)

        cpu_image = torch.from_numpy(cpu["image"].copy()).permute(2, 0, 1).float().unsqueeze(0) / 255
        cpu_masks = torch.from_numpy(np.stack(cpu["masks"]).copy()).float().unsqueeze(0)
        torch.testing.assert_close(image_out, cpu_image, rtol=0, atol=1e-5)
        torch.testing.assert_close(boxes_out, torch.tensor([cpu["bboxes"]]), rtol=0, atol=1e-5)
        torch.testing.assert_close(masks_out, cpu_masks, rtol=0, atol=0)


@_requires_kornia
class TestAffineScalarParameters:
    """Scalar ``Affine`` ranges must not lose an axis or fail in the Kornia backend."""

    def test_scalar_translate_percent_moves_both_axes(self) -> None:
        """A scalar translation must not silently leave the horizontal axis fixed."""
        torch.manual_seed(0)
        pipeline = build_kornia_pipeline(
            {"Affine": {"translate_percent": 0.1, "rotate": (0.0, 0.0), "p": 1.0}}, resolution=64
        )
        image = torch.zeros(1, 1, 64, 64)
        image[0, 0, 32, 32] = 1.0
        boxes = torch.tensor([[[31.0, 31.0, 33.0, 33.0]]])
        horizontal, vertical = [], []

        for _ in range(128):
            moved, _ = pipeline(image, boxes)
            flat_index = int(moved[0, 0].flatten().argmax().item())
            horizontal.append(flat_index % 64 - 32)
            vertical.append(flat_index // 64 - 32)

        assert min(horizontal) < 0 < max(horizontal), horizontal
        assert min(vertical) < 0 < max(vertical), vertical

    @_requires_albumentations
    def test_scalar_translate_percent_warns_about_the_cpu_distribution(self, mocker) -> None:
        """A fixed positive CPU scalar must not silently become signed GPU sampling."""
        import albumentations

        cpu_affine = albumentations.Affine(translate_percent=0.1)
        warn = mocker.patch.object(kornia_transforms.logger, "warning")
        gpu_affine = kornia_transforms._make_affine({"translate_percent": 0.1, "p": 1.0})

        assert cpu_affine.translate_percent == {"x": (0.1, 0.1), "y": (0.1, 0.1)}
        assert tuple(float(value) for value in gpu_affine._param_generator.translate) == pytest.approx(
            (0.1, 0.1), abs=1e-6
        )
        messages = _logged_messages(warn)
        assert any("scalar" in message and "different distribution" in message for message in messages), messages

    def test_scalar_scale_executes_public_pipeline(self) -> None:
        """A scalar scale must build and run instead of failing inside Kornia."""
        pipeline = build_kornia_pipeline({"Affine": {"scale": 1.1, "rotate": (0.0, 0.0), "p": 1.0}}, resolution=64)
        image = torch.rand(1, 3, 64, 64)
        boxes = torch.tensor([[[8.0, 8.0, 24.0, 24.0]]])

        image_out, boxes_out = pipeline(image, boxes)

        assert image_out.shape == image.shape
        assert boxes_out.shape == boxes.shape
        assert not torch.allclose(boxes_out, boxes)

    def test_unset_rotate_samples_no_rotation(self) -> None:
        """An unset ``rotate`` means no rotation, as in Albumentations' ``Affine``."""
        ranges = _affine_ranges(_make_affine({"translate_percent": (-0.1, 0.1), "scale": (0.8, 1.2), "p": 1.0}))

        assert ranges["degrees"] == pytest.approx((0.0, 0.0), abs=1e-6)

    def test_scale_only_config_leaves_the_image_unrotated(self) -> None:
        """A scale-only config with a unit scale changes nothing, so it cannot have rotated."""
        torch.manual_seed(0)
        transform = _make_affine({"scale": (1.0, 1.0), "p": 1.0})
        image = torch.rand(1, 3, 32, 32)

        result = transform(image)

        assert torch.allclose(result, image, atol=1e-5)

    def test_existing_pairs_keep_their_ranges(self) -> None:
        """The scalar fix must not change existing ordered-pair behaviour."""
        ranges = _affine_ranges(_make_affine({"translate_percent": (-0.05, 0.2), "scale": (0.8, 1.2), "p": 1.0}))

        assert ranges["translate"] == pytest.approx((0.2, 0.2), abs=1e-6)
        assert ranges["scale"] == pytest.approx((0.8, 1.2), abs=1e-6)

    @pytest.mark.parametrize(
        "params,key,expected",
        [
            pytest.param(
                {"translate_percent": 0.1, "scale": (0.9, 1.1), "rotate": (0.0, 0.0), "p": 1.0},
                "translate",
                (0.1, 0.1),
                id="translate",
            ),
            pytest.param(
                {"translate_percent": (-0.05, 0.05), "scale": 1.1, "rotate": (0.0, 0.0), "p": 1.0},
                "scale",
                (1.1, 1.1),
                id="scale",
            ),
        ],
    )
    def test_scalar_parameters_resolve_to_the_symmetric_range(
        self, params: dict[str, Any], key: str, expected: tuple[float, float]
    ) -> None:
        """A scalar parameter must resolve to the exact symmetric range Kornia receives, not just execute."""
        ranges = _affine_ranges(_make_affine(params))

        assert ranges[key] == pytest.approx(expected, abs=1e-6)

    @pytest.mark.parametrize(
        "parameter,value",
        [
            pytest.param("translate_percent", ("-0.1", "0.1"), id="translate-pair"),
            pytest.param("scale", ("0.8", "1.2"), id="scale-pair"),
            pytest.param("translate_percent", "0.1", id="translate-scalar"),
            pytest.param("scale", "1.1", id="scale-scalar"),
        ],
    )
    def test_string_values_keep_their_existing_rejection(self, parameter: str, value: Any) -> None:
        """Normalising numeric scalars must not accept string values."""
        with pytest.raises((TypeError, ValueError)):
            _make_affine({parameter: value, "p": 1.0})


@_requires_kornia
class TestShiftScaleRotateFactory:
    """`ShiftScaleRotate` on the Kornia backend (issue #1252).

    Albumentations deprecates this name in favour of `Affine`, but the CPU path still accepts it, so a config using it
    trained on a CPU box and raised on a GPU box. It maps onto the same `RandomAffine` that `Affine` uses, which is what
    makes it safe: no resolution change, so the padding-mask constraint that keeps the crops unsupported does not apply.

    The limits are *not* pass-through, which is why this needs its own builder rather than an alias.
    """

    def _only_affine(self, aug_config: dict[str, dict[str, Any]]) -> Any:
        """Build a pipeline and return its sole ``RandomAffine`` transform.

        Examples:
            Requires the optional Kornia dependency, so the examples are skipped where it is unavailable.

            >>> config = {"ShiftScaleRotate": {"p": 1.0}}
            >>> transform = TestShiftScaleRotateFactory()._only_affine(config)  # doctest: +SKIP
            >>> transform.__class__.__name__  # doctest: +SKIP
            'RandomAffine'
        """
        return _only_child(build_kornia_pipeline(aug_config, 560), "RandomAffine")

    def test_scale_limit_is_a_delta_biased_by_one(self) -> None:
        """The mapping that a plain alias to Affine would get wrong.

        Albumentations documents `scale_limit` as "biased by 1": it samples from `(1 + low, 1 + high)`, so `0.1` means a
        scale between 0.9 and 1.1. Kornia's `scale` is the absolute multiplier, so forwarding `0.1` unchanged would ask
        it to shrink the image to between a tenth of its size and nothing at all.
        """
        ranges = _affine_ranges(self._only_affine({"ShiftScaleRotate": {"scale_limit": 0.1, "p": 1.0}}))
        assert ranges["scale"] == pytest.approx((0.9, 1.1), abs=1e-4)

    def test_scale_limit_as_asymmetric_pair(self) -> None:
        """A pair is also a delta, so it pivots the same way rather than passing through."""
        ranges = _affine_ranges(self._only_affine({"ShiftScaleRotate": {"scale_limit": (-0.2, 0.5), "p": 1.0}}))
        assert ranges["scale"] == pytest.approx((0.8, 1.5), abs=1e-4)

    def test_scalar_limits_expand_symmetrically(self) -> None:
        """`rotate_limit=30` means (-30, 30), not the degenerate (30, 30) `_as_range` would give."""
        ranges = _affine_ranges(self._only_affine({"ShiftScaleRotate": {"rotate_limit": 30, "p": 1.0}}))
        assert ranges["degrees"] == pytest.approx((-30.0, 30.0), abs=1e-4)

    def test_defaults_match_albumentations(self) -> None:
        """An empty config resolves to Albumentations' own documented defaults."""
        ranges = _affine_ranges(self._only_affine({"ShiftScaleRotate": {"p": 1.0}}))
        assert ranges["degrees"] == pytest.approx((-45.0, 45.0), abs=1e-4)
        assert ranges["translate"] == pytest.approx((0.0625, 0.0625), abs=1e-4)
        assert ranges["scale"] == pytest.approx((0.9, 1.1), abs=1e-4)

    def test_per_axis_shift_limits(self) -> None:
        """`shift_limit_x`/`shift_limit_y` override the shared limit; Kornia takes them as (tx, ty)."""
        ranges = _affine_ranges(
            self._only_affine({"ShiftScaleRotate": {"shift_limit_x": 0.2, "shift_limit_y": 0.05, "p": 1.0}})
        )
        assert ranges["translate"] == pytest.approx((0.2, 0.05), abs=1e-4)

    @pytest.mark.parametrize("key", ["shift_limit_x", "shift_limit_y"])
    def test_none_per_axis_shift_limit_uses_the_shared_limit(self, key: str) -> None:
        """Albumentations accepts ``None`` as an axis-level fallback to ``shift_limit``."""
        ranges = _affine_ranges(self._only_affine({"ShiftScaleRotate": {"shift_limit": 0.2, key: None, "p": 1.0}}))
        assert ranges["translate"] == pytest.approx((0.2, 0.2), abs=1e-4)

    def test_asymmetric_shift_limit_warns_about_the_symmetric_kornia_approximation(self, mocker) -> None:
        """A one-sided CPU range must not silently become a different GPU distribution."""
        warn = mocker.patch.object(kornia_transforms.logger, "warning")
        ranges = _affine_ranges(self._only_affine({"ShiftScaleRotate": {"shift_limit_x": (0.1, 0.2), "p": 1.0}}))

        assert ranges["translate"] == pytest.approx((0.2, 0.0625), abs=1e-4)
        messages = _logged_messages(warn)
        assert any("asymmetric" in message and "shift_limit_x" in message for message in messages), messages

    def test_plain_config_does_not_warn(self, mocker) -> None:
        """Every parameter here maps, so an ordinary config must stay quiet."""
        warn = mocker.patch.object(kornia_transforms.logger, "warning")
        kornia_transforms.build_kornia_pipeline(
            {"ShiftScaleRotate": {"shift_limit": 0.1, "scale_limit": 0.2, "rotate_limit": 15, "p": 1.0}}, 560
        )

        assert not warn.called, _logged_messages(warn)


@_requires_kornia
class TestResolutionPreservingGeometry:
    """Perspective and ShiftScaleRotate keep the output resolution and move boxes with the image (issue #1252)."""

    @pytest.mark.parametrize(
        "config",
        [
            pytest.param({"Perspective": {"scale": 0.3, "p": 1.0}}, id="perspective"),
            pytest.param({"ShiftScaleRotate": {"rotate_limit": 30, "p": 1.0}}, id="shift-scale-rotate"),
        ],
    )
    def test_output_keeps_the_input_resolution(self, config) -> None:
        """Image height and width survive the transform, which is what makes it safe where the crops are not."""
        img = torch.rand(2, 3, 64, 64)
        boxes = torch.tensor([[[8.0, 8.0, 40.0, 40.0]], [[4.0, 4.0, 20.0, 20.0]]])

        img_out, _ = build_kornia_pipeline(config, 560)(img, boxes)

        assert img_out.shape[-2:] == img.shape[-2:]

    @pytest.mark.parametrize(
        "config",
        [
            pytest.param({"Perspective": {"scale": 0.4, "p": 1.0}}, id="perspective"),
            pytest.param({"ShiftScaleRotate": {"rotate_limit": 45, "p": 1.0}}, id="shift-scale-rotate"),
        ],
    )
    def test_boxes_follow_the_transform(self, config) -> None:
        """A geometric transform that left the boxes where they were would silently mislabel every image."""
        img = torch.rand(1, 3, 64, 64)
        boxes = torch.tensor([[[8.0, 8.0, 40.0, 40.0]]])

        _, boxes_out = build_kornia_pipeline(config, 560)(img, boxes)

        assert not torch.allclose(boxes_out, boxes), "boxes must move with the image"

    @pytest.mark.parametrize(
        ("name", "key", "value"),
        [
            ("Perspective", "fit_output", True),
            ("Perspective", "interpolation", 1),
            ("Perspective", "mask_interpolation", 0),
            ("Perspective", "border_mode", 0),
            ("Perspective", "fill", 0),
            ("Perspective", "fill_mask", 0),
            ("ShiftScaleRotate", "interpolation", 1),
            ("ShiftScaleRotate", "border_mode", 0),
            ("ShiftScaleRotate", "mask_interpolation", 0),
            ("ShiftScaleRotate", "fill", 0),
            ("ShiftScaleRotate", "fill_mask", 0),
            ("ShiftScaleRotate", "rotate_method", "ellipse"),
        ],
    )
    def test_unmappable_options_are_reported_not_silently_dropped(self, mocker, name, key, value) -> None:
        """Options Kornia's random warp cannot take (RandomPerspective: only distortion_scale and p) must warn."""
        warn = mocker.patch.object(kornia_transforms.logger, "warning")
        build_kornia_pipeline({name: {key: value}}, 560)

        messages = _logged_messages(warn)
        assert any("ignores" in m and key in m for m in messages), messages
