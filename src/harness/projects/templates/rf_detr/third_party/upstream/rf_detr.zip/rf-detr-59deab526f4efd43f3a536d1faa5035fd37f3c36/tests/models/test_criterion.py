# ------------------------------------------------------------------------
# RF-DETR
# Copyright (c) 2025 Roboflow. All Rights Reserved.
# Licensed under the Apache License, Version 2.0 [see LICENSE for details]
# ------------------------------------------------------------------------
"""Unit tests for SetCriterion edge paths: _output_device and num_boxes_for_targets."""

import logging
import pickle
from typing import Any
from unittest.mock import MagicMock, patch

import numpy as np
import pytest
import torch
from pytest_mock import MockerFixture
from torch import Tensor

import rfdetr.models.criterion as criterion_module
from rfdetr.models.criterion import (
    SetCriterion,
    dice_loss,
    dice_loss_jit,
    sigmoid_ce_loss,
    sigmoid_ce_loss_jit,
)
from rfdetr.models.heads.segmentation import SegmentationHead
from rfdetr.models.lwdetr import LWDETR
from rfdetr.models.matcher import HungarianMatcher
from rfdetr.utilities.tensors import NestedTensor, pad_targets_to_fixed_count
from tests._markers import _requires_cuda, _requires_cuda_bf16, _requires_torch_xla


class _MatcherStub:
    """Minimal matcher that returns identity indices for every target in the batch."""

    def __call__(self, outputs, targets, group_detr=1, target_side_safety=None):
        return [(torch.arange(len(t["labels"])), torch.arange(len(t["labels"]))) for t in targets]


class _LegacyMatcherStub:
    """Matcher predating the target-side-safety cache: two-argument signature, no precompute method.

    Deliberately has neither a ``target_side_safety`` parameter nor a ``_precompute_target_side_safety`` attribute, so
    it raises TypeError if ``SetCriterion.forward`` passes the kwarg unconditionally.
    """

    def __call__(self, outputs, targets, group_detr=1):
        return [(torch.arange(len(t["labels"])), torch.arange(len(t["labels"]))) for t in targets]


def _bare_criterion() -> SetCriterion:
    """Return a SetCriterion with no losses so forward() is a no-op.

    Examples:
        >>> isinstance(_bare_criterion(), SetCriterion)
        True
    """
    criterion = SetCriterion.__new__(SetCriterion)
    criterion.training = True
    criterion.group_detr = 1
    criterion.sum_group_losses = False
    criterion.losses = []
    criterion.weight_dict = {}
    criterion.matcher = _MatcherStub()
    criterion.num_keypoints_per_class = []
    return criterion


class TestOutputDevice:
    """Tests for SetCriterion._output_device — probes top-level tensor values only."""

    def test_returns_device_of_first_tensor(self):
        """Device inferred from the first tensor value in outputs."""
        outputs = {"pred_logits": torch.zeros(1, 1, 1)}

        device = SetCriterion._output_device(outputs)

        assert device == torch.device("cpu")

    def test_raises_when_no_tensor_present(self):
        """ValueError raised when no top-level value is a tensor."""
        outputs = {"meta": "string_value", "count": 42}

        with pytest.raises(ValueError) as exc_info:
            SetCriterion._output_device(outputs)

        assert "at least one tensor" in str(exc_info.value)

    def test_skips_non_tensor_values(self):
        """Non-tensor entries at the top level are skipped; first tensor wins."""
        outputs = {"meta": "ignored", "pred_logits": torch.zeros(1, 1, 1)}

        device = SetCriterion._output_device(outputs)

        assert device == torch.device("cpu")


class TestNumBoxesForTargets:
    """Tests for SetCriterion.num_boxes_for_targets — clamp and empty-target edge cases."""

    def test_returns_tensor_gte_one(self):
        """Result must be clamped to >= 1.0 to prevent division by zero."""
        criterion = _bare_criterion()
        outputs = {"pred_logits": torch.zeros(1, 1, 1)}
        targets = [{"labels": torch.tensor([0, 1])}]

        result = criterion.num_boxes_for_targets(outputs, targets)

        assert result.item() >= 1.0

    def test_clamps_zero_box_count_to_one(self):
        """Empty targets (no labels) must clamp to 1.0 to avoid zero denominator."""
        criterion = _bare_criterion()
        outputs = {"pred_logits": torch.zeros(1, 1, 1)}
        targets = [{"labels": torch.zeros(0, dtype=torch.int64)}]

        result = criterion.num_boxes_for_targets(outputs, targets)

        assert result.item() == pytest.approx(1.0)

    def test_clamps_empty_target_list(self):
        """Empty target list (batch_size=0 edge case) must also clamp to 1.0."""
        criterion = _bare_criterion()
        outputs = {"pred_logits": torch.zeros(1, 1, 1)}
        targets = []

        result = criterion.num_boxes_for_targets(outputs, targets)

        assert result.item() == pytest.approx(1.0)

    def test_counts_labels_across_targets(self):
        """Box count equals total number of labels across all targets in the batch."""
        criterion = _bare_criterion()
        outputs = {"pred_logits": torch.zeros(1, 1, 1)}
        targets = [
            {"labels": torch.tensor([0, 1])},
            {"labels": torch.tensor([0])},
        ]

        result = criterion.num_boxes_for_targets(outputs, targets)

        # 2 + 1 = 3 boxes; single-process so no all-reduce
        assert result.item() == pytest.approx(3.0)


class TestLossMasksEmptyMatch:
    """Tests for the dict-path zero-GT branch of SetCriterion.loss_masks."""

    def test_dict_path_zero_gt_stays_connected_to_graph(self):
        """Zero-match dict path returns a loss that back-propagates to every segmentation-head output."""
        criterion = _bare_criterion()
        spatial_features = torch.randn(1, 4, 8, 8, requires_grad=True)
        query_features = torch.randn(1, 5, 4, requires_grad=True)
        bias = torch.randn(1, requires_grad=True)
        outputs = {
            "pred_masks": {
                "spatial_features": spatial_features,
                "query_features": query_features,
                "bias": bias,
            }
        }
        empty = torch.empty(0, dtype=torch.long)
        indices = [(empty, empty)]

        losses = criterion.loss_masks(outputs, targets=[{}], indices=indices, num_boxes=1)

        assert losses["loss_mask_ce"].requires_grad
        (losses["loss_mask_ce"] + losses["loss_mask_dice"]).backward()
        assert spatial_features.grad is not None
        assert query_features.grad is not None
        assert bias.grad is not None


class TestTargetMaskPointSampling:
    """Tests for the guarded direct sampling of matched ground-truth masks."""

    @pytest.mark.gpu
    @_requires_cuda
    @pytest.mark.parametrize(
        "variant", ["random", "ties", "outside", "nan", "strided", "empty", "coords_grad", "negative", "cuda_indices"]
    )
    def test_cuda_sampling_matches_native_labels(self, variant: str) -> None:
        """Every CUDA route preserves native labels and matched-group order."""
        torch.manual_seed(51)
        masks = [torch.rand(3, 211, 673, device="cuda") > 0.5 for _ in range(3)]
        matched = [torch.tensor([2, 0, 1, 2, 1, 0]) for _ in masks]
        if variant == "empty":
            matched[1] = torch.empty(0, dtype=torch.int64)
        elif variant == "negative":
            matched = [index - 3 for index in matched]
        elif variant == "cuda_indices":
            matched = [index.cuda() for index in matched]
        if variant == "strided":
            masks = [mask.transpose(1, 2) for mask in masks]
        coords = torch.rand(sum(index.numel() for index in matched), 17, 2, device="cuda")
        if variant == "ties":
            coords[:] = torch.tensor([1 / 673, 1 / 211], device="cuda")
        elif variant == "outside":
            coords[0, 0] = torch.tensor([-0.2, 1.2], device="cuda")
        elif variant == "nan":
            coords[0, 0] = float("nan")
        elif variant == "coords_grad":
            coords.requires_grad_()
        reference_masks = torch.cat([mask[index] for mask, index in zip(masks, matched)])
        expected = criterion_module.point_sample(
            reference_masks.unsqueeze(1).float(), coords, align_corners=False, mode="nearest"
        ).squeeze(1)

        actual = criterion_module._sample_target_masks_at_points(
            [{"masks": mask} for mask in masks], [(index, index) for index in matched], coords
        )

        assert torch.equal(actual.detach().view(torch.uint8), expected.detach().view(torch.uint8))
        if coords.requires_grad:
            expected_grad = torch.autograd.grad(expected.sum(), coords)[0]
            actual_grad = torch.autograd.grad(actual.sum(), coords)[0]
            assert torch.equal(actual_grad.view(torch.uint8), expected_grad.view(torch.uint8))

    @pytest.mark.gpu
    @_requires_cuda
    @pytest.mark.parametrize(
        ("variant", "expected_sampled_rows"),
        [
            ("random", []),
            ("single_match", []),
            ("ties", [3, 3, 3]),
            ("nan", [1]),
            ("strided", [6, 6, 6]),
            ("coords_grad", [6, 6, 6]),
        ],
    )
    def test_cuda_bool_masks_are_gathered_not_copied(
        self, mocker: MockerFixture, variant: str, expected_sampled_rows: list[int]
    ) -> None:
        """Contiguous CUDA boolean masks are read with a gather; grid sampling only resolves ties and NaNs.

        Grid sampling needs float masks, so every row it is handed is a full-resolution float copy of a matched mask.
        Tied points are grouped by mask, so 102 ties over three distinct masks copy three masks, not 102. Non-contiguous
        masks and coordinates that require a gradient keep the per-image grid-sampling path.
        """
        torch.manual_seed(7)
        masks = [torch.rand(3, 211, 673, device="cuda") > 0.5 for _ in range(3)]
        matched = [torch.tensor([2, 0, 1, 2, 1, 0]) for _ in masks]
        if variant == "single_match":
            matched = [torch.tensor([1]) for _ in masks]
        coords = torch.rand(sum(index.numel() for index in matched), 17, 2, device="cuda")
        if variant == "ties":
            coords[:] = torch.tensor([1 / 673, 1 / 211], device="cuda")
        elif variant == "nan":
            coords[0, 0] = float("nan")
        elif variant == "strided":
            masks = [mask.transpose(1, 2) for mask in masks]
        elif variant == "coords_grad":
            coords.requires_grad_()
        sampler = mocker.patch.object(criterion_module, "point_sample", wraps=criterion_module.point_sample)

        criterion_module._sample_target_masks_at_points(
            [{"masks": mask} for mask in masks], [(index, index) for index in matched], coords
        )

        assert [call.args[0].shape[0] for call in sampler.call_args_list] == expected_sampled_rows

    @pytest.mark.gpu
    @_requires_cuda
    @pytest.mark.parametrize("variant", ["float", "all_empty", "different_shapes", "wrong_count"])
    def test_cuda_per_image_sampling_retains_fallback(self, mocker: MockerFixture, variant: str) -> None:
        """Unsupported inputs retain native concatenation and sampler validation."""
        masks = [torch.ones(2, 24, 24, dtype=torch.bool, device="cuda") for _ in range(2)]
        matched = torch.arange(2) if variant != "all_empty" else torch.empty(0, dtype=torch.int64)
        coords = torch.zeros(matched.numel() * 2, 7, 2, device="cuda")
        if variant == "float":
            masks = [mask.float() for mask in masks]
        elif variant == "different_shapes":
            masks[1] = masks[1][:, :12]
        elif variant == "wrong_count":
            coords = coords[:1]
        sampler = mocker.patch.object(criterion_module, "point_sample", wraps=criterion_module.point_sample)
        if variant in ("different_shapes", "wrong_count"):
            with pytest.raises(RuntimeError) as exc_info:
                criterion_module._sample_target_masks_at_points(
                    [{"masks": mask} for mask in masks], [(matched, matched)] * 2, coords
                )
            assert any(text in str(exc_info.value) for text in ("Sizes of tensors must match", "same batch size"))
        else:
            actual = criterion_module._sample_target_masks_at_points(
                [{"masks": mask} for mask in masks], [(matched, matched)] * 2, coords
            )
            assert actual.shape == (matched.numel() * 2, 7)
            assert torch.equal(actual, torch.ones_like(actual))
            # Float masks keep grid sampling; boolean masks with no matches are gathered (nothing to sample).
            assert sampler.call_count == (1 if variant == "float" else 0)

    @pytest.mark.parametrize(
        ("height", "width", "groups", "expected_fallback_calls"),
        [
            pytest.param(24, 24, 13, 1, id="small-repeated-targets-fall-back"),
            pytest.param(256, 256, 2, 0, id="large-targets-use-direct-indexing"),
        ],
    )
    def test_matches_grid_sample_bitwise_and_routes_by_cost_guard(
        self,
        mocker: MockerFixture,
        height: int,
        width: int,
        groups: int,
        expected_fallback_calls: int,
    ) -> None:
        """Direct and fallback paths match nearest ``grid_sample`` bit-for-bit."""
        num_targets = 8
        masks = torch.arange(num_targets * height * width, dtype=torch.int32).reshape(num_targets, height, width)
        masks = masks.remainder(251).to(torch.uint8)
        matched = torch.arange(num_targets).repeat(groups)
        indices = [(matched, matched)]
        generator = torch.Generator().manual_seed(0)
        point_coords = torch.rand((matched.numel(), 17, 2), generator=generator)
        point_coords[:, :4] = torch.tensor(
            [
                # 0.0/1.0 unnormalize to an exact pixel-center tie for any mask size (covered by
                # ``test_pixel_center_tie_corrects_only_the_tied_points``); these stay near the edges without
                # tying, so this case still exercises boundary clamping on the direct path.
                [0.001, 0.001],
                [0.999, 0.999],
                [-0.2, 1.2],
                [0.3, 0.7],
            ]
        )
        expected = criterion_module.point_sample(
            masks[matched].unsqueeze(1).float(),
            point_coords,
            align_corners=False,
            mode="nearest",
        ).squeeze(1)
        fallback = mocker.patch.object(criterion_module, "point_sample", wraps=criterion_module.point_sample)

        actual = criterion_module._sample_target_masks_at_points([{"masks": masks}], indices, point_coords)

        assert torch.equal(actual.view(torch.int32), expected.view(torch.int32))
        assert fallback.call_count == expected_fallback_calls

    @pytest.mark.parametrize(
        ("height", "n_images", "masks_per_image", "matches_per_image", "n_points"),
        [
            pytest.param(64, 16, 2, 4, 64, id="many-small-image-groups"),
            pytest.param(300, 8, 1, 1, 380, id="single-match-per-image-groups"),
        ],
    )
    def test_groups_under_a_per_group_floor_fall_back(
        self,
        mocker: MockerFixture,
        height: int,
        n_images: int,
        masks_per_image: int,
        matches_per_image: int,
        n_points: int,
    ) -> None:
        """Image groups that clear the aggregate cost floor but not a per-group one stay on ``point_sample``.

        The direct path pays a fixed per-image loop iteration cost (slicing, index computation, a device transfer, a
        gather) that is not amortized by a small or single-match group.

        ``many-small-image-groups``: 16 images with 4 matches each of 64x64 masks total 1,048,576 elements -- far above
        ``_MIN_DIRECT_MASK_ELEMENTS`` (1048576) -- but each image alone contributes only 16,384. Measured on this
        machine: the direct path is ~4.4x SLOWER than ``point_sample``, stable across 65536/262144/1048576-element
        totals, not machine noise.

        ``single-match-per-image-groups``: 8 images with exactly 1 match each of 300x300 masks have a per-group element
        count (90,000) that the per-group element floor does not reject, but the loop overhead is not amortized by one
        match per group. Measured: the direct path is ~1.25-1.5x SLOWER than ``point_sample`` across 1-8 images. The
        per-group MATCH COUNT floor (independent of mask resolution) keeps the guard from taking it.
        """
        masks = [torch.rand(masks_per_image, height, height) for _ in range(n_images)]
        targets = [{"masks": image_masks} for image_masks in masks]
        matched = torch.arange(masks_per_image).repeat(matches_per_image // masks_per_image)
        indices = [(matched, matched) for _ in range(n_images)]
        point_coords = torch.rand(n_images * matches_per_image, n_points, 2)
        expected_masks = torch.cat([image_masks[matched] for image_masks in masks])
        expected = criterion_module.point_sample(
            expected_masks.unsqueeze(1).float(),
            point_coords,
            align_corners=False,
            mode="nearest",
        ).squeeze(1)
        fallback = mocker.patch.object(criterion_module, "point_sample", wraps=criterion_module.point_sample)

        actual = criterion_module._sample_target_masks_at_points(targets, indices, point_coords)

        assert torch.equal(actual.view(torch.int32), expected.view(torch.int32))
        fallback.assert_called_once()

    def test_tied_points_grouped_by_mask_keep_their_order(self, mocker: MockerFixture) -> None:
        """Grouping tied points by mask samples each point from its own mask and returns them in input order."""
        generator = torch.Generator().manual_seed(3)
        masks = torch.rand(5, 37, 53, generator=generator) > 0.5
        mask_indices = torch.tensor([4, 0, 4, 2, 0, 4, 1, 2, 4])
        coords = torch.rand(mask_indices.numel(), 2, generator=generator)
        expected = criterion_module.point_sample(
            masks[mask_indices].unsqueeze(1).float(), coords.unsqueeze(1), align_corners=False, mode="nearest"
        ).flatten()
        sampler = mocker.patch.object(criterion_module, "point_sample", wraps=criterion_module.point_sample)

        actual = criterion_module._sample_tied_points(masks, mask_indices, coords)

        assert torch.equal(actual, expected)
        (sampled_masks, padded_coords), _ = sampler.call_args
        assert sampled_masks.shape[0] == 4  # distinct masks, not points
        assert padded_coords.shape == (4, 4, 2)  # mask 4 holds the most tied points

    @pytest.mark.parametrize(
        ("axis", "height", "width"),
        [
            pytest.param(0, 560, 673, id="x-axis"),
            pytest.param(1, 673, 560, id="y-axis"),
        ],
    )
    def test_pixel_center_tie_corrects_only_the_tied_points(
        self, mocker: MockerFixture, axis: int, height: int, width: int
    ) -> None:
        """A coordinate on an exact pixel-center tie, on either axis, is corrected via ``point_sample``, not a full
        fallback.

        ``1 / 673`` unnormalizes to exactly ``0.5`` for a side of 673, a tie where PyTorch's compiled ``grid_sample``
        nearest-mode kernel disagrees with ``torch.round`` (a float32 evaluation-order artifact; it agrees for 96).
        Without a per-point correction this mask/coordinate pair samples label ``0`` where ``point_sample`` samples
        ``1``. A real point set of a few hundred points routinely contains such a tie (22/30 runs of a 104-match x
        380-point set did), so falling back for the whole call on any tie would give away most of the optimization: only
        the tied points should pay the ``point_sample`` cost, not the other 152 points sampled in this call.
        """
        masks = torch.zeros(8, height, width, dtype=torch.uint8)
        # Index 1 on the tied axis is the only way to tell "rounded to 0" from "to 1".
        masks.select(2 - axis, 1).fill_(1)
        matched = torch.arange(8)
        indices = [(matched, matched)]
        generator = torch.Generator().manual_seed(0)
        point_coords = torch.rand(8, 20, 2, generator=generator)
        point_coords[:, 0, axis] = 1.0 / 673.0  # ties every row's first point; the other 19 columns per row do not.
        expected = criterion_module.point_sample(
            masks[matched].unsqueeze(1).float(), point_coords, align_corners=False, mode="nearest"
        ).squeeze(1)
        fallback = mocker.patch.object(criterion_module, "point_sample", wraps=criterion_module.point_sample)

        actual = criterion_module._sample_target_masks_at_points([{"masks": masks}], indices, point_coords)

        assert torch.equal(actual.view(torch.int32), expected.view(torch.int32))
        fallback.assert_called_once()
        # The correction call covers only the 8 tied points (one per row's column 0), not all 8x20 = 160 sampled points.
        (correction_masks, correction_coords), _ = fallback.call_args
        assert correction_masks.shape[0] == 8
        assert correction_coords.shape == (8, 1, 2)

    def test_float64_point_coords_preserve_fallback_semantics(self, mocker: MockerFixture) -> None:
        """Float64 coordinates remain on the established fallback path."""
        masks = torch.rand(8, 96, 96)
        matched = torch.arange(8)
        indices = [(matched, matched)]
        point_coords = torch.rand(8, 11, 2, dtype=torch.float64)
        fallback = mocker.patch.object(criterion_module, "point_sample", wraps=criterion_module.point_sample)

        with pytest.raises(RuntimeError) as exc_info:
            criterion_module._sample_target_masks_at_points([{"masks": masks}], indices, point_coords)

        assert "scalar type Float but found Double" in str(exc_info.value)
        fallback.assert_called_once()

    def test_noncontiguous_masks_preserve_fallback_semantics(self, mocker: MockerFixture) -> None:
        """Non-contiguous masks remain on the established fallback path."""
        masks = torch.rand(8, 96, 96).transpose(1, 2)
        assert not masks.is_contiguous()
        matched = torch.arange(8)
        indices = [(matched, matched)]
        point_coords = torch.rand(8, 11, 2)
        expected = criterion_module.point_sample(
            masks[matched].unsqueeze(1).float(),
            point_coords,
            align_corners=False,
            mode="nearest",
        ).squeeze(1)
        fallback = mocker.patch.object(criterion_module, "point_sample", wraps=criterion_module.point_sample)

        actual = criterion_module._sample_target_masks_at_points([{"masks": masks}], indices, point_coords)

        assert torch.equal(actual.view(torch.int32), expected.view(torch.int32))
        fallback.assert_called_once()

    def test_non_int64_target_indices_preserve_fallback_semantics(self, mocker: MockerFixture) -> None:
        """Non-int64 matcher indices remain on the established fallback path."""
        masks = torch.rand(8, 96, 96)
        matched = torch.arange(8, dtype=torch.int32)
        indices = [(matched, matched)]
        point_coords = torch.rand(8, 11, 2)
        expected = criterion_module.point_sample(
            masks[matched].unsqueeze(1).float(),
            point_coords,
            align_corners=False,
            mode="nearest",
        ).squeeze(1)
        fallback = mocker.patch.object(criterion_module, "point_sample", wraps=criterion_module.point_sample)

        actual = criterion_module._sample_target_masks_at_points([{"masks": masks}], indices, point_coords)

        assert torch.equal(actual.view(torch.int32), expected.view(torch.int32))
        fallback.assert_called_once()

    def test_positive_out_of_range_indices_preserve_fallback_semantics(self, mocker: MockerFixture) -> None:
        """Positive out-of-range matcher indices remain on the established fallback path."""
        masks = torch.rand(8, 96, 96)
        matched = torch.tensor([0, 1, 2, 3, 4, 5, 6, 8])
        indices = [(matched, matched)]
        point_coords = torch.rand(8, 11, 2)
        fallback_targets = [{"masks": masks}]
        fallback = mocker.patch.object(criterion_module, "point_sample", wraps=criterion_module.point_sample)

        with pytest.raises(IndexError):
            criterion_module._sample_target_masks_at_points(fallback_targets, indices, point_coords)

        fallback.assert_not_called()

    @pytest.mark.gpu
    @_requires_cuda
    def test_cuda_point_coords_preserve_fallback_for_cpu_masks(self, mocker: MockerFixture) -> None:
        """CUDA point coordinates with CPU masks remain on the established fallback path."""
        masks = torch.rand(8, 96, 96)
        matched = torch.arange(8)
        indices = [(matched, matched)]
        point_coords = torch.rand(8, 11, 2, device="cuda")
        fallback = mocker.patch.object(
            criterion_module, "point_sample", return_value=torch.zeros(8, 1, 11, device="cuda")
        )

        criterion_module._sample_target_masks_at_points([{"masks": masks}], indices, point_coords)

        fallback.assert_called_once()

    @pytest.mark.gpu
    @_requires_cuda
    def test_cuda_matcher_indices_preserve_fallback_semantics(self, mocker: MockerFixture) -> None:
        """CUDA matcher indices remain on the established fallback path."""
        masks = torch.rand(8, 96, 96, device="cuda")
        matched = torch.arange(8, device="cuda")
        indices = [(matched, matched)]
        point_coords = torch.rand(8, 11, 2, device="cuda")
        fallback = mocker.patch.object(
            criterion_module, "point_sample", return_value=torch.zeros(8, 1, 11, device="cuda")
        )

        criterion_module._sample_target_masks_at_points([{"masks": masks}], indices, point_coords)

        fallback.assert_called_once()

    def test_negative_indices_preserve_existing_fallback_semantics(self, mocker: MockerFixture) -> None:
        """Valid negative advanced indices stay on the existing ``point_sample`` path."""
        height = width = 96
        masks = torch.rand(8, height, width)
        matched = torch.tensor([0, 1, 2, 3, 4, 5, 6, -1])
        indices = [(matched, matched)]
        point_coords = torch.rand(matched.numel(), 11, 2)
        expected = criterion_module.point_sample(
            masks[matched].unsqueeze(1).float(),
            point_coords,
            align_corners=False,
            mode="nearest",
        ).squeeze(1)
        fallback = mocker.patch.object(criterion_module, "point_sample", wraps=criterion_module.point_sample)

        actual = criterion_module._sample_target_masks_at_points([{"masks": masks}], indices, point_coords)

        assert torch.equal(actual.view(torch.int32), expected.view(torch.int32))
        fallback.assert_called_once()

    def test_direct_path_preserves_multi_image_match_order(self, mocker: MockerFixture) -> None:
        """Per-image direct samples concatenate in matcher order, including an empty middle image.

        Each non-empty group uses 16 matched targets at 256x256 (1,048,576 elements) so it clears the per-group cost
        floor on its own -- a group below that floor is expected to fall back regardless of the other
        groups' size (see ``test_matches_grid_sample_bitwise_and_routes_by_cost_guard``'s
        ``small-repeated-targets-fall-back`` case and the per-group guard in
        ``_sample_target_masks_at_points``).
        """
        torch.manual_seed(0)  # deterministic and, at this point count, verified to land no exact-tie coordinate.
        masks = [torch.rand(8, 256, 256), torch.empty(0, 256, 256), torch.rand(8, 256, 256)]
        first = torch.arange(8).repeat(2)
        empty = torch.empty(0, dtype=torch.int64)
        last = torch.tensor([7, 5, 1, 0, 6, 2, 4, 3]).repeat(2)
        indices = [(first, first), (empty, empty), (last, last)]
        point_coords = torch.rand(32, 19, 2)
        expected_masks = torch.cat((masks[0][first], masks[1][empty], masks[2][last]))
        expected = criterion_module.point_sample(
            expected_masks.unsqueeze(1).float(),
            point_coords,
            align_corners=False,
            mode="nearest",
        ).squeeze(1)
        fallback = mocker.patch.object(criterion_module, "point_sample", wraps=criterion_module.point_sample)

        actual = criterion_module._sample_target_masks_at_points(
            [{"masks": image_masks} for image_masks in masks], indices, point_coords
        )

        assert torch.equal(actual.view(torch.int32), expected.view(torch.int32))
        fallback.assert_not_called()

    @pytest.mark.gpu
    @_requires_cuda
    def test_single_cuda_image_is_gathered(self, mocker: MockerFixture) -> None:
        """A single CUDA image is gathered too: batch 1 at high resolution is where the float copies cost most."""
        torch.manual_seed(0)  # deterministic and, at this point count, verified to land no exact-tie coordinate.
        masks = (torch.rand(8, 96, 96, device="cuda") > 0.5).contiguous()
        matched = torch.arange(8)
        indices = [(matched, matched)]
        point_coords = torch.rand(8, 17, 2, device="cuda")
        expected = criterion_module.point_sample(
            masks[matched].unsqueeze(1).float(),
            point_coords,
            align_corners=False,
            mode="nearest",
        ).squeeze(1)
        fallback = mocker.patch.object(criterion_module, "point_sample", wraps=criterion_module.point_sample)

        actual = criterion_module._sample_target_masks_at_points([{"masks": masks}], indices, point_coords)

        assert torch.equal(actual.view(torch.int32), expected.view(torch.int32))
        fallback.assert_not_called()

    def test_loss_masks_uses_guarded_target_sampler(self, mocker: MockerFixture) -> None:
        """The tensor ``loss_masks`` path delegates target labels to the guarded sampler."""
        criterion = _bare_criterion()
        criterion.mask_point_sample_ratio = 16
        pred_masks = torch.randn(1, 8, 24, 24, requires_grad=True)
        targets = [{"masks": torch.rand(8, 96, 96) > 0.5}]
        matched = torch.arange(8)
        indices = [(matched, matched)]
        sampler = mocker.patch.object(
            criterion_module, "_sample_target_masks_at_points", wraps=criterion_module._sample_target_masks_at_points
        )

        losses = criterion.loss_masks({"pred_masks": pred_masks}, targets, indices, num_boxes=torch.tensor(8.0))
        (losses["loss_mask_ce"] + losses["loss_mask_dice"]).backward()

        sampler.assert_called_once()
        assert pred_masks.grad is not None


class TestLossMasksNonEmptyMatchUsesRealSegmentationHeadOutput:
    """The non-empty-match branch of the dict path (``criterion.py``'s einsum over
    ``outputs["pred_masks"]["spatial_features"]``) reads that key straight off the dict with no projection of its own —
    it trusts whatever produced it.

    ``SegmentationHead``-only tests can't catch a regression here, since they never call ``loss_masks``. This builds the
    dict with a real ``SegmentationHead`` (``sparse_forward(skip_blocks=True)``, non-identity ``spatial_features_proj``)
    instead of hand-built tensors, and checks the loss is sensitive to whether the projection was applied and that
    gradient reaches ``spatial_features_proj.weight``.
    """

    def test_loss_backprops_to_projection_weight_and_is_sensitive_to_it(self) -> None:
        """Mask losses backpropagate to ``spatial_features_proj.weight`` and differ from the unprojected-features
        losses."""
        torch.manual_seed(0)
        hidden, mask_size = 4, 8
        head = SegmentationHead(in_dim=hidden, num_blocks=1, bottleneck_ratio=1, downsample_ratio=1)
        spatial_features = torch.randn(1, hidden, mask_size, mask_size)
        query_features = torch.randn(1, 2, hidden)
        targets = [{"masks": torch.rand(2, mask_size, mask_size)}]
        indices = [(torch.tensor([0, 1]), torch.tensor([0, 1]))]
        criterion = _bare_criterion()
        criterion.mask_point_sample_ratio = 16

        # Real head output: spatial_features is already projected by sparse_forward.
        real_dict = head.sparse_forward(spatial_features, [query_features], (mask_size, mask_size), skip_blocks=True)[0]
        torch.manual_seed(1)  # get_uncertain_point_coords_with_randomness draws torch.rand internally.
        real_losses = criterion.loss_masks({"pred_masks": real_dict}, targets, indices, num_boxes=torch.tensor(2.0))
        (real_losses["loss_mask_ce"] + real_losses["loss_mask_dice"]).backward()
        assert head.spatial_features_proj.weight.grad is not None
        assert torch.isfinite(head.spatial_features_proj.weight.grad).all()

        # Corrupted dict: same query_features/bias, but spatial_features is the RAW, unprojected
        # tensor — exactly what the pre-fix skip_blocks=True branch used to hand loss_masks.
        with torch.no_grad():
            raw_resized = torch.nn.functional.interpolate(
                spatial_features, size=(mask_size, mask_size), mode="bilinear", align_corners=False
            )
        corrupted_dict = {
            "spatial_features": raw_resized,
            "query_features": real_dict["query_features"].detach(),
            "bias": real_dict["bias"].detach(),
        }
        torch.manual_seed(1)  # same point-sampling draw as the real-dict call above, for a fair comparison.
        corrupted_losses = criterion.loss_masks(
            {"pred_masks": corrupted_dict}, targets, indices, num_boxes=torch.tensor(2.0)
        )

        assert not torch.allclose(real_losses["loss_mask_ce"], corrupted_losses["loss_mask_ce"])
        assert not torch.allclose(real_losses["loss_mask_dice"], corrupted_losses["loss_mask_dice"])


def _build_encoder_only_features(batch_size: int, hidden_dim: int, size: int) -> list[NestedTensor]:
    """Build the single-level backbone feature map an ``LWDETR`` forward pass consumes.

    Examples:
        >>> len(_build_encoder_only_features(batch_size=1, hidden_dim=4, size=4))
        1
    """
    return [
        NestedTensor(
            torch.randn(batch_size, hidden_dim, size, size),
            torch.zeros(batch_size, size, size, dtype=torch.bool),
        )
    ]


class TestEncOutputsMaskLossThroughRealForwardPath:
    """No prior test drove a real ``SegmentationHead`` through the actual production path: ``LWDETR.forward()`` building
    ``enc_outputs["pred_masks"]`` with ``skip_blocks=True``, then ``SetCriterion.forward()``'s ``"enc_outputs"`` branch
    (``lwdetr.py``'s two-stage block, ``criterion.py``'s ``_enc``-suffixed losses).

    The other tests in this module and in ``test_matcher.py`` call ``SegmentationHead.sparse_forward()``,
    ``loss_masks()``, and ``HungarianMatcher.__call__()`` directly instead — real coverage of each unit, but none of
    them exercise the forward/criterion wiring that actually reaches ``enc_outputs`` in training, where ``two_stage``
    and ``aux_loss`` both default to ``True`` for every released ``RFDETRSeg*`` model.
    """

    def test_loss_mask_ce_enc_backprops_to_projection_weight(self) -> None:
        """A real ``LWDETR`` forward feeds ``enc_outputs`` mask losses whose gradient reaches
        ``spatial_features_proj.weight``."""
        torch.manual_seed(0)
        batch_size, hidden_dim, num_queries, num_queries_enc, num_classes, mask_size = 1, 4, 2, 3, 3, 8

        backbone = MagicMock()
        backbone.return_value = (_build_encoder_only_features(batch_size, hidden_dim, size=4), [torch.zeros(1)], None)

        transformer = MagicMock()
        transformer.d_model = hidden_dim
        transformer.return_value = (
            torch.randn(1, batch_size, num_queries, hidden_dim),  # hs (1 decoder layer)
            torch.rand(1, batch_size, num_queries, 4) * 0.4 + 0.3,  # ref_unsigmoid
            torch.randn(batch_size, num_queries_enc, hidden_dim),  # hs_enc
            torch.rand(batch_size, num_queries_enc, 4) * 0.4 + 0.3,  # ref_enc
        )

        model = LWDETR(
            backbone=backbone,
            transformer=transformer,
            segmentation_head=SegmentationHead(in_dim=hidden_dim, num_blocks=1, bottleneck_ratio=1, downsample_ratio=1),
            num_classes=num_classes,
            num_queries=num_queries,
            aux_loss=False,
            group_detr=1,
            two_stage=True,
            bbox_reparam=False,
        )

        outputs = model(torch.randn(batch_size, 3, mask_size, mask_size))
        assert isinstance(outputs["enc_outputs"]["pred_masks"], dict)

        criterion = SetCriterion(
            num_classes=num_classes,
            matcher=HungarianMatcher(),
            weight_dict={},
            focal_alpha=0.25,
            losses=["masks"],
            group_detr=1,
            mask_point_sample_ratio=16,
        )
        targets: list[dict[str, Tensor]] = [
            {
                "labels": torch.tensor([0]),
                "boxes": torch.rand(1, 4) * 0.4 + 0.3,
                "masks": torch.rand(1, mask_size, mask_size),
            }
        ]

        losses = criterion(outputs, targets)

        assert "loss_mask_ce_enc" in losses
        (losses["loss_mask_ce_enc"] + losses["loss_mask_dice_enc"]).backward()
        proj_grad = model.segmentation_head.spatial_features_proj.weight.grad
        assert proj_grad is not None
        assert torch.isfinite(proj_grad).all()


class TestMatcherContract:
    """``target_side_safety`` is an optimization SetCriterion offers, not part of the matcher contract it requires."""

    def test_forward_supports_matcher_without_target_side_safety_kwarg(self) -> None:
        """A duck-typed matcher with a two-argument signature drives a full multi-call step without TypeError.

        The step deliberately carries a non-empty ``aux_outputs`` plus ``enc_outputs`` -- the shape that makes
        ``SetCriterion.forward`` want a precomputed safety value in the first place. A step without them short-circuits
        before any precompute and would pass even against an unguarded call site, proving nothing.
        """
        batch_size, num_queries, num_classes = 2, 4, 3
        layers = [
            {
                "pred_logits": torch.zeros(batch_size, num_queries, num_classes),
                "pred_boxes": torch.full((batch_size, num_queries, 4), 0.5),
            }
            for _ in range(3)
        ]
        outputs = {**layers[0], "aux_outputs": [layers[1]], "enc_outputs": layers[2]}
        targets = [
            {"labels": torch.zeros(2, dtype=torch.int64), "boxes": torch.full((2, 4), 0.5)} for _ in range(batch_size)
        ]
        criterion = _bare_criterion()
        criterion.matcher = _LegacyMatcherStub()

        assert criterion.forward(outputs, targets, num_boxes=1.0) == {}


class TestMatchedTargetCache:
    """Matched labels and boxes are shared by all detection losses for one output layer."""

    def test_matched_targets_collects_each_target_field_once(self) -> None:
        """The cache preserves target ordering while providing one shared loss context.

        This prevents the criterion from reconstructing the same labels and boxes for classification and box losses
        independently. It fails before the cache exists.
        """
        criterion = _bare_criterion()
        targets = [
            {
                "labels": torch.tensor([2, 1], dtype=torch.int64),
                "boxes": torch.tensor([[0.2, 0.3, 0.4, 0.5], [0.4, 0.5, 0.2, 0.3]]),
            },
            {
                "labels": torch.tensor([0], dtype=torch.int64),
                "boxes": torch.tensor([[0.5, 0.5, 0.1, 0.2]]),
            },
        ]
        indices = [(torch.tensor([1]), torch.tensor([0])), (torch.tensor([0]), torch.tensor([0]))]

        matched = criterion._get_matched_targets(targets, indices)

        assert torch.equal(matched.source_indices[0], torch.tensor([0, 1]))
        assert torch.equal(matched.source_indices[1], torch.tensor([1, 0]))
        assert torch.equal(matched.labels, torch.tensor([2, 0]))
        assert torch.equal(matched.boxes, torch.tensor([[0.2, 0.3, 0.4, 0.5], [0.5, 0.5, 0.1, 0.2]]))

    def test_forward_reuses_one_cached_call_per_layer_for_labels_and_boxes(self, mocker: MockerFixture) -> None:
        """``forward()`` must call ``_get_matched_targets`` exactly once per output layer, not once per loss.

        The other test in this class only checks ``_get_matched_targets``'s own return values in isolation -- it would
        still pass if ``forward()`` stopped supplying the cache and ``loss_labels``/``loss_boxes`` rebuilt their matched
        tensors independently. This drives a real ``forward()`` call with ``losses=["labels", "boxes"]`` across three
        output layers (final, one aux, one enc) and spies on ``_get_matched_targets`` to prove one cached call serves
        both losses for each layer.
        """
        batch_size, num_queries, num_classes = 2, 4, 3
        criterion = SetCriterion(
            num_classes=num_classes,
            matcher=_MatcherStub(),
            weight_dict={},
            focal_alpha=0.25,
            losses=["labels", "boxes"],
            group_detr=1,
        )
        targets = [
            {"labels": torch.tensor([1, 2]), "boxes": torch.rand(2, 4) * 0.4 + 0.3},
            {"labels": torch.tensor([0]), "boxes": torch.rand(1, 4) * 0.4 + 0.3},
        ]

        def _layer() -> dict[str, torch.Tensor]:
            return {
                "pred_logits": torch.randn(batch_size, num_queries, num_classes),
                "pred_boxes": torch.rand(batch_size, num_queries, 4) * 0.4 + 0.3,
            }

        outputs = {**_layer(), "aux_outputs": [_layer()], "enc_outputs": _layer()}

        spy = mocker.patch.object(criterion, "_get_matched_targets", wraps=criterion._get_matched_targets)

        losses = criterion(outputs, targets, num_boxes=1.0)

        assert spy.call_count == 3, "one cached call per output layer (final + aux + enc), not per loss"
        for suffix in ("", "_0", "_enc"):
            assert f"loss_ce{suffix}" in losses
            assert f"loss_bbox{suffix}" in losses
            assert f"loss_giou{suffix}" in losses

    @pytest.mark.parametrize("loss_flag", ["ia_bce_loss", "use_position_supervised_loss"])
    def test_loss_labels_matches_cached_and_recomputed_matched_targets(self, loss_flag: str) -> None:
        """``loss_labels`` must return the same ``loss_ce`` whether it recomputes ``idx``/``target_classes_o`` (and, for
        these two flags, ``target_boxes``) from ``targets``+``indices`` itself (``matched_targets=None``) or consumes a
        ``_MatchedTargets`` cache built from those same ``indices``.

        ``ia_bce_loss`` and ``use_position_supervised_loss`` are the only two ``loss_labels`` branches that read
        ``matched_targets.boxes``, and are mutually exclusive (``if``/``elif``). Elsewhere they were only ever checked
        for flag *forwarding* onto the criterion, never for loss correctness against a populated cache -- this pins that
        the cache is a pure optimization, not a behavior change.
        """
        batch_size, num_queries, num_classes = 2, 4, 3
        criterion = SetCriterion(
            num_classes=num_classes,
            matcher=_MatcherStub(),
            weight_dict={},
            focal_alpha=0.25,
            losses=["labels"],
            group_detr=1,
            **{loss_flag: True},
        )
        torch.manual_seed(7)
        outputs = {
            "pred_logits": torch.randn(batch_size, num_queries, num_classes),
            "pred_boxes": torch.rand(batch_size, num_queries, 4) * 0.4 + 0.3,
        }
        targets = [
            {"labels": torch.tensor([1, 2]), "boxes": torch.rand(2, 4) * 0.4 + 0.3},
            {"labels": torch.tensor([0]), "boxes": torch.rand(1, 4) * 0.4 + 0.3},
        ]
        indices = [(torch.tensor([1, 3]), torch.tensor([0, 1])), (torch.tensor([2]), torch.tensor([0]))]
        num_boxes = torch.tensor(3.0)
        matched_targets = criterion._get_matched_targets(targets, indices)

        recomputed = criterion.loss_labels(outputs, targets, indices, num_boxes, log=False)
        cached = criterion.loss_labels(outputs, targets, indices, num_boxes, log=False, matched_targets=matched_targets)

        assert torch.allclose(recomputed["loss_ce"], cached["loss_ce"]), (
            f"{loss_flag}=True must compute the same loss_ce from a cached matched_targets as it does recomputing "
            "target_classes_o/idx/target_boxes from targets+indices directly"
        )


class TestBatchedFastPathRespectsMatcherOverrides:
    """The batched matcher fast path must decline whenever the matcher customizes matching."""

    def test_forward_uses_subclass_override_instead_of_batched_fast_path(self) -> None:
        """A ``HungarianMatcher`` subclass overriding ``forward`` must be called for every layer.

        The batched fast path reads ``_match_many`` off the matcher's class and calls it unbound, bypassing
        ``nn.Module.__call__``. Without the forward-identity veto, a subclass overriding ``forward`` (the sanctioned
        extension point) would have the base ``_match_many`` silently answer in its place instead, with no error.
        Driving a real multi-layer ``forward()`` call (final + aux + enc) through a logging subclass proves the override
        actually runs once per layer rather than being silently skipped.
        """
        call_log: list[int] = []

        class _LoggingMatcher(HungarianMatcher):
            def forward(self, outputs, targets, group_detr=1, target_side_safety=None):
                call_log.append(len(call_log))
                return super().forward(outputs, targets, group_detr=group_detr, target_side_safety=target_side_safety)

        batch_size, num_queries, num_classes = 2, 4, 3
        criterion = SetCriterion(
            num_classes=num_classes,
            matcher=_LoggingMatcher(),
            weight_dict={},
            focal_alpha=0.25,
            losses=["labels", "boxes"],
            group_detr=1,
        )
        targets = [
            {"labels": torch.tensor([1, 2]), "boxes": torch.rand(2, 4) * 0.4 + 0.3},
            {"labels": torch.tensor([0]), "boxes": torch.rand(1, 4) * 0.4 + 0.3},
        ]

        def _layer() -> dict[str, torch.Tensor]:
            return {
                "pred_logits": torch.randn(batch_size, num_queries, num_classes),
                "pred_boxes": torch.rand(batch_size, num_queries, 4) * 0.4 + 0.3,
            }

        outputs = {**_layer(), "aux_outputs": [_layer()], "enc_outputs": _layer()}

        criterion(outputs, targets, num_boxes=1.0)

        assert len(call_log) == 3, (
            "the overridden forward() must run once per output layer (final + aux + enc); a call count below 3 "
            "means the batched fast path silently bypassed the subclass override"
        )


class TestMaskLossDenominatorStaysOnDevice:
    """The JIT mask losses take their denominator as a Tensor, so the mask path never reads it back.

    ``loss_masks`` normalizes by ``num_boxes``, which is either ``num_boxes_for_targets``'s all-reduced (across
    distributed ranks) Tensor, or an explicit grad-accum-aware override a manual-optimization caller supplies instead --
    segmentation models train on Lightning's automatic-optimization path (``module_model.py``'s ``training_step`` calls
    ``self.criterion(outputs, targets)`` with no override), so in practice they get the former, not the latter. While
    ``dice_loss``/``sigmoid_ce_loss`` were TorchScripted with ``num_masks: float`` the caller had to unwrap that Tensor
    to a Python scalar, and on XLA every unwrap is a device-to-host sync that cuts the lazy graph.
    ``SetCriterion.forward`` calls ``loss_masks`` once per matched output layer (the final layer, every aux layer, and
    the enc layer), so a segmentation model's training step pays this sync several times, not once -- 5 times for
    SegNano/SegSmall (``dec_layers=4``), 6 for SegMedium/SegLarge (``dec_layers=5``), 7 for SegXLarge/Seg2XLarge
    (``dec_layers=6``).
    """

    def test_loss_masks_hands_the_jit_losses_the_num_boxes_tensor_unconverted(self, mocker: MockerFixture) -> None:
        """Prove the *production* call site, not just the two JIT leaves in isolation.

        Before this fix, ``loss_masks`` called ``float(num_boxes)`` ONCE and reused that single Python float for both
        JIT calls -- one host read per ``loss_masks`` call, not two (and ``loss_masks`` itself runs once per matched
        output layer per training step, see the class docstring above).  Spying on the module-level JIT functions from
        ``loss_masks``'s real call site shows there is now no ``float()``/``.item()`` conversion anywhere on the path:
        the exact same ``num_boxes`` Tensor object reaches both calls untouched.
        """
        criterion = _bare_criterion()
        criterion.mask_point_sample_ratio = 16
        pred_masks = torch.randn(1, 8, 24, 24, requires_grad=True)
        targets = [{"masks": torch.rand(8, 96, 96) > 0.5}]
        matched = torch.arange(8)
        indices = [(matched, matched)]
        num_boxes = torch.tensor(8.0)
        dice_spy = mocker.patch.object(criterion_module, "dice_loss_jit", wraps=criterion_module.dice_loss_jit)
        ce_spy = mocker.patch.object(
            criterion_module, "sigmoid_ce_loss_jit", wraps=criterion_module.sigmoid_ce_loss_jit
        )

        criterion.loss_masks({"pred_masks": pred_masks}, targets, indices, num_boxes=num_boxes)

        dice_spy.assert_called_once()
        ce_spy.assert_called_once()
        assert dice_spy.call_args.args[2] is num_boxes
        assert ce_spy.call_args.args[2] is num_boxes

    def test_int_denominator_matches_the_pre_fix_signature(self) -> None:
        """A bare Python ``int`` denominator must keep working, bit-for-bit against the pre-fix ``float``-only call.

        Before the denominator was widened to ``Union[Tensor, float, int]``, ``dice_loss``/``sigmoid_ce_loss`` declared
        ``num_masks: float`` and callers passed ``5`` or ``5.0`` interchangeably. Both spellings must keep producing the
        identical result through the ``_jit`` aliases.
        """
        torch.manual_seed(0)
        inputs = torch.randn(2, 16)
        targets = torch.randint(0, 2, (2, 16)).float()

        assert torch.equal(dice_loss_jit(inputs, targets, 5), dice_loss_jit(inputs, targets, 5.0))
        assert torch.equal(sigmoid_ce_loss_jit(inputs, targets, 5), sigmoid_ce_loss_jit(inputs, targets, 5.0))

    @pytest.mark.parametrize("denominator", [5.0, 5])
    def test_eager_denominator_branches_match_scripted_float_behavior(self, denominator: float | int) -> None:
        """Cover float and int denominators with the legacy numeric result.

        The production path passes a Tensor denominator; a Python ``float`` or ``int`` caller (the historical re-
        exported signature) must keep the pre-fix numeric oracle: dividing by the ``float`` value as given.
        """
        torch.manual_seed(0)
        inputs = torch.randn(2, 16)
        targets = torch.randint(0, 2, (2, 16)).float()

        assert torch.equal(dice_loss(inputs, targets, denominator), dice_loss_jit(inputs, targets, float(denominator)))
        assert torch.equal(
            sigmoid_ce_loss(inputs, targets, denominator), sigmoid_ce_loss_jit(inputs, targets, float(denominator))
        )

    def test_eager_functions_accept_numpy_scalar_denominators(self) -> None:
        """Keep the eager documentation accurate for NumPy scalar callers.

        The formerly scripted wrappers rejected NumPy scalars; the eager functions go through Python's ordinary tensor
        division and must keep accepting them.
        """
        torch.manual_seed(0)
        inputs = torch.randn(2, 16)
        targets = torch.randint(0, 2, (2, 16)).float()
        denominator = np.float32(5.0)

        assert torch.equal(dice_loss(inputs, targets, denominator), dice_loss(inputs, targets, float(denominator)))
        assert torch.equal(
            sigmoid_ce_loss(inputs, targets, denominator), sigmoid_ce_loss(inputs, targets, float(denominator))
        )

    def test_jit_losses_accept_a_tensor_denominator(self) -> None:
        """The ``_jit`` aliases and the eager functions agree when handed an on-device denominator."""
        torch.manual_seed(0)
        inputs = torch.randn(2, 16)
        targets = torch.randint(0, 2, (2, 16)).float()
        denominator = torch.tensor(2.0)

        assert torch.allclose(dice_loss_jit(inputs, targets, denominator), dice_loss(inputs, targets, denominator))
        assert torch.allclose(
            sigmoid_ce_loss_jit(inputs, targets, denominator), sigmoid_ce_loss(inputs, targets, denominator)
        )

    def test_tensor_denominator_divides_exactly_as_before(self) -> None:
        """Normalizing by ``n`` must equal normalizing by 1 and dividing by ``n`` afterwards."""
        torch.manual_seed(0)
        inputs = torch.randn(3, 32)
        targets = torch.randint(0, 2, (3, 32)).float()
        one = torch.tensor(1.0)
        n = 5.0

        assert torch.allclose(dice_loss_jit(inputs, targets, torch.tensor(n)), dice_loss_jit(inputs, targets, one) / n)
        assert torch.allclose(
            sigmoid_ce_loss_jit(inputs, targets, torch.tensor(n)), sigmoid_ce_loss_jit(inputs, targets, one) / n
        )

    def test_float_denominator_still_matches_the_pre_fix_signature_bit_for_bit(self) -> None:
        """Backward compat for ``lwdetr.py``'s re-exports: a caller stuck on the old ``float`` signature must see the
        exact same numbers it always did, not merely "close" ones.

        Before this PR, ``dice_loss``/``sigmoid_ce_loss`` declared ``num_masks: float`` and divided by it directly.
        Wrapping that float in a Tensor before dividing (an earlier version of this fix did exactly that) changes the
        result under reduced precision, because ``tensor / python_float`` and ``tensor / tensor_wrapping_that_float``
        are not the same operation once the tensor's dtype has fewer mantissa bits than the float needs -- dividing by
        the wrapped Tensor quantizes the denominator to the tensor's dtype first, while dividing by the bare Python
        float does not.  So the fix must branch on ``num_masks``'s type and let the ``float`` branch divide by the
        unwrapped Python float exactly as the old code did, never materializing a Tensor for it.
        """
        torch.manual_seed(0)
        inputs = torch.randn(3, 47).to(torch.bfloat16)  # a non-power-of-two shape and a reduced dtype are
        targets = torch.randint(0, 2, (3, 47)).float()  # both required to expose a quantization regression
        denom = 17.0  # a non-power-of-two value: exact division by 2**k would hide a quantization bug

        dice_out = dice_loss_jit(inputs, targets, denom)
        ce_out = sigmoid_ce_loss_jit(inputs, targets, denom)

        # Reference: the literal pre-fix computation, with num_masks used as a bare Python float throughout.
        sig = inputs.sigmoid().flatten(1)
        numerator = 2 * (sig * targets).sum(-1)
        denominator = sig.sum(-1) + targets.sum(-1)
        expected_dice = (1 - (numerator + 1) / (denominator + 1)).sum() / denom
        expected_ce = (
            torch.nn.functional.binary_cross_entropy_with_logits(inputs, targets, reduction="none").mean(1).sum()
            / denom
        )

        assert torch.equal(dice_out, expected_dice)
        assert torch.equal(ce_out, expected_ce)

    @pytest.mark.parametrize("input_dtype", [torch.bfloat16, torch.float16])
    def test_reduced_precision_predictions_with_production_shaped_targets_match_the_pre_fix_value(
        self, input_dtype: torch.dtype
    ) -> None:
        """The fix must not change loss values on the dtype combination training actually produces.

        ``_sample_target_masks_at_points`` always ends with ``.float()`` (criterion.py's point-sampling helper), so
        ``point_labels`` is ``float32`` in every real training step regardless of the model's autocast dtype --  only
        ``point_logits`` (the predictions) can be at a reduced dtype.  That asymmetry already promotes ``dice_loss``'s
        ``inputs * targets`` and ``sigmoid_ce_loss``'s ``binary_cross_entropy_with_logits`` to ``float32`` before the
        denominator is ever involved, so switching the denominator from a Python float to a Tensor changes neither the
        dtype nor the value on this, the only combination ``loss_masks`` actually feeds these functions.
        """
        torch.manual_seed(0)
        inputs = torch.randn(2, 16).to(input_dtype)
        targets = torch.randint(0, 2, (2, 16)).float()  # always float32, matching real point-label sampling
        denom = 2.0

        dice_new = dice_loss_jit(inputs, targets, torch.tensor(denom))
        ce_new = sigmoid_ce_loss_jit(inputs, targets, torch.tensor(denom))
        dice_old = dice_loss_jit(inputs, targets, denom)  # the pre-fix call shape: a bare Python float
        ce_old = sigmoid_ce_loss_jit(inputs, targets, denom)

        assert dice_new.dtype == torch.float32
        assert ce_new.dtype == torch.float32
        assert torch.equal(dice_new, dice_old)
        assert torch.equal(ce_new, ce_old)

    @pytest.mark.parametrize("input_dtype", [torch.bfloat16, torch.float16])
    def test_reduced_precision_targets_are_a_documented_boundary_training_never_reaches(
        self, input_dtype: torch.dtype
    ) -> None:
        """Reducing BOTH inputs and targets -- a combination real training cannot produce, see the test above -- is the
        one case where the Tensor-denominator path's ``float32`` promotion measurably changes the value versus the old
        Python-float division, which stayed at the narrower dtype throughout.

        This pins that documented boundary without implying it is reachable from ``loss_masks``.
        """
        torch.manual_seed(0)
        inputs = torch.randn(2, 16).to(input_dtype)
        targets = torch.randint(0, 2, (2, 16)).float().to(input_dtype)
        denom = 2.0

        dice_new = dice_loss_jit(inputs, targets, torch.tensor(denom))
        ce_new = sigmoid_ce_loss_jit(inputs, targets, torch.tensor(denom))

        assert dice_new.dtype == torch.float32
        assert ce_new.dtype == torch.float32
        assert torch.allclose(dice_new, dice_loss(inputs, targets, torch.tensor(denom)))
        assert torch.allclose(ce_new, sigmoid_ce_loss(inputs, targets, torch.tensor(denom)))

    def test_tensor_denominator_carries_gradient(self) -> None:
        """Passing a ``requires_grad=True`` Tensor now backpropagates into the denominator; it never could before.

        Under the pre-fix ``float``-only signature, TorchScript's single-type binding accepted a Tensor too (by silently
        coercing it through the same generic Python-to-double path a NumPy scalar used, itself an undocumented host
        read), which detached it from the autograd graph -- the gradient was always ``None`` no matter what was passed,
        because a Tensor could never reach the function still carrying its graph connection. A ``Union[Tensor, float,
        int]`` denominator instead passes a Tensor through unchanged, so if that Tensor requires grad, the gradient now
        flows. No prior caller could have depended on the old dropped-gradient behavior for a Tensor input, because
        passing a Tensor through the scripted call boundary was never a documented, type-checked contract before this
        PR.
        """
        torch.manual_seed(0)
        inputs = torch.randn(2, 16)
        targets = torch.randint(0, 2, (2, 16)).float()
        denominator = torch.tensor(2.0, requires_grad=True)

        dice_loss_jit(inputs, targets, denominator).backward()

        assert denominator.grad is not None

    @pytest.mark.xla
    @_requires_torch_xla
    def test_denominator_is_not_read_back_to_the_host_on_xla(self) -> None:
        """No ``_local_scalar_dense`` and no ``aten::`` fallback: the whole call stays on device.

        Runs on any PJRT backend -- ``device.type`` is ``"xla"`` under ``PJRT_DEVICE=CPU`` too, which is all the
        host-sync counter depends on, so this needs no TPU silicon.
        """
        import torch_xla
        import torch_xla.debug.metrics as met

        device = torch_xla.device()
        torch.manual_seed(0)
        inputs = torch.randn(2, 16, device=device)
        targets = torch.randint(0, 2, (2, 16), device=device).float()
        denominator = torch.tensor(2.0, device=device)

        # Warm up so one-off compilation transfers do not land in the measured counters.
        dice_loss_jit(inputs, targets, denominator)
        sigmoid_ce_loss_jit(inputs, targets, denominator)
        torch_xla.sync()

        met.clear_all()
        dice_loss_jit(inputs, targets, denominator)
        sigmoid_ce_loss_jit(inputs, targets, denominator)
        torch_xla.sync()

        assert met.counter_value("aten::_local_scalar_dense") is None
        assert [name for name in met.counter_names() if name.startswith("aten::")] == []


def _padding_batch(seed: int, batch_size: int = 4, num_classes: int = 5, queries: int = 60):
    """Build one random detection batch with a different ground-truth count per image.

    Args:
        seed: Seed for the batch's generator.
        batch_size: Images in the batch.
        num_classes: Class count for the logits.
        queries: Query count for the logits and boxes.

    Returns:
        A ``(outputs, targets)`` pair shaped like the detection head's output.

    Examples:
        >>> outputs, targets = _padding_batch(0)
        >>> outputs["pred_logits"].shape[0] == len(targets)
        True
    """
    generator = torch.Generator().manual_seed(seed)
    outputs = {
        "pred_logits": torch.randn(batch_size, queries, num_classes, generator=generator),
        "pred_boxes": torch.rand(batch_size, queries, 4, generator=generator) * 0.5 + 0.25,
    }
    targets = []
    for _ in range(batch_size):
        count = int(torch.randint(1, 9, (1,), generator=generator).item())
        targets.append(
            {
                "boxes": torch.rand(count, 4, generator=generator) * 0.5 + 0.25,
                "labels": torch.randint(0, num_classes, (count,), generator=generator),
                "iscrowd": torch.zeros(count, dtype=torch.int64),
                "area": torch.rand(count, generator=generator),
            }
        )
    return outputs, targets


def _padding_criterion(num_classes: int = 5, losses: list[str] | None = None, **overrides):
    """Build a criterion on the production classification branch.

    ``SetCriterion`` defaults ``ia_bce_loss`` to False while ``TrainConfig`` sets it True, so a test
    that takes the constructor default would exercise a branch training never runs.

    Args:
        num_classes: Class count.
        losses: Loss names to configure. Defaults to ``["labels", "boxes"]``.
        overrides: Extra ``SetCriterion`` keyword arguments.

    Returns:
        A configured :class:`SetCriterion`.

    Examples:
        >>> _padding_criterion().ia_bce_loss
        True
    """
    options = {"ia_bce_loss": True}
    options.update(overrides)
    return SetCriterion(
        num_classes=num_classes,
        matcher=HungarianMatcher(),
        weight_dict={"loss_bbox": 5.0, "loss_giou": 2.0, "loss_ce": 1.0},
        focal_alpha=0.25,
        losses=losses if losses is not None else ["labels", "boxes"],
        group_detr=1,
        **options,
    )


def _layered_detection_batch(
    target_counts: tuple[int, ...],
    *,
    device: torch.device | str = "cpu",
    dtype: torch.dtype = torch.float32,
    seed: int = 904,
    queries: int = 16,
    layer_count: int = 3,
    mask_side: int | None = None,
    requires_grad: bool = False,
) -> tuple[dict[str, Any], list[dict[str, Tensor]], list[dict[str, Tensor]]]:
    """Build detection output layers and their per-image targets.

    Optional masks cover the segmentation case. Target boxes stay float32 to match training, and a local generator
    keeps cases reproducible without changing the caller's global RNG state.

    Args:
        target_counts: Ground-truth label count for each image in the batch.
        device: Device for predictions and targets.
        dtype: Prediction dtype; target boxes remain float32.
        seed: Seed for this case's local random generator.
        queries: Number of decoder queries per image.
        layer_count: Number of output layers, including the encoder output.
        mask_side: Mask height and width when testing segmentation losses.
        requires_grad: Whether prediction tensors require gradients.

    Returns:
        Model outputs, individual output layers, and per-image targets.

    Examples:
        >>> outputs, _, targets = _layered_detection_batch((3, 0))
        >>> tuple(outputs["pred_logits"].shape), [len(target["labels"]) for target in targets]
        ((2, 16, 5), [3, 0])
        >>> masked, _, targets = _layered_detection_batch((3, 0), mask_side=8)
        >>> tuple(masked["pred_masks"].shape), [len(target["masks"]) for target in targets]
        ((2, 16, 8, 8), [3, 0])
        >>> outputs, layers, _ = _layered_detection_batch((3, 0, 7), queries=24, layer_count=4)
        >>> len(layers), len(outputs["aux_outputs"]), tuple(outputs["enc_outputs"]["pred_logits"].shape)
        (4, 2, (3, 24, 5))
    """
    device = torch.device(device)
    generator = torch.Generator(device=device).manual_seed(seed)
    batch_size, classes = len(target_counts), 5
    layers: list[dict[str, Tensor]] = []
    for _ in range(layer_count):
        layer = {
            "pred_logits": torch.randn(
                batch_size,
                queries,
                classes,
                device=device,
                dtype=dtype,
                generator=generator,
                requires_grad=requires_grad,
            ),
            "pred_boxes": (
                (torch.rand(batch_size, queries, 4, device=device, generator=generator) * 0.5 + 0.25).to(dtype)
            ).requires_grad_(requires_grad),
        }
        if mask_side is not None:
            layer["pred_masks"] = torch.randn(
                batch_size, queries, mask_side, mask_side, device=device, dtype=dtype, generator=generator
            ).requires_grad_(requires_grad)
        layers.append(layer)
    outputs = {**layers[0], "aux_outputs": layers[1:-1], "enc_outputs": layers[-1]}
    targets: list[dict[str, Tensor]] = []
    for count in target_counts:
        target = {
            "labels": torch.randint(0, classes, (count,), device=device, generator=generator),
            "boxes": torch.rand(count, 4, device=device, generator=generator) * 0.5 + 0.25,
        }
        if mask_side is not None:
            target["masks"] = torch.rand(count, mask_side, mask_side, device=device, generator=generator) > 0.5
        targets.append(target)
    return outputs, layers, targets


class TestBatchedDetectionLosses:
    """The default IA-BCE criterion batches equivalent work across output layers."""

    def test_cpu_outputs_stay_on_the_per_layer_path_after_enabling(self) -> None:
        """CPU outputs never batch: every other condition is stock, so only the device can decline."""
        criterion = _padding_criterion(losses=["labels", "boxes", "cardinality"])
        criterion.enable_compiled_detection_losses()
        matched = [
            criterion_module._MatchedTargets(
                (torch.arange(2), torch.arange(2)),
                torch.arange(2),
                torch.rand(2, 4),
            )
            for _ in range(2)
        ]
        outputs = [{"pred_logits": torch.rand(1, 2, 5), "pred_boxes": torch.rand(1, 2, 4)} for _ in range(2)]

        assert not criterion._can_batch_detection_losses(outputs, matched)

    def test_cuda_batcher_compiles_lazily_once(self, mocker: MockerFixture) -> None:
        """CUDA resolves one cached dynamic compiler wrapper instead of recompiling each step."""
        criterion = _padding_criterion(losses=["labels", "boxes", "cardinality"])
        compiled = MagicMock(wraps=criterion_module._batched_detection_loss_tensors)

        compile_mock = mocker.patch.object(torch, "compile", return_value=compiled)

        first = criterion._resolve_batched_detection_losses(torch.device("cuda"))
        second = criterion._resolve_batched_detection_losses(torch.device("cuda"))

        assert first is compiled
        assert second is compiled
        compile_mock.assert_called_once_with(criterion_module._batched_detection_loss_tensors, dynamic=True)

    def test_enabled_criterion_pickles_before_first_use(self) -> None:
        """Spawn-based training pickles the criterion before any CUDA work, so the compiled wrapper stays lazy."""
        criterion = _padding_criterion(losses=["labels", "boxes", "cardinality"])
        criterion.enable_compiled_detection_losses()

        restored = pickle.loads(pickle.dumps(criterion))

        assert restored._compile_batched_detection_losses is True
        assert restored._compiled_batched_detection_losses is None

    def test_cpu_batcher_stays_eager(self, mocker: MockerFixture) -> None:
        """CPU compatibility never initializes Inductor for the CUDA-only fast path."""
        criterion = _padding_criterion(losses=["labels", "boxes", "cardinality"])

        compile_mock = mocker.patch.object(torch, "compile")

        resolved = criterion._resolve_batched_detection_losses(torch.device("cpu"))

        assert resolved is criterion_module._batched_detection_loss_tensors
        compile_mock.assert_not_called()

    @pytest.mark.parametrize("padded", [False, True])
    @pytest.mark.parametrize("target_counts", [(3, 0, 7), (0, 0, 0)])
    def test_losses_and_gradients_match_per_layer_fallback(
        self, mocker: MockerFixture, padded: bool, target_counts: tuple[int, int, int]
    ) -> None:
        """Batching preserves every diagnostic, optimized loss and output gradient, including padding masks."""
        outputs, layers, targets = _layered_detection_batch(
            target_counts, queries=24, layer_count=4, seed=903, requires_grad=True
        )
        if padded:
            targets = list(pad_targets_to_fixed_count(targets, 8))
        criterion = _padding_criterion(losses=["labels", "boxes", "cardinality"])

        can_batch = mocker.patch.object(criterion, "_can_batch_detection_losses", return_value=False)
        fallback_losses = criterion(outputs, targets, num_boxes=1.0)
        sum(fallback_losses.values()).backward()
        fallback_gradients = [(layer["pred_logits"].grad.clone(), layer["pred_boxes"].grad.clone()) for layer in layers]
        for layer in layers:
            layer["pred_logits"].grad = None
            layer["pred_boxes"].grad = None

        can_batch.return_value = True
        batched = mocker.patch.object(
            criterion, "_get_batched_detection_losses", wraps=criterion._get_batched_detection_losses
        )
        box_iou = mocker.patch.object(
            criterion_module.box_ops, "elementwise_box_iou", wraps=criterion_module.box_ops.elementwise_box_iou
        )
        generalized_box_iou = mocker.patch.object(
            criterion_module.box_ops,
            "elementwise_generalized_box_iou",
            wraps=criterion_module.box_ops.elementwise_generalized_box_iou,
        )
        batched_losses = criterion(outputs, targets, num_boxes=1.0)
        batched.assert_called_once()
        assert box_iou.call_count == 2  # one direct call plus generalized IoU's internal elementwise IoU
        generalized_box_iou.assert_called_once()
        sum(batched_losses.values()).backward()

        assert fallback_losses.keys() == batched_losses.keys()
        for key in fallback_losses:
            assert torch.allclose(fallback_losses[key], batched_losses[key], rtol=1e-5, atol=1e-6), key
        for layer, (logit_gradient, box_gradient) in zip(layers, fallback_gradients, strict=True):
            assert torch.allclose(logit_gradient, layer["pred_logits"].grad, rtol=1e-5, atol=1e-6)
            assert torch.allclose(box_gradient, layer["pred_boxes"].grad, rtol=1e-5, atol=1e-6)

    @pytest.mark.parametrize("padded", [False, True])
    @pytest.mark.parametrize("dtype", [torch.bfloat16, torch.float16])
    def test_low_precision_losses_keep_per_layer_dtype_and_values(
        self, mocker: MockerFixture, dtype: torch.dtype, padded: bool
    ) -> None:
        """BF16/FP16 outputs return the per-layer path's dtypes, values and gradients, not low-precision quotients.

        The per-layer path divides a 0-dim sum by ``num_boxes``, which promotes to float32; a per-layer vector of sums
        divided by the same scalar would silently keep the BF16/FP16 dtype instead.
        """
        outputs, layers, targets = _layered_detection_batch(
            (3, 0, 7), queries=24, layer_count=4, dtype=dtype, seed=905, requires_grad=True
        )
        if padded:
            targets = list(pad_targets_to_fixed_count(targets, 8))
        criterion = SetCriterion(
            num_classes=5,
            matcher=_MatcherStub(),
            weight_dict={"loss_bbox": 5.0, "loss_giou": 2.0, "loss_ce": 1.0},
            focal_alpha=0.25,
            losses=["labels", "boxes", "cardinality"],
            group_detr=1,
            ia_bce_loss=True,
        )

        can_batch = mocker.patch.object(criterion, "_can_batch_detection_losses", return_value=False)
        fallback_losses = criterion(outputs, targets, num_boxes=10.0)
        sum(fallback_losses[key] for key in fallback_losses if key.startswith("loss_")).backward()
        fallback_gradients = [(layer["pred_logits"].grad.clone(), layer["pred_boxes"].grad.clone()) for layer in layers]
        for layer in layers:
            layer["pred_logits"].grad = None
            layer["pred_boxes"].grad = None

        can_batch.return_value = True
        batched_losses = criterion(outputs, targets, num_boxes=10.0)
        sum(batched_losses[key] for key in batched_losses if key.startswith("loss_")).backward()

        tolerance = 4 * torch.finfo(dtype).eps
        assert fallback_losses.keys() == batched_losses.keys()
        for key in fallback_losses:
            assert batched_losses[key].dtype == fallback_losses[key].dtype, key
            assert torch.allclose(batched_losses[key], fallback_losses[key], rtol=tolerance, atol=tolerance), key
        for layer, (logit_gradient, box_gradient) in zip(layers, fallback_gradients, strict=True):
            for actual, expected in (
                (layer["pred_logits"].grad, logit_gradient),
                (layer["pred_boxes"].grad, box_gradient),
            ):
                assert actual.dtype == expected.dtype
                assert (actual.float() - expected.float()).abs().max() <= tolerance * expected.float().abs().max()

    @pytest.mark.gpu
    @_requires_cuda
    @pytest.mark.parametrize("target_counts", [(3, 0), (0, 0)])
    def test_compiled_cuda_losses_and_gradients_match_fallback(self, target_counts: tuple[int, int]) -> None:
        """The real lazy CUDA compilation preserves losses and gradients, including an empty batch."""
        outputs, layers, targets = _layered_detection_batch(target_counts, device="cuda", requires_grad=True)
        criterion = _padding_criterion(losses=["labels", "boxes", "cardinality"]).cuda()

        with patch.object(criterion, "_can_batch_detection_losses", return_value=False):
            fallback_losses = criterion(outputs, targets, num_boxes=1.0)
        sum(fallback_losses.values()).backward()
        fallback_gradients = [(layer["pred_logits"].grad.clone(), layer["pred_boxes"].grad.clone()) for layer in layers]
        for layer in layers:
            layer["pred_logits"].grad = None
            layer["pred_boxes"].grad = None

        criterion.enable_compiled_detection_losses()
        compiled_losses = criterion(outputs, targets, num_boxes=1.0)
        sum(compiled_losses.values()).backward()

        assert criterion._compiled_batched_detection_losses is not None, "the batched CUDA graph never ran"
        assert fallback_losses.keys() == compiled_losses.keys()
        for key in fallback_losses:
            assert torch.allclose(fallback_losses[key], compiled_losses[key], rtol=1e-5, atol=1e-6), key
        for layer, (logit_gradient, box_gradient) in zip(layers, fallback_gradients, strict=True):
            assert torch.allclose(logit_gradient, layer["pred_logits"].grad, rtol=1e-5, atol=1e-6)
            assert torch.allclose(box_gradient, layer["pred_boxes"].grad, rtol=1e-5, atol=1e-6)

    @pytest.mark.gpu
    @_requires_cuda
    @_requires_cuda_bf16
    @pytest.mark.parametrize("target_counts", [(3, 0), (0, 0)])
    def test_compiled_cuda_bf16_autocast_matches_fallback(self, target_counts: tuple[int, int]) -> None:
        """The compiled graph matches the per-layer path in the BF16 autocast regime training actually runs.

        Under autocast the model emits BF16 logits and boxes while targets stay float32, so the loss dtypes, values and
        gradients must follow the per-layer path with BF16 rounding tolerance.
        """
        outputs, layers, targets = _layered_detection_batch(
            target_counts, device="cuda", dtype=torch.bfloat16, seed=906, requires_grad=True
        )
        criterion = _padding_criterion(losses=["labels", "boxes", "cardinality"]).cuda()

        with (
            torch.autocast("cuda", dtype=torch.bfloat16),
            patch.object(criterion, "_can_batch_detection_losses", return_value=False),
        ):
            fallback_losses = criterion(outputs, targets, num_boxes=10.0)
        sum(value for key, value in fallback_losses.items() if key.startswith("loss_")).backward()
        fallback_gradients = [(layer["pred_logits"].grad.clone(), layer["pred_boxes"].grad.clone()) for layer in layers]
        for layer in layers:
            layer["pred_logits"].grad = None
            layer["pred_boxes"].grad = None

        criterion.enable_compiled_detection_losses()
        with torch.autocast("cuda", dtype=torch.bfloat16):
            compiled_losses = criterion(outputs, targets, num_boxes=10.0)
        sum(value for key, value in compiled_losses.items() if key.startswith("loss_")).backward()

        assert criterion._compiled_batched_detection_losses is not None, "the batched CUDA graph never ran"
        tolerance = 4 * torch.finfo(torch.bfloat16).eps
        assert fallback_losses.keys() == compiled_losses.keys()
        for key in fallback_losses:
            assert compiled_losses[key].dtype == fallback_losses[key].dtype, key
            assert torch.allclose(compiled_losses[key], fallback_losses[key], rtol=tolerance, atol=tolerance), key
        for layer, (logit_gradient, box_gradient) in zip(layers, fallback_gradients, strict=True):
            for actual, expected in (
                (layer["pred_logits"].grad, logit_gradient),
                (layer["pred_boxes"].grad, box_gradient),
            ):
                assert actual.dtype == expected.dtype
                assert (actual.float() - expected.float()).abs().max() <= tolerance * expected.float().abs().max()

    @pytest.mark.gpu
    @_requires_cuda
    @pytest.mark.parametrize(
        ("losses", "overrides", "enabled", "layer_count", "batched"),
        [
            pytest.param(["labels", "boxes", "cardinality"], {}, True, 3, True, id="stock-control"),
            pytest.param(["labels", "boxes", "cardinality"], {}, False, 3, False, id="not-enabled-by-the-model"),
            pytest.param(["labels", "boxes", "cardinality", "masks"], {}, True, 3, False, id="segmentation-masks"),
            pytest.param(["labels", "boxes", "cardinality", "keypoints"], {}, True, 3, False, id="keypoints"),
            pytest.param(["labels", "boxes"], {}, True, 3, False, id="no-cardinality-loss"),
            pytest.param(["labels", "boxes", "cardinality"], {"ia_bce_loss": False}, True, 3, False, id="plain-focal"),
            pytest.param(
                ["labels", "boxes", "cardinality"],
                {"ia_bce_loss": False, "use_varifocal_loss": True},
                True,
                3,
                False,
                id="varifocal",
            ),
            pytest.param(
                ["labels", "boxes", "cardinality"],
                {"ia_bce_loss": False, "use_position_supervised_loss": True},
                True,
                3,
                False,
                id="position-supervised",
            ),
            pytest.param(["labels", "boxes", "cardinality"], {}, True, 1, False, id="single-output-layer"),
        ],
    )
    def test_guard_batches_only_the_stock_detection_configuration(
        self, losses: list[str], overrides: dict[str, Any], enabled: bool, layer_count: int, batched: bool
    ) -> None:
        """Each non-stock configuration declines batching; the stock control proves the guard can admit it.

        Every row differs from ``stock-control`` in exactly one guard condition, so a row only passes while that
        condition is enforced. A declined criterion keeps its own loss code, so no configured loss is silently dropped.
        """
        criterion = _padding_criterion(losses=losses, **overrides).cuda()
        if enabled:
            criterion.enable_compiled_detection_losses()
        matched = [
            criterion_module._MatchedTargets(
                (torch.arange(2, device="cuda"), torch.arange(2, device="cuda")),
                torch.arange(2, device="cuda"),
                torch.rand(2, 4, device="cuda"),
            )
            for _ in range(layer_count)
        ]
        outputs = [
            {"pred_logits": torch.rand(1, 2, 5, device="cuda"), "pred_boxes": torch.rand(1, 2, 4, device="cuda")}
            for _ in range(layer_count)
        ]

        assert criterion._can_batch_detection_losses(outputs, matched) is batched

    @pytest.mark.gpu
    @_requires_cuda
    @pytest.mark.parametrize(
        ("queries", "logits_dtype", "boxes_dtype", "matches", "batched"),
        [
            pytest.param(2, torch.float32, torch.float32, 2, True, id="identical-layers-control"),
            pytest.param(3, torch.float32, torch.float32, 2, False, id="query-count"),
            pytest.param(2, torch.float16, torch.float32, 2, False, id="logits-dtype"),
            pytest.param(2, torch.float32, torch.float16, 2, False, id="boxes-dtype"),
            pytest.param(2, torch.float32, torch.float32, 3, False, id="matched-count"),
        ],
    )
    def test_layers_that_disagree_keep_per_layer_path(
        self, queries: int, logits_dtype: torch.dtype, boxes_dtype: torch.dtype, matches: int, batched: bool
    ) -> None:
        """A non-stock layer declines batching instead of failing in, or silently promoting through, ``torch.stack``.

        The second output layer differs from the first in one property per row; the control row proves that identical
        layers are admitted.
        """
        criterion = _padding_criterion(losses=["labels", "boxes", "cardinality"]).cuda()
        criterion.enable_compiled_detection_losses()
        matched = [
            criterion_module._MatchedTargets(
                (torch.arange(count, device="cuda"), torch.arange(count, device="cuda")),
                torch.arange(count, device="cuda"),
                torch.rand(count, 4, device="cuda"),
            )
            for count in (2, matches)
        ]
        outputs = [
            {"pred_logits": torch.rand(1, 2, 5, device="cuda"), "pred_boxes": torch.rand(1, 2, 4, device="cuda")},
            {
                "pred_logits": torch.rand(1, queries, 5, device="cuda", dtype=logits_dtype),
                "pred_boxes": torch.rand(1, queries, 4, device="cuda", dtype=boxes_dtype),
            },
        ]

        assert criterion._can_batch_detection_losses(outputs, matched) is batched

    @pytest.mark.gpu
    @_requires_cuda
    def test_segmentation_losses_survive_enabled_batching(self) -> None:
        """A segmentation criterion on CUDA still returns its mask losses for every layer once batching is enabled."""
        outputs, _, targets = _layered_detection_batch((3, 2), device="cuda", mask_side=8)
        criterion = _padding_criterion(losses=["labels", "boxes", "cardinality", "masks"]).cuda()
        criterion.enable_compiled_detection_losses()

        losses = criterion(outputs, targets, num_boxes=1.0)

        expected = {
            f"{name}{suffix}"
            for name in ("loss_ce", "loss_bbox", "loss_giou", "loss_mask_ce", "loss_mask_dice")
            for suffix in ("", "_0", "_enc")
        }
        assert expected <= losses.keys()
        assert criterion._compiled_batched_detection_losses is None, "the segmentation criterion was batched"

    @pytest.mark.gpu
    @_requires_cuda
    def test_criterion_subclass_keeps_its_own_box_loss(self) -> None:
        """An overridden loss on a ``SetCriterion`` subclass is not answered by the batched base implementation."""
        sentinel = torch.tensor(123.0, device="cuda")
        custom_class = type(
            "_CustomCriterion",
            (SetCriterion,),
            {"loss_boxes": lambda self, *args, **kwargs: {"loss_bbox": sentinel, "loss_giou": sentinel}},
        )
        criterion = custom_class(
            num_classes=5,
            matcher=HungarianMatcher(),
            weight_dict={"loss_bbox": 5.0, "loss_giou": 2.0, "loss_ce": 1.0},
            focal_alpha=0.25,
            losses=["labels", "boxes", "cardinality"],
            group_detr=1,
            ia_bce_loss=True,
        ).cuda()
        criterion.enable_compiled_detection_losses()
        outputs, _, targets = _layered_detection_batch((3, 2), device="cuda")

        losses = criterion(outputs, targets, num_boxes=1.0)

        for suffix in ("", "_0", "_enc"):
            assert losses[f"loss_bbox{suffix}"] is sentinel
            assert losses[f"loss_giou{suffix}"] is sentinel
        assert criterion._compiled_batched_detection_losses is None, "the subclass was batched"

    @pytest.mark.gpu
    @_requires_cuda
    def test_compiled_graph_is_reused_across_matched_pair_counts(self) -> None:
        """After warm-up, batches with another number of matched pairs must not recompile the loss graph.

        The matched-pair count changes on every batch of a real run. ``dynamic=True`` keeps one graph for every count of
        two or more (Dynamo specializes 0 and 1, which are deliberately outside this stream); a static compile would
        rebuild the graph for each new count, which ``error_on_recompile`` turns into a failure. The stream is one
        stateful compiled wrapper, so it is a single scenario rather than parametrized cases.
        """
        torch._dynamo.reset()
        torch._dynamo.utils.counters.clear()
        criterion = _padding_criterion(losses=["labels", "boxes", "cardinality"]).cuda()
        criterion.enable_compiled_detection_losses()
        batches = []
        for counts in [(3, 4), (5, 2), (1, 1), (6, 5), (2, 3)]:  # matched pairs per layer: 7, 7, 2, 11, 5
            outputs, _, targets = _layered_detection_batch(counts, device="cuda", requires_grad=True)
            batches.append((outputs, targets))

        for index, (outputs, targets) in enumerate(batches):
            with torch._dynamo.config.patch(error_on_recompile=index > 0):
                losses = criterion(outputs, targets, num_boxes=1.0)
                sum(losses.values()).backward()

        assert criterion._compiled_batched_detection_losses is not None, "the batched CUDA graph never ran"
        # Without ``fullgraph=True`` a graph break would silently split the graph instead of raising.
        assert torch._dynamo.utils.counters["stats"]["unique_graphs"] == 1
        assert not torch._dynamo.utils.counters["graph_break"]

    @pytest.mark.gpu
    @_requires_cuda
    def test_compiled_loss_falls_back_to_eager_past_the_recompile_limit(
        self, caplog: pytest.LogCaptureFixture, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Exhausting Dynamo's recompile cache degrades to the eager function instead of aborting the run.

        Validation drives the same wrapper under ``inference_mode`` and with partial batches, and matched-pair counts of
        0 and 1 each specialize their own graph, so a long run can accumulate more guard sets than the recompile limit.
        ``fullgraph=True`` turns that into ``FailOnRecompileLimitHit``; the default calls the numerically identical
        eager function, as the matcher's compiled L1 cost does. A limit of two makes the third guard set (no matched
        pairs) the overflow: Dynamo reports the limit for that call alone and compiles no third graph, and the result
        still matches the per-layer path, which never uses the compiled function and is the oracle. The four calls share
        one stateful compiled wrapper and one recompile budget, so they are a single scenario rather than parametrized
        cases.
        """
        # Dynamo's loggers set propagate=False, so caplog's root-level handler only sees them while it is re-enabled.
        monkeypatch.setattr(logging.getLogger("torch"), "propagate", True)
        monkeypatch.setattr(logging.getLogger("torch._dynamo"), "propagate", True)
        caplog.set_level(logging.WARNING, logger="torch._dynamo")
        torch._dynamo.reset()
        torch._dynamo.utils.counters.clear()
        batched = _padding_criterion(losses=["labels", "boxes", "cardinality"]).cuda()
        batched.enable_compiled_detection_losses()
        reference = _padding_criterion(losses=["labels", "boxes", "cardinality"]).cuda()
        # Matched pairs per layer: generic, one, none (the overflow), generic again (reuses the first graph).
        for counts, overflows in [((3, 4), False), ((1, 0), False), ((0, 0), True), ((2, 5), False)]:
            outputs, _, targets = _layered_detection_batch(counts, device="cuda")

            caplog.clear()
            with torch._dynamo.config.patch(cache_size_limit=2):
                losses = batched(outputs, targets, num_boxes=1.0)
            limit_reports = [record.getMessage() for record in caplog.records if "hit config." in record.getMessage()]
            assert bool(limit_reports) == overflows, (counts, limit_reports)
            if overflows:
                assert "_batched_detection_loss_tensors" in limit_reports[0], limit_reports

            expected = reference(outputs, targets, num_boxes=1.0)
            assert losses.keys() == expected.keys()
            for key in expected:
                assert torch.allclose(losses[key], expected[key], rtol=1e-4, atol=1e-6), (counts, key)
        assert batched._compiled_batched_detection_losses is not None, "the batched CUDA graph never ran"
        # Two guard sets fit under the limit; the overflow ran the eager function instead of compiling a third graph.
        assert torch._dynamo.utils.counters["stats"]["unique_graphs"] == 2


class TestPaddedTargets:
    """Fixed-size target padding keeps the XLA graph shape-stable without changing the arithmetic.

    XLA compiles per tensor shape, and the detection loss is shaped by the ground-truth box count, so an unpadded run
    recompiles whenever a batch brings a new per-image count. Padding is only worth anything if it is invisible to the
    result, which is what these pin.
    """

    @pytest.mark.parametrize(
        ("count", "pad_to", "expected_valid"),
        [
            pytest.param(1, 4, [True, False, False, False], id="pads-up"),
            pytest.param(4, 4, [True] * 4, id="exact-fit"),
            pytest.param(6, 4, [True] * 4, id="truncates-down"),
        ],
    )
    def test_every_per_object_field_reaches_the_same_length(self, count, pad_to, expected_valid) -> None:
        """A consumer that cross-checks two target fields (COCO matching does) must not see a mismatch."""
        target = {
            "boxes": torch.rand(count, 4),
            "labels": torch.zeros(count, dtype=torch.int64),
            "iscrowd": torch.zeros(count, dtype=torch.int64),
            "area": torch.rand(count),
            "orig_size": torch.tensor([640, 480]),
        }
        padded = pad_targets_to_fixed_count([target], pad_to)[0]

        for key in ("boxes", "labels", "iscrowd", "area"):
            assert padded[key].shape[0] == pad_to, key
        assert padded["valid"].tolist() == expected_valid
        assert padded["orig_size"].tolist() == [640, 480], "non per-object entries stay untouched"

    @pytest.mark.parametrize("pad_to", [0, -1])
    def test_non_positive_pad_to_raises(self, pad_to) -> None:
        """A silently empty or a cryptic low-level error is worse than a clear, actionable one."""
        target = {"boxes": torch.rand(2, 4), "labels": torch.zeros(2, dtype=torch.int64)}

        with pytest.raises(ValueError) as exc_info:
            pad_targets_to_fixed_count([target], pad_to)

        assert "pad_to must be a positive integer" in str(exc_info.value)

    def test_truncation_logs_the_dropped_box_count(self, caplog: pytest.LogCaptureFixture, monkeypatch) -> None:
        """Dropping real ground-truth boxes must be observable, even though it stays non-fatal."""
        target = {"boxes": torch.rand(6, 4), "labels": torch.zeros(6, dtype=torch.int64)}

        # get_logger() sets propagate=False on the "rf-detr" logger, so caplog's root-level
        # handler only sees its records while propagation is re-enabled.
        monkeypatch.setattr(logging.getLogger("rf-detr"), "propagate", True)

        with caplog.at_level(logging.WARNING, logger="rf-detr"):
            pad_targets_to_fixed_count([target], 4)

        assert any("2 box(es) are dropped" in record.getMessage() for record in caplog.records)

    @pytest.mark.parametrize("seed", range(8))
    @pytest.mark.parametrize(
        ("batch_size", "queries"),
        [
            pytest.param(4, 60, id="compact-path"),
            pytest.param(1, 8, id="full-cartesian-path"),
        ],
    )
    def test_padding_does_not_change_the_assignment(self, batch_size, queries, seed) -> None:
        """Padded columns carry a query-independent cost, so they cannot displace a real target.

        ``HungarianMatcher._compact_path_applicable`` only takes the compact path for ``batch_size > 1``; a single-image
        batch always falls to the full cartesian path in ``forward()``, which needs its own copy of the same
        ``_PADDED_TARGET_COST`` masking. With few queries relative to the padded target count (12), a filler target that
        isn't masked can win a query a real target would otherwise have taken.
        """
        outputs, targets = _padding_batch(seed, batch_size=batch_size, queries=queries)
        criterion = _padding_criterion()
        plain = criterion.matcher(outputs, targets)
        padded = criterion.matcher(outputs, list(pad_targets_to_fixed_count(targets, 12)))

        for count, (src_a, tgt_a), (src_b, tgt_b) in zip([int(t["boxes"].shape[0]) for t in targets], plain, padded):
            real = tgt_b < count
            assert dict(zip(tgt_a.tolist(), src_a.tolist())) == dict(zip(tgt_b[real].tolist(), src_b[real].tolist()))

    @pytest.mark.parametrize("seed", range(8))
    def test_padding_does_not_change_the_losses(self, seed) -> None:
        """Every reported term matches; the box terms differ only by float32 summation order."""
        outputs, targets = _padding_batch(seed)
        criterion = _padding_criterion()
        plain = criterion(outputs, targets)
        padded = criterion(outputs, list(pad_targets_to_fixed_count(targets, 12)))

        assert set(plain) == set(padded)
        for key in plain:
            assert torch.allclose(plain[key], padded[key], rtol=1e-5, atol=1e-6), (
                f"{key} diverged: {float(plain[key])} vs {float(padded[key])}"
            )

    @pytest.mark.parametrize("seed", range(8))
    def test_cardinality_error_counts_real_boxes_not_padded_rows(self, seed) -> None:
        """``loss_cardinality`` compared padded targets' constant row count against the prediction count instead of the
        real ground-truth count; ``valid`` must be read back out of it."""
        outputs, targets = _padding_batch(seed)
        criterion = _padding_criterion(losses=["cardinality"])
        plain = criterion(outputs, targets)
        padded = criterion(outputs, list(pad_targets_to_fixed_count(targets, 12)))

        assert torch.allclose(plain["cardinality_error"], padded["cardinality_error"], rtol=1e-5, atol=1e-6)

    @pytest.mark.xla
    @_requires_torch_xla
    def test_cardinality_error_does_not_read_the_valid_mask_back_to_the_host(self) -> None:
        """No ``_local_scalar_dense``: reading padded targets' ``valid`` counts must stay a device transfer.

        Padding runs host-side in the collate seam (as it does in production), so this pads before moving the batch to
        the XLA device -- exactly the boundary an ``int()`` per image would cross on every read. Runs on any PJRT
        backend -- ``device.type`` is ``"xla"`` under ``PJRT_DEVICE=CPU`` too, which is all the host-sync counter
        depends on, so this needs no TPU silicon.
        """
        import torch_xla
        import torch_xla.debug.metrics as met

        device = torch_xla.device()
        outputs, targets = _padding_batch(0, batch_size=2, queries=8)
        padded = [
            {key: (value.to(device) if torch.is_tensor(value) else value) for key, value in target.items()}
            for target in pad_targets_to_fixed_count(targets, 12)
        ]
        outputs = {key: value.to(device) for key, value in outputs.items()}
        criterion = _padding_criterion(losses=["cardinality"])
        num_boxes = torch.tensor(0.0, device=device)

        # Warm up so one-off compilation transfers do not land in the measured counters.
        criterion.loss_cardinality(outputs, padded, indices=[], num_boxes=num_boxes)
        torch_xla.sync()

        met.clear_all()
        criterion.loss_cardinality(outputs, padded, indices=[], num_boxes=num_boxes)
        torch_xla.sync()

        assert met.counter_value("aten::_local_scalar_dense") is None

    def test_unmasked_classification_branches_refuse_padded_targets(self) -> None:
        """Better a loud failure than a loss that quietly counts filler rows as real matches."""
        outputs, targets = _padding_batch(0)
        criterion = _padding_criterion(ia_bce_loss=False)

        with pytest.raises(NotImplementedError) as exc_info:
            criterion(outputs, list(pad_targets_to_fixed_count(targets, 12)))

        assert "IoU-aware BCE" in str(exc_info.value)

    def test_mask_loss_refuses_padded_targets(self) -> None:
        """``loss_masks`` point-samples every matched pair, so a filler pair would contribute real gradient."""
        criterion = _bare_criterion()
        criterion.mask_point_sample_ratio = 16
        pred_masks = torch.randn(1, 8, 24, 24, requires_grad=True)
        targets = list(
            pad_targets_to_fixed_count([{"boxes": torch.rand(8, 4), "masks": torch.rand(8, 96, 96) > 0.5}], 12)
        )
        indices = [(torch.arange(8), torch.arange(8))]

        with pytest.raises(NotImplementedError) as exc_info:
            criterion.loss_masks({"pred_masks": pred_masks}, targets, indices, num_boxes=torch.tensor(8.0))

        assert "pad_targets_to unset for segmentation" in str(exc_info.value)

    def test_keypoints_loss_refuses_padded_targets(self) -> None:
        """``loss_keypoints`` reads every matched pair with no valid-row mask, so a filler pair would contribute real
        gradient -- same shape of gap as ``loss_masks`` above, on the sibling head."""
        criterion = _bare_criterion()
        outputs = {"pred_keypoints": torch.randn(1, 8, 3, 3, requires_grad=True)}
        targets = list(
            pad_targets_to_fixed_count(
                [
                    {
                        "boxes": torch.rand(8, 4),
                        "labels": torch.zeros(8, dtype=torch.int64),
                        "keypoints": torch.rand(8, 3, 3),
                    }
                ],
                12,
            )
        )
        indices = [(torch.arange(8), torch.arange(8))]

        with pytest.raises(NotImplementedError) as exc_info:
            criterion.loss_keypoints(outputs, targets, indices, num_boxes=torch.tensor(8.0))

        assert "pad_targets_to unset for keypoint" in str(exc_info.value)
