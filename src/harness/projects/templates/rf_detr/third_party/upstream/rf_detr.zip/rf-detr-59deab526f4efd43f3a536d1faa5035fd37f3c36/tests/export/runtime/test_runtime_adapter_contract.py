# ------------------------------------------------------------------------
# RF-DETR
# Copyright (c) 2025 Roboflow. All Rights Reserved.
# Licensed under the Apache License, Version 2.0 [see LICENSE for details]
# ------------------------------------------------------------------------
"""Boundary tests for exported-model runtime adapters."""

from __future__ import annotations

import builtins
import logging
import sys
from pathlib import Path
from types import SimpleNamespace
from typing import Any

import numpy as np
import pytest
import torch
from pytest_mock import MockerFixture

from rfdetr.export._runtime.adapters import ExportRuntime, _input_array, load_runtime
from rfdetr.export._runtime.context import load_exported_context
from rfdetr.export._runtime.metadata import ExportMetadata, metadata_from_model, read_metadata, write_metadata
from tests.export._openvino_shapes import FakePartialShape
from tests.export.conftest import _make_rfdetr


def _load_onnx_runtime(
    monkeypatch: pytest.MonkeyPatch,
    mocker: MockerFixture,
    tmp_path: Path,
    provider: str,
    torch_sees_cuda: bool,
    labels_shape: list[int | str],
    device: str = "auto",
) -> tuple[ExportRuntime, Any]:
    """Load an ONNX runtime over a mocked session with a symbolic batch axis and two outputs.

    Args:
        monkeypatch: Pytest monkeypatch fixture.
        mocker: Pytest-mock fixture.
        tmp_path: Directory for the placeholder artifact.
        provider: The one execution provider the fake onnxruntime offers.
        torch_sees_cuda: Whether ``torch.cuda.is_available()`` reports a GPU.
        labels_shape: Shape of the second output.
        device: Device passed to ``load_runtime``.

    Returns:
        The loaded runtime and its mocked session.

    Examples:
        Needs pytest fixtures, so it is only listed here.

        >>> shape = ["batch", 2, 3]
        >>> _load_onnx_runtime(monkeypatch, mocker, tmp_path, "CPUExecutionProvider", True, shape)  # doctest: +SKIP
    """
    path = tmp_path / "model.onnx"
    path.write_bytes(b"model")
    session = mocker.Mock()
    session.get_inputs.return_value = [SimpleNamespace(name="input", type="tensor(float)", shape=["batch", 3, 8, 8])]
    session.get_outputs.return_value = [
        SimpleNamespace(name="dets", type="tensor(float)", shape=["batch", 2, 4]),
        SimpleNamespace(name="labels", type="tensor(float)", shape=labels_shape),
    ]
    session.get_providers.return_value = [provider]
    monkeypatch.setitem(sys.modules, "onnxruntime", SimpleNamespace(get_available_providers=lambda: [provider]))
    mocker.patch("rfdetr.export._onnx.inference._create_onnx_session", return_value=session)
    mocker.patch("rfdetr.export._onnx.inference.torch.cuda.is_available", return_value=torch_sees_cuda)
    metadata = _metadata(
        format="onnx",
        task="detect",
        input_shape=(1, 3, 8, 8),
        input_name="input",
        outputs={"pred_boxes": "dets", "pred_logits": "labels"},
    )
    return load_runtime(path, metadata, device=device), session


def _metadata(**fields: Any) -> ExportMetadata:
    """Make a complete prediction contract for runtime tests.

    Two classes give three logit slots: the class ids plus the trailing no-object slot.

    Examples:
        >>> contract = _metadata(format="onnx", task="detect", input_shape=(1, 3, 8, 8),
        ...     outputs={"pred_boxes": "dets", "pred_logits": "labels"})
        >>> contract.num_classes
        2
    """
    return ExportMetadata(
        class_names=["one", "two"],
        class_id_to_name={0: "one", 1: "two"},
        num_classes=2,
        num_select=2,
        patch_size=16,
        num_windows=1,
        means=[0.485, 0.456, 0.406],
        stds=[0.229, 0.224, 0.225],
        trace_alpha=0.2,
        **fields,
    )


class TestInputArray:
    """Check tensor conversion to the artifact's NumPy input interface."""

    @pytest.mark.parametrize(
        ("input_layout", "axes"),
        [
            pytest.param("NCHW", (0, 1, 2, 3), id="channels-first"),
            pytest.param("NHWC", (0, 2, 3, 1), id="channels-last"),
        ],
    )
    def test_converts_to_artifact_layout(self, input_layout: str, axes: tuple[int, int, int, int]) -> None:
        """Preserve values when converting a batch to the artifact's layout.

        Distinct channel and spatial values in a rectangular NCHW batch expose an incorrect axis permutation.
        """
        metadata = _metadata(
            format="onnx",
            task="detect",
            input_shape=(1, 3, 2, 4),
            input_layout=input_layout,
            outputs={"pred_boxes": "dets", "pred_logits": "labels"},
        )
        batch = torch.arange(24, dtype=torch.float32).reshape(1, 3, 2, 4)
        expected = batch.numpy().transpose(axes)

        result = _input_array(batch, metadata)

        assert result.shape == expected.shape
        assert result.flags.c_contiguous
        np.testing.assert_array_equal(result, expected)

    @pytest.mark.parametrize("input_dtype", ["int8", "uint8"])
    def test_rejects_non_floating_artifact_dtype(self, input_dtype: str) -> None:
        """Refuse integer artifact inputs without quantization parameters.

        A normalized floating batch cannot be converted to a quantized artifact's dtype by a plain cast.
        """
        metadata = _metadata(
            format="onnx",
            task="detect",
            input_shape=(1, 3, 2, 4),
            input_dtype=input_dtype,
            outputs={"pred_boxes": "dets", "pred_logits": "labels"},
        )
        batch = torch.zeros(1, 3, 2, 4)

        with pytest.raises(ValueError, match="needs quantization parameters"):
            _input_array(batch, metadata)

    def test_rejects_unknown_artifact_dtype(self) -> None:
        """Report an unsupported artifact dtype as a ValueError.

        Metadata accepts an arbitrary dtype string, so the adapter must wrap NumPy's TypeError for an unknown name.
        """
        metadata = _metadata(
            format="onnx",
            task="detect",
            input_shape=(1, 3, 2, 4),
            input_dtype="nonesuch",
            outputs={"pred_boxes": "dets", "pred_logits": "labels"},
        )
        batch = torch.zeros(1, 3, 2, 4)

        with pytest.raises(ValueError, match="Unsupported export input dtype") as exc_info:
            _input_array(batch, metadata)

        assert isinstance(exc_info.value.__cause__, TypeError)

    @pytest.mark.parametrize(
        ("tensor_dtype", "input_dtype"),
        [
            pytest.param(torch.float32, "float32", id="float32-to-float32"),
            pytest.param(torch.float16, "float32", id="float16-to-float32"),
            pytest.param(torch.bfloat16, "float32", id="bfloat16-to-float32"),
            pytest.param(torch.bfloat16, "float16", id="bfloat16-to-float16"),
        ],
    )
    def test_casts_to_artifact_dtype(self, tensor_dtype: torch.dtype, input_dtype: str) -> None:
        """Convert floating tensors to the artifact's dtype, including BF16, which NumPy cannot hold.

        A BF16 tensor passed to ``RFDETRInference.predict`` kept its dtype through preprocessing, so the artifact's
        floating dtype has to be applied in torch before ``.numpy()``; the values must survive and the array be
        contiguous.
        """
        metadata = _metadata(
            format="onnx",
            task="detect",
            input_shape=(1, 3, 8, 8),
            input_dtype=input_dtype,
            outputs={"pred_boxes": "dets", "pred_logits": "labels"},
        )
        batch = torch.linspace(-1.1, 1.1, 3 * 8 * 8, dtype=tensor_dtype).reshape(1, 3, 8, 8)
        expected = batch.float().numpy().astype(input_dtype)

        result = _input_array(batch, metadata)

        assert result.dtype == np.dtype(input_dtype)
        assert result.flags.c_contiguous
        np.testing.assert_array_equal(result, expected)


class TestExportRuntimeOutputs:
    """Check output conversion through the runtime contract."""

    def test_owned_list_outputs_convert_to_tensors(self) -> None:
        """Python-list outputs from a session convert to tensors of the declared shape, including on NumPy 2."""
        metadata = _metadata(
            format="onnx",
            task="detect",
            input_shape=(1, 3, 8, 8),
            outputs={"pred_boxes": "dets", "pred_logits": "labels"},
        )
        runtime = ExportRuntime(
            "onnx",
            metadata,
            session=object(),
            device_policy="CPUExecutionProvider",
            execute=lambda batch: {"dets": [[[0.0, 0.0, 1.0, 1.0]]], "labels": [[[1.0, 2.0, 3.0]]]},
            borrowed_outputs=False,
        )

        result = runtime.run(torch.zeros(1, 3, 8, 8))

        assert result["pred_boxes"].shape == (1, 1, 4)

    @pytest.mark.parametrize(
        ("outputs", "raw", "match"),
        [
            pytest.param(
                {"pred_boxes": "dets", "pred_logits": "labels"},
                {"dets": np.zeros((1, 2, 4), np.float32), "labels": np.zeros((1, 2, 2), np.float32)},
                "2 class slots",
                id="logits-without-no-object-slot",
            ),
            pytest.param(
                {"pred_boxes": "dets", "pred_logits": "labels"},
                {"dets": np.zeros((1, 2, 4), np.float32), "labels": np.zeros((1, 2, 5), np.float32)},
                "5 class slots",
                id="logits-wider-than-metadata",
            ),
            pytest.param(
                {"pred_boxes": "dets", "pred_logits": "labels"},
                {"dets": np.zeros((1, 2, 4), np.float32), "scores": np.zeros((1, 2, 3), np.float32)},
                "maps to missing runtime output 'labels'",
                id="unknown-output-name",
            ),
            pytest.param(
                {"pred_boxes": 0, "pred_logits": 2},
                [np.zeros((1, 2, 4), np.float32), np.zeros((1, 2, 3), np.float32)],
                "maps to missing runtime output 2",
                id="position-past-last-output",
            ),
            pytest.param(
                {"pred_boxes": "dets", "pred_logits": "labels"},
                {"dets": np.zeros((1, 3, 4), np.float32), "labels": np.zeros((1, 2, 3), np.float32)},
                "incompatible shapes",
                id="query-count-mismatch",
            ),
        ],
    )
    def test_rejects_outputs_outside_contract(self, outputs: dict[str, str | int], raw: Any, match: str) -> None:
        """Graph outputs that disagree with the metadata are refused instead of mislabelled.

        A plain executor returns the given tensors, so only the shared output mapping decides: a logits tensor whose
        width is not ``num_classes + 1`` would shift the no-object slot onto a real class id.
        """
        metadata = _metadata(format="onnx", task="detect", input_shape=(1, 3, 8, 8), outputs=outputs)
        runtime = ExportRuntime(
            "onnx", metadata, session=object(), device_policy="CPUExecutionProvider", execute=lambda batch: raw
        )

        with pytest.raises(ValueError, match=match):
            runtime.run(torch.zeros(1, 3, 8, 8))


class TestONNXRuntimeAdapter:
    """Exercise provider choice and semantic output mapping through the loader."""

    def test_cpu_run_returns_owned_semantic_tensors(
        self, monkeypatch: pytest.MonkeyPatch, mocker: MockerFixture, tmp_path: Path
    ) -> None:
        """An ONNX call maps graph names and owns returned arrays."""
        path = tmp_path / "model.onnx"
        path.write_bytes(b"model")
        output = np.ones((1, 2, 4), dtype=np.float32)
        logits = np.ones((1, 2, 3), dtype=np.float32)
        session = mocker.Mock()
        session.get_inputs.return_value = [SimpleNamespace(name="input", type="tensor(float)", shape=[1, 3, 8, 8])]
        session.get_outputs.return_value = [SimpleNamespace(name="dets"), SimpleNamespace(name="labels")]
        session.get_providers.return_value = ["CPUExecutionProvider"]
        session.run.return_value = [output, logits]
        monkeypatch.setitem(
            sys.modules, "onnxruntime", SimpleNamespace(get_available_providers=lambda: ["CPUExecutionProvider"])
        )
        mocker.patch("rfdetr.export._onnx.inference._create_onnx_session", return_value=session)
        metadata = _metadata(
            format="onnx",
            task="detect",
            input_shape=(1, 3, 8, 8),
            input_name="input",
            outputs={"pred_boxes": "dets", "pred_logits": "labels"},
        )

        runtime = load_runtime(path, metadata, device="cpu")
        result = runtime.run(torch.zeros(1, 3, 8, 8))

        assert runtime.info == {"backend": "onnx", "device": "CPUExecutionProvider"}
        assert runtime.device == torch.device("cpu")
        assert result["pred_boxes"][0, 0, 0] == 1
        assert np.shares_memory(result["pred_boxes"].numpy(), output)
        session.run.assert_called_once()

    def test_explicit_cuda_refuses_missing_provider(
        self, monkeypatch: pytest.MonkeyPatch, mocker: MockerFixture, tmp_path: Path
    ) -> None:
        """An explicit CUDA request cannot fall back to CPU."""
        path = tmp_path / "model.onnx"
        path.write_bytes(b"model")
        monkeypatch.setitem(
            sys.modules, "onnxruntime", SimpleNamespace(get_available_providers=lambda: ["CPUExecutionProvider"])
        )
        metadata = _metadata(
            format="onnx",
            task="detect",
            input_shape=(1, 3, 8, 8),
            outputs={"pred_boxes": "dets", "pred_logits": "labels"},
        )

        with pytest.raises(RuntimeError, match="CUDAExecutionProvider is unavailable"):
            load_runtime(path, metadata, device="cuda:0")

    @pytest.mark.parametrize(
        "provider,torch_sees_cuda,labels_shape,device,expected",
        [
            pytest.param(
                "CUDAExecutionProvider", True, ["batch", 2, 3], "auto", torch.device("cuda", 0), id="cuda-provider"
            ),
            pytest.param(
                "CUDAExecutionProvider", True, ["batch", 2, 3], "cuda:1", torch.device("cuda", 1), id="cuda-index"
            ),
            pytest.param(
                "CUDAExecutionProvider", False, ["batch", 2, 3], "auto", torch.device("cpu"), id="torch-without-cuda"
            ),
            pytest.param(
                "CUDAExecutionProvider", True, ["batch", "queries", 3], "auto", torch.device("cpu"), id="dynamic-axis"
            ),
            pytest.param("CUDAExecutionProvider", True, [], "auto", torch.device("cpu"), id="scalar-output"),
            pytest.param("CUDAExecutionProvider", True, [5, 3], "auto", torch.device("cpu"), id="fixed-leading-axis"),
            pytest.param(
                "CUDAExecutionProvider", True, ["queries", 3], "auto", torch.device("cpu"), id="non-batch-leading-axis"
            ),
            pytest.param("CPUExecutionProvider", True, ["batch", 2, 3], "auto", torch.device("cpu"), id="cpu-provider"),
        ],
    )
    def test_runtime_device_follows_the_provider(
        self,
        monkeypatch: pytest.MonkeyPatch,
        mocker: MockerFixture,
        tmp_path: Path,
        provider: str,
        torch_sees_cuda: bool,
        labels_shape: list[int | str],
        device: str,
        expected: torch.device,
    ) -> None:
        """The CUDA provider makes the runtime a CUDA device, so the batch is prepared and bound on the GPU.

        It falls back to a CPU runtime, the path every provider took before, when torch cannot see the GPU or an output
        is a scalar, does not lead with the input's batch axis, or has a dynamic axis other than the batch, whose buffer
        cannot be allocated before the run.
        """
        runtime, _ = _load_onnx_runtime(monkeypatch, mocker, tmp_path, provider, torch_sees_cuda, labels_shape, device)

        assert runtime.device == expected

    @pytest.mark.parametrize(
        "provider,torch_sees_cuda,bound_calls",
        [
            pytest.param("CUDAExecutionProvider", True, 1, id="on-device"),
            pytest.param("CUDAExecutionProvider", False, 0, id="torch-without-cuda"),
            pytest.param("CPUExecutionProvider", True, 0, id="cpu-provider"),
        ],
    )
    def test_run_binds_the_batch_only_on_device(
        self,
        monkeypatch: pytest.MonkeyPatch,
        mocker: MockerFixture,
        tmp_path: Path,
        provider: str,
        torch_sees_cuda: bool,
        bound_calls: int,
    ) -> None:
        """``run`` hands the batch to ``_run_onnx_bound`` exactly when the runtime is on a CUDA device."""
        runtime, _ = _load_onnx_runtime(monkeypatch, mocker, tmp_path, provider, torch_sees_cuda, ["batch", 2, 3])
        bound = mocker.patch(
            "rfdetr.export._onnx.inference._run_onnx_bound",
            return_value=[torch.zeros(1, 2, 4), torch.zeros(1, 2, 3)],
        )
        mocker.patch(
            "rfdetr.export._onnx.inference._run_onnx_raw", return_value=[np.zeros((1, 2, 4)), np.zeros((1, 2, 3))]
        )
        mocker.patch("rfdetr.export._runtime.adapters._select_outputs", return_value={})

        runtime.run(torch.zeros(1, 3, 8, 8))

        assert bound.call_count == bound_calls


class TestTFLiteRuntimeAdapter:
    """Exercise layout conversion, dynamic batches, and positional outputs."""

    def test_nhwc_run_maps_positional_outputs(self, mocker: MockerFixture, tmp_path: Path) -> None:
        """A LiteRT artifact receives NHWC data and returns semantic outputs."""
        path = tmp_path / "model.tflite"
        path.write_bytes(b"model")
        interpreter = mocker.Mock()
        interpreter.get_input_details.return_value = [
            {"name": "input", "index": 7, "shape": [1, 8, 8, 3], "dtype": np.float32}
        ]
        interpreter.get_output_details.return_value = [
            {"name": "opaque_0", "index": 9},
            {"name": "opaque_1", "index": 10},
        ]
        boxes = np.zeros((1, 2, 4), np.float32)
        interpreter.get_tensor.side_effect = [boxes, np.zeros((1, 2, 3), np.float32)]
        mocker.patch("rfdetr.export._tflite.inference._create_interpreter", return_value=interpreter)
        metadata = _metadata(
            format="litert",
            task="detect",
            input_shape=(1, 3, 8, 8),
            input_layout="NHWC",
            outputs={"pred_boxes": 0, "pred_logits": 1},
        )

        runtime = load_runtime(path, metadata)
        result = runtime.run(torch.zeros(1, 3, 8, 8))

        assert interpreter.set_tensor.call_args.args[0] == 7
        assert interpreter.set_tensor.call_args.args[1].shape == (1, 8, 8, 3)
        assert result["pred_boxes"].shape == (1, 2, 4)
        assert np.shares_memory(result["pred_boxes"].numpy(), boxes)
        interpreter.invoke.assert_called_once()

    def test_rejects_wrong_fixed_batch_before_invoke(self, mocker: MockerFixture, tmp_path: Path) -> None:
        """A fixed batch artifact rejects a two-image call before execution."""
        path = tmp_path / "model.tflite"
        path.write_bytes(b"model")
        interpreter = mocker.Mock()
        interpreter.get_input_details.return_value = [
            {"name": "input", "index": 0, "shape": [1, 8, 8, 3], "dtype": np.float32}
        ]
        interpreter.get_output_details.return_value = [
            {"name": "opaque_0", "index": 1},
            {"name": "opaque_1", "index": 2},
        ]
        mocker.patch("rfdetr.export._tflite.inference._create_interpreter", return_value=interpreter)
        metadata = _metadata(
            format="tflite",
            task="detect",
            input_shape=(1, 3, 8, 8),
            input_layout="NHWC",
            outputs={"pred_boxes": 0, "pred_logits": 1},
        )

        runtime = load_runtime(path, metadata)
        with pytest.raises(ValueError, match="Input axis 0 must be 1"):
            runtime.run(torch.zeros(2, 3, 8, 8))
        interpreter.invoke.assert_not_called()

    def test_dynamic_signature_accepts_fixed_batch_metadata(self, mocker: MockerFixture, tmp_path: Path) -> None:
        """A graph whose signature leaves the batch dynamic loads fixed batch-2 metadata.

        The interpreter allocates batch 1 by default, so checking the current shape instead of the signature would
        refuse an artifact that ``_run_interpreter_raw`` can resize to batch 2.
        """
        path = tmp_path / "model.tflite"
        path.write_bytes(b"model")
        interpreter = mocker.Mock()
        interpreter.get_input_details.return_value = [
            {"name": "input", "index": 0, "shape": [1, 8, 8, 3], "shape_signature": [-1, 8, 8, 3], "dtype": np.float32}
        ]
        interpreter.get_output_details.return_value = [{"name": "dets", "index": 1}, {"name": "labels", "index": 2}]
        mocker.patch("rfdetr.export._tflite.inference._create_interpreter", return_value=interpreter)
        metadata = _metadata(
            format="tflite",
            task="detect",
            input_shape=(2, 3, 8, 8),
            input_layout="NHWC",
            outputs={"pred_boxes": 0, "pred_logits": 1},
        )

        runtime = load_runtime(path, metadata)

        assert runtime.metadata.input_shape == (2, 3, 8, 8)

    def test_fixed_graph_rejects_dynamic_batch_metadata(self, mocker: MockerFixture, tmp_path: Path) -> None:
        """A graph with a fixed batch refuses metadata that promises any batch size.

        Without a dynamic signature the interpreter cannot resize, so accepting ``-1`` metadata would defer the failure
        to the first multi-image call.
        """
        path = tmp_path / "model.tflite"
        path.write_bytes(b"model")
        interpreter = mocker.Mock()
        interpreter.get_input_details.return_value = [
            {"name": "input", "index": 0, "shape": [1, 8, 8, 3], "shape_signature": [1, 8, 8, 3], "dtype": np.float32}
        ]
        interpreter.get_output_details.return_value = [{"name": "dets", "index": 1}, {"name": "labels", "index": 2}]
        mocker.patch("rfdetr.export._tflite.inference._create_interpreter", return_value=interpreter)
        metadata = _metadata(
            format="tflite",
            task="detect",
            input_shape=(-1, 3, 8, 8),
            input_layout="NHWC",
            outputs={"pred_boxes": 0, "pred_logits": 1},
        )

        with pytest.raises(ValueError, match="disagrees with export metadata"):
            load_runtime(path, metadata)

    def test_dynamic_batch_resizes_one_interpreter(self, mocker: MockerFixture, tmp_path: Path) -> None:
        """A dynamic model resizes once and still executes one two-image batch."""
        path = tmp_path / "model.tflite"
        path.write_bytes(b"model")
        interpreter = mocker.Mock()
        interpreter.get_input_details.return_value = [
            {
                "name": "input",
                "index": 0,
                "shape": [1, 8, 8, 3],
                "shape_signature": [-1, 8, 8, 3],
                "dtype": np.float32,
            }
        ]
        interpreter.get_output_details.return_value = [{"name": "dets", "index": 1}, {"name": "labels", "index": 2}]
        interpreter.get_tensor.side_effect = [np.zeros((2, 2, 4), np.float32), np.zeros((2, 2, 3), np.float32)]
        mocker.patch("rfdetr.export._tflite.inference._create_interpreter", return_value=interpreter)
        metadata = _metadata(
            format="tflite",
            task="detect",
            input_shape=(-1, 3, 8, 8),
            input_layout="NHWC",
            outputs={"pred_boxes": 0, "pred_logits": 1},
        )

        runtime = load_runtime(path, metadata)
        result = runtime.run(torch.zeros(2, 3, 8, 8))

        interpreter.resize_tensor_input.assert_called_once_with(0, (2, 8, 8, 3), strict=True)
        interpreter.invoke.assert_called_once()
        assert result["pred_boxes"].shape[0] == 2


class TestTensorRTRuntimeAdapter:
    """Check shared TensorRT execution without the deprecated facade."""

    def test_engine_waits_for_prepared_cuda_input(
        self, monkeypatch: pytest.MonkeyPatch, mocker: MockerFixture, tmp_path: Path
    ) -> None:
        """A stream-free engine call cannot read input before its torch stream finishes."""
        path = tmp_path / "model.engine"
        path.write_bytes(b"engine")
        events: list[str] = []
        session = mocker.Mock()
        session.input_names = ["input"]
        session.output_names = ["dets", "labels"]
        session.bindings = {"input": SimpleNamespace(dtype=np.float32, shape=(1, 3, 8, 8))}
        session.engine_device = torch.device("cuda:0")
        session.side_effect = lambda _: events.append("execute") or {}
        stream = SimpleNamespace(synchronize=lambda: events.append("input ready"))
        mocker.patch.object(torch.cuda, "is_available", return_value=True)
        mocker.patch.object(torch.cuda, "current_stream", return_value=stream)
        monkeypatch.setattr(torch.Tensor, "to", lambda self, **kwargs: self)
        mocker.patch("rfdetr.export._tensorrt.inference._load_tensorrt_session", return_value=session)
        mocker.patch(
            "rfdetr.export._tensorrt.inference._run_tensorrt_session", side_effect=lambda state, blob: state(blob)
        )
        monkeypatch.delattr("rfdetr.export._tensorrt.inference.TRTInference")
        metadata = _metadata(
            format="tensorrt",
            task="detect",
            input_shape=(1, 3, 8, 8),
            outputs={"pred_boxes": "dets", "pred_logits": "labels"},
        )

        runtime = load_runtime(path, metadata)
        runtime._execute(torch.zeros(1, 3, 8, 8))

        assert events == ["input ready", "execute"]

    def test_engine_run_copies_reused_outputs(
        self, monkeypatch: pytest.MonkeyPatch, mocker: MockerFixture, tmp_path: Path
    ) -> None:
        """A later engine call cannot change a prior prediction."""
        path = tmp_path / "model.engine"
        path.write_bytes(b"engine")
        boxes = torch.ones(1, 2, 4)
        logits = torch.ones(1, 2, 3)
        session = mocker.Mock()
        session.input_names = ["input"]
        session.output_names = ["dets", "labels"]
        session.bindings = {"input": SimpleNamespace(dtype=np.float32, shape=(1, 3, 8, 8))}
        session.engine_device = torch.device("cpu")
        session.side_effect = lambda _: {"dets": boxes, "labels": logits}
        mocker.patch.object(torch.cuda, "is_available", return_value=True)
        mocker.patch("rfdetr.export._tensorrt.inference._load_tensorrt_session", return_value=session)
        mocker.patch(
            "rfdetr.export._tensorrt.inference._run_tensorrt_session", side_effect=lambda state, blob: state(blob)
        )
        monkeypatch.delattr("rfdetr.export._tensorrt.inference.TRTInference")
        metadata = _metadata(
            format="tensorrt",
            task="detect",
            input_shape=(1, 3, 8, 8),
            outputs={"pred_boxes": "dets", "pred_logits": "labels"},
        )

        runtime = load_runtime(path, metadata)
        batch = torch.zeros(1, 3, 8, 8)
        first = runtime.run(batch)
        boxes.fill_(9)

        assert first["pred_boxes"][0, 0, 0] == 1
        assert runtime.device == session.engine_device
        assert session.call_args.args[0]["input"] is batch
        session.assert_called_once()


class TestCoreAIRuntimeAdapter:
    """Check the documented Core AI load and execution APIs."""

    def test_float16_keypoints_auto_uses_cpu(
        self, monkeypatch: pytest.MonkeyPatch, mocker: MockerFixture, tmp_path: Path, caplog: pytest.LogCaptureFixture
    ) -> None:
        """Automatic execution avoids the unsafe Neural Engine path."""
        path = tmp_path / "model.aimodel"
        path.write_bytes(b"asset")
        function = mocker.Mock(
            return_value={
                "dets": SimpleNamespace(numpy=lambda: np.zeros((1, 2, 4), np.float32)),
                "labels": SimpleNamespace(numpy=lambda: np.zeros((1, 2, 3), np.float32)),
                "keypoints": SimpleNamespace(numpy=lambda: np.zeros((1, 2, 17, 3), np.float32)),
            }
        )
        model = mocker.Mock()
        model.load_function.return_value = function
        options = SimpleNamespace(
            cpu_only=mocker.Mock(return_value="cpu-option"), default=mocker.Mock(return_value="default-option")
        )
        ai_model = SimpleNamespace(load=mocker.Mock(return_value=model))
        runtime_module = SimpleNamespace(
            AIModel=ai_model, ComputeUnitKind=mocker.Mock(), SpecializationOptions=options, NDArray=lambda array: array
        )
        monkeypatch.setitem(sys.modules, "coreai", SimpleNamespace(runtime=runtime_module))
        monkeypatch.setitem(sys.modules, "coreai.runtime", runtime_module)
        mocker.patch("rfdetr.export._runtime.adapters.platform.system", return_value="Darwin")
        monkeypatch.setattr(logging.getLogger("rf-detr"), "propagate", True)
        metadata = _metadata(
            format="coreai",
            task="keypoints",
            input_shape=(1, 3, 8, 8),
            input_dtype="float16",
            num_keypoints_per_class=[17, 17, 17],
            outputs={"pred_boxes": "dets", "pred_logits": "labels", "pred_keypoints": "keypoints"},
        )

        runtime = load_runtime(path, metadata)
        result = runtime.run(torch.zeros(1, 3, 8, 8))

        ai_model.load.assert_called_once_with(path, "cpu-option")
        assert runtime.info["device"] == "cpu"
        assert "float16 keypoint" in caplog.text and "Neural Engine" in caplog.text
        assert result["pred_keypoints"].shape == (1, 2, 17, 3)
        del runtime


class TestOpenVINORuntimeAdapter:
    """Check shared OpenVINO execution without the deprecated facade."""

    def test_cpu_run_maps_positional_outputs(
        self, monkeypatch: pytest.MonkeyPatch, mocker: MockerFixture, tmp_path: Path
    ) -> None:
        """Shared OpenVINO execution returns a tuple in metadata order."""
        path = tmp_path / "model.xml"
        path.write_text("<net/>")
        session = mocker.Mock()
        raw_boxes = np.zeros((1, 2, 4), np.float32)
        session.infer.return_value = (raw_boxes, np.zeros((1, 2, 3), np.float32))
        session.compiled_model.inputs = [object()]
        session.input_layer.partial_shape = FakePartialShape((1, 3, 8, 8))
        session.output_layers = ["dets", "labels"]
        core = mocker.Mock(available_devices=["CPU"])
        monkeypatch.setitem(sys.modules, "openvino", SimpleNamespace(Core=lambda: core))
        mocker.patch("rfdetr.export._openvino.inference._load_openvino_session", return_value=session)
        mocker.patch(
            "rfdetr.export._openvino.inference._infer_openvino", side_effect=lambda state, array: state.infer(array)
        )
        monkeypatch.delattr("rfdetr.export._openvino.inference.OpenVINOInference")
        metadata = _metadata(
            format="openvino",
            task="detect",
            input_shape=(1, 3, 8, 8),
            outputs={"pred_boxes": 0, "pred_logits": 1},
        )

        runtime = load_runtime(path, metadata, device="cpu")
        result = runtime.run(torch.zeros(1, 3, 8, 8))

        assert runtime.info["device"] == "CPU"
        assert runtime.device == torch.device("cpu")
        assert result["pred_logits"].shape == (1, 2, 3)
        assert result["pred_boxes"].data_ptr() == raw_boxes.ctypes.data
        session.infer.assert_called_once()


class TestExecuTorchRuntimeAdapter:
    """Check the documented ExecuTorch Python runtime method."""

    def test_xnnpack_run_uses_forward_method(
        self, monkeypatch: pytest.MonkeyPatch, mocker: MockerFixture, tmp_path: Path
    ) -> None:
        """The loader keeps the program alive and executes one batch."""
        path = tmp_path / "model.pte"
        path.write_bytes(b"pte")
        method = mocker.Mock()
        method.execute.return_value = [torch.zeros(1, 2, 4), torch.zeros(1, 2, 3)]
        program = mocker.Mock()
        program.load_method.return_value = method
        engine = mocker.Mock()
        engine.load_program.return_value = program
        runtime_class = SimpleNamespace(get=lambda: engine)
        monkeypatch.setitem(sys.modules, "executorch", SimpleNamespace(runtime=SimpleNamespace(Runtime=runtime_class)))
        monkeypatch.setitem(sys.modules, "executorch.runtime", SimpleNamespace(Runtime=runtime_class))
        metadata = _metadata(
            format="executorch",
            task="detect",
            backend="xnnpack",
            input_shape=(1, 3, 8, 8),
            outputs={"pred_boxes": 0, "pred_logits": 1},
        )

        runtime = load_runtime(path, metadata)
        result = runtime.run(torch.zeros(1, 3, 8, 8))

        program.load_method.assert_called_once_with("forward")
        method.execute.assert_called_once()
        assert result["pred_boxes"].shape == (1, 2, 4)

    def test_tensorrt_registers_its_delegate_and_reports_cuda(
        self, monkeypatch: pytest.MonkeyPatch, mocker: MockerFixture, tmp_path: Path
    ) -> None:
        """A TensorRT program imports the delegate package before the program loads, and reports the CUDA policy."""
        path = tmp_path / "model.pte"
        path.write_bytes(b"pte")
        events: list[str] = []
        engine = mocker.Mock()
        engine.load_program.side_effect = lambda _path: events.append("load_program") or mocker.Mock()
        runtime_class = SimpleNamespace(get=lambda: engine)
        monkeypatch.setitem(sys.modules, "executorch", SimpleNamespace(runtime=SimpleNamespace(Runtime=runtime_class)))
        monkeypatch.setitem(sys.modules, "executorch.runtime", SimpleNamespace(Runtime=runtime_class))
        monkeypatch.delitem(sys.modules, "torch_tensorrt_executorch_runtime", raising=False)
        mocker.patch("rfdetr.export._executorch.exporter._check_executorch_available")
        mocker.patch("torch.cuda.is_available", return_value=True)
        metadata = _metadata(
            format="executorch",
            task="detect",
            backend="tensorrt",
            input_shape=(1, 3, 8, 8),
            outputs={"pred_boxes": 0, "pred_logits": 1},
        )
        delegate = SimpleNamespace(__name__="torch_tensorrt_executorch_runtime")
        original_import = __import__

        def _import(name: str, *args: Any, **kwargs: Any) -> Any:
            if name == "torch_tensorrt_executorch_runtime":
                events.append("register")
                return delegate
            return original_import(name, *args, **kwargs)

        monkeypatch.setattr("builtins.__import__", _import)

        runtime = load_runtime(path, metadata)

        assert events == ["register", "load_program"]
        assert runtime.info["device"] == "cuda"

    def test_tensorrt_without_its_delegate_names_the_extra(
        self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path
    ) -> None:
        """A TensorRT program without the delegate package fails with the extra that installs it."""
        path = tmp_path / "model.pte"
        path.write_bytes(b"pte")
        monkeypatch.setitem(sys.modules, "torch_tensorrt_executorch_runtime", None)
        monkeypatch.setattr("torch.cuda.is_available", lambda: True)
        metadata = _metadata(
            format="executorch",
            task="detect",
            backend="tensorrt",
            input_shape=(1, 3, 8, 8),
            outputs={"pred_boxes": 0, "pred_logits": 1},
        )

        with pytest.raises(ImportError, match=r"rfdetr\[executorch-tensorrt\]"):
            load_runtime(path, metadata)

    def test_tensorrt_rejects_a_cpu_device(self, tmp_path: Path) -> None:
        """A TensorRT program runs on the GPU, so an explicit CPU request is refused before anything loads."""
        path = tmp_path / "model.pte"
        path.write_bytes(b"pte")
        metadata = _metadata(
            format="executorch",
            task="detect",
            backend="tensorrt",
            input_shape=(1, 3, 8, 8),
            outputs={"pred_boxes": 0, "pred_logits": 1},
        )

        with pytest.raises(ValueError, match="ExecuTorch TensorRT requires cuda or auto"):
            load_runtime(path, metadata, device="cpu")

    def test_tensorrt_without_cuda_is_refused(self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
        """A TensorRT program on a host with no CUDA device is refused before the delegate or program loads."""
        path = tmp_path / "model.pte"
        path.write_bytes(b"pte")
        monkeypatch.setattr("torch.cuda.is_available", lambda: False)
        metadata = _metadata(
            format="executorch",
            task="detect",
            backend="tensorrt",
            input_shape=(1, 3, 8, 8),
            outputs={"pred_boxes": 0, "pred_logits": 1},
        )

        with pytest.raises(RuntimeError, match="requires an available CUDA device"):
            load_runtime(path, metadata)

    def test_runtime_compatibility_error_prevents_program_load(self, mocker: MockerFixture, tmp_path: Path) -> None:
        """A mismatched ExecuTorch runtime stops before the program loader runs."""
        path = tmp_path / "model.pte"
        path.write_bytes(b"pte")
        mocker.patch(
            "rfdetr.export._executorch.exporter._check_executorch_available",
            side_effect=ImportError("ABI-compatibility gap"),
        )
        metadata = _metadata(
            format="executorch",
            task="detect",
            backend="xnnpack",
            input_shape=(1, 3, 8, 8),
            outputs={"pred_boxes": 0, "pred_logits": 1},
        )

        with pytest.raises(ImportError, match="ABI-compatibility gap"):
            load_runtime(path, metadata)


class TestCoreMLRuntimeAdapter:
    """Check native CoreML output ordering and device policy."""

    @pytest.mark.parametrize("device", ["auto", "cpu", "cpu_and_gpu", "cpu_and_ne"])
    def test_compute_policy_and_spec_output_order(
        self, monkeypatch: pytest.MonkeyPatch, mocker: MockerFixture, tmp_path: Path, device: str
    ) -> None:
        """Position mappings follow the model spec despite dictionary order."""
        path = tmp_path / "model.mlpackage"
        path.mkdir()
        session = mocker.Mock()
        session.get_spec.return_value = SimpleNamespace(
            description=SimpleNamespace(
                input=[
                    SimpleNamespace(
                        name="input",
                        type=SimpleNamespace(
                            WhichOneof=lambda field: "multiArrayType",
                            multiArrayType=SimpleNamespace(shape=(1, 3, 8, 8), dataType=65568),
                        ),
                    )
                ],
                output=[SimpleNamespace(name="dets"), SimpleNamespace(name="labels")],
            )
        )
        boxes = np.zeros((1, 2, 4), np.float32)
        session.predict.return_value = {
            "labels": np.zeros((1, 2, 3), np.float32),
            "dets": boxes,
        }
        coreml = SimpleNamespace(
            ComputeUnit=SimpleNamespace(ALL="all", CPU_ONLY="cpu", CPU_AND_GPU="cpu_and_gpu", CPU_AND_NE="cpu_and_ne"),
            models=SimpleNamespace(MLModel=mocker.Mock(return_value=session)),
        )
        monkeypatch.setitem(sys.modules, "coremltools", coreml)
        mocker.patch("rfdetr.export._runtime.adapters.platform.system", return_value="Darwin")
        metadata = _metadata(
            format="coreml",
            task="detect",
            input_shape=(1, 3, 8, 8),
            outputs={"pred_boxes": 0, "pred_logits": 1},
        )

        runtime = load_runtime(path, metadata, device=device)
        result = runtime.run(torch.zeros(1, 3, 8, 8))

        assert result["pred_boxes"].shape == (1, 2, 4)
        assert np.shares_memory(result["pred_boxes"].numpy(), boxes)
        assert result["pred_logits"].shape == (1, 2, 3)
        coreml.models.MLModel.assert_called_once_with(str(path), compute_units="all" if device == "auto" else device)

    def test_explicit_ane_is_refused(
        self, monkeypatch: pytest.MonkeyPatch, mocker: MockerFixture, tmp_path: Path
    ) -> None:
        """CoreML cannot guarantee an ANE-only execution request."""
        path = tmp_path / "model.mlpackage"
        path.mkdir()
        coreml = SimpleNamespace(
            ComputeUnit=SimpleNamespace(ALL="all", CPU_ONLY="cpu", CPU_AND_GPU="cpu_and_gpu", CPU_AND_NE="cpu_and_ne")
        )
        monkeypatch.setitem(sys.modules, "coremltools", coreml)
        mocker.patch("rfdetr.export._runtime.adapters.platform.system", return_value="Darwin")
        metadata = _metadata(
            format="coreml",
            task="detect",
            input_shape=(1, 3, 8, 8),
            outputs={"pred_boxes": 0, "pred_logits": 1},
        )

        with pytest.raises(ValueError, match="also permit CPU"):
            load_runtime(path, metadata, device="ane")


class TestExecuTorchTensorRTLoader:
    """The TensorRT delegate loader accepts an explicit CUDA device and reads the backend from the sidecar."""

    @pytest.fixture
    def tensorrt_pte(
        self, monkeypatch: pytest.MonkeyPatch, mocker: MockerFixture, tmp_path: Path
    ) -> tuple[Path, ExportMetadata]:
        """A ``.pte`` path and TensorRT metadata, with ExecuTorch, CUDA and the delegate package stubbed."""
        path = tmp_path / "model.pte"
        path.write_bytes(b"pte")
        runtime_class = SimpleNamespace(get=lambda: mocker.Mock())
        monkeypatch.setitem(sys.modules, "executorch", SimpleNamespace(runtime=SimpleNamespace(Runtime=runtime_class)))
        monkeypatch.setitem(sys.modules, "executorch.runtime", SimpleNamespace(Runtime=runtime_class))
        monkeypatch.setitem(sys.modules, "torch_tensorrt_executorch_runtime", SimpleNamespace())
        mocker.patch("rfdetr.export._executorch.exporter._check_executorch_available")
        mocker.patch("torch.cuda.is_available", return_value=True)
        metadata = _metadata(
            format="executorch",
            task="detect",
            backend="tensorrt",
            input_shape=(1, 3, 8, 8),
            outputs={"pred_boxes": 0, "pred_logits": 1},
        )
        return path, metadata

    def test_explicit_cuda_device_is_accepted(self, tensorrt_pte: tuple[Path, ExportMetadata]) -> None:
        """Asking for ``device="cuda"`` loads the TensorRT program and reports the CUDA policy."""
        path, metadata = tensorrt_pte

        runtime = load_runtime(path, metadata, device="cuda")

        assert runtime.info["device"] == "cuda"

    def test_foreign_module_not_found_is_reraised(
        self, monkeypatch: pytest.MonkeyPatch, tensorrt_pte: tuple[Path, ExportMetadata]
    ) -> None:
        """A delegate package that is installed but fails to import a dependency raises its own error, not the hint."""
        path, metadata = tensorrt_pte
        monkeypatch.delitem(sys.modules, "torch_tensorrt_executorch_runtime")
        real_import = builtins.__import__

        def import_with_broken_delegate(name: str, *args: Any, **kwargs: Any) -> Any:
            if name == "torch_tensorrt_executorch_runtime":
                raise ModuleNotFoundError("No module named 'tensorrt'", name="tensorrt")
            return real_import(name, *args, **kwargs)

        monkeypatch.setattr(builtins, "__import__", import_with_broken_delegate)

        with pytest.raises(ModuleNotFoundError, match="No module named 'tensorrt'"):
            load_runtime(path, metadata)

    def test_sidecar_round_trip_selects_the_tensorrt_policy(self, tensorrt_pte: tuple[Path, ExportMetadata]) -> None:
        """Export metadata for a TensorRT ``.pte`` is written to the sidecar and selects the CUDA policy on load."""
        path, _ = tensorrt_pte
        exported = metadata_from_model(
            _make_rfdetr(), format="executorch", shape=(8, 8), batch_size=1, dynamic_batch=False, backend="tensorrt"
        )

        sidecar = write_metadata(path, exported)
        context = load_exported_context(path, device="auto", metadata=None)

        assert sidecar is not None
        assert read_metadata(path).backend == "tensorrt"
        assert context.runtime_info["device"] == "cuda"
