# ------------------------------------------------------------------------
# RF-DETR
# Copyright (c) 2025 Roboflow. All Rights Reserved.
# Licensed under the Apache License, Version 2.0 [see LICENSE for details]
# ------------------------------------------------------------------------
"""Comprehensive unit tests for RFDETRModelModule (LightningModule wrapper)."""

import logging
import math
import pickle
import random
import warnings
from contextlib import nullcontext
from pathlib import Path
from types import SimpleNamespace
from typing import Any
from unittest.mock import MagicMock, PropertyMock, patch

import pytest
import torch
from pytorch_lightning import Callback, Trainer
from pytorch_lightning.core.optimizer import LightningOptimizer
from torch import nn

from rfdetr.config import RFDETRBaseConfig, RFDETRNanoConfig, RFDETRSmallConfig, TrainConfig
from rfdetr.models.criterion import SetCriterion
from rfdetr.models.lwdetr import build_criterion_from_config, build_model_from_config
from rfdetr.models.matcher import HungarianMatcher
from rfdetr.models.weights import apply_lora, load_pretrain_weights
from rfdetr.training.callbacks.best_model import RFDETREarlyStopping
from rfdetr.training.cuda_graph_step import CudaGraphTrainingRunner
from rfdetr.training.module_data import RFDETRDataModule
from rfdetr.training.module_model import RFDETRModelModule
from rfdetr.utilities.box_ops import pairwise_box_l1_cost
from rfdetr.utilities.imports import _IS_PYTORCH_OPTIMIZER_INSTALLED
from rfdetr.utilities.tensors import NestedTensor
from tests._markers import _requires_cuda
from tests.training.helpers import _fake_postprocess as _helpers_fake_postprocess
from tests.training.helpers import _FakeCriterion, _FakeDataset, _make_param_dicts, _TinyModel

_requires_pytorch_optimizer = pytest.mark.skipif(
    not _IS_PYTORCH_OPTIMIZER_INSTALLED, reason="pytorch_optimizer not installed"
)

# Private helpers shared by module-level fixtures and class-level _setup_* methods (which cannot inject fixtures);
# define one only when it has more than one call site.


def _base_model_config(**overrides):
    """Return a minimal RFDETRBaseConfig with pretrain_weights disabled.

    Examples:
        >>> config = _base_model_config(num_classes=7)
        >>> config.device, config.num_classes, config.pretrain_weights
        ('cpu', 7, None)
    """
    defaults = dict(pretrain_weights=None, device="cpu", num_classes=5)
    defaults.update(overrides)
    return RFDETRBaseConfig(**defaults)


def _base_train_config(tmp_path=None, **overrides):
    """Return a minimal TrainConfig suitable for unit tests.

    Examples:
        >>> config = _base_train_config(batch_size=4)
        >>> config.batch_size, config.dataset_dir.endswith("dataset"), config.output_dir.endswith("output")
        (4, True, True)
    """
    dataset_dir = str(tmp_path / "dataset") if tmp_path else "/nonexistent/dataset"
    output_dir = str(tmp_path / "output") if tmp_path else "/nonexistent/output"
    defaults = dict(
        dataset_dir=dataset_dir,
        output_dir=output_dir,
        epochs=10,
        lr=1e-4,
        lr_encoder=1.5e-4,
        batch_size=2,
        weight_decay=1e-4,
        warmup_epochs=1.0,
        drop_path=0.0,
        multi_scale=False,
        expanded_scales=False,
        grad_accum_steps=1,
        tensorboard=False,
    )
    defaults.update(overrides)
    return TrainConfig(**defaults)


def _fake_model():
    """Return a MagicMock that behaves enough like an LWDETR model.

    Examples:
        >>> model = _fake_model()
        >>> isinstance(next(model.parameters()), nn.Parameter)
        True
    """
    model = MagicMock(spec=nn.Module)
    real_param = nn.Parameter(torch.randn(4, 4))
    model.parameters.return_value = iter([real_param])
    model.named_parameters.return_value = iter([("weight", real_param)])
    model.update_drop_path = MagicMock()
    model.update_dropout = MagicMock()
    model.reinitialize_detection_head = MagicMock()
    return model


def _fake_criterion():
    """Return a MagicMock criterion with a realistic weight_dict.

    Examples:
        >>> criterion = _fake_criterion()
        >>> sorted(criterion.weight_dict)
        ['loss_bbox', 'loss_ce', 'loss_giou']
    """
    criterion = MagicMock()
    criterion.weight_dict = {"loss_ce": 1.0, "loss_bbox": 5.0, "loss_giou": 2.0}
    criterion.num_boxes_for_targets.return_value = torch.tensor(1.0)
    return criterion


def _fake_postprocess():
    """Return a callable MagicMock for postprocess.

    Examples:
        >>> import torch
        >>> postprocess = _fake_postprocess()
        >>> sorted(postprocess({}, torch.zeros(1, 2))[0])
        ['boxes', 'labels', 'scores']
    """
    return MagicMock(return_value=[{"boxes": torch.zeros(1, 4), "scores": torch.ones(1), "labels": torch.zeros(1)}])


class _RecordingOptimizer(torch.optim.Optimizer):
    """Optimizer test double that records constructor defaults and kwargs."""

    def __init__(self, params, lr=1e-3, weight_decay=0.0, **kwargs):
        self.extra_kwargs = dict(kwargs)
        super().__init__(params, {"lr": lr, "weight_decay": weight_decay, **kwargs})

    def step(self, closure=None):
        """Run an optimizer step for the test double."""
        if closure is not None:
            return closure()
        return None


class _NoWeightDecayOptimizer(torch.optim.Optimizer):
    """Optimizer test double whose constructor does not accept ``weight_decay``."""

    def __init__(self, params, lr=1e-3, momentum=0.0):
        super().__init__(params, {"lr": lr, "momentum": momentum})

    def step(self, closure=None):
        """Run an optimizer step for the test double."""
        if closure is not None:
            return closure()
        return None


class _RaisingOptimizer:
    """Optimizer test double that always fails to construct."""

    def __init__(self, *args, **kwargs):
        raise TypeError("simulated optimizer construction failure")


class _StepHookOptimizer:
    """Optimizer double that fires ``on_before_optimizer_step`` from ``step()``, like ``LightningOptimizer``.

    Real ``LightningOptimizer.step()`` routes through ``Precision.optimizer_step``, which invokes the
    ``on_before_optimizer_step`` hook before running the wrapped optimizer's own ``step()``. This double reproduces just
    that ordering so tests can exercise the module's hook wiring without standing up the full Lightning
    precision/strategy stack.
    """

    def __init__(self, module, optimizer):
        self._module = module
        self._optimizer = optimizer

    @property
    def param_groups(self):
        """Proxy the wrapped optimizer's parameter groups."""
        return self._optimizer.param_groups

    def step(self, *args, **kwargs):
        """Fire the before-step hook, then delegate to the wrapped optimizer's ``step()``."""
        self._module.on_before_optimizer_step(self)
        self._optimizer.step(*args, **kwargs)

    def zero_grad(self, *args, **kwargs):
        """Delegate to the wrapped optimizer's ``zero_grad()``."""
        self._optimizer.zero_grad(*args, **kwargs)


def _build_module(model_config=None, train_config=None, tmp_path=None):
    """Construct RFDETRModelModule with build_model_from_config and build_criterion_from_config mocked.

    Examples:
        >>> module, model, criterion, postprocess = _build_module()
        >>> module.model is model and module.criterion is criterion and module.postprocess is postprocess
        True
    """
    mc = model_config or _base_model_config()
    tc = train_config or _base_train_config(tmp_path)
    fake_model = _fake_model()
    fake_criterion = _fake_criterion()
    fake_postprocess = _fake_postprocess()
    with (
        patch("rfdetr.training.module_model.build_model_from_config", return_value=fake_model),
        patch(
            "rfdetr.training.module_model.build_criterion_from_config",
            return_value=(fake_criterion, fake_postprocess),
        ),
    ):
        from rfdetr.training.module_model import RFDETRModelModule

        module = RFDETRModelModule(mc, tc)
    return module, fake_model, fake_criterion, fake_postprocess


def test_keypoint_training_resets_gaussian_parameters_after_pretrained_load(tmp_path, mocker) -> None:
    """Keypoint finetuning should reset pretrained Gaussian precision rows after loading weights."""
    mc = _base_model_config(
        pretrain_weights="/fake/keypoint.pth",
        use_grouppose_keypoints=True,
        num_keypoints_per_class=[17],
    )
    tc = _base_train_config(tmp_path)
    fake_model = _fake_model()
    fake_model.reset_keypoint_gaussian_parameters = MagicMock()
    events: list[str] = []

    mocker.patch("rfdetr.training.module_model.build_model_from_config", return_value=fake_model)
    mock_load_pretrain_weights = mocker.patch("rfdetr.training.module_model.load_pretrain_weights")
    mocker.patch(
        "rfdetr.training.module_model.build_criterion_from_config",
        return_value=(_fake_criterion(), _fake_postprocess()),
    )
    mock_load_pretrain_weights.side_effect = lambda *_args, **_kwargs: events.append("load")
    fake_model.reset_keypoint_gaussian_parameters.side_effect = lambda: events.append("reset")

    from rfdetr.training.module_model import RFDETRModelModule

    RFDETRModelModule(mc, tc)

    mock_load_pretrain_weights.assert_called_once_with(fake_model, mc)
    fake_model.reset_keypoint_gaussian_parameters.assert_called_once_with()
    assert events == ["load", "reset"]


def _make_batch(batch_size=2, channels=3, h=16, w=16):
    """Build a (NestedTensor, targets) tuple for testing.

    Examples:
        >>> samples, targets = _make_batch(batch_size=2, h=8, w=8)
        >>> samples.tensors.shape, len(targets)
        (torch.Size([2, 3, 8, 8]), 2)
    """
    tensors = torch.randn(batch_size, channels, h, w)
    mask = torch.zeros(batch_size, h, w, dtype=torch.bool)
    samples = NestedTensor(tensors, mask)
    targets = [
        {
            "boxes": torch.tensor([[0.5, 0.5, 0.1, 0.1]]),
            "labels": torch.tensor([1]),
            "image_id": torch.tensor(i),
            "orig_size": torch.tensor([h, w]),
        }
        for i in range(batch_size)
    ]
    return samples, targets


def _attach_trainer(module, **attributes):
    """Attach a MagicMock trainer carrying ``attributes`` to ``module`` and return it.

    Examples:
        >>> module, *_ = _build_module()
        >>> trainer = _attach_trainer(module, global_step=3)
        >>> module.trainer is trainer, trainer.global_step
        (True, 3)
    """
    trainer = MagicMock()
    for name, value in attributes.items():
        setattr(trainer, name, value)
    module._trainer = trainer
    type(module).trainer = property(lambda self: self._trainer)
    return trainer


class TestMultiScaleBatchStart:
    """on_train_batch_start multi-scale resize picks a step-deterministic scale without clobbering global RNG."""

    def _build_multi_scale_module(self, tmp_path, global_step):
        """Return a module configured for multi-scale with a stubbed trainer at the given global step."""
        tc = _base_train_config(tmp_path, multi_scale="per-batch")
        module, *_ = _build_module(train_config=tc, tmp_path=tmp_path)
        module.trainer = SimpleNamespace(global_step=global_step)
        return module

    def test_scale_choice_is_deterministic_per_step(self, tmp_path):
        """The same global step must resize the batch to the same scale regardless of batch contents."""
        module = self._build_multi_scale_module(tmp_path, global_step=7)

        batch_a = _make_batch(h=64, w=64)
        module.on_train_batch_start(batch_a, 0)
        size_a = tuple(batch_a[0].tensors.shape[-2:])

        batch_b = _make_batch(h=64, w=64)
        module.on_train_batch_start(batch_b, 0)
        size_b = tuple(batch_b[0].tensors.shape[-2:])

        assert size_a == size_b

    def test_does_not_perturb_global_rng(self, tmp_path):
        """Scale selection must use a step-local generator and leave the process-global RNG untouched."""
        module = self._build_multi_scale_module(tmp_path, global_step=3)

        random.seed(42)
        expected = [random.random() for _ in range(3)]

        random.seed(42)
        module.on_train_batch_start(_make_batch(h=64, w=64), 0)
        actual = [random.random() for _ in range(3)]

        assert actual == expected


class _ScalarLossModel(nn.Module):
    """Tiny model exposing one scalar parameter for gradient-scaling tests."""

    def __init__(self) -> None:
        super().__init__()
        self.value = nn.Parameter(torch.zeros(()))

    def forward(self, samples, targets=None):
        return {"loss_scale": self.value}


class _DynamicShapeModel(nn.Module):
    """Tiny model whose loss path depends on the multi-scale batch tensor."""

    def __init__(self) -> None:
        super().__init__()
        self.weight = nn.Parameter(torch.ones(()))

    def forward(self, samples, targets=None):
        return {"dummy": samples.tensors.mean() * self.weight}

    def update_drop_path(self, *args, **kwargs) -> None:
        pass

    def update_dropout(self, *args, **kwargs) -> None:
        pass

    def reinitialize_detection_head(self, *args, **kwargs) -> None:
        pass


class _BoxNormalizedCriterion:
    """Criterion with controllable per-target loss numerators and box counts."""

    weight_dict = {"loss_ce": 1.0}
    supports_loss_normalizer_override: bool = True

    def num_boxes_for_targets(self, outputs, targets):
        return torch.as_tensor(
            sum(int(target["labels"].numel()) for target in targets),
            dtype=torch.float32,
            device=outputs["loss_scale"].device,
        ).clamp(min=1.0)

    def __call__(self, outputs, targets, num_boxes=None):
        denominator = self.num_boxes_for_targets(outputs, targets) if num_boxes is None else num_boxes
        numerator = outputs["loss_scale"] * sum(target["loss_numerator"] for target in targets)
        return {"loss_ce": numerator / denominator}


# Fixtures: prefer these over the private helpers in test methods; class-level _setup_* helpers call the helpers.


@pytest.fixture
def build_module(tmp_path):
    """Factory fixture — returns (module, fake_model, fake_criterion, fake_postprocess).

    build_model and build_criterion_and_postprocessors are mocked automatically. tmp_path is injected automatically so
    test methods do not need to declare it.
    """
    return lambda model_config=None, train_config=None: _build_module(model_config, train_config, tmp_path)


@pytest.fixture
def make_batch():
    """Factory fixture — call with optional batch_size/channels/h/w."""
    return _make_batch


#: Skip a test node that replays Inductor CUDA graph trees.
_requires_cudagraph_trees = pytest.mark.skipif(
    not torch.cuda.is_available() or not hasattr(torch.compiler, "cudagraph_mark_step_begin"),
    reason="combined cudagraph regression requires CUDA graph-tree support",
)


class TestInit:
    """Tests for RFDETRModelModule.__init__.

    Covers attribute assignment and delegation to build_model() / build_criterion_and_postprocessors() when
    pretrain_weights is None.
    """

    @pytest.mark.parametrize(
        "model_config,expected_manual",
        [
            pytest.param(_base_model_config(use_grouppose_keypoints=False), False, id="detection"),
            pytest.param(_base_model_config(segmentation_head=True), False, id="segmentation"),
            pytest.param(
                _base_model_config(use_grouppose_keypoints=True, num_keypoints_per_class=[17]),
                True,
                id="keypoints",
            ),
        ],
    )
    def test_optimization_mode_per_model_type(self, build_module, model_config, expected_manual):
        """Only keypoint models need manual optimization for box-normalized accumulation.

        Detection and segmentation keep Lightning's automatic optimization path.
        """
        module, _, _, _ = build_module(model_config=model_config)

        assert module._use_manual_optimization is expected_manual
        assert module.automatic_optimization is (not expected_manual)

    @pytest.mark.parametrize(
        "attribute, built_index",
        [("model", 1), ("criterion", 2), ("postprocess", 3)],
    )
    def test_built_component_is_assigned(self, build_module, attribute, built_index):
        """__init__ assigns the built model, criterion and postprocessor to module.model/.criterion/.postprocess."""
        built = build_module()
        assert getattr(built[0], attribute) is built[built_index]

    def test_stores_configs(self, base_model_config, base_train_config, build_module):
        """Both model and train configs must be stored for later access."""
        mc = base_model_config()
        tc = base_train_config()
        module, _, _, _ = build_module(model_config=mc, train_config=tc)
        assert module.model_config is mc
        assert module.train_config is tc

    def test_compile_runs_when_multi_scale_enabled(self, mocker, tmp_path):
        """torch.compile still runs with multi_scale=True, which is the shipped default.

        ``dynamic=True`` is passed precisely so one graph covers every (H, W) the multi-scale pipeline produces, so
        multi-scale is not a reason to skip compilation on CUDA.
        """
        mc = _base_model_config(compile=True)
        tc = _base_train_config(tmp_path, multi_scale=True)
        mocker.patch("rfdetr.config.DEVICE", "cuda")
        mock_compile = mocker.patch("rfdetr.training.module_model.torch.compile", side_effect=lambda m, **_: m)
        _, _, criterion, _ = _build_module(model_config=mc, train_config=tc, tmp_path=tmp_path)
        mock_compile.assert_called_once()
        assert mock_compile.call_args.kwargs["dynamic"] is True
        criterion.enable_compiled_detection_losses.assert_not_called()

    def test_compile_does_not_enable_global_error_suppression(self, mocker, tmp_path: Path) -> None:
        """RF-DETR must not hide compiler failures or change unrelated models' fallback policy."""
        mocker.patch("rfdetr.config.DEVICE", "cuda")
        mocker.patch("rfdetr.training.module_model.torch.compile", side_effect=lambda model, **_: model)
        with torch._dynamo.config.patch(suppress_errors=False):
            _build_module(model_config=_base_model_config(compile=True), tmp_path=tmp_path)
            assert torch._dynamo.config.suppress_errors is False

    @pytest.mark.gpu
    @_requires_cuda
    def test_compiled_multi_scale_forward_backward_across_resolutions(self, tmp_path):
        """The real compiled CUDA module must backpropagate finite losses at two resized multi-scale resolutions."""
        torch.manual_seed(0)
        model_config = _base_model_config(compile=True, resolution=128)
        train_config = _base_train_config(tmp_path, multi_scale=True)
        model = _DynamicShapeModel().cuda()
        criterion = _FakeCriterion()

        with (
            patch("rfdetr.config.DEVICE", "cuda"),
            patch("rfdetr.training.module_model.build_model_from_config", return_value=model),
            patch(
                "rfdetr.training.module_model.build_criterion_from_config",
                return_value=(criterion, _fake_postprocess()),
            ),
        ):
            module = RFDETRModelModule(model_config, train_config)

        resized_shapes = set()
        for global_step in (0, 1):
            module.trainer = SimpleNamespace(global_step=global_step)
            samples, targets = _make_batch(h=128, w=128)
            samples.tensors = samples.tensors.cuda()
            samples.mask = samples.mask.cuda()

            module.on_train_batch_start((samples, targets), batch_idx=global_step)
            resized_shapes.add(tuple(samples.tensors.shape[-2:]))
            loss = criterion(module.model(samples, targets), targets)["loss_ce"]
            loss.backward()

            assert torch.isfinite(loss)
            assert model.weight.grad is not None
            assert torch.isfinite(model.weight.grad)
            model.zero_grad(set_to_none=True)

        assert len(resized_shapes) == 2

    @pytest.mark.gpu
    @_requires_cuda
    def test_static_compile_runs_compiled_batched_losses_through_training_step(self, tmp_path: Path) -> None:
        """A real RF-DETR Nano training step statically compiles the model and reaches the compiled loss graph.

        The shipped builders create the detector, the criterion (``group_detr=13``) and the matcher. Only the whole-
        model ``torch.compile`` is replaced by a recorder, because compiling the detector takes minutes; the loss graph
        is compiled for real, and the step's loss matches the per-layer path on the same weights.
        """
        torch.manual_seed(0)
        real_compile = torch.compile
        model_config = RFDETRNanoConfig(num_classes=5, pretrain_weights=None, compile=True, device="cuda")
        train_config = _base_train_config(tmp_path, multi_scale=False)

        with (
            patch("rfdetr.config.DEVICE", "cuda"),
            patch(
                "rfdetr.training.module_model.torch.compile",
                side_effect=lambda target, **kwargs: (
                    target if isinstance(target, nn.Module) else real_compile(target, **kwargs)
                ),
            ) as compiler,
        ):
            module = RFDETRModelModule(model_config, train_config).cuda().train()

        model_compiles = [call for call in compiler.call_args_list if isinstance(call.args[0], nn.Module)]
        assert len(model_compiles) == 1
        assert model_compiles[0].kwargs["dynamic"] is False
        criterion = module.criterion
        assert type(criterion) is SetCriterion
        assert criterion._compile_batched_detection_losses is True

        resolution = model_config.resolution
        samples, _ = _make_batch(batch_size=2, h=resolution, w=resolution)
        samples.tensors = samples.tensors.cuda()
        samples.mask = samples.mask.cuda()
        targets = [
            {
                "boxes": torch.tensor([[0.5, 0.5, 0.2, 0.2], [0.3, 0.6, 0.1, 0.2]][:count], device="cuda"),
                "labels": torch.tensor([1, 3][:count], device="cuda"),
            }
            for count in (2, 1)
        ]
        module.log = MagicMock()
        module.log_dict = MagicMock()
        trainer = SimpleNamespace(accumulate_grad_batches=1)
        with patch.object(type(module), "trainer", new_callable=PropertyMock, return_value=trainer):
            loss = module.training_step((samples, targets), batch_idx=0)
            loss.backward()
            with patch.object(criterion, "_can_batch_detection_losses", return_value=False):
                fallback_loss = module.training_step((samples, targets), batch_idx=0)

        assert criterion._compiled_batched_detection_losses is not None, "the compiled loss graph never ran"
        assert torch.isfinite(loss)
        gradients = [parameter.grad for parameter in module.model.parameters() if parameter.grad is not None]
        assert gradients
        assert all(torch.isfinite(gradient).all() for gradient in gradients)
        assert torch.allclose(loss.detach(), fallback_loss.detach(), rtol=1e-4, atol=1e-6)

    @pytest.mark.gpu
    @_requires_cudagraph_trees
    def test_compiled_cudagraph_trees_replay_two_optimizer_steps(self, mocker, tmp_path: Path) -> None:
        """Combined compilation and CUDA graph trees must preserve finite gradients across optimizer replays."""
        torch.manual_seed(0)
        model_config = _base_model_config(compile=True, cuda_graphs=True, resolution=128)
        train_config = _base_train_config(tmp_path, multi_scale=False)
        model = _DynamicShapeModel().cuda().train()
        criterion = _FakeCriterion()

        with (
            patch("rfdetr.config.DEVICE", "cuda"),
            patch("rfdetr.training.module_model.build_model_from_config", return_value=model),
            patch(
                "rfdetr.training.module_model.build_criterion_from_config",
                return_value=(criterion, _fake_postprocess()),
            ),
        ):
            module = RFDETRModelModule(model_config, train_config)

        assert module._inductor_cudagraphs is True
        optimizer = torch.optim.SGD(module.model.parameters(), lr=1e-3)
        trainer = SimpleNamespace(accumulate_grad_batches=1)
        module.log = MagicMock()
        module.log_dict = MagicMock()
        mocker.patch.object(type(module), "trainer", new_callable=PropertyMock, return_value=trainer)
        for step in range(2):
            samples, targets = _make_batch(h=128, w=128)
            samples.tensors = samples.tensors.cuda()
            samples.mask = samples.mask.cuda()
            loss = module.training_step((samples, targets), batch_idx=step)
            loss.backward()

            assert torch.isfinite(loss)
            assert model.weight.grad is not None
            assert torch.isfinite(model.weight.grad).all()
            optimizer.step()
            optimizer.zero_grad(set_to_none=True)

    @pytest.mark.parametrize("accelerator", ["xla", "tpu"])
    def test_compile_disabled_on_xla_accelerator_even_with_static_shapes(self, mocker, accelerator, tmp_path):
        """XLA/TPU never compiles, and that no longer depends on multi_scale being set.

        This is the invariant the removed ``not multi_scale`` clause was documented as protecting; the accelerator check
        is what actually enforces it.
        """
        mocker.patch("rfdetr.config.DEVICE", "cuda")
        mock_compile = mocker.patch("rfdetr.training.module_model.torch.compile")
        mc = _base_model_config(compile=True)
        tc = _base_train_config(tmp_path, multi_scale=False, accelerator=accelerator)
        _build_module(model_config=mc, train_config=tc, tmp_path=tmp_path)
        mock_compile.assert_not_called()

    def test_compile_disabled_when_device_is_not_cuda(self, mocker, tmp_path, caplog, monkeypatch):
        """A non-CUDA accelerator disables compilation regardless of multi_scale, with an explanatory notice.

        A caller who sets ``compile=True`` on CPU/XLA/TPU must still learn why nothing was compiled, the same way the
        old multi_scale-only notice used to inform CUDA callers.
        """
        mc = _base_model_config(compile=True)
        tc = _base_train_config(tmp_path, multi_scale=True)
        # get_logger() sets propagate=False on the "rf-detr" logger, so caplog's root-level
        # handler only sees its records while propagation is re-enabled.
        monkeypatch.setattr(logging.getLogger("rf-detr"), "propagate", True)
        mocker.patch("rfdetr.config.DEVICE", "cpu")
        mock_compile = mocker.patch("rfdetr.training.module_model.torch.compile")
        with caplog.at_level(logging.INFO, logger="rf-detr"):
            _build_module(model_config=mc, train_config=tc, tmp_path=tmp_path)
        mock_compile.assert_not_called()
        assert any("Disabling torch.compile" in record.getMessage() for record in caplog.records)

    def test_compile_runs_when_enabled_and_static_shapes(self, mocker, tmp_path):
        """torch.compile runs when compile=True and multi_scale=False on CUDA."""
        mc = _base_model_config(compile=True)
        tc = _base_train_config(tmp_path, multi_scale=False)
        mocker.patch("rfdetr.config.DEVICE", "cuda")
        mock_compile = mocker.patch("rfdetr.training.module_model.torch.compile", side_effect=lambda m, **_: m)
        _, _, criterion, _ = _build_module(model_config=mc, train_config=tc, tmp_path=tmp_path)
        mock_compile.assert_called_once()
        assert mock_compile.call_args.kwargs["dynamic"] is False
        criterion.enable_compiled_detection_losses.assert_called_once_with()

    @pytest.mark.parametrize(
        ("model_overrides", "train_overrides"),
        [
            pytest.param({}, {"square_resize_div_64": False}, id="aspect-ratio-resize"),
            pytest.param(
                {},
                {"aug_config": {"RandomCrop": {"height": 320, "width": 320, "p": 0.5}}},
                id="custom-shape-changing-augmentation",
            ),
            pytest.param({"cuda_graphs": True}, {}, id="inductor-cuda-graphs"),
            pytest.param({"segmentation_head": True}, {}, id="segmentation"),
            pytest.param({"use_grouppose_keypoints": True}, {}, id="keypoints"),
        ],
    )
    def test_compile_keeps_dynamic_shapes_when_batch_shape_can_vary(
        self, mocker, model_overrides: dict[str, Any], train_overrides: dict[str, Any], tmp_path: Path
    ) -> None:
        """A fixed ``multi_scale=False`` run still keeps the dynamic recipe outside the measured detection route.

        Aspect-preserving resize pads each batch to its own per-axis maximum, and custom augmentations may change image
        shape after resize; static graphs would recompile when those batch shapes vary. Inductor CUDA graph trees keep
        their established recipe, and segmentation and keypoint models were not measured. None of these routes enables
        the batched loss graph.
        """
        mc = _base_model_config(compile=True, **model_overrides)
        tc = _base_train_config(tmp_path, multi_scale=False, **train_overrides)
        mocker.patch("rfdetr.config.DEVICE", "cuda")
        mocker.patch("torch._inductor.config", SimpleNamespace(triton=SimpleNamespace()))
        mock_compile = mocker.patch("rfdetr.training.module_model.torch.compile", side_effect=lambda m, **_: m)
        _, _, criterion, _ = _build_module(model_config=mc, train_config=tc, tmp_path=tmp_path)
        mock_compile.assert_called_once()
        assert mock_compile.call_args.kwargs["dynamic"] is True
        criterion.enable_compiled_detection_losses.assert_not_called()

    def test_compile_tolerates_criterion_without_matcher(self, mocker, tmp_path: Path) -> None:
        """A criterion that exposes no ``matcher`` attribute must not break compiled construction.

        ``_FakeCriterion`` is what the GPU compile regressions inject; reading ``self.criterion.matcher`` unguarded
        raised ``AttributeError`` there before the ``getattr`` probe.
        """
        mocker.patch("rfdetr.config.DEVICE", "cuda")
        mocker.patch("rfdetr.training.module_model.build_model_from_config", return_value=_fake_model())
        mocker.patch(
            "rfdetr.training.module_model.build_criterion_from_config",
            return_value=(_FakeCriterion(), _fake_postprocess()),
        )
        compiler = mocker.patch("rfdetr.training.module_model.torch.compile", side_effect=lambda m, **_: m)
        module = RFDETRModelModule(_base_model_config(compile=True), _base_train_config(tmp_path))

        assert module._compile_active is True
        compiler.assert_called_once()

    @pytest.mark.parametrize("compile_enabled", [False, True])
    def test_matcher_l1_compilation_follows_model_flag(self, tmp_path: Path, compile_enabled: bool) -> None:
        """Compile only the real matcher's tensor cost, without changing other matcher instances."""
        matcher = HungarianMatcher()
        criterion = SetCriterion(
            num_classes=5,
            matcher=matcher,
            weight_dict={"loss_ce": 1.0, "loss_bbox": 5.0, "loss_giou": 2.0},
            focal_alpha=0.25,
            losses=["labels", "boxes", "cardinality"],
        )
        model = _fake_model()
        with (
            patch("rfdetr.config.DEVICE", "cuda"),
            patch("torch._inductor.config", SimpleNamespace(triton=SimpleNamespace(coalesce_tiling_analysis=True))),
            patch("rfdetr.training.module_model.build_model_from_config", return_value=model),
            patch(
                "rfdetr.training.module_model.build_criterion_from_config",
                return_value=(criterion, _fake_postprocess()),
            ),
            patch.object(HungarianMatcher, "enable_compiled_l1_cost", autospec=True) as enabler,
            patch("rfdetr.training.module_model.torch.compile", side_effect=lambda value, **_: value) as compiler,
        ):
            module = RFDETRModelModule(
                _base_model_config(compile=compile_enabled, cuda_graphs=True), _base_train_config(tmp_path)
            )

        assert module.criterion.matcher is matcher
        assert type(matcher).forward is HungarianMatcher.forward
        if not compile_enabled:
            enabler.assert_not_called()
            compiler.assert_not_called()
            return
        # Construction compiles only the model; the matcher's cost compiles lazily on its first use, from the
        # same Inductor options the model got (the matcher itself forces CUDA graph replay off on top of them).
        compiler.assert_called_once()
        assert compiler.call_args.args == (model,)
        model_options = compiler.call_args.kwargs["options"]
        assert model_options == {"triton.coalesce_tiling_analysis": False, "triton.cudagraphs": True}
        enabler.assert_called_once_with(matcher, model_options)

    def test_compiled_matcher_stays_picklable_for_spawn_launchers(self, tmp_path: Path) -> None:
        """The module's matcher pickles before and after its compiled cost is built in this process.

        ``ddp_spawn``/``ddp_notebook`` pickle the trainer -- criterion and matcher included -- into every worker. The
        ``torch.compile`` double returns a local closure, which ``pickle`` rejects (negative control below), so this
        passes only when the matcher stores the compile request and builds the callable lazily per process.
        """

        def unpicklable_compile(fn, **_):
            def compiled(*args):
                return fn(*args)

            return compiled

        with pytest.raises((pickle.PicklingError, AttributeError)):
            pickle.dumps(unpicklable_compile(pairwise_box_l1_cost))

        matcher = HungarianMatcher()
        criterion = SetCriterion(
            num_classes=5,
            matcher=matcher,
            weight_dict={"loss_ce": 1.0, "loss_bbox": 5.0, "loss_giou": 2.0},
            focal_alpha=0.25,
            losses=["labels", "boxes", "cardinality"],
        )
        # The double is live during construction too: an eager compile in __init__ would already leave the
        # unpicklable closure on the matcher and fail the first pickle below.
        with (
            patch("rfdetr.config.DEVICE", "cuda"),
            patch("rfdetr.training.module_model.build_model_from_config", return_value=_fake_model()),
            patch(
                "rfdetr.training.module_model.build_criterion_from_config",
                return_value=(criterion, _fake_postprocess()),
            ),
            patch(
                "rfdetr.training.module_model.torch.compile",
                side_effect=lambda value, **_: unpicklable_compile(value) if value is pairwise_box_l1_cost else value,
            ),
        ):
            module = RFDETRModelModule(_base_model_config(compile=True), _base_train_config(tmp_path))

        torch.manual_seed(0)
        outputs = {"pred_logits": torch.randn(2, 4, 5), "pred_boxes": torch.rand(2, 4, 4) * 0.4 + 0.3}
        targets = [
            {"labels": torch.tensor([1, 3]), "boxes": torch.rand(2, 4) * 0.4 + 0.3},
            {"labels": torch.tensor([0]), "boxes": torch.rand(1, 4) * 0.4 + 0.3},
        ]
        expected = HungarianMatcher()(outputs, targets)

        # Pickled before any use: the spawn launcher's moment.
        spawned_matcher = pickle.loads(pickle.dumps(module.criterion.matcher))
        with patch("rfdetr.training.module_model.torch.compile", side_effect=unpicklable_compile) as compiler:
            actual = module.criterion.matcher(outputs, targets)
            spawned = spawned_matcher(outputs, targets)
        assert compiler.call_count == 2, "each process builds its own compiled callable on first use"
        for (actual_i, actual_j), (expected_i, expected_j) in zip((*actual, *spawned), (*expected, *expected)):
            assert torch.equal(actual_i, expected_i)
            assert torch.equal(actual_j, expected_j)

        # Pickled after use: the compiled callable is a per-process cache, never state.
        pickle.dumps(module.criterion.matcher)

    @pytest.mark.parametrize("knob_supported", [True, False])
    def test_coalesce_tiling_knob_passed_only_when_torch_exposes_it(self, mocker, knob_supported, tmp_path):
        """The Inductor workaround reaches torch.compile only on a torch whose config exposes the knob.

        Older torch versions have no ``triton.coalesce_tiling_analysis``; passing it there raises
        ``RuntimeError("Unexpected optimization option ...")`` from ``_TorchCompileInductorWrapper.apply_options``.
        Compilation must still proceed in both cases, and the matcher's compile request must carry the same knob
        decision as the model's.
        """
        triton_config = SimpleNamespace(coalesce_tiling_analysis=True) if knob_supported else SimpleNamespace()
        mc = _base_model_config(compile=True)
        tc = _base_train_config(tmp_path, multi_scale=False)
        matcher = HungarianMatcher()
        criterion = SetCriterion(
            num_classes=5,
            matcher=matcher,
            weight_dict={"loss_ce": 1.0, "loss_bbox": 5.0, "loss_giou": 2.0},
            focal_alpha=0.25,
            losses=["labels", "boxes", "cardinality"],
        )
        mocker.patch("rfdetr.config.DEVICE", "cuda")
        mocker.patch("torch._inductor.config", SimpleNamespace(triton=triton_config))
        mocker.patch("rfdetr.training.module_model.build_model_from_config", return_value=_fake_model())
        mocker.patch(
            "rfdetr.training.module_model.build_criterion_from_config",
            return_value=(criterion, _fake_postprocess()),
        )
        enabler = mocker.patch.object(HungarianMatcher, "enable_compiled_l1_cost", autospec=True)
        mock_compile = mocker.patch("rfdetr.training.module_model.torch.compile", side_effect=lambda m, **_: m)
        RFDETRModelModule(mc, tc)

        expected = {"triton.coalesce_tiling_analysis": False} if knob_supported else {}
        assert mock_compile.call_args.kwargs["options"] == (expected or None)
        enabler.assert_called_once_with(matcher, expected)

    def test_coalesce_tiling_knob_leaves_process_global_config_untouched(self, mocker, tmp_path):
        """The workaround must not disable coalesce tiling for unrelated compilations in the same process."""
        triton_config = SimpleNamespace(coalesce_tiling_analysis=True)
        mc = _base_model_config(compile=True)
        tc = _base_train_config(tmp_path, multi_scale=False)
        mocker.patch("rfdetr.config.DEVICE", "cuda")
        mocker.patch("torch._inductor.config", SimpleNamespace(triton=triton_config))
        mocker.patch("rfdetr.training.module_model.torch.compile", side_effect=lambda m, **_: m)
        _build_module(model_config=mc, train_config=tc, tmp_path=tmp_path)

        assert triton_config.coalesce_tiling_analysis is True

    def test_cuda_graphs_with_compile_requests_inductor_cudagraphs(self, mocker, tmp_path):
        """``cuda_graphs=True`` together with ``compile=True`` turns on Inductor's CUDA graph trees.

        ``torch.compile(mode="reduce-overhead")`` cannot be used here because ``mode`` and ``options`` are mutually
        exclusive in ``torch.compile``; the equivalent option key is what must reach the compiler alongside the existing
        coalesce-tiling workaround.
        """
        triton_config = SimpleNamespace(coalesce_tiling_analysis=True)
        mc = _base_model_config(compile=True, cuda_graphs=True)
        tc = _base_train_config(tmp_path, multi_scale=False)
        mocker.patch("rfdetr.config.DEVICE", "cuda")
        mocker.patch("torch._inductor.config", SimpleNamespace(triton=triton_config))
        mock_compile = mocker.patch("rfdetr.training.module_model.torch.compile", side_effect=lambda m, **_: m)
        module, _, _, _ = _build_module(model_config=mc, train_config=tc, tmp_path=tmp_path)

        assert mock_compile.call_args.kwargs["options"] == {
            "triton.coalesce_tiling_analysis": False,
            "triton.cudagraphs": True,
        }
        assert module._inductor_cudagraphs is True

    @pytest.mark.parametrize(
        ("model_overrides", "train_overrides"),
        [
            pytest.param({}, {"grad_accum_steps": 2}, id="gradient-accumulation"),
            pytest.param({}, {"devices": 2}, id="multi-device"),
            pytest.param({}, {"num_nodes": 2}, id="multi-node"),
            pytest.param({}, {"amp_dtype": "fp8"}, id="fp8-needs-te-capture"),
            pytest.param({"segmentation_head": True}, {}, id="segmentation"),
            pytest.param({"use_grouppose_keypoints": True, "num_keypoints_per_class": [1]}, {}, id="keypoints"),
            pytest.param({"gradient_checkpointing": True}, {}, id="gradient-checkpointing"),
        ],
    )
    def test_cuda_graphs_with_compile_falls_back_to_plain_compile_outside_validated_scope(
        self, mocker, model_overrides, train_overrides, tmp_path, caplog, monkeypatch
    ):
        """Outside the single-GPU detection scope the combined request degrades to compile-only with a warning.

        Inductor CUDA graph trees allocate gradient outputs inside the graph pool, so a ``.grad`` adopted by the first
        microbatch is overwritten by the next replay — gradient accumulation cannot run on this path. Model modes and
        distributed layouts mirror the limits of the eager graph runner.
        """
        mc = _base_model_config(compile=True, cuda_graphs=True, **model_overrides)
        tc = _base_train_config(tmp_path, multi_scale=False, **train_overrides)
        monkeypatch.setattr(logging.getLogger("rf-detr"), "propagate", True)
        mocker.patch("rfdetr.config.DEVICE", "cuda")
        mocker.patch("torch._inductor.config", SimpleNamespace(triton=SimpleNamespace()))
        mock_compile = mocker.patch("rfdetr.training.module_model.torch.compile", side_effect=lambda m, **_: m)
        with caplog.at_level(logging.WARNING, logger="rf-detr"):
            module, _, _, _ = _build_module(model_config=mc, train_config=tc, tmp_path=tmp_path)

        assert mock_compile.call_args.kwargs["options"] is None
        assert module._inductor_cudagraphs is False
        assert any("compile-only" in record.getMessage() for record in caplog.records)

    def test_compile_disabled_when_train_accelerator_is_cpu(self, mocker, tmp_path):
        """Compile stays disabled when training is explicitly forced to CPU."""
        mocker.patch("rfdetr.config.DEVICE", "cuda")
        _mock_compile = mocker.patch("rfdetr.training.module_model.torch.compile")
        mc = _base_model_config(compile=True)
        tc = _base_train_config(tmp_path, multi_scale=False, accelerator="cpu")
        _build_module(model_config=mc, train_config=tc, tmp_path=tmp_path)
        _mock_compile.assert_not_called()


class TestLoadPretrainWeights:
    """Tests for _load_pretrain_weights().

    Covers checkpoint validation, detection-head reinitialization on class-count mismatch, query-embedding trimming, re-
    download on corruption, and class-name extraction from checkpoint metadata.
    """

    def _make_checkpoint(self, num_classes_in_ckpt=91, num_queries=300, group_detr=13):
        """Build a fake checkpoint dict."""
        total_queries = num_queries * group_detr
        return {
            "model": {
                "class_embed.weight": torch.randn(num_classes_in_ckpt, 256),
                "class_embed.bias": torch.randn(num_classes_in_ckpt),
                "refpoint_embed.weight": torch.randn(total_queries, 4),
                "query_feat.weight": torch.randn(total_queries, 256),
                "other_layer.weight": torch.randn(10, 10),
            }
        }

    def test_loads_valid_checkpoint(self, mocker, base_model_config, build_module):
        """A valid checkpoint must be validated, loaded, and applied to the model."""
        mock_validate = mocker.patch("rfdetr.models.weights.validate_pretrain_weights")
        mock_torch_load = mocker.patch("rfdetr.models.weights.torch.load")
        mc = base_model_config(num_classes=90)
        checkpoint = self._make_checkpoint(num_classes_in_ckpt=91)
        mock_torch_load.return_value = checkpoint

        module, _, _, _ = build_module(model_config=mc)
        module.model_config = module.model_config.model_copy(update={"pretrain_weights": "/fake/weights.pth"})
        load_pretrain_weights(module.model, module.model_config)

        mock_validate.assert_called_once_with("/fake/weights.pth", strict=False)
        module.model.load_state_dict.assert_called_once()

    def test_class_count_mismatch_triggers_reinitialize(self, mocker, base_model_config, build_module):
        """Detection head is expanded to checkpoint size, then trimmed back to config size."""
        mocker.patch("rfdetr.models.weights.validate_pretrain_weights")
        mock_torch_load = mocker.patch("rfdetr.models.weights.torch.load")
        mc = base_model_config(num_classes=5)
        checkpoint = self._make_checkpoint(num_classes_in_ckpt=91)
        mock_torch_load.return_value = checkpoint

        module, fake_model, _, _ = build_module(model_config=mc)
        module.model_config = module.model_config.model_copy(update={"pretrain_weights": "/fake/weights.pth"})
        load_pretrain_weights(module.model, module.model_config)

        # First call: expand to checkpoint size so load_state_dict shapes match.
        # Second call: trim back to configured num_classes + 1 (background class).
        fake_model.reinitialize_detection_head.assert_has_calls([mocker.call(91), mocker.call(6)])
        assert fake_model.reinitialize_detection_head.call_count == 2

    def test_class_count_match_does_not_reinitialize(self, mocker, base_model_config, build_module):
        """Detection head must NOT be reinitialized when class counts match."""
        mocker.patch("rfdetr.models.weights.validate_pretrain_weights")
        mock_torch_load = mocker.patch("rfdetr.models.weights.torch.load")
        mc = base_model_config(num_classes=5)
        checkpoint = self._make_checkpoint(num_classes_in_ckpt=6)
        mock_torch_load.return_value = checkpoint

        module, fake_model, _, _ = build_module(model_config=mc)
        module.model_config = module.model_config.model_copy(update={"pretrain_weights": "/fake/weights.pth"})
        load_pretrain_weights(module.model, module.model_config)

        fake_model.reinitialize_detection_head.assert_not_called()

    def test_query_embedding_trimmed_to_configured_count(self, mocker, base_model_config, build_module):
        """Oversized query embeddings in checkpoint must be trimmed to match config."""
        mocker.patch("rfdetr.models.weights.validate_pretrain_weights")
        mock_torch_load = mocker.patch("rfdetr.models.weights.torch.load")
        mc = base_model_config(num_classes=90)
        module, _, _, _ = build_module(model_config=mc)

        num_queries = getattr(module.model_config, "num_queries", 300)
        group_detr = getattr(module.model_config, "group_detr", 13)
        desired = num_queries * group_detr

        large_total = desired + 500
        checkpoint = {
            "model": {
                "class_embed.weight": torch.randn(91, 256),
                "class_embed.bias": torch.randn(91),
                "refpoint_embed.weight": torch.randn(large_total, 4),
                "query_feat.weight": torch.randn(large_total, 256),
            }
        }
        mock_torch_load.return_value = checkpoint

        module.model_config = module.model_config.model_copy(update={"pretrain_weights": "/fake/weights.pth"})
        load_pretrain_weights(module.model, module.model_config)

        assert checkpoint["model"]["refpoint_embed.weight"].shape[0] == desired
        assert checkpoint["model"]["query_feat.weight"].shape[0] == desired

    def test_load_failure_does_not_redownload_existing_weights(self, mocker, base_model_config, build_module):
        """A checkpoint read failure propagates without replacing the existing file."""
        mocker.patch("rfdetr.models.weights.validate_pretrain_weights")
        mock_download = mocker.patch("rfdetr.models.weights.download_pretrain_weights")
        mocker.patch("rfdetr.models.weights.os.path.isfile", return_value=True)
        mc = base_model_config(num_classes=90)
        module, _, _, _ = build_module(model_config=mc)
        module.model_config = module.model_config.model_copy(update={"pretrain_weights": "/fake/weights.pth"})

        mock_load = mocker.patch("rfdetr.utilities.io._safe_torch_load", side_effect=RuntimeError("corrupted file"))
        with pytest.raises(RuntimeError, match="corrupted file"):
            load_pretrain_weights(module.model, module.model_config)

        mock_download.assert_called_once_with("/fake/weights.pth")
        mock_load.assert_called_once()

    def test_download_before_load_when_weights_absent(self, mocker, base_model_config, build_module):
        """download_pretrain_weights is called before torch.load when weights are absent.

        A fresh environment (e.g. Colab) then downloads weights automatically.

        Regression test: previously download was only called as an except-block fallback, but ModelWeights.from_filename
        received the absolute path and returned None, causing a silent no-op and a FileNotFoundError.
        """
        mock_torch_load = mocker.patch("rfdetr.models.weights.torch.load")
        mocker.patch("rfdetr.models.weights.validate_pretrain_weights")
        mock_download = mocker.patch("rfdetr.models.weights.download_pretrain_weights")
        mocker.patch("rfdetr.models.weights.os.path.isfile", return_value=False)
        mc = base_model_config(num_classes=90)
        checkpoint = self._make_checkpoint(num_classes_in_ckpt=91)
        mock_torch_load.return_value = checkpoint

        module, _, _, _ = build_module(model_config=mc)
        module.model_config = module.model_config.model_copy(update={"pretrain_weights": "/content/rf-detr-base.pth"})
        load_pretrain_weights(module.model, module.model_config)

        # download_pretrain_weights must have been called at least once before any load
        assert mock_download.call_count >= 1
        first_call = mock_download.call_args_list[0]
        assert first_call.args[0] == "/content/rf-detr-base.pth"

    @pytest.mark.parametrize(
        "ckpt_segmentation_head, ckpt_patch_size, module_overrides, expected_match",
        [
            pytest.param(
                True, 12, {"segmentation_head": False}, "segmentation head", id="seg-checkpoint-into-detection-model"
            ),
            pytest.param(
                False, 16, {"segmentation_head": True}, "segmentation head", id="detection-checkpoint-into-seg-model"
            ),
            pytest.param(
                False,
                12,
                {"segmentation_head": False, "patch_size": 16},
                "patch_size",
                id="patch-size-mismatch",
            ),
        ],
    )
    def test_incompatible_checkpoint_raises(
        self,
        mocker,
        base_model_config,
        build_module,
        ckpt_segmentation_head: bool,
        ckpt_patch_size: int,
        module_overrides: dict[str, object],
        expected_match: str,
    ):
        """Loading a checkpoint whose segmentation_head/patch_size mismatch the model must raise ValueError."""
        mocker.patch("rfdetr.models.weights.validate_pretrain_weights")
        mock_torch_load = mocker.patch("rfdetr.models.weights.torch.load")
        mc = base_model_config(num_classes=90)
        ckpt_args = SimpleNamespace(segmentation_head=ckpt_segmentation_head, patch_size=ckpt_patch_size)
        checkpoint = self._make_checkpoint(num_classes_in_ckpt=91)
        checkpoint["args"] = ckpt_args
        mock_torch_load.return_value = checkpoint

        module, _, _, _ = build_module(model_config=mc)
        module.model_config = module.model_config.model_copy(
            update={"pretrain_weights": "/fake/weights.pth", **module_overrides}
        )

        with pytest.raises(ValueError) as exc_info:
            load_pretrain_weights(module.model, module.model_config)
        assert expected_match in str(exc_info.value)

    def test_compatible_checkpoint_does_not_raise(self, mocker, base_model_config, build_module):
        """A checkpoint matching segmentation_head and patch_size must load without error."""
        mocker.patch("rfdetr.models.weights.validate_pretrain_weights")
        mock_torch_load = mocker.patch("rfdetr.models.weights.torch.load")
        mc = base_model_config(num_classes=90)
        ckpt_args = SimpleNamespace(segmentation_head=False, patch_size=14, class_names=[])
        checkpoint = self._make_checkpoint(num_classes_in_ckpt=91)
        checkpoint["args"] = ckpt_args
        mock_torch_load.return_value = checkpoint

        module, _, _, _ = build_module(model_config=mc)
        module.model_config = module.model_config.model_copy(
            update={"pretrain_weights": "/fake/weights.pth", "segmentation_head": False, "patch_size": 14}
        )

        # Should not raise.
        load_pretrain_weights(module.model, module.model_config)


class TestApplyLora:
    """Tests for _apply_lora().

    Verifies that PEFT LoraConfig is constructed with the correct target modules and that the backbone encoder is
    replaced in-place with the wrapped PEFT model.
    """

    def _build_module_with_backbone(self, tmp_path):
        """Build module with a mock backbone that exposes backbone[0].encoder."""
        mc = _base_model_config()
        tc = _base_train_config(tmp_path)

        fake_model = MagicMock()
        fake_encoder = MagicMock()
        fake_backbone_0 = MagicMock()
        fake_backbone_0.encoder = fake_encoder
        fake_model.backbone = MagicMock()
        fake_model.backbone.__getitem__ = MagicMock(return_value=fake_backbone_0)

        with (
            patch("rfdetr.training.module_model.build_model_from_config", return_value=fake_model),
            patch(
                "rfdetr.training.module_model.build_criterion_from_config",
                return_value=(_fake_criterion(), _fake_postprocess()),
            ),
        ):
            from rfdetr.training.module_model import RFDETRModelModule

            module = RFDETRModelModule(mc, tc)

        return module, fake_model, fake_backbone_0, fake_encoder

    def test_calls_lora_config_with_correct_target_modules(self, mocker, tmp_path):
        """LoRA must target the expected attention and token projection modules."""
        mock_lora_cfg_class = mocker.patch("peft.LoraConfig")
        mock_get_peft = mocker.patch("peft.get_peft_model")
        module, _, _, _ = self._build_module_with_backbone(tmp_path)
        mock_get_peft.return_value = MagicMock()

        apply_lora(module.model)

        mock_lora_cfg_class.assert_called_once()
        target_modules = mock_lora_cfg_class.call_args.kwargs.get("target_modules")
        expected = ["q_proj", "v_proj", "k_proj", "qkv", "query", "key", "value", "cls_token", "register_tokens"]
        assert target_modules == expected

    def test_replaces_encoder_with_peft_model(self, mocker, tmp_path):
        """The backbone encoder must be replaced in-place with the PEFT-wrapped model."""
        mocker.patch("peft.LoraConfig")
        mock_get_peft = mocker.patch("peft.get_peft_model")
        module, _, fake_backbone_0, fake_encoder = self._build_module_with_backbone(tmp_path)
        peft_wrapped = MagicMock()
        mock_get_peft.return_value = peft_wrapped

        apply_lora(module.model)

        assert mock_get_peft.call_args[0][0] is fake_encoder
        assert fake_backbone_0.encoder is peft_wrapped


class TestOnFitStart:
    """Tests for on_fit_start() seeding behavior."""

    @pytest.mark.parametrize("rank, expected_seed", [(0, 7), (2, 9)])
    def test_seed_is_offset_by_rank(self, mocker, base_train_config, build_module, rank, expected_seed):
        """seed_everything(seed + global_rank) is called, so each DDP worker seeds uniquely (rank 0 keeps the seed)."""
        mock_seed = mocker.patch("rfdetr.training.module_model.seed_everything")
        tc = base_train_config(seed=7)
        module, _, _, _ = build_module(train_config=tc)

        mocker.patch.object(type(module), "global_rank", new_callable=PropertyMock, return_value=rank)
        module.on_fit_start()

        mock_seed.assert_called_once_with(expected_seed, workers=True)

    def test_seed_skipped_when_none(self, mocker, base_train_config, build_module):
        """No seed means on_fit_start should not call seed_everything."""
        mock_seed = mocker.patch("rfdetr.training.module_model.seed_everything")
        tc = base_train_config(seed=None)
        module, _, _, _ = build_module(train_config=tc)

        module.on_fit_start()

        mock_seed.assert_not_called()


class TestOnTrainBatchStart:
    """Tests for on_train_batch_start().

    Covers multi-scale interpolation of NestedTensor inputs and verifies regularization scheduling is delegated to
    DropPathCallback.
    """

    def _setup_module(
        self,
        tmp_path,
        multi_scale=False,
    ):
        tc = _base_train_config(tmp_path, multi_scale=multi_scale)
        module, fake_model, _, _ = _build_module(train_config=tc)

        _attach_trainer(module, global_step=0)

        return module, fake_model

    @pytest.mark.parametrize("method_name, step", [("update_drop_path", 1), ("update_dropout", 2)])
    def test_regularization_not_applied_in_module_hook(self, method_name, step, tmp_path):
        """Drop-path and dropout scheduling belong to DropPathCallback, not the module hook."""
        module, fake_model = self._setup_module(tmp_path)
        module._trainer.global_step = step

        module.on_train_batch_start(_make_batch(), batch_idx=step)

        getattr(fake_model, method_name).assert_not_called()

    @pytest.mark.parametrize(
        "method_name",
        [
            pytest.param("update_drop_path", id="drop-path"),
            pytest.param("update_dropout", id="dropout"),
        ],
    )
    def test_update_not_called_when_schedule_is_none(self, method_name, tmp_path):
        """Without a schedule, neither update_drop_path nor update_dropout must be called."""
        module, fake_model = self._setup_module(tmp_path)

        module.on_train_batch_start(_make_batch(), batch_idx=0)

        getattr(fake_model, method_name).assert_not_called()

    def test_multi_scale_resize_mutates_nested_tensor(self, tmp_path):
        """Multi-scale training must resize the input tensor to a square resolution."""
        module, _ = self._setup_module(tmp_path, multi_scale="per-batch")
        module._trainer.global_step = 0
        samples, targets = _make_batch(batch_size=2, h=16, w=16)

        module.on_train_batch_start((samples, targets), batch_idx=0)

        new_h, new_w = samples.tensors.shape[2], samples.tensors.shape[3]
        assert new_h == new_w, "Multi-scale should produce square outputs"

    def test_multi_scale_skipped_when_per_sample(self, tmp_path):
        """Per-sample scaling happens in the dataset, so the batch-level resize must be a no-op."""
        module, _ = self._setup_module(tmp_path, multi_scale="per-sample")
        samples, targets = _make_batch(batch_size=2, h=16, w=16)
        original_shape = samples.tensors.shape

        module.on_train_batch_start((samples, targets), batch_idx=0)

        assert samples.tensors.shape == original_shape


class TestTrainingStep:
    """Tests for training_step().

    Covers weighted loss aggregation, per-loss logging under the train/ prefix, prog_bar visibility, scalar tensor
    output, and that losses absent from weight_dict are excluded from the total.
    """

    def _run_step(
        self,
        tmp_path,
        loss_dict=None,
        weight_dict=None,
        accumulate_grad_batches=1,
        model_config=None,
        train_log_on_step=False,
        compact_train_metrics=True,
    ):
        module, fake_model, fake_criterion, _ = _build_module(
            model_config=model_config,
            train_config=_base_train_config(
                tmp_path,
                grad_accum_steps=accumulate_grad_batches,
                train_log_on_step=train_log_on_step,
                compact_train_metrics=compact_train_metrics,
            ),
            tmp_path=tmp_path,
        )
        samples, targets = _make_batch()
        fake_model.return_value = {}
        fake_criterion.return_value = loss_dict or {"loss_ce": torch.tensor(1.0)}
        fake_criterion.weight_dict = weight_dict or {"loss_ce": 1.0}
        module.log = MagicMock()
        module.log_dict = MagicMock()
        # Provide a real optimizer so param_groups carries a real "lr" key.
        real_param = nn.Parameter(torch.randn(4))
        real_optimizer = torch.optim.SGD([real_param], lr=1e-3)
        module.optimizers = MagicMock(return_value=real_optimizer)
        module.manual_backward = MagicMock()
        module.lr_schedulers = MagicMock(return_value=None)
        _attach_trainer(
            module,
            accumulate_grad_batches=1,
            num_training_batches=1,
            gradient_clip_val=0.0,
            gradient_clip_algorithm="norm",
        )
        return module, samples, targets, fake_model, fake_criterion

    def test_returns_weighted_loss_sum(self, tmp_path):
        """Total loss must equal the sum of each loss multiplied by its weight."""
        loss_dict = {"loss_ce": torch.tensor(1.0), "loss_bbox": torch.tensor(2.0), "loss_giou": torch.tensor(3.0)}
        weight_dict = {"loss_ce": 1.0, "loss_bbox": 5.0, "loss_giou": 2.0}
        module, samples, targets, _, _ = self._run_step(tmp_path, loss_dict, weight_dict)

        loss = module.training_step((samples, targets), batch_idx=0)

        assert loss.item() == pytest.approx(1.0 + 10.0 + 6.0)

    def test_automatic_optimization_never_touches_trainer_strategy(self, mocker, tmp_path: Path) -> None:
        """Detection models must not fetch ``self.optimizers()`` — Lightning owns the optimizer on that path.

        ``optimizers()`` dereferences ``trainer.strategy._lightning_optimizers``. Only the keypoint manual-optimization
        branch consumes the result, so a trainer stub that carries nothing but ``accumulate_grad_batches`` must be
        enough for a detection ``training_step``; anything else means the automatic path grew a hidden dependency.
        """
        module, fake_model, fake_criterion, _ = _build_module(tmp_path=tmp_path)
        samples, targets = _make_batch()
        fake_model.return_value = {}
        fake_criterion.return_value = {"loss_ce": torch.tensor(1.0)}
        fake_criterion.weight_dict = {"loss_ce": 1.0}
        module.log = MagicMock()
        module.log_dict = MagicMock()
        trainer = SimpleNamespace(accumulate_grad_batches=1)

        mocker.patch.object(type(module), "trainer", new_callable=PropertyMock, return_value=trainer)
        loss = module.training_step((samples, targets), batch_idx=0)

        assert loss.item() == pytest.approx(1.0)

    def test_routes_forward_through_cuda_graph_runner(self, tmp_path: Path) -> None:
        """Once configured, training_step uses the graph runner while leaving self.model registered."""
        module, samples, targets, fake_model, fake_criterion = self._run_step(tmp_path)
        runner = MagicMock(return_value={})
        module._cuda_graph_runner = runner
        fake_criterion.return_value = {"loss_ce": torch.tensor(1.0)}

        module.training_step((samples, targets), batch_idx=0)

        runner.assert_called_once_with(samples, targets)
        fake_model.assert_not_called()

    @pytest.mark.parametrize("inductor_cudagraphs", [True, False])
    def test_marks_cudagraph_step_only_on_inductor_path(self, mocker, inductor_cudagraphs, tmp_path):
        """Each step on the Inductor CUDA graph path begins with ``cudagraph_mark_step_begin``; other paths never do.

        Lightning keeps the logged loss tensors alive across steps. Without the mark, cudagraph trees raise "accessing
        tensor output of CUDAGraphs that has been overwritten by a subsequent run" on the next replay.
        """
        mark_step = mocker.patch("rfdetr.training.module_model.torch.compiler.cudagraph_mark_step_begin")
        module, samples, targets, _, _ = self._run_step(tmp_path)
        module._inductor_cudagraphs = inductor_cudagraphs

        module.training_step((samples, targets), batch_idx=0)

        assert mark_step.call_count == (1 if inductor_cudagraphs else 0)

    def test_real_model_composes_through_cuda_graph_runner_on_training_step(self, tmp_path: Path) -> None:
        """A real detector, criterion, backward, and optimizer compose through the graph-runner ``training_step()``.

        Neither the synthetic model ``CudaGraphTrainingRunner`` is unit-tested against in isolation nor a fully-mocked
        runner class, as in the test above, covers this.

        ``torch.cuda.make_graphed_callables`` is the one CUDA-only primitive mocked here (as in
        ``test_capture_preserves_accumulated_gradients``); everything else — model, transformer capture toggle,
        criterion, Lightning's training_step, and the optimizer step — runs for real on CPU.
        """
        mc = RFDETRNanoConfig(pretrain_weights=None, num_classes=3, device="cpu")
        tc = _base_train_config(tmp_path)
        real_model = build_model_from_config(mc, tc)
        real_criterion, real_postprocess = build_criterion_from_config(mc, tc)
        real_model.train()

        with (
            patch("rfdetr.training.module_model.build_model_from_config", return_value=real_model),
            patch(
                "rfdetr.training.module_model.build_criterion_from_config",
                return_value=(real_criterion, real_postprocess),
            ),
        ):
            module = RFDETRModelModule(mc, tc)

        module._cuda_graph_runner = CudaGraphTrainingRunner(module.model)
        samples, targets = _make_batch(batch_size=1, h=mc.resolution, w=mc.resolution)
        module.log = MagicMock()
        module.log_dict = MagicMock()
        real_optimizer = torch.optim.SGD(module.model.parameters(), lr=1e-3)
        module.optimizers = MagicMock(return_value=real_optimizer)
        _attach_trainer(module, accumulate_grad_batches=1, num_training_batches=1)

        with patch("torch.cuda.make_graphed_callables", side_effect=lambda inner, _args, **_kwargs: inner):
            loss = module.training_step((samples, targets), batch_idx=0)

        assert torch.isfinite(loss)
        assert all(p.grad is None for p in module.model.parameters())
        loss.backward()
        assert any(p.grad is not None for p in module.model.parameters())
        assert len(module._cuda_graph_runner._graphed_cache) == 1

    def test_loss_backward_uses_box_normalizer_contract(self, tmp_path):
        """Backward loss for keypoint models is scaled by the criterion box normalizer.

        Manual optimization owns accumulation, so Lightning's ``accumulate_grad_batches`` does not scale it.
        """
        loss_dict = {"loss_ce": torch.tensor(4.0)}
        weight_dict = {"loss_ce": 1.0}
        keypoint_config = _base_model_config(use_grouppose_keypoints=True, num_keypoints_per_class=[17])
        module, samples, targets, _, _ = self._run_step(
            tmp_path,
            loss_dict,
            weight_dict,
            accumulate_grad_batches=4,
            model_config=keypoint_config,
        )
        module.criterion.num_boxes_for_targets.return_value = torch.tensor(4.0)

        loss = module.training_step((samples, targets), batch_idx=0)

        assert loss.item() == pytest.approx(1.0)
        backward_loss = module.manual_backward.call_args.args[0]
        assert backward_loss.item() == pytest.approx(1.0)

    @pytest.mark.parametrize(
        "grad_accum_steps,num_training_batches,batch_idx,sync_grad",
        [(2, 2, 0, False), (2, 4, 1, True), (4, 2, 1, True)],
    )
    def test_keypoint_accumulation_syncs_only_when_optimizer_steps(
        self, tmp_path, grad_accum_steps, num_training_batches, batch_idx, sync_grad
    ):
        """Keypoint DDP must skip gradient synchronization until an accumulation window closes."""
        keypoint_config = _base_model_config(use_grouppose_keypoints=True, num_keypoints_per_class=[17])
        module, samples, targets, _, _ = self._run_step(
            tmp_path,
            accumulate_grad_batches=grad_accum_steps,
            model_config=keypoint_config,
        )
        optimizer = MagicMock(spec=LightningOptimizer)
        optimizer.param_groups = [{"lr": 1e-3}]
        optimizer.toggle_model.return_value = nullcontext()
        optimizer.zero_grad = MagicMock()
        module.optimizers.return_value = optimizer
        module._trainer.num_training_batches = num_training_batches

        module.training_step((samples, targets), batch_idx=batch_idx)

        optimizer.toggle_model.assert_called_once_with(sync_grad=sync_grad)
        module.manual_backward.assert_called_once()

    def test_detection_loss_is_returned_unscaled_for_lightning_accumulation(self, tmp_path: Path) -> None:
        """Detection (automatic optimization) returns the weighted loss unscaled.

        Lightning's ``ClosureResult.from_training_step_output`` divides the returned loss by
        ``trainer.accumulate_grad_batches`` before ``backward()``. Dividing here as well would scale every accumulated
        gradient by ``1/N**2`` (``tests/training/test_grad_accumulation.py`` holds the gradient-level proof).
        """
        loss_dict = {"loss_ce": torch.tensor(4.0)}
        weight_dict = {"loss_ce": 1.0}
        module, samples, targets, _, _ = self._run_step(
            tmp_path,
            loss_dict,
            weight_dict,
            accumulate_grad_batches=1,
        )
        module._trainer.accumulate_grad_batches = 4

        loss = module.training_step((samples, targets), batch_idx=0)

        assert loss.item() == pytest.approx(4.0)
        module.manual_backward.assert_not_called()

    def _make_keypoint_module(self, tmp_path, grad_accum_steps, num_training_batches):
        """Build a keypoint module wired with ``_ScalarLossModel`` and ``_BoxNormalizedCriterion`` for accum tests."""
        module, *_ = _build_module(
            model_config=_base_model_config(use_grouppose_keypoints=True, num_keypoints_per_class=[17]),
            train_config=_base_train_config(tmp_path, grad_accum_steps=grad_accum_steps),
            tmp_path=tmp_path,
        )
        model = _ScalarLossModel()
        optimizer = torch.optim.SGD(model.parameters(), lr=1.0)
        module.model = model
        module.criterion = _BoxNormalizedCriterion()
        module.postprocess = MagicMock()
        module.log = MagicMock()
        module.log_dict = MagicMock()
        module.optimizers = MagicMock(return_value=optimizer)
        module.manual_backward = lambda loss: loss.backward()
        module.lr_schedulers = MagicMock(return_value=None)
        _attach_trainer(
            module,
            accumulate_grad_batches=1,
            num_training_batches=num_training_batches,
            gradient_clip_val=0.0,
            gradient_clip_algorithm="norm",
        )
        return module, model

    @pytest.mark.parametrize(
        "grad_accum_steps,box_counts,loss_numerators,expected_value",
        [
            pytest.param(1, (4,), (8.0,), -2.0, id="ga1-single-microbatch"),
            pytest.param(2, (2, 6), (10.0, 6.0), -2.0, id="ga2-balanced"),
            pytest.param(3, (2, 4, 6), (4.0, 8.0, 12.0), -2.0, id="ga3-balanced"),
            pytest.param(4, (1, 1, 1, 1), (2.0, 2.0, 2.0, 2.0), -2.0, id="ga4-uniform"),
            pytest.param(2, (1, 99), (1.0, 99.0), -1.0, id="ga2-skewed-1-vs-99"),
            pytest.param(4, (1, 1, 1, 97), (1.0, 1.0, 1.0, 97.0), -1.0, id="ga4-skewed-1-1-1-97"),
        ],
    )
    def test_box_normalized_accumulation_matches_large_effective_batch(
        self, tmp_path, grad_accum_steps, box_counts, loss_numerators, expected_value
    ):
        """Gradients over ``grad_accum_steps`` microbatches equal one large batch normalized by total boxes.

        This holds regardless of how lopsided the per-microbatch box counts are.
        """
        large_module, large_model = self._make_keypoint_module(tmp_path, grad_accum_steps=1, num_training_batches=1)
        accum_module, accum_model = self._make_keypoint_module(
            tmp_path, grad_accum_steps=grad_accum_steps, num_training_batches=grad_accum_steps
        )

        microbatch_targets = [
            {
                "labels": torch.ones(box_count, dtype=torch.int64),
                "loss_numerator": torch.tensor(loss_numerator),
                "orig_size": torch.tensor([16, 16]),
            }
            for box_count, loss_numerator in zip(box_counts, loss_numerators, strict=True)
        ]
        samples, _ = _make_batch(batch_size=2)

        large_module.training_step((samples, microbatch_targets), batch_idx=0)
        for batch_idx, target in enumerate(microbatch_targets):
            accum_module.training_step((samples, [target]), batch_idx=batch_idx)

        torch.testing.assert_close(accum_model.value, large_model.value)
        assert large_model.value.item() == pytest.approx(expected_value)

    def test_logs_live_train_loss_to_progress_bar(self, tmp_path):
        """Aggregate training loss must be logged every step as a progress-only metric."""
        module, samples, targets, _, _ = self._run_step(tmp_path)

        module.training_step((samples, targets), batch_idx=0)

        progress_loss_calls = [c for c in module.log.call_args_list if c[0][0] == "loss"]
        assert len(progress_loss_calls) == 1
        assert progress_loss_calls[0].kwargs.get("prog_bar") is True
        assert progress_loss_calls[0].kwargs.get("logger") is False
        assert progress_loss_calls[0].kwargs.get("on_step") is True
        assert progress_loss_calls[0].kwargs.get("on_epoch") is False

    @pytest.mark.parametrize(
        ("progress_name", "scale"),
        [("loss", 2.0), ("loss_cls", 1.0)],
    )
    def test_progress_loss_is_epoch_running_mean_weighted_by_batch_size(
        self, tmp_path: Path, progress_name: str, scale: float
    ) -> None:
        """The live progress value is the sample-weighted mean of the epoch so far, not the latest batch."""
        module, _, _, _, fake_criterion = self._run_step(tmp_path, weight_dict={"loss_ce": 2.0})
        first_samples, first_targets = _make_batch(batch_size=1)
        second_samples, second_targets = _make_batch(batch_size=3)

        fake_criterion.return_value = {"loss_ce": torch.tensor(1.0)}
        module.training_step((first_samples, first_targets), batch_idx=0)
        fake_criterion.return_value = {"loss_ce": torch.tensor(4.0)}
        module.training_step((second_samples, second_targets), batch_idx=1)

        progress_calls = [c for c in module.log.call_args_list if c[0][0] == progress_name]
        assert progress_calls[-1].args[1].item() == pytest.approx(scale * (1.0 * 1 + 4.0 * 3) / 4)

    def test_progress_terms_stay_per_batch_when_train_log_on_step(self, tmp_path: Path) -> None:
        """With train_log_on_step=True every progress term keeps its per-batch value, as train/loss_step does."""
        module, samples, targets, _, fake_criterion = self._run_step(tmp_path, train_log_on_step=True)

        fake_criterion.return_value = {"loss_ce": torch.tensor(1.0)}
        module.training_step((samples, targets), batch_idx=0)
        second_value = torch.tensor(3.0)
        fake_criterion.return_value = {"loss_ce": second_value}
        module.training_step((samples, targets), batch_idx=1)

        progress_calls = [c for c in module.log.call_args_list if c[0][0] == "loss_cls"]
        assert progress_calls[-1].args[1] is second_value

    @pytest.mark.parametrize("train_log_on_step", [False, True])
    def test_progress_terms_are_progress_bar_only(self, tmp_path: Path, train_log_on_step: bool) -> None:
        """Every progress term goes to the progress bar only, per step, with the same flags in both modes."""
        module, samples, targets, _, _ = self._run_step(tmp_path, train_log_on_step=train_log_on_step)

        module.training_step((samples, targets), batch_idx=0)

        progress_calls = [c for c in module.log.call_args_list if c[0][0] == "loss_cls"]
        assert progress_calls[-1].kwargs == {
            "prog_bar": True,
            "logger": False,
            "on_step": True,
            "on_epoch": False,
            "batch_size": 2,
        }

    @pytest.mark.parametrize("progress_name", ["loss", "loss_cls"])
    def test_progress_loss_running_mean_restarts_each_epoch(self, tmp_path: Path, progress_name: str) -> None:
        """The running mean restarts at each epoch, so the first step of a new epoch reports its own loss."""
        module, samples, targets, _, fake_criterion = self._run_step(tmp_path)

        fake_criterion.return_value = {"loss_ce": torch.tensor(1.0)}
        module.training_step((samples, targets), batch_idx=0)
        module.on_train_epoch_start()
        fake_criterion.return_value = {"loss_ce": torch.tensor(3.0)}
        module.log.reset_mock()
        module.training_step((samples, targets), batch_idx=0)

        progress_calls = [c for c in module.log.call_args_list if c[0][0] == progress_name]
        assert progress_calls[-1].args[1].item() == pytest.approx(3.0)

    def test_progress_loss_running_mean_is_detached_from_autograd(self, tmp_path: Path) -> None:
        """The running sums must not keep the autograd graph of every step alive until the epoch ends."""
        module, samples, targets, _, fake_criterion = self._run_step(tmp_path)
        fake_criterion.return_value = {"loss_ce": torch.tensor(1.0, requires_grad=True)}

        module.training_step((samples, targets), batch_idx=0)

        progress_calls = [c for c in module.log.call_args_list if c[0][0] == "loss_cls"]
        assert progress_calls[-1].args[1].requires_grad is False

    def test_progress_loss_running_mean_accumulates_in_float32(self, tmp_path: Path) -> None:
        """A half-precision loss term is summed in float32, so the bar does not drift over a long epoch."""
        module, samples, targets, _, fake_criterion = self._run_step(tmp_path)
        fake_criterion.return_value = {"loss_ce": torch.tensor(1.0, dtype=torch.bfloat16)}

        module.training_step((samples, targets), batch_idx=0)

        progress_calls = [c for c in module.log.call_args_list if c[0][0] == "loss_cls"]
        assert progress_calls[-1].args[1].dtype is torch.float32

    @pytest.mark.parametrize(
        "train_log_on_step",
        [
            pytest.param(False, id="epoch-only"),
            pytest.param(True, id="step-and-epoch"),
        ],
    )
    def test_logs_epoch_train_loss_to_progress_bar(self, tmp_path, train_log_on_step):
        """Canonical training loss stays epoch-aggregated, with on_step mirroring train_log_on_step."""
        module, samples, targets, _, _ = self._run_step(tmp_path, train_log_on_step=train_log_on_step)

        module.training_step((samples, targets), batch_idx=0)

        epoch_loss_calls = [call for call in module.log.call_args_list if call[0][0] == "train/loss"]
        assert len(epoch_loss_calls) == 1
        assert epoch_loss_calls[0].kwargs.get("prog_bar") is True
        assert epoch_loss_calls[0].kwargs.get("on_step") is train_log_on_step
        assert epoch_loss_calls[0].kwargs.get("on_epoch") is True

    @pytest.mark.parametrize(
        "train_log_on_step,expected_live_loss_calls",
        [
            pytest.param(False, 1, id="default-emits-live-loss"),
            pytest.param(True, 0, id="on-step-skips-live-loss"),
        ],
    )
    def test_live_loss_key_gated_on_train_log_on_step(
        self, tmp_path: Path, train_log_on_step: bool, expected_live_loss_calls: int
    ) -> None:
        """Redundant live ``loss`` progress key is emitted only when train_log_on_step is False.

        With train_log_on_step=True the ``train/loss`` call forks into a per-batch ``train/loss_step`` progress entry,
        which already shows the aggregate, so the running-mean ``loss`` scalar is skipped to keep the bar's keys as
        before.
        """
        module, samples, targets, _, _ = self._run_step(tmp_path, train_log_on_step=train_log_on_step)

        module.training_step((samples, targets), batch_idx=0)

        live_loss_calls = [c for c in module.log.call_args_list if c[0][0] == "loss"]
        assert len(live_loss_calls) == expected_live_loss_calls

    def test_training_step_does_not_log_learning_rate(self, tmp_path):
        """Learning-rate metrics must wait for the optimizer-step boundary."""
        module, samples, targets, _, _ = self._run_step(tmp_path)

        module.training_step((samples, targets), batch_idx=0)

        lr_calls = [c for c in module.log.call_args_list if c[0][0] == "train/lr"]
        assert not lr_calls

    def test_logs_learning_rate_range_for_multiple_param_groups(self, tmp_path):
        """An automatic optimizer step logs first, minimum, and maximum rates with distinct visibility flags."""
        module, samples, targets, _, _ = self._run_step(tmp_path)
        first_param = nn.Parameter(torch.randn(4))
        second_param = nn.Parameter(torch.randn(4))
        third_param = nn.Parameter(torch.randn(4))
        module.optimizers.return_value = torch.optim.SGD(
            [
                {"params": [first_param], "lr": 0.1},
                {"params": [second_param], "lr": 0.05},
                {"params": [third_param], "lr": 0.2},
            ],
            lr=0.1,
        )

        module.on_before_optimizer_step(module.optimizers.return_value)

        expected_metrics = {
            "train/lr": (0.1, True),
            "train/lr_min": (0.05, False),
            "train/lr_max": (0.2, False),
        }
        for metric_name, (expected_value, expected_prog_bar) in expected_metrics.items():
            metric_calls = [call for call in module.log.call_args_list if call.args[0] == metric_name]
            assert len(metric_calls) == 1
            assert metric_calls[0].args[1] == pytest.approx(expected_value)
            assert metric_calls[0].kwargs.get("prog_bar") is expected_prog_bar
            assert metric_calls[0].kwargs.get("on_step") is True
            assert metric_calls[0].kwargs.get("on_epoch") is False

    def test_compacts_auxiliary_loss_metrics(self, tmp_path):
        """Layer-suffixed loss metrics should be reduced to one aggregate per base loss term."""
        loss_dict = {
            "loss_ce": torch.tensor(1.0),
            "loss_bbox": torch.tensor(2.0),
            "loss_ce_0": torch.tensor(3.0),
            "loss_bbox_0": torch.tensor(4.0),
            "loss_ce_enc": torch.tensor(5.0),
        }
        module, samples, targets, _, _ = self._run_step(
            tmp_path,
            loss_dict=loss_dict,
            weight_dict={key: 1.0 for key in loss_dict},
        )

        module.training_step((samples, targets), batch_idx=0)

        logged = module.log_dict.call_args.args[0]
        assert set(logged) == {"train/loss_ce", "train/loss_bbox", "train/loss_ce_aux", "train/loss_bbox_aux"}
        assert logged["train/loss_ce_aux"].item() == pytest.approx(8.0)
        assert logged["train/loss_bbox_aux"].item() == pytest.approx(4.0)

    def test_excludes_non_weighted_layer_suffixed_keys_from_aggregation(self, tmp_path):
        """A digit/enc-suffixed key absent from weight_dict must be logged individually, not aggregated.

        ``cardinality_error_0`` is a diagnostic count, never a weighted loss term, so weight_dict never contains it even
        though its name matches the layer-suffix pattern used for real auxiliary terms.
        """
        loss_dict = {
            "loss_ce": torch.tensor(1.0),
            "loss_ce_0": torch.tensor(2.0),
            "cardinality_error": torch.tensor(3.0),
            "cardinality_error_0": torch.tensor(4.0),
        }
        module, samples, targets, _, _ = self._run_step(
            tmp_path,
            loss_dict=loss_dict,
            weight_dict={"loss_ce": 1.0, "loss_ce_0": 1.0},
        )

        module.training_step((samples, targets), batch_idx=0)

        logged = module.log_dict.call_args.args[0]
        assert set(logged) == {
            "train/loss_ce",
            "train/loss_ce_aux",
            "train/cardinality_error",
            "train/cardinality_error_0",
        }
        assert logged["train/cardinality_error"].item() == pytest.approx(3.0)
        assert logged["train/cardinality_error_0"].item() == pytest.approx(4.0)

    def test_logs_layer_suffixed_keys_individually_when_compact_metrics_disabled(self, tmp_path):
        """With compact_train_metrics=False, every per-layer key is logged individually, honoring on_step."""
        loss_dict = {
            "loss_ce": torch.tensor(1.0),
            "loss_ce_0": torch.tensor(2.0),
            "loss_ce_enc": torch.tensor(3.0),
        }
        module, samples, targets, _, _ = self._run_step(
            tmp_path,
            loss_dict=loss_dict,
            weight_dict={key: 1.0 for key in loss_dict},
            train_log_on_step=True,
            compact_train_metrics=False,
        )

        module.training_step((samples, targets), batch_idx=0)

        logged = module.log_dict.call_args.args[0]
        assert set(logged) == {"train/loss_ce", "train/loss_ce_0", "train/loss_ce_enc"}
        assert module.log_dict.call_args.kwargs.get("on_step") is True

    def test_compacts_real_criterion_output_gated_by_weight_dict(self, tmp_path):
        """Aggregation of a real SetCriterion's key inventory must fold only weighted per-layer losses.

        ``test_compacts_auxiliary_loss_metrics`` above only exercises synthetic ``loss_ce``/``loss_bbox`` keys, whose
        weight_dict membership and layer-suffix pattern happen to coincide. RF-DETR's real criterion also emits
        ``cardinality_error`` with the same ``_<i>``/``_enc`` suffix pattern (see ``SetCriterion.forward``) despite
        never appearing in ``weight_dict`` (it is a logging-only diagnostic, not a backpropagated loss term). Suffix-
        only aggregation folds it into a spurious ``cardinality_error_aux`` key; correct aggregation must gate on
        ``weight_dict`` membership and leave it out. This uses the real ``RFDETRSmall`` model/criterion (this repo's
        default size) with a tiny synthetic batch so the assertion is checked against RF-DETR's actual key inventory
        instead of a hand-picked synthetic one.
        """
        mc = RFDETRSmallConfig(pretrain_weights=None, num_classes=3, device="cpu")
        tc = _base_train_config(tmp_path)
        real_model = build_model_from_config(mc, tc)
        real_criterion, real_postprocess = build_criterion_from_config(mc, tc)
        real_model.train()

        with (
            patch("rfdetr.training.module_model.build_model_from_config", return_value=real_model),
            patch(
                "rfdetr.training.module_model.build_criterion_from_config",
                return_value=(real_criterion, real_postprocess),
            ),
        ):
            module = RFDETRModelModule(mc, tc)

        samples, targets = _make_batch(batch_size=1, h=mc.resolution, w=mc.resolution)
        module.log = MagicMock()
        module.log_dict = MagicMock()
        real_param = nn.Parameter(torch.randn(4))
        module.optimizers = MagicMock(return_value=torch.optim.SGD([real_param], lr=1e-3))
        _attach_trainer(module, accumulate_grad_batches=1, num_training_batches=1)

        # Spy on the criterion to capture its raw (pre-aggregation) per-key loss dict, so the expected
        # aggregate is derived from the same real forward pass training_step() uses internally rather
        # than a second, independently-random forward pass.
        raw_loss_dicts: list[dict[str, torch.Tensor]] = []
        original_forward = module.criterion.forward

        def _spy_forward(*args, **kwargs):
            result = original_forward(*args, **kwargs)
            raw_loss_dicts.append(result)
            return result

        module.criterion.forward = _spy_forward

        module.training_step((samples, targets), batch_idx=0)

        raw_loss_dict = raw_loss_dicts[0]
        weight_dict = module.criterion.weight_dict
        expected_aux_sums: dict[str, torch.Tensor] = {}
        expected_base_keys: set[str] = set()
        for key, value in raw_loss_dict.items():
            base_name, separator, suffix = key.rpartition("_")
            is_layer_suffixed = bool(separator) and (suffix.isdigit() or suffix == "enc")
            if is_layer_suffixed and key in weight_dict:
                aggregate_name = f"train/{base_name}_aux"
                expected_aux_sums[aggregate_name] = expected_aux_sums.get(aggregate_name, torch.zeros(())) + value
            else:
                # Not layer-suffixed, or layer-suffixed but absent from weight_dict (e.g.
                # cardinality_error_0/_1/_enc — a diagnostic count, never a weighted loss term):
                # both cases fall through to individual logging, matching production's else branch.
                expected_base_keys.add(f"train/{key}")

        logged = module.log_dict.call_args.args[0]
        assert set(logged) == expected_base_keys | set(expected_aux_sums)
        assert "train/cardinality_error_aux" not in logged
        for aggregate_name, expected_value in expected_aux_sums.items():
            assert logged[aggregate_name].item() == pytest.approx(expected_value.item())

    def test_logs_loss_components_on_epoch_when_step_logging_is_enabled(self, tmp_path):
        """Per-step total loss logging must not re-enable per-step component metrics."""
        module, samples, targets, _, _ = self._run_step(tmp_path, train_log_on_step=True)

        module.training_step((samples, targets), batch_idx=0)

        assert module.log_dict.call_args.kwargs.get("on_step") is False
        assert module.log_dict.call_args.kwargs.get("on_epoch") is True

    @pytest.mark.parametrize(
        "grad_accum_steps, num_training_batches, expected_log_count",
        [
            pytest.param(2, 3, 2, id="manual-accumulation-tail-fallback-logs-once-per-window-never-twice"),
            pytest.param(
                1,
                3,
                3,
                id="grad-accum-steps-one-every-batch-closes-its-own-window-and-logs",
            ),
            pytest.param(
                2,
                float("inf"),
                1,
                id="infinite-dataset-logs-only-at-modulo-boundary-tail-fallback-never-fires",
            ),
        ],
    )
    def test_logs_learning_rates_for_manual_optimizer_steps(
        self, tmp_path, grad_accum_steps: int, num_training_batches: float, expected_log_count: int
    ):
        """Manual accumulation logs learning rates once per completed or partial optimizer window, never twice.

        ``_step_optimizer`` must not log learning rates itself — the single emission site is the
        ``on_before_optimizer_step`` hook, which ``_StepHookOptimizer`` fires from ``step()`` the same way Lightning's
        real ``LightningOptimizer.step()`` does on both automatic and manual paths. The finite case
        (``num_training_batches=3``) exercises ``_should_step_optimizer``'s end-of-epoch tail fallback on its third
        batch; the infinite case proves ``batch_idx + 1 >= num_training_batches`` can never trip against infinity, so
        only the modulo-boundary step (batch_idx=1) logs.
        """
        module, *_ = _build_module(
            model_config=_base_model_config(use_grouppose_keypoints=True, num_keypoints_per_class=[17]),
            train_config=_base_train_config(tmp_path, grad_accum_steps=grad_accum_steps),
            tmp_path=tmp_path,
        )
        parameter = nn.Parameter(torch.randn(4))
        optimizer = _StepHookOptimizer(module, torch.optim.SGD([parameter], lr=0.1))
        trainer = MagicMock(
            num_training_batches=num_training_batches, gradient_clip_val=0.0, gradient_clip_algorithm="norm"
        )
        module._trainer = trainer
        type(module).trainer = property(lambda self: self._trainer)
        module.log = MagicMock()

        for batch_idx in range(3):
            if module._should_step_optimizer(batch_idx):
                module._step_optimizer(optimizer)

        for metric_name in ("train/lr", "train/lr_min", "train/lr_max"):
            metric_calls = [call for call in module.log.call_args_list if call.args[0] == metric_name]
            assert len(metric_calls) == expected_log_count

    def test_logs_convergence_components_to_progress_bar(self, tmp_path):
        """Selected detection and keypoint losses should appear as compact progress-only metrics."""
        loss_dict = {
            "loss_ce": torch.tensor(0.5),
            "loss_bbox": torch.tensor(0.3),
            "loss_keypoints_l1": torch.tensor(0.4),
            "loss_keypoints_nll": torch.tensor(0.2),
        }
        weight_dict = {key: 1.0 for key in loss_dict}
        module, samples, targets, _, _ = self._run_step(tmp_path, loss_dict, weight_dict)

        module.training_step((samples, targets), batch_idx=0)

        progress_names = {c[0][0] for c in module.log.call_args_list if c.kwargs.get("prog_bar") is True}
        assert {"loss_cls", "loss_box", "kp_l1", "kp_nll"}.issubset(progress_names)

    def test_logs_individual_main_losses_as_dict(self, tmp_path):
        """Each main decoder loss must be logged separately under the train/ prefix."""
        loss_dict = {"loss_ce": torch.tensor(0.5), "loss_bbox": torch.tensor(0.3)}
        weight_dict = {"loss_ce": 1.0, "loss_bbox": 5.0}
        module, samples, targets, _, _ = self._run_step(tmp_path, loss_dict, weight_dict)

        module.training_step((samples, targets), batch_idx=0)

        module.log_dict.assert_called_once()
        logged = module.log_dict.call_args[0][0]
        assert "train/loss_ce" in logged
        assert "train/loss_bbox" in logged

    def test_returns_scalar_tensor(self, tmp_path):
        """Loss must be a 0-dim tensor so Lightning can call .backward() on it."""
        module, samples, targets, _, _ = self._run_step(tmp_path)

        loss = module.training_step((samples, targets), batch_idx=0)

        assert loss.dim() == 0

    def test_returns_detached_predictions_when_train_metrics_enabled(self, tmp_path):
        """compute_train_metrics=True should expose detached predictions without changing the Lightning loss key."""
        tc = _base_train_config(tmp_path, compute_train_metrics=True)
        module, fake_model, fake_criterion, fake_postprocess = _build_module(train_config=tc, tmp_path=tmp_path)
        samples, targets = _make_batch()
        model_output = {"pred_logits": torch.randn(2, 3, requires_grad=True)}
        fake_model.return_value = model_output
        fake_criterion.return_value = {"loss_ce": torch.tensor(1.0)}
        fake_criterion.weight_dict = {"loss_ce": 1.0}
        fake_postprocess.return_value = [{"boxes": torch.randn(1, 4, requires_grad=True)}]
        module.log = MagicMock()
        module.log_dict = MagicMock()
        real_param = nn.Parameter(torch.randn(4))
        module.optimizers = MagicMock(return_value=torch.optim.SGD([real_param], lr=1e-3))
        _attach_trainer(module, accumulate_grad_batches=1)

        result = module.training_step((samples, targets), batch_idx=0)

        assert isinstance(result, dict)
        assert result["loss"].dim() == 0
        assert result["results"][0]["boxes"].requires_grad is False
        assert result["targets"] is targets

    def test_ignores_losses_not_in_weight_dict(self, tmp_path):
        """Losses absent from weight_dict (e.g. cardinality_error) must not affect total."""
        loss_dict = {"loss_ce": torch.tensor(1.0), "cardinality_error": torch.tensor(99.0)}
        weight_dict = {"loss_ce": 2.0}
        module, samples, targets, _, _ = self._run_step(tmp_path, loss_dict, weight_dict)

        loss = module.training_step((samples, targets), batch_idx=0)

        assert loss.item() == pytest.approx(2.0)

    def test_train_metrics_slices_to_group0_queries(self, tmp_path):
        """compute_train_metrics postprocess must receive only group-0 queries ([:num_queries]).

        Group DETR emits group_detr×num_queries outputs in train mode. Without the slice, postprocess top-k draws from
        all groups and OKS/mAP reads ~50× below true accuracy. Assert the received pred_logits has shape (B,
        num_queries, C).
        """
        nq = 10
        group_detr = 3
        batch_size = 2
        num_classes = 5
        mc = _base_model_config(num_classes=num_classes, num_queries=nq)
        tc = _base_train_config(tmp_path, compute_train_metrics=True)
        module, fake_model, fake_criterion, _ = _build_module(model_config=mc, train_config=tc, tmp_path=tmp_path)

        full_logits = torch.randn(batch_size, group_detr * nq, num_classes)
        model_output = {
            "pred_logits": full_logits,
            "pred_boxes": torch.randn(batch_size, group_detr * nq, 4),
        }
        fake_model.return_value = model_output
        fake_criterion.return_value = {"loss_ce": torch.tensor(1.0)}
        fake_criterion.weight_dict = {"loss_ce": 1.0}

        received: dict = {}

        def capture_postprocess(outputs, orig_sizes):
            received.update(outputs)
            return [
                {"boxes": torch.zeros(nq, 4), "scores": torch.ones(nq), "labels": torch.zeros(nq, dtype=torch.long)}
            ]

        module.postprocess = capture_postprocess
        module.log = MagicMock()
        module.log_dict = MagicMock()
        real_param = nn.Parameter(torch.randn(4))
        module.optimizers = MagicMock(return_value=torch.optim.SGD([real_param], lr=1e-3))
        _attach_trainer(module, accumulate_grad_batches=1, num_training_batches=1)
        samples, targets = _make_batch(batch_size=batch_size)

        module.training_step((samples, targets), batch_idx=0)

        assert "pred_logits" in received
        assert received["pred_logits"].shape == (batch_size, nq, num_classes)
        torch.testing.assert_close(received["pred_logits"], full_logits[:, :nq])

    def test_train_metrics_skips_dict_pred_masks(self, tmp_path):
        """Dict-valued pred_masks (sparse_forward in train mode) must not crash training_step.

        In segmentation train mode lwdetr uses sparse_forward which returns pred_masks as a dict. PostProcess cannot
        handle a dict — it calls .shape[0] on it. The fix filters out non-tensor values so postprocess receives
        pred_masks=None (box path).
        """
        tc = _base_train_config(tmp_path, compute_train_metrics=True)
        module, fake_model, fake_criterion, _ = _build_module(train_config=tc, tmp_path=tmp_path)

        model_output = {
            "pred_logits": torch.randn(2, 10, 5),
            "pred_boxes": torch.randn(2, 10, 4),
            "pred_masks": {"spatial_features": torch.randn(2, 256, 8, 8), "query_features": torch.randn(2, 10, 256)},
        }
        fake_model.return_value = model_output
        fake_criterion.return_value = {"loss_ce": torch.tensor(1.0)}
        fake_criterion.weight_dict = {"loss_ce": 1.0}

        received: dict = {}

        def capture_postprocess(outputs, orig_sizes):
            received.update(outputs)
            return [{"boxes": torch.zeros(1, 4), "scores": torch.ones(1), "labels": torch.zeros(1, dtype=torch.long)}]

        module.postprocess = capture_postprocess
        module.log = MagicMock()
        module.log_dict = MagicMock()
        real_param = nn.Parameter(torch.randn(4))
        module.optimizers = MagicMock(return_value=torch.optim.SGD([real_param], lr=1e-3))
        _attach_trainer(module, accumulate_grad_batches=1, num_training_batches=1)
        samples, targets = _make_batch()

        module.training_step((samples, targets), batch_idx=0)

        assert "pred_masks" not in received


class TestOnBeforeOptimizerStepFiresOncePerAccumulationWindow:
    """``on_before_optimizer_step`` must fire once per optimizer update on the automatic-optimization path.

    ``TestTrainingStep.test_logs_learning_rate_range_for_multiple_param_groups`` above calls
    ``on_before_optimizer_step`` directly with a hand-built optimizer, which only verifies the payload it logs — it
    never drives Lightning's own automatic-optimization gradient-accumulation loop, so it cannot catch a regression
    where the hook fired once per microbatch instead of once per completed accumulation window. Detection/segmentation
    models use PTL's automatic optimization (unlike keypoint models' manual ``_should_step_optimizer`` path tested
    elsewhere in this file), so accumulation gating here is entirely internal to Lightning; the only way to exercise
    it faithfully is a real ``Trainer.fit()`` run with ``accumulate_grad_batches > 1``.
    """

    def test_fires_once_per_window_not_once_per_microbatch(self, mocker, tmp_path):
        """4 training batches at accumulate_grad_batches=2 must trigger exactly 2 optimizer-step hook calls."""
        mc = _base_model_config()
        tc = _base_train_config(tmp_path, num_workers=0)

        tiny_model = _TinyModel()
        fake_criterion = _FakeCriterion()
        fake_postprocess = MagicMock(side_effect=_helpers_fake_postprocess)
        fake_dataset = _FakeDataset(length=20)

        class _CountOptimizerSteps(Callback):
            """Count how many times Lightning invokes the pre-optimizer-step hook."""

            def __init__(self) -> None:
                self.count = 0

            def on_before_optimizer_step(self, trainer, pl_module, optimizer) -> None:
                """Increment the call count for every hook invocation."""
                self.count += 1

        counter = _CountOptimizerSteps()

        mocker.patch("rfdetr.training.module_model.build_model_from_config", return_value=tiny_model)
        mocker.patch(
            "rfdetr.training.module_model.build_criterion_from_config",
            return_value=(fake_criterion, fake_postprocess),
        )
        mocker.patch("rfdetr.training.module_data.build_dataset", return_value=fake_dataset)
        mocker.patch(
            "rfdetr.training.module_model.get_param_dict",
            side_effect=lambda args, model: _make_param_dicts(model),
        )
        module = RFDETRModelModule(mc, tc)
        datamodule = RFDETRDataModule(mc, tc)
        trainer = Trainer(
            fast_dev_run=4,
            accelerator="cpu",
            enable_progress_bar=False,
            enable_model_summary=False,
            logger=False,
            accumulate_grad_batches=2,
            callbacks=[counter],
        )
        trainer.fit(module, datamodule)

        assert counter.count == 2


class TestShouldStepOptimizer:
    """Tests for ``_should_step_optimizer``.

    Covers the modulo path, the end-of-epoch fallback, and the iterable / infinite dataset case where
    ``trainer.num_training_batches`` is ``float('inf')``.
    """

    def _make_module_with_trainer(self, tmp_path, grad_accum_steps, num_training_batches):
        """Build a module with a stub trainer exposing ``num_training_batches`` for the test scenario."""
        module, *_ = _build_module(
            model_config=_base_model_config(use_grouppose_keypoints=True, num_keypoints_per_class=[17]),
            train_config=_base_train_config(tmp_path, grad_accum_steps=grad_accum_steps),
            tmp_path=tmp_path,
        )
        _attach_trainer(module, num_training_batches=num_training_batches)
        return module

    @pytest.mark.parametrize(
        "grad_accum_steps,num_training_batches,batch_idx,expected",
        [
            pytest.param(1, 10, 0, True, id="ga1-bidx0-steps-every-batch"),
            pytest.param(1, 10, 9, True, id="ga1-bidx9-steps-every-batch"),
            pytest.param(2, 10, 0, False, id="ga2-bidx0-mid-window"),
            pytest.param(2, 10, 1, True, id="ga2-bidx1-closes-window"),
            pytest.param(2, 10, 2, False, id="ga2-bidx2-opens-new-window"),
            pytest.param(2, 10, 9, True, id="ga2-bidx9-closes-final-window"),
            pytest.param(4, 10, 7, True, id="ga4-bidx7-closes-second-window"),
            pytest.param(4, 10, 8, False, id="ga4-bidx8-opens-partial-window"),
            pytest.param(4, 10, 9, True, id="ga4-bidx9-final-batch-flushes-partial"),
            pytest.param(4, 11, 8, False, id="ga4-bidx8-of-11-mid-window"),
            pytest.param(4, 11, 10, True, id="ga4-bidx10-final-batch-flushes-partial"),
        ],
    )
    def test_finite_dataset_steps_at_window_close_and_epoch_end(
        self, tmp_path, grad_accum_steps, num_training_batches, batch_idx, expected
    ):
        """Optimizer steps when the accumulation window closes or when the epoch ends with a partial window."""
        module = self._make_module_with_trainer(tmp_path, grad_accum_steps, num_training_batches)

        assert module._should_step_optimizer(batch_idx) is expected

    @pytest.mark.parametrize(
        "grad_accum_steps,batch_idx,expected",
        [
            pytest.param(2, 0, False, id="ga2-bidx0-mid-window"),
            pytest.param(2, 1, True, id="ga2-bidx1-closes-window"),
            pytest.param(4, 2, False, id="ga4-bidx2-mid-window"),
            pytest.param(4, 3, True, id="ga4-bidx3-closes-window"),
        ],
    )
    def test_infinite_dataset_uses_modulo_only(self, tmp_path, grad_accum_steps, batch_idx, expected):
        """Iterable datasets report ``num_training_batches=float('inf')``; only the modulo path can close the window."""
        module = self._make_module_with_trainer(tmp_path, grad_accum_steps, float("inf"))

        assert module._should_step_optimizer(batch_idx) is expected

    def test_none_num_training_batches_uses_modulo_only(self, tmp_path):
        """If trainer.num_training_batches is None (very early in fit), only the modulo path can trigger a step."""
        module = self._make_module_with_trainer(tmp_path, grad_accum_steps=2, num_training_batches=None)

        assert module._should_step_optimizer(batch_idx=0) is False
        assert module._should_step_optimizer(batch_idx=1) is True


class TestOnTrainEpochStart:
    """Tests for ``on_train_epoch_start`` — must reset the accumulated box normalizer between epochs."""

    def test_reset_clears_stale_accumulator(self, tmp_path):
        """A stale normalizer from a previous epoch must not leak into the new epoch's first microbatch."""
        module, *_ = _build_module(
            model_config=_base_model_config(use_grouppose_keypoints=True, num_keypoints_per_class=[17]),
            tmp_path=tmp_path,
        )
        module._accumulated_box_normalizer = torch.tensor(42.0)

        module.on_train_epoch_start()

        assert module._accumulated_box_normalizer is None

    def test_is_noop_for_detection_module(self, tmp_path):
        """Detection models never populate _accumulated_box_normalizer; reset must leave it None."""
        module, *_ = _build_module(tmp_path=tmp_path)

        module.on_train_epoch_start()

        assert module._accumulated_box_normalizer is None

    def test_zeros_optimizer_grad_on_stale_accumulator(self, tmp_path):
        """When a partial window survived epoch end, optimizer gradients must be zeroed before reset."""
        module, *_ = _build_module(
            model_config=_base_model_config(use_grouppose_keypoints=True, num_keypoints_per_class=[17]),
            tmp_path=tmp_path,
        )
        real_param = nn.Parameter(torch.randn(4))
        real_param.grad = torch.ones(4)
        optimizer = torch.optim.SGD([real_param], lr=1.0)
        module.optimizers = MagicMock(return_value=optimizer)
        module._accumulated_box_normalizer = torch.tensor(7.0)

        module.on_train_epoch_start()

        assert module._accumulated_box_normalizer is None
        assert real_param.grad is None or real_param.grad.abs().sum().item() == pytest.approx(0.0)

    def test_forwards_current_epoch_to_datamodule_train_batch_sampler(self, tmp_path):
        """A custom batch sampler on the datamodule must receive set_epoch(current_epoch) every epoch.

        PTL never calls epoch hooks on a LightningDataModule itself, so RFDETRModelModule bridges the gap
        from its own on_train_epoch_start: this is the only place WeightedMultiSourceBatchSampler's seeded
        per-epoch reshuffle actually advances instead of reusing the first epoch's shuffle for the whole run.
        """
        module, *_ = _build_module(tmp_path=tmp_path)
        fake_sampler = MagicMock()
        fake_datamodule = MagicMock(train_batch_sampler=fake_sampler)
        fake_trainer = MagicMock(datamodule=fake_datamodule)
        module._trainer = fake_trainer
        with patch.object(type(module), "current_epoch", new=3):
            module.on_train_epoch_start()

        fake_sampler.set_epoch.assert_called_once_with(3)

    def test_is_noop_when_datamodule_has_no_custom_batch_sampler(self, tmp_path):
        """build_train_sampler() returning None must not raise when there is no set_epoch to forward."""
        module, *_ = _build_module(tmp_path=tmp_path)
        fake_datamodule = MagicMock(train_batch_sampler=None)
        fake_trainer = MagicMock(datamodule=fake_datamodule)
        module._trainer = fake_trainer

        module.on_train_epoch_start()  # must not raise

        assert module._accumulated_box_normalizer is None

    def test_is_noop_when_trainer_is_unattached(self, tmp_path):
        """Calling on_train_epoch_start with no Trainer attached must not raise (matches the other cases in this
        class)."""
        module, *_ = _build_module(tmp_path=tmp_path)

        module.on_train_epoch_start()  # must not raise RuntimeError from the unattached self.trainer property

        assert module._accumulated_box_normalizer is None


class TestRescaleAccumulatedGradients:
    """Direct contract tests for _rescale_accumulated_gradients."""

    @pytest.mark.parametrize(
        "in_features, out_features, factor, weight_grad, bias_grad, weight_expected, bias_expected",
        [
            pytest.param(3, 5, 0.5, 4.0, 8.0, 2.0, 4.0, id="factor-half-halves-grads"),
            pytest.param(2, 2, 1.0, 3.0, 7.0, 3.0, 7.0, id="factor-one-is-identity"),
        ],
    )
    def test_scales_parameter_grads_by_factor(
        self, tmp_path, in_features, out_features, factor, weight_grad, bias_grad, weight_expected, bias_expected
    ):
        """Every parameter's .grad is multiplied by the factor; factor 1.0 leaves gradients exactly unchanged."""
        module, *_ = _build_module(
            model_config=_base_model_config(use_grouppose_keypoints=True, num_keypoints_per_class=[17]),
            tmp_path=tmp_path,
        )
        nano_model = nn.Linear(in_features, out_features)
        nano_model.weight.grad = torch.full((out_features, in_features), weight_grad)
        nano_model.bias.grad = torch.full((out_features,), bias_grad)
        module.model = nano_model

        module._rescale_accumulated_gradients(torch.tensor(factor))

        torch.testing.assert_close(nano_model.weight.grad, torch.full((out_features, in_features), weight_expected))
        torch.testing.assert_close(nano_model.bias.grad, torch.full((out_features,), bias_expected))

    def test_skips_params_with_no_grad(self, tmp_path):
        """Parameters without .grad must remain None after rescaling."""
        module, *_ = _build_module(
            model_config=_base_model_config(use_grouppose_keypoints=True, num_keypoints_per_class=[17]),
            tmp_path=tmp_path,
        )
        nano_model = nn.Linear(2, 2)
        # No backward pass — all grads are None
        module.model = nano_model

        module._rescale_accumulated_gradients(torch.tensor(0.5))

        assert nano_model.weight.grad is None
        assert nano_model.bias.grad is None


class TestValidationStep:
    """Validation-specific behaviour of validation_step(): loss policy, keypoint loss logging, and eval-model choice.

    The contracts validation_step() shares with test_step() live in :class:`TestEvalStepOutputs`.
    """

    def _run_val_step(
        self,
        tmp_path,
        loss_dict: dict[str, torch.Tensor] | None = None,
        weight_dict: dict[str, float] | None = None,
    ):
        tc = _base_train_config(tmp_path, compute_val_loss=True)
        module, fake_model, fake_criterion, fake_pp = _build_module(train_config=tc, tmp_path=tmp_path)
        samples, targets = _make_batch()
        fake_model.return_value = {}
        fake_criterion.return_value = loss_dict or {"loss_ce": torch.tensor(0.5)}
        fake_criterion.weight_dict = weight_dict or {"loss_ce": 1.0}
        module.log = MagicMock()
        module.log_dict = MagicMock()
        result = module.validation_step((samples, targets), batch_idx=0)
        return result, fake_pp, module

    def test_logs_val_keypoint_loss_components_once(self, tmp_path):
        """Validation should expose full keypoint losses without duplicate progress aliases."""
        loss_dict = {
            "loss_ce": torch.tensor(0.5),
            "loss_keypoints_l1": torch.tensor(0.4),
            "loss_keypoints_findable": torch.tensor(0.3),
            "loss_keypoints_visible": torch.tensor(0.2),
            "loss_keypoints_nll": torch.tensor(0.1),
        }
        weight_dict = {key: 1.0 for key in loss_dict}

        _, _, module = self._run_val_step(tmp_path, loss_dict=loss_dict, weight_dict=weight_dict)

        module.log_dict.assert_called_once()
        logged = module.log_dict.call_args.args[0]
        assert "val/loss_keypoints_l1" in logged
        assert "val/loss_keypoints_findable" in logged
        logged_names = {c[0][0] for c in module.log.call_args_list}
        assert "val/kp_l1" not in logged_names
        assert "val/kp_find" not in logged_names
        assert "val/kp_vis" not in logged_names
        assert "val/kp_nll" not in logged_names

    def test_val_detection_loss_components_not_relogged_as_aliases(self, tmp_path):
        """Validation component losses should be logged once under canonical ``val/loss_*`` names."""
        loss_dict = {
            "loss_ce": torch.tensor(0.5),
            "loss_bbox": torch.tensor(0.3),
            "loss_giou": torch.tensor(0.2),
        }
        weight_dict = {key: 1.0 for key in loss_dict}

        _, _, module = self._run_val_step(tmp_path, loss_dict=loss_dict, weight_dict=weight_dict)

        logged_loss_names = set(module.log_dict.call_args.args[0])
        direct_log_names = {c[0][0] for c in module.log.call_args_list}
        assert "val/loss_giou" in logged_loss_names
        assert "val/loss_giou" not in direct_log_names
        assert "val/giou" not in direct_log_names

    @pytest.mark.parametrize("inductor_cudagraphs", [True, False])
    def test_marks_cudagraph_step_only_on_inductor_path(self, mocker, inductor_cudagraphs, tmp_path):
        """Validation on the Inductor CUDA graph path marks each step, since the compiled model records an eval graph.

        With ``eval_base_model=True`` or ``use_ema=False`` the ``OptimizedModule`` itself runs validation; the results
        kept by ``COCOEvalCallback`` across the epoch must not alias a graph output the next batch rewrites.
        """
        mark_step = mocker.patch("rfdetr.training.module_model.torch.compiler.cudagraph_mark_step_begin")
        tc = _base_train_config(tmp_path, compute_val_loss=False)
        module, fake_model, _, _ = _build_module(train_config=tc, tmp_path=tmp_path)
        module._inductor_cudagraphs = inductor_cudagraphs
        samples, targets = _make_batch()
        fake_model.return_value = {}
        module.log = MagicMock()

        module.validation_step((samples, targets), batch_idx=0)

        assert mark_step.call_count == (1 if inductor_cudagraphs else 0)

    def test_auto_val_loss_skips_criterion_without_a_loss_monitor(self, tmp_path):
        """compute_val_loss='auto' skips validation loss when no configured consumer monitors it."""
        tc = _base_train_config(tmp_path, compute_val_loss="auto")
        module, fake_model, fake_criterion, _ = _build_module(train_config=tc, tmp_path=tmp_path)
        samples, targets = _make_batch()
        fake_model.return_value = {}
        module.log = MagicMock()

        result = module.validation_step((samples, targets), batch_idx=0)

        fake_criterion.assert_not_called()
        assert "results" in result and "targets" in result

    def test_auto_val_loss_keeps_criterion_for_callback_monitor(self, tmp_path):
        """compute_val_loss='auto' retains validation loss for a callback monitoring val/loss."""
        tc = _base_train_config(tmp_path, compute_val_loss="auto")
        module, fake_model, fake_criterion, _ = _build_module(train_config=tc, tmp_path=tmp_path)
        samples, targets = _make_batch()
        fake_model.return_value = {}
        fake_criterion.return_value = {"loss_ce": torch.tensor(0.5)}
        fake_criterion.weight_dict = {"loss_ce": 1.0}
        module.trainer = SimpleNamespace(callbacks=[SimpleNamespace(monitor="val/loss")])
        module.log = MagicMock()
        module.log_dict = MagicMock()

        module.validation_step((samples, targets), batch_idx=0)

        fake_criterion.assert_called_once_with({}, targets)
        assert any(call.args[0] == "val/loss" for call in module.log.call_args_list)

    @pytest.mark.parametrize(
        "callbacks, expected",
        [
            pytest.param(
                [RFDETREarlyStopping(monitor_regular="val/loss")],
                True,
                id="real-rfdetr-early-stopping-monitor-lives-in-monitor-regular-not-monitor",
            ),
            pytest.param(
                [SimpleNamespace(monitor="__rfdetr_effective_map__", _monitor_ema="val/loss")],
                True,
                id="ema-monitor-attribute-consuming-val-loss",
            ),
            pytest.param([], False, id="empty-callback-list-resolves-like-the-unattached-case"),
        ],
    )
    def test_auto_val_loss_scan_resolves_policy(self, tmp_path, callbacks: list, expected: bool):
        """compute_val_loss='auto' scans trainer.callbacks for any callback that would consume val/loss.

        Covers three cases a naive scan (monitor attribute only) could miss: ``RFDETREarlyStopping``'s real target lives
        in ``_monitor_regular`` (its ``monitor`` is always the synthetic ``__rfdetr_effective_map__`` key it injects
        itself); RF-DETR's EMA callbacks track their metric via ``_monitor_ema`` instead; and an attached trainer with
        an empty callback list must resolve exactly like the unattached case rather than raising or falling back to
        computing the loss.
        """
        tc = _base_train_config(tmp_path, compute_val_loss="auto")
        module, *_ = _build_module(train_config=tc, tmp_path=tmp_path)
        module.trainer = SimpleNamespace(callbacks=callbacks)

        assert module._should_compute_val_loss is expected

    def test_explicit_val_loss_disable_rejects_callback_monitor(self, tmp_path):
        """compute_val_loss=False rejects a callback that would consume val/loss."""
        tc = _base_train_config(tmp_path, compute_val_loss=False)
        module, *_ = _build_module(train_config=tc, tmp_path=tmp_path)
        module.trainer = SimpleNamespace(callbacks=[SimpleNamespace(monitor="val/loss")])

        with pytest.raises(ValueError) as exc_info:
            module.on_fit_start()
        assert "compute_val_loss=False is incompatible" in str(exc_info.value)

    def test_standalone_validate_skips_fit_start_rejection(self, mocker, tmp_path):
        """A standalone trainer.validate() with compute_val_loss=False runs despite a callback monitoring val/loss.

        The rejection lives in ``on_fit_start``, which PTL invokes only when ``trainer.state.fn`` is ``FITTING``; a bare
        ``validate()`` call sets it to ``VALIDATING`` and skips the hook entirely. The asymmetry is intentional (a
        validation-only run has no scheduler or early-stopping loop to starve), so this test documents the current
        behaviour instead of asserting a raise.
        """
        mc = _base_model_config()
        tc = _base_train_config(tmp_path, compute_val_loss=False, num_workers=0)

        class _ValLossMonitorCallback(Callback):
            """Callback declaring a val/loss monitor, as PTL-native checkpoint and early-stopping callbacks do."""

            monitor = "val/loss"

        fake_postprocess = MagicMock(side_effect=_helpers_fake_postprocess)

        mocker.patch("rfdetr.training.module_model.build_model_from_config", return_value=_TinyModel())
        mocker.patch(
            "rfdetr.training.module_model.build_criterion_from_config",
            return_value=(_FakeCriterion(), fake_postprocess),
        )
        mocker.patch("rfdetr.training.module_data.build_dataset", return_value=_FakeDataset(length=4))
        module = RFDETRModelModule(mc, tc)
        datamodule = RFDETRDataModule(mc, tc)
        trainer = Trainer(
            limit_val_batches=1,
            accelerator="cpu",
            enable_progress_bar=False,
            enable_model_summary=False,
            enable_checkpointing=False,
            logger=False,
            callbacks=[_ValLossMonitorCallback()],
        )
        trainer.validate(module, datamodule)

        # The validation batch reached postprocess, so the loop ran to completion instead of raising the guard.
        fake_postprocess.assert_called_once()

    def test_forwards_through_ema_model_not_base_by_default(self, tmp_path):
        """Validation must forward through the EMA-averaged model, not the base model, by default.

        Regression for #416: this single forward replaces the duplicate base+EMA pair COCOEvalCallback would otherwise
        run, and is the ~3-3.5%-of-epoch saving behind the eval_base_model default.
        """
        tc = _base_train_config(tmp_path, use_ema=True)
        module, fake_model, fake_criterion, _ = _build_module(train_config=tc, tmp_path=tmp_path)
        samples, targets = _make_batch()
        fake_model.return_value = {"base": True}
        fake_criterion.return_value = {"loss_ce": torch.tensor(0.5)}
        fake_criterion.weight_dict = {"loss_ce": 1.0}

        ema_model = MagicMock(name="ema_model", return_value={"ema": True})
        fake_ema_callback = SimpleNamespace(_average_model=SimpleNamespace(module=SimpleNamespace(model=ema_model)))
        module.trainer = SimpleNamespace(callbacks=[fake_ema_callback])
        module.log = MagicMock()
        module.log_dict = MagicMock()

        module.validation_step((samples, targets), batch_idx=0)

        ema_model.assert_called_once()
        fake_model.assert_not_called()

    def test_falls_back_to_base_model_when_ema_not_warmed_up(self, tmp_path):
        """Validation must fall back to the base model if the EMA callback has no averaged model yet.

        The very first validation can run before RFDETREMACallback has built its averaged model; forwarding through a
        missing EMA model would crash instead of degrading to the base weights.
        """
        tc = _base_train_config(tmp_path, use_ema=True)
        module, fake_model, fake_criterion, _ = _build_module(train_config=tc, tmp_path=tmp_path)
        samples, targets = _make_batch()
        fake_model.return_value = {"base": True}
        fake_criterion.return_value = {"loss_ce": torch.tensor(0.5)}
        fake_criterion.weight_dict = {"loss_ce": 1.0}

        fake_ema_callback = SimpleNamespace(_average_model=None)
        module.trainer = SimpleNamespace(callbacks=[fake_ema_callback])
        module.log = MagicMock()
        module.log_dict = MagicMock()

        module.validation_step((samples, targets), batch_idx=0)

        fake_model.assert_called_once()

    def test_eval_base_model_does_not_touch_trainer(self, tmp_path):
        """eval_base_model=True must not access self.trainer at all — it returns the base model unconditionally.

        validation_step has to stay usable on a module with no Trainer attached, as every other test in this class
        relies on; the opt-in path must short-circuit before any trainer lookup.
        """
        tc = _base_train_config(tmp_path, eval_base_model=True)
        module, fake_model, _, _ = _build_module(train_config=tc, tmp_path=tmp_path)

        assert module._resolve_eval_model() is fake_model

    def test_falls_back_to_base_model_when_trainer_unattached(self, tmp_path):
        """Validation must fall back to the base model — not raise — when the module isn't attached to a Trainer at all.

        ``LightningModule.trainer`` raises ``RuntimeError`` (not ``None``) when unattached, so a naive
        ``getattr(self.trainer, ...)`` would crash instead of falling back (regression: module never has a Trainer wired
        up in this test module, matching the direct/standalone validation_step-call scenario).
        """
        tc = _base_train_config(tmp_path, use_ema=True)
        module, fake_model, fake_criterion, _ = _build_module(train_config=tc, tmp_path=tmp_path)
        samples, targets = _make_batch()
        fake_model.return_value = {"base": True}
        fake_criterion.return_value = {"loss_ce": torch.tensor(0.5)}
        fake_criterion.weight_dict = {"loss_ce": 1.0}
        module.log = MagicMock()
        module.log_dict = MagicMock()

        module.validation_step((samples, targets), batch_idx=0)

        fake_model.assert_called_once()


class TestValidationLossSkipNotice:
    """on_validation_epoch_start() announces an 'auto' policy that resolved to skipping validation-loss computation.

    The consumer scan cannot see a human reading a ``val/loss`` curve from ``metrics.csv``, TensorBoard, or Weights &
    Biases, so the resolution is stated once instead of the curve vanishing silently.
    """

    def _build_module_with_trainer(self, tmp_path, **trainer_state):
        """Return an 'auto'-policy module whose stub trainer carries the given validation-loop state."""
        tc = _base_train_config(tmp_path, compute_val_loss="auto")
        module, *_ = _build_module(train_config=tc, tmp_path=tmp_path)
        state = dict(callbacks=[], sanity_checking=False, is_global_zero=True)
        state.update(trainer_state)
        module.trainer = SimpleNamespace(**state)
        return module

    def test_notice_is_emitted_once_across_validation_epochs(self, mocker, tmp_path):
        """The skip notice is logged on the first validation epoch only, not once per epoch.

        Every validation epoch re-enters the hook, so an unguarded notice would repeat for the whole run and drown the
        per-epoch metric lines it sits next to.
        """
        mock_logger = mocker.patch("rfdetr.training.module_model.logger")
        module = self._build_module_with_trainer(tmp_path)

        module.on_validation_epoch_start()
        module.on_validation_epoch_start()

        mock_logger.info.assert_called_once()

    def test_no_notice_when_a_callback_consumes_val_loss(self, mocker, tmp_path):
        """No notice is logged while a callback monitors val/loss, because the loss is still computed."""
        mock_logger = mocker.patch("rfdetr.training.module_model.logger")
        module = self._build_module_with_trainer(tmp_path, callbacks=[SimpleNamespace(monitor="val/loss")])

        module.on_validation_epoch_start()

        mock_logger.info.assert_not_called()

    def test_sanity_check_defers_notice(self, mocker, tmp_path):
        """The pre-training sanity-check validation pass does not consume the one-shot notice.

        Sanity checking runs before training starts and is invisible in most run logs; emitting the notice there would
        spend the single announcement on a pass the user is least likely to be watching.
        """
        mock_logger = mocker.patch("rfdetr.training.module_model.logger")
        module = self._build_module_with_trainer(tmp_path, sanity_checking=True)

        module.on_validation_epoch_start()

        mock_logger.info.assert_not_called()


class TestValidationLossPolicyCaching:
    """_should_compute_val_loss reuses the resolution that on_validation_epoch_start cached for the running epoch."""

    def test_per_batch_reads_reuse_epoch_resolution(self, tmp_path):
        """A callback attached mid-epoch does not change the policy the running validation epoch already resolved.

        The resolution walks every configured callback, so ``validation_step`` must not redo it per batch. Mutating
        ``trainer.callbacks`` after the epoch hook ran is the observable proxy: an unchanged answer proves the batch
        read came from the cached resolution rather than a fresh scan.
        """
        tc = _base_train_config(tmp_path, compute_val_loss="auto")
        module, *_ = _build_module(train_config=tc, tmp_path=tmp_path)
        module.trainer = SimpleNamespace(callbacks=[], sanity_checking=False, is_global_zero=True)
        module.on_validation_epoch_start()

        module.trainer.callbacks.append(SimpleNamespace(monitor="val/loss"))

        assert module._should_compute_val_loss is False

    def test_resolution_is_refreshed_at_every_validation_epoch(self, tmp_path):
        """Each validation epoch re-resolves the policy, so a fit -> validate transition cannot serve a stale answer."""
        tc = _base_train_config(tmp_path, compute_val_loss="auto")
        module, *_ = _build_module(train_config=tc, tmp_path=tmp_path)
        module.trainer = SimpleNamespace(callbacks=[], sanity_checking=False, is_global_zero=True)
        module.on_validation_epoch_start()

        module.trainer.callbacks.append(SimpleNamespace(monitor="val/loss"))
        module.on_validation_epoch_start()

        assert module._should_compute_val_loss is True


@pytest.mark.parametrize(
    ("step", "prefix", "loss_flag"),
    [("validation_step", "val", "compute_val_loss"), ("test_step", "test", "compute_test_loss")],
)
class TestEvalStepOutputs:
    """validation_step() and test_step() share one forward+postprocess contract and differ in the metric prefix."""

    @staticmethod
    def _run(tmp_path: Path, step: str, loss_flag: str, compute_loss: bool = True) -> SimpleNamespace:
        """Run one eval step on a fake module and return the pieces the tests inspect."""
        tc = _base_train_config(tmp_path, **{loss_flag: compute_loss})
        module, fake_model, fake_criterion, fake_pp = _build_module(train_config=tc, tmp_path=tmp_path)
        samples, targets = _make_batch()
        fake_model.return_value = {}
        fake_criterion.return_value = {"loss_ce": torch.tensor(0.5)}
        fake_criterion.weight_dict = {"loss_ce": 1.0}
        module.log = MagicMock()
        module.log_dict = MagicMock()
        result = getattr(module, step)((samples, targets), batch_idx=0)
        return SimpleNamespace(
            result=result,
            module=module,
            model=fake_model,
            criterion=fake_criterion,
            postprocess=fake_pp,
            samples=samples,
        )

    @pytest.mark.parametrize("key", ["results", "targets"])
    def test_returns_dict_with_required_key(self, tmp_path, step, prefix, loss_flag, key):
        """The output dict carries both 'results' and 'targets' for downstream metric computation."""
        run = self._run(tmp_path, step, loss_flag)

        assert key in run.result

    def test_postprocess_called_with_orig_sizes(self, tmp_path, step, prefix, loss_flag):
        """The postprocessor receives original image sizes to rescale predictions."""
        run = self._run(tmp_path, step, loss_flag)

        run.postprocess.assert_called_once()
        assert run.postprocess.call_args[0][1].shape == (2, 2)

    def test_logs_loss_under_own_prefix_only(self, tmp_path, step, prefix, loss_flag):
        """The loss is logged once as '<prefix>/loss' and never under the other step's namespace."""
        run = self._run(tmp_path, step, loss_flag)

        logged = [c[0][0] for c in run.module.log.call_args_list]
        assert logged.count(f"{prefix}/loss") == 1
        assert ({"val/loss", "test/loss"} - {f"{prefix}/loss"}).isdisjoint(logged)

    def test_model_called_with_samples_only(self, tmp_path, step, prefix, loss_flag):
        """The step passes only samples (not targets) to the model forward."""
        run = self._run(tmp_path, step, loss_flag)

        run.model.assert_called_once_with(run.samples)

    def test_can_disable_loss_computation(self, tmp_path, step, prefix, loss_flag):
        """Disabling the loss flag skips the criterion call and the '<prefix>/loss' log."""
        run = self._run(tmp_path, step, loss_flag, compute_loss=False)

        run.criterion.assert_not_called()
        assert f"{prefix}/loss" not in [c[0][0] for c in run.module.log.call_args_list]
        assert "results" in run.result and "targets" in run.result


class TestConfigureOptimizers:
    """Tests for configure_optimizers().

    Covers required output keys, AdamW optimizer type, step-interval scheduler, LR lambda warmup ramp, and step-decay
    behaviour before and after lr_drop.
    """

    def _setup_module(self, tmp_path, **train_overrides):
        tc = _base_train_config(tmp_path, **train_overrides)
        module, _, _, _ = _build_module(train_config=tc)

        _attach_trainer(module, estimated_stepping_batches=1000)

        real_param = nn.Parameter(torch.randn(4, 4))
        param_dicts = [{"params": real_param, "lr": tc.lr}]
        return module, param_dicts

    @pytest.mark.parametrize(
        "key",
        [
            pytest.param("optimizer", id="optimizer-key"),
            pytest.param("lr_scheduler", id="lr-scheduler-key"),
        ],
    )
    def test_returns_required_key(self, mocker, key, tmp_path):
        """Lightning requires both 'optimizer' and 'lr_scheduler' keys in the returned config dict."""
        mock_get_param_dict = mocker.patch("rfdetr.training.module_model.get_param_dict")
        module, param_dicts = self._setup_module(tmp_path)
        mock_get_param_dict.return_value = param_dicts

        assert key in module.configure_optimizers()

    def test_optimizer_is_adamw(self, mocker, tmp_path):
        """RF-DETR must use AdamW for its decoupled weight decay behavior."""
        mock_get_param_dict = mocker.patch("rfdetr.training.module_model.get_param_dict")
        module, param_dicts = self._setup_module(tmp_path)
        mock_get_param_dict.return_value = param_dicts

        assert isinstance(module.configure_optimizers()["optimizer"], torch.optim.AdamW)

    def test_adamw_optimizer_kwargs_forwarded(self, mocker, tmp_path):
        """optimizer_kwargs are forwarded to RF-DETR's default AdamW optimizer."""
        mock_get_param_dict = mocker.patch("rfdetr.training.module_model.get_param_dict")
        optimizer_kwargs = {"betas": (0.8, 0.95), "eps": 1e-7}
        module, param_dicts = self._setup_module(tmp_path, optimizer_kwargs=optimizer_kwargs)
        mock_get_param_dict.return_value = param_dicts

        optimizer = module.configure_optimizers()["optimizer"]

        assert optimizer.defaults["betas"] == optimizer_kwargs["betas"]
        assert optimizer.defaults["eps"] == pytest.approx(optimizer_kwargs["eps"])

    def test_managed_optimizer_resolves_native_class(self, mocker, tmp_path):
        """Managed short names resolve to a native torch.optim class with lr/weight_decay injected."""
        mock_get_param_dict = mocker.patch("rfdetr.training.module_model.get_param_dict")
        module, param_dicts = self._setup_module(tmp_path, optimizer="sgd")
        mock_get_param_dict.return_value = param_dicts

        mock_resolve = mocker.patch(
            "rfdetr.training.module_model._resolve_native_optimizer", return_value=_RecordingOptimizer
        )
        optimizer = module.configure_optimizers()["optimizer"]

        mock_resolve.assert_called_once_with("sgd")
        assert isinstance(optimizer, _RecordingOptimizer)
        assert optimizer.defaults["lr"] == pytest.approx(module.train_config.lr)
        assert optimizer.defaults["weight_decay"] == pytest.approx(module.train_config.weight_decay)

    def test_managed_optimizer_preserves_rfdetr_param_groups(self, mocker, tmp_path):
        """Managed optimizers must receive RF-DETR param groups with layer-wise LR values."""
        mock_get_param_dict = mocker.patch("rfdetr.training.module_model.get_param_dict")
        module, param_dicts = self._setup_module(tmp_path, optimizer="sgd")
        param_dicts[0]["lr"] = 2.5e-5
        mock_get_param_dict.return_value = param_dicts

        mocker.patch("rfdetr.training.module_model._resolve_native_optimizer", return_value=_RecordingOptimizer)
        optimizer = module.configure_optimizers()["optimizer"]

        assert optimizer.param_groups[0]["initial_lr"] == pytest.approx(2.5e-5)

    def test_managed_optimizer_kwargs_forwarded(self, mocker, tmp_path):
        """optimizer_kwargs are forwarded to a managed optimizer constructor."""
        mock_get_param_dict = mocker.patch("rfdetr.training.module_model.get_param_dict")
        optimizer_kwargs = {"momentum": 0.9, "nesterov": True}
        module, param_dicts = self._setup_module(tmp_path, optimizer="sgd", optimizer_kwargs=optimizer_kwargs)
        mock_get_param_dict.return_value = param_dicts

        mocker.patch("rfdetr.training.module_model._resolve_native_optimizer", return_value=_RecordingOptimizer)
        optimizer = module.configure_optimizers()["optimizer"]

        assert optimizer.extra_kwargs == optimizer_kwargs

    def test_callable_optimizer_called_with_param_groups_only(self, mocker, tmp_path):
        """A non-reconstructable callable optimizer is invoked with the param groups and nothing else."""
        mock_get_param_dict = mocker.patch("rfdetr.training.module_model.get_param_dict")
        module, param_dicts = self._setup_module(tmp_path, optimizer=lambda params: _RecordingOptimizer(params))
        mock_get_param_dict.return_value = param_dicts

        optimizer = module.configure_optimizers()["optimizer"]

        assert isinstance(optimizer, _RecordingOptimizer)
        assert optimizer.extra_kwargs == {}

    def test_dotted_optimizer_built_from_kwargs_without_injection(self, mocker, tmp_path):
        """A dotted-path optimizer is built from optimizer_kwargs only, with no lr/weight_decay injection."""
        mock_get_param_dict = mocker.patch("rfdetr.training.module_model.get_param_dict")
        module, param_dicts = self._setup_module(
            tmp_path, optimizer="torch.optim.AdamW", optimizer_kwargs={"weight_decay": 0.5}
        )
        mock_get_param_dict.return_value = param_dicts

        optimizer = module.configure_optimizers()["optimizer"]

        assert isinstance(optimizer, torch.optim.AdamW)
        assert optimizer.defaults["weight_decay"] == pytest.approx(0.5)
        # Explicit mode must not inject the config lr as the optimizer-level default.
        assert optimizer.defaults["lr"] == pytest.approx(1e-3)

    def test_uninstalled_import_path_optimizer_raises_value_error(self, mocker, tmp_path):
        """A dotted import path that cannot be imported surfaces as a configuration error at train start."""
        mock_get_param_dict = mocker.patch("rfdetr.training.module_model.get_param_dict")
        module, param_dicts = self._setup_module(tmp_path, optimizer="pytorch_optimizer.Lion")
        mock_get_param_dict.return_value = param_dicts

        mocker.patch("rfdetr.training.module_model.importlib.import_module", side_effect=ImportError("No module"))
        with pytest.raises(ValueError) as exc_info:
            module.configure_optimizers()
        assert "Could not import optimizer" in str(exc_info.value)

    @_requires_pytorch_optimizer
    def test_real_import_path_optimizer_smoke(self, mocker, tmp_path):
        """A real pytorch-optimizer optimizer can be built via its import path when installed."""
        mock_get_param_dict = mocker.patch("rfdetr.training.module_model.get_param_dict")
        module, param_dicts = self._setup_module(tmp_path, optimizer="pytorch_optimizer.Lion")
        mock_get_param_dict.return_value = param_dicts

        optimizer = module.configure_optimizers()["optimizer"]

        assert optimizer.__class__.__name__ == "Lion"

    def test_custom_optimizer_omits_weight_decay_when_unsupported(self, mocker, tmp_path):
        """weight_decay must not be injected into optimizers whose constructor does not accept it."""
        mock_get_param_dict = mocker.patch("rfdetr.training.module_model.get_param_dict")
        module, param_dicts = self._setup_module(tmp_path, optimizer="sgd")
        mock_get_param_dict.return_value = param_dicts

        mocker.patch("rfdetr.training.module_model._resolve_native_optimizer", return_value=_NoWeightDecayOptimizer)
        optimizer = module.configure_optimizers()["optimizer"]

        assert isinstance(optimizer, _NoWeightDecayOptimizer)
        assert "weight_decay" not in optimizer.defaults

    def test_fused_optimizer_warns_for_custom_optimizer_on_bf16(self, mocker, tmp_path):
        """A custom optimizer on a fused-eligible BF16/CUDA run must warn that fused_optimizer is ignored."""
        mocker.patch("rfdetr.training.module_model.torch.cuda.is_bf16_supported", return_value=True)
        mocker.patch("rfdetr.training.module_model.torch.cuda.is_available", return_value=True)
        mock_get_param_dict = mocker.patch("rfdetr.training.module_model.get_param_dict")
        module, param_dicts = self._setup_module(tmp_path, optimizer="sgd")
        mock_get_param_dict.return_value = param_dicts
        module._trainer.precision = "bf16-mixed"

        mocker.patch("rfdetr.training.module_model._resolve_native_optimizer", return_value=_RecordingOptimizer)
        mock_warning = mocker.patch("rfdetr.training.module_model.logger.warning")
        module.configure_optimizers()

        assert any("fused_optimizer=True is ignored" in str(call.args[0]) for call in mock_warning.call_args_list)

    def test_no_fused_warning_for_adamw_on_bf16(self, mocker, tmp_path):
        """The built-in AdamW path uses fused and must not emit the fused-ignored warning."""
        mocker.patch("rfdetr.training.module_model.torch.cuda.is_bf16_supported", return_value=True)
        mocker.patch("rfdetr.training.module_model.torch.cuda.is_available", return_value=True)
        mock_get_param_dict = mocker.patch("rfdetr.training.module_model.get_param_dict")
        module, param_dicts = self._setup_module(tmp_path)
        mock_get_param_dict.return_value = param_dicts
        module._trainer.precision = "bf16-mixed"

        mock_warning = mocker.patch("rfdetr.training.module_model.logger.warning")
        module.configure_optimizers()

        assert not any("fused_optimizer=True is ignored" in str(call.args[0]) for call in mock_warning.call_args_list)

    def test_adamw_construction_error_is_rewrapped(self, mocker, tmp_path):
        """An unsupported AdamW kwarg must surface as an RF-DETR-specific initialization error."""
        mock_get_param_dict = mocker.patch("rfdetr.training.module_model.get_param_dict")
        module, param_dicts = self._setup_module(tmp_path, optimizer_kwargs={"nonexistent_adamw_kwarg": True})
        mock_get_param_dict.return_value = param_dicts

        with pytest.raises(TypeError) as exc_info:
            module.configure_optimizers()
        assert "Failed to initialize optimizer 'adamw'" in str(exc_info.value)

    def test_pytorch_optimizer_construction_error_is_rewrapped(self, mocker, tmp_path):
        """A managed optimizer constructor failure must surface as an RF-DETR-specific initialization error."""
        mock_get_param_dict = mocker.patch("rfdetr.training.module_model.get_param_dict")
        module, param_dicts = self._setup_module(tmp_path, optimizer="sgd")
        mock_get_param_dict.return_value = param_dicts

        mocker.patch("rfdetr.training.module_model._resolve_native_optimizer", return_value=_RaisingOptimizer)
        with pytest.raises(TypeError) as exc_info:
            module.configure_optimizers()
        assert "Failed to initialize optimizer 'sgd'" in str(exc_info.value)

    def test_use_fused_optimizer_false_for_custom_optimizer(self, mocker, tmp_path):
        """Fused AdamW lifecycle must not activate for custom optimizers, even on BF16/CUDA."""
        mocker.patch("rfdetr.training.module_model.torch.cuda.is_available", return_value=True)
        mocker.patch("rfdetr.training.module_model.torch.cuda.is_bf16_supported", return_value=True)
        module, _ = self._setup_module(tmp_path, optimizer="sgd")
        module._trainer.precision = "bf16-mixed"

        assert module._use_fused_optimizer is False

    def test_use_fused_optimizer_true_for_adamw(self, mocker, tmp_path):
        """Fused AdamW must activate for the built-in AdamW optimizer on BF16/CUDA."""
        mocker.patch("rfdetr.training.module_model.torch.cuda.is_available", return_value=True)
        mocker.patch("rfdetr.training.module_model.torch.cuda.is_bf16_supported", return_value=True)
        module, _ = self._setup_module(tmp_path)
        module._trainer.precision = "bf16-mixed"

        assert module._use_fused_optimizer is True

    def test_scheduler_interval_is_step(self, mocker, tmp_path):
        """Scheduler must step per batch (not per epoch) for fine-grained warmup."""
        mock_get_param_dict = mocker.patch("rfdetr.training.module_model.get_param_dict")
        module, param_dicts = self._setup_module(tmp_path)
        mock_get_param_dict.return_value = param_dicts

        assert module.configure_optimizers()["lr_scheduler"]["interval"] == "step"

    @pytest.mark.parametrize(
        "step, expected_behavior",
        [
            pytest.param(0, "warmup_start", id="warmup-start"),
            pytest.param(50, "warmup_mid", id="warmup-midpoint"),
        ],
    )
    def test_lr_lambda_warmup_phase(self, mocker, step, expected_behavior, tmp_path):
        """LR lambda must produce a linear ramp during the warmup phase."""
        mock_get_param_dict = mocker.patch("rfdetr.training.module_model.get_param_dict")
        module, param_dicts = self._setup_module(tmp_path, warmup_epochs=1.0, epochs=10)
        module._trainer.estimated_stepping_batches = 1000
        mock_get_param_dict.return_value = param_dicts

        scheduler = module.configure_optimizers()["lr_scheduler"]["scheduler"]
        lr_lambda = scheduler.lr_lambdas[0]

        # steps_per_epoch=100, warmup_steps=100
        expected = float(step) / float(max(1, 100))
        assert lr_lambda(step) == pytest.approx(expected)

    @pytest.mark.parametrize(
        "step, expected_factor",
        [
            pytest.param(500, 1.0, id="before-lr-drop-epoch-8-times-100-steps-per-epoch-equals-800"),
            pytest.param(900, 0.1, id="after-lr-drop-epoch-decays-to-0.1"),
        ],
    )
    def test_lr_lambda_step_decay(self, mocker, tmp_path, step: int, expected_factor: float):
        """The step-decay LR multiplier stays at 1.0 before lr_drop and decays to 0.1 after it."""
        mock_get_param_dict = mocker.patch("rfdetr.training.module_model.get_param_dict")
        module, param_dicts = self._setup_module(
            tmp_path, warmup_epochs=0.0, epochs=10, lr_scheduler_kwargs={"lr_drop": 8}
        )
        module._trainer.estimated_stepping_batches = 1000
        mock_get_param_dict.return_value = param_dicts

        scheduler = module.configure_optimizers()["lr_scheduler"]["scheduler"]
        lr_lambda = scheduler.lr_lambdas[0]

        assert lr_lambda(step) == pytest.approx(expected_factor)

    def test_lr_lambda_cosine_reads_train_config_fields(self, mocker, tmp_path):
        """Cosine preset must read its floor from lr_scheduler_kwargs['min_factor']."""
        mock_get_param_dict = mocker.patch("rfdetr.training.module_model.get_param_dict")
        module, param_dicts = self._setup_module(
            tmp_path,
            warmup_epochs=0.0,
            epochs=10,
            lr_scheduler="cosine",
            lr_scheduler_kwargs={"min_factor": 0.2},
        )
        module._trainer.estimated_stepping_batches = 1000
        mock_get_param_dict.return_value = param_dicts

        scheduler = module.configure_optimizers()["lr_scheduler"]["scheduler"]
        lr_lambda = scheduler.lr_lambdas[0]

        # At the final step, cosine schedule must end at min_factor.
        assert lr_lambda(1000) == pytest.approx(0.2)

    def test_lr_lambda_step_default_drop_is_epoch_100(self, mocker, tmp_path):
        """With no ``lr_drop`` kwarg the step preset falls back to the managed default of 100 epochs."""
        mock_get_param_dict = mocker.patch("rfdetr.training.module_model.get_param_dict")
        module, param_dicts = self._setup_module(tmp_path, warmup_epochs=0.0, epochs=200)
        module._trainer.estimated_stepping_batches = 20000
        mock_get_param_dict.return_value = param_dicts

        scheduler = module.configure_optimizers()["lr_scheduler"]["scheduler"]
        lr_lambda = scheduler.lr_lambdas[0]

        # steps_per_epoch=100 -> drop at step 10000
        assert lr_lambda(9999) == pytest.approx(1.0)
        assert lr_lambda(10000) == pytest.approx(0.1)

    def test_lr_lambda_cosine_default_floor_is_zero(self, mocker, tmp_path):
        """With no ``min_factor`` kwarg the cosine preset anneals to the managed default floor of 0.0."""
        mock_get_param_dict = mocker.patch("rfdetr.training.module_model.get_param_dict")
        module, param_dicts = self._setup_module(tmp_path, warmup_epochs=0.0, epochs=10, lr_scheduler="cosine")
        module._trainer.estimated_stepping_batches = 1000
        mock_get_param_dict.return_value = param_dicts

        scheduler = module.configure_optimizers()["lr_scheduler"]["scheduler"]
        lr_lambda = scheduler.lr_lambdas[0]

        assert lr_lambda(1000) == pytest.approx(0.0)

    def test_explicit_dotted_scheduler_builds_from_kwargs(self, mocker, tmp_path):
        """An explicit dotted-path lr_scheduler is built from lr_scheduler_kwargs verbatim."""
        mock_get_param_dict = mocker.patch("rfdetr.training.module_model.get_param_dict")
        module, param_dicts = self._setup_module(
            tmp_path,
            warmup_epochs=0.0,
            lr_scheduler="torch.optim.lr_scheduler.StepLR",
            lr_scheduler_kwargs={"step_size": 30, "gamma": 0.1},
        )
        module._trainer.estimated_stepping_batches = 1000
        mock_get_param_dict.return_value = param_dicts

        scheduler = module.configure_optimizers()["lr_scheduler"]["scheduler"]

        assert isinstance(scheduler, torch.optim.lr_scheduler.StepLR)
        assert scheduler.step_size == 30
        assert scheduler.gamma == pytest.approx(0.1)

    def test_per_parameter_lr_lambda_list_is_collapsed_onto_merged_groups(self, mocker, tmp_path):
        """A legacy per-parameter lr_lambda list is regrouped to one callback per merged group."""
        mock_get_param_dict = mocker.patch("rfdetr.training.module_model.get_param_dict")
        mock_build_param_dicts = mocker.patch("rfdetr.training.module_model._build_param_dicts")

        def shared_lambda(step: int) -> float:
            return 1.0

        module, param_dicts = self._setup_module(
            tmp_path,
            warmup_epochs=0.0,
            lr_scheduler="torch.optim.lr_scheduler.LambdaLR",
            lr_scheduler_kwargs={"lr_lambda": [shared_lambda, shared_lambda]},
        )
        mock_get_param_dict.return_value = param_dicts
        lr = module.train_config.lr
        mock_build_param_dicts.return_value = [
            {"params": nn.Parameter(torch.randn(2)), "lr": lr},
            {"params": nn.Parameter(torch.randn(2)), "lr": lr},
        ]

        scheduler = module.configure_optimizers()["lr_scheduler"]["scheduler"]

        assert scheduler.lr_lambdas == [shared_lambda]

    def test_managed_preset_builds_lambda_lr(self, mocker, tmp_path):
        """A managed preset still builds a LambdaLR at step interval."""
        mock_get_param_dict = mocker.patch("rfdetr.training.module_model.get_param_dict")
        module, param_dicts = self._setup_module(tmp_path, lr_scheduler="step")
        module._trainer.estimated_stepping_batches = 1000
        mock_get_param_dict.return_value = param_dicts

        config = module.configure_optimizers()["lr_scheduler"]

        assert isinstance(config["scheduler"], torch.optim.lr_scheduler.LambdaLR)
        assert config["interval"] == "step"

    def test_callable_scheduler_built_from_optimizer_only(self, mocker, tmp_path):
        """A non-reconstructable callable scheduler is invoked with the optimizer and nothing else."""
        mock_get_param_dict = mocker.patch("rfdetr.training.module_model.get_param_dict")
        module, param_dicts = self._setup_module(
            tmp_path,
            warmup_epochs=0.0,
            lr_scheduler=lambda optimizer: torch.optim.lr_scheduler.StepLR(optimizer, step_size=11),
        )
        module._trainer.estimated_stepping_batches = 1000
        mock_get_param_dict.return_value = param_dicts

        scheduler = module.configure_optimizers()["lr_scheduler"]["scheduler"]

        assert isinstance(scheduler, torch.optim.lr_scheduler.StepLR)
        assert scheduler.step_size == 11

    def test_explicit_scheduler_auto_wrapped_with_warmup(self, mocker, tmp_path):
        """With warmup_epochs>0 an explicit scheduler is wrapped in a SequentialLR linear warmup."""
        mock_get_param_dict = mocker.patch("rfdetr.training.module_model.get_param_dict")
        module, param_dicts = self._setup_module(
            tmp_path,
            warmup_epochs=1.0,
            lr_scheduler="torch.optim.lr_scheduler.StepLR",
            lr_scheduler_kwargs={"step_size": 5},
        )
        module._trainer.estimated_stepping_batches = 1000
        mock_get_param_dict.return_value = param_dicts

        scheduler = module.configure_optimizers()["lr_scheduler"]["scheduler"]

        assert isinstance(scheduler, torch.optim.lr_scheduler.SequentialLR)

    def test_epoch_interval_warmup_ramps_over_multiple_epochs(self, mocker, tmp_path):
        """An epoch-interval explicit scheduler gets a real warmup ramp sized in whole epochs (not optimizer steps)."""
        mock_get_param_dict = mocker.patch("rfdetr.training.module_model.get_param_dict")
        module, param_dicts = self._setup_module(
            tmp_path,
            warmup_epochs=3.0,
            epochs=10,
            lr_scheduler="torch.optim.lr_scheduler.StepLR",
            lr_scheduler_kwargs={"step_size": 5},
            lr_scheduler_interval="epoch",
        )
        module._trainer.estimated_stepping_batches = 1000  # steps_per_epoch = 100
        mock_get_param_dict.return_value = param_dicts

        scheduler = module.configure_optimizers()["lr_scheduler"]["scheduler"]

        # The ramp spans 3 epoch-steps (not 300 optimizer-steps) and actually ramps up (start_factor < 1.0).
        assert isinstance(scheduler, torch.optim.lr_scheduler.SequentialLR)
        warmup = scheduler._schedulers[0]
        assert warmup.total_iters == 3
        assert warmup.start_factor < 1.0

    def test_epoch_interval_single_epoch_warmup_warns_and_skips(self, mocker, tmp_path):
        """A single-epoch epoch-interval warmup cannot ramp; it warns and is skipped, not silently flat."""
        mock_get_param_dict = mocker.patch("rfdetr.training.module_model.get_param_dict")
        mock_logger = mocker.patch("rfdetr.training.module_model.logger")
        module, param_dicts = self._setup_module(
            tmp_path,
            warmup_epochs=1.0,
            epochs=10,
            lr_scheduler="torch.optim.lr_scheduler.StepLR",
            lr_scheduler_kwargs={"step_size": 5},
            lr_scheduler_interval="epoch",
        )
        module._trainer.estimated_stepping_batches = 1000
        mock_get_param_dict.return_value = param_dicts

        scheduler = module.configure_optimizers()["lr_scheduler"]["scheduler"]

        # No degenerate flat SequentialLR wrap; the no-op warmup is skipped loudly instead.
        assert not isinstance(scheduler, torch.optim.lr_scheduler.SequentialLR)
        mock_logger.warning.assert_called_once()

    def test_explicit_scheduler_interval_propagates(self, mocker, tmp_path):
        """lr_scheduler_interval is forwarded to the Lightning scheduler config for explicit schedulers."""
        mock_get_param_dict = mocker.patch("rfdetr.training.module_model.get_param_dict")
        module, param_dicts = self._setup_module(
            tmp_path,
            warmup_epochs=0.0,
            lr_scheduler="torch.optim.lr_scheduler.StepLR",
            lr_scheduler_kwargs={"step_size": 5},
            lr_scheduler_interval="epoch",
        )
        module._trainer.estimated_stepping_batches = 1000
        mock_get_param_dict.return_value = param_dicts

        assert module.configure_optimizers()["lr_scheduler"]["interval"] == "epoch"

    def test_reduce_on_plateau_sets_monitor_and_epoch_interval(self, mocker, tmp_path):
        """A plateau loss monitor makes automatic validation loss available each epoch."""
        mock_get_param_dict = mocker.patch("rfdetr.training.module_model.get_param_dict")
        module, param_dicts = self._setup_module(
            tmp_path,
            warmup_epochs=0.0,
            lr_scheduler="torch.optim.lr_scheduler.ReduceLROnPlateau",
            lr_scheduler_monitor="val/loss",
        )
        module._trainer.estimated_stepping_batches = 1000
        mock_get_param_dict.return_value = param_dicts

        config = module.configure_optimizers()["lr_scheduler"]

        assert isinstance(config["scheduler"], torch.optim.lr_scheduler.ReduceLROnPlateau)
        assert config["monitor"] == "val/loss"
        assert config["interval"] == "epoch"
        assert module._should_compute_val_loss is True

    def test_reduce_on_plateau_records_each_group_initial_lr(self, mocker, tmp_path: Path) -> None:
        """A resumed run rescales its reduced lr from the recorded initial lr when ``lr`` changes (#1613).

        Every other scheduler sets ``initial_lr`` itself.
        """
        mock_get_param_dict = mocker.patch("rfdetr.training.module_model.get_param_dict")
        module, param_dicts = self._setup_module(
            tmp_path,
            warmup_epochs=0.0,
            lr_scheduler="torch.optim.lr_scheduler.ReduceLROnPlateau",
            lr_scheduler_monitor="train/loss",
        )
        mock_get_param_dict.return_value = param_dicts

        optimizer = module.configure_optimizers()["optimizer"]

        assert optimizer.param_groups[0]["initial_lr"] == module.train_config.lr

    @pytest.mark.parametrize(
        ("train_overrides", "expected_base"),
        [
            pytest.param({"warmup_epochs": 1.0}, 1e-4, id="managed-warmup"),
            pytest.param(
                {
                    "warmup_epochs": 0.0,
                    "lr_scheduler": "torch.optim.lr_scheduler.OneCycleLR",
                    "lr_scheduler_kwargs": {"max_lr": 1e-3, "total_steps": 100},
                },
                1e-3 / 25,
                id="one-cycle",
            ),
        ],
    )
    def test_records_each_group_base_as_its_scheduler_set_it(
        self, mocker, train_overrides: dict[str, Any], expected_base: float, tmp_path: Path
    ) -> None:
        """A resumed run compares the recorded base with the restored one (#1613).

        The base is the scheduler's own: not the warmup-scaled current lr and, for a scheduler that sets its own rates
        (OneCycleLR starts at ``max_lr / 25``), not ``lr``.
        """
        mock_get_param_dict = mocker.patch("rfdetr.training.module_model.get_param_dict")
        module, param_dicts = self._setup_module(tmp_path, **train_overrides)
        mock_get_param_dict.return_value = param_dicts

        module.configure_optimizers()

        assert module._configured_param_group_settings[0][0] == pytest.approx(expected_base)

    def test_callable_plateau_scheduler_rejects_disabled_val_loss(self, mocker, tmp_path):
        """A closure-built ReduceLROnPlateau monitoring val/loss is rejected when compute_val_loss=False.

        ``TrainConfig.validate_explicit_val_loss_disable`` only string-compares ``lr_scheduler`` against the
        ReduceLROnPlateau dotted path, and a lambda closure — unlike a plain ``functools.partial``, which is desugared
        to that path — never reaches the comparison. The runtime check in ``configure_optimizers`` is therefore the only
        guard left once the concrete scheduler exists.
        """
        mock_get_param_dict = mocker.patch("rfdetr.training.module_model.get_param_dict")
        with warnings.catch_warnings():
            # A lambda lr_scheduler cannot round-trip through training_config.json; that reproducibility warning is
            # expected here and unrelated to the conflict under test.
            warnings.simplefilter("ignore", UserWarning)
            module, param_dicts = self._setup_module(
                tmp_path,
                warmup_epochs=0.0,
                lr_scheduler=lambda optimizer: torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, factor=0.5),
                lr_scheduler_monitor="val/loss",
                compute_val_loss=False,
            )
        mock_get_param_dict.return_value = param_dicts

        with pytest.raises(ValueError) as exc_info:
            module.configure_optimizers()
        assert "incompatible with ReduceLROnPlateau" in str(exc_info.value)

    def test_uninstalled_scheduler_path_raises_value_error(self, mocker, tmp_path):
        """A dotted scheduler path that cannot be imported surfaces as a configuration error at train start."""
        mock_get_param_dict = mocker.patch("rfdetr.training.module_model.get_param_dict")
        module, param_dicts = self._setup_module(tmp_path, lr_scheduler="nonexistent_pkg.MyScheduler")
        mock_get_param_dict.return_value = param_dicts

        mocker.patch("rfdetr.training.module_model.importlib.import_module", side_effect=ImportError("No module"))
        with pytest.raises(ValueError) as exc_info:
            module.configure_optimizers()
        assert "Could not import lr_scheduler" in str(exc_info.value)

    def test_explicit_scheduler_construction_error_is_reraised(self, mocker, tmp_path):
        """A missing required scheduler kwarg surfaces as an RF-DETR configuration error, not a bare TypeError."""
        mock_get_param_dict = mocker.patch("rfdetr.training.module_model.get_param_dict")
        module, param_dicts = self._setup_module(
            tmp_path,
            warmup_epochs=0.0,
            lr_scheduler="torch.optim.lr_scheduler.StepLR",  # StepLR requires step_size
            lr_scheduler_kwargs={},
        )
        module._trainer.estimated_stepping_batches = 1000
        mock_get_param_dict.return_value = param_dicts

        with pytest.raises(TypeError) as exc_info:
            module.configure_optimizers()
        assert "Failed to initialize lr_scheduler" in str(exc_info.value)

    def test_plateau_with_warmup_warns(self, mocker, tmp_path):
        """warmup_epochs>0 with ReduceLROnPlateau warns; a metric-driven scheduler cannot compose with a warmup ramp."""
        mock_get_param_dict = mocker.patch("rfdetr.training.module_model.get_param_dict")
        mock_logger = mocker.patch("rfdetr.training.module_model.logger")
        module, param_dicts = self._setup_module(
            tmp_path,
            warmup_epochs=1.0,
            lr_scheduler="torch.optim.lr_scheduler.ReduceLROnPlateau",
            lr_scheduler_monitor="val/loss",
        )
        module._trainer.estimated_stepping_batches = 1000
        mock_get_param_dict.return_value = param_dicts

        module.configure_optimizers()

        mock_logger.warning.assert_called_once()

    @pytest.mark.parametrize(
        "precision, expected_fused",
        [
            pytest.param(
                "32-true",
                False,
                id="not-bf16-disables-fused-even-though-the-gpu-supports-bf16",
            ),
            pytest.param(
                "bf16-mixed",
                True,
                id="bf16-mixed-enables-fused-params-grads-and-state-share-dtype-and-layout",
            ),
            pytest.param(
                "transformer-engine",
                True,
                id="transformer-engine-default-fp8-uses-bf16-weights-so-fused-stays-active",
            ),
        ],
    )
    def test_fused_optimizer_gating_by_precision(self, mocker, tmp_path, precision: str, expected_fused: bool):
        """Fused AdamW is enabled only for the precisions whose params/grads/state all stay BF16-compatible.

        On Ampere+ GPUs ``torch.cuda.is_bf16_supported()`` is True even when the trainer is configured for 32-true
        precision. The old code always enabled fused AdamW based on GPU capability alone, crashing with ``params, grads,
        exp_avgs, and exp_avg_sqs must have same dtype, device, and layout`` when DDP gradient bucket views had non-
        matching strides — the fix checks ``trainer.precision`` before enabling fused.
        """
        mocker.patch("rfdetr.training.module_model.torch.cuda.is_available", return_value=True)
        mocker.patch("rfdetr.training.module_model.torch.cuda.is_bf16_supported", return_value=True)
        mock_get_param_dict = mocker.patch("rfdetr.training.module_model.get_param_dict")
        module, param_dicts = self._setup_module(tmp_path)
        mock_get_param_dict.return_value = param_dicts
        module._trainer.precision = precision

        optimizer = module.configure_optimizers()["optimizer"]

        assert bool(optimizer.defaults.get("fused")) is expected_fused

    def test_fused_optimizer_disabled_when_cuda_unavailable(self, mocker, tmp_path):
        """_use_fused_optimizer must return False when CUDA is not available, regardless of precision."""
        mocker.patch("rfdetr.training.module_model.torch.cuda.is_available", return_value=False)
        module, _ = self._setup_module(tmp_path)
        module._trainer.precision = "bf16-mixed"

        assert not module._use_fused_optimizer

    def test_total_steps_divided_by_grad_accum_for_keypoint_module(self, mocker, tmp_path):
        """Keypoint (manual-opt) path must divide estimated_stepping_batches by grad_accum_steps for LR scheduling.

        With microbatches=100, grad_accum_steps=4, epochs=1, warmup_epochs=0 the scheduler should span 25 optimizer
        steps (ceil(100/4)).  At step 24 (0-indexed last step) a cosine LR schedule should be nearly at min_factor; if
        total_steps were mistakenly 100 the LR would still be near its peak at step 24.
        """
        mock_get_param_dict = mocker.patch("rfdetr.training.module_model.get_param_dict")
        grad_accum_steps = 4
        microbatches = 100
        min_factor = 0.1
        tc = _base_train_config(
            tmp_path,
            grad_accum_steps=grad_accum_steps,
            warmup_epochs=0,
            epochs=1,
            lr_scheduler="cosine",
            lr_scheduler_kwargs={"min_factor": min_factor},
        )
        module, _, _, _ = _build_module(
            model_config=_base_model_config(use_grouppose_keypoints=True, num_keypoints_per_class=[17]),
            train_config=tc,
        )
        _attach_trainer(module, estimated_stepping_batches=microbatches)
        real_param = nn.Parameter(torch.randn(4, 4))
        mock_get_param_dict.return_value = [{"params": real_param, "lr": tc.lr}]

        result = module.configure_optimizers()
        scheduler = result["lr_scheduler"]["scheduler"]
        lr_lambda = scheduler.lr_lambdas[0]

        expected_total_steps = max(1, math.ceil(microbatches / grad_accum_steps))  # 25
        # The cosine schedule reaches min_factor exactly at step == total_steps (progress=1.0).
        # If total_steps were wrongly 100, lr at step 25 would still be ~0.87 (near peak).
        lr_at_decay_end = lr_lambda(expected_total_steps)
        assert lr_at_decay_end == pytest.approx(min_factor, abs=1e-6)


class TestCudaGraphLifecycle:
    """Tests for enabling the graph runner after Lightning resolves runtime ownership."""

    def test_on_train_start_enables_single_cuda_detection(
        self, mocker, tmp_path: Path, caplog: pytest.LogCaptureFixture, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """A supported CUDA fit builds one runner around the registered detector and says so.

        The enable path must be as visible as the fallback warnings: without a log line a graph run
        and an eager run print identical consoles.
        """
        mc = _base_model_config(cuda_graphs=True, fused_optimizer=False)
        module, model, _, _ = _build_module(model_config=mc, train_config=_base_train_config(tmp_path))
        trainer = SimpleNamespace(world_size=1, precision="bf16-mixed")
        runner = MagicMock()
        monkeypatch.setattr(logging.getLogger("rf-detr"), "propagate", True)

        mocker.patch.object(type(module), "device", new_callable=PropertyMock, return_value=torch.device("cuda"))
        mocker.patch.object(type(module), "trainer", new_callable=PropertyMock, return_value=trainer)
        runner_type = mocker.patch("rfdetr.training.module_model.CudaGraphTrainingRunner", return_value=runner)
        with caplog.at_level(logging.INFO, logger="rf-detr"):
            module.on_train_start()

        runner_type.assert_called_once_with(model)
        assert module._cuda_graph_runner is runner
        assert any("CUDA graph replay enabled" in record.getMessage() for record in caplog.records)

    def test_on_train_start_leaves_replay_to_inductor_when_compiled(
        self, mocker, tmp_path: Path, caplog: pytest.LogCaptureFixture, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """When Inductor owns CUDA graph replay, the eager runner is never wrapped around the compiled model.

        ``make_graphed_callables`` over an ``OptimizedModule`` would capture Inductor's own launch path a second time;
        cudagraph trees already replay the compiled kernels. The console still announces which runtime replays.
        """
        mc = _base_model_config(cuda_graphs=True, compile=True, fused_optimizer=False)
        module, _, _, _ = _build_module(model_config=mc, train_config=_base_train_config(tmp_path))
        module._inductor_cudagraphs = True
        trainer = SimpleNamespace(world_size=1, precision="bf16-mixed")
        monkeypatch.setattr(logging.getLogger("rf-detr"), "propagate", True)

        mocker.patch.object(type(module), "device", new_callable=PropertyMock, return_value=torch.device("cuda"))
        mocker.patch.object(type(module), "trainer", new_callable=PropertyMock, return_value=trainer)
        runner_type = mocker.patch("rfdetr.training.module_model.CudaGraphTrainingRunner")
        with caplog.at_level(logging.INFO, logger="rf-detr"):
            module.on_train_start()

        runner_type.assert_not_called()
        assert module._cuda_graph_runner is None
        assert any("Inductor" in record.getMessage() for record in caplog.records)

    def test_on_train_start_keeps_compile_only_fallback_out_of_eager_capture(self, mocker, tmp_path: Path) -> None:
        """Gradient accumulation must not wrap a compiled fallback in the eager CUDA graph runner."""
        mc = _base_model_config(cuda_graphs=True, compile=True, fused_optimizer=False)
        tc = _base_train_config(tmp_path, grad_accum_steps=2)
        with (
            patch("rfdetr.config.DEVICE", "cuda"),
            patch("torch._inductor.config", SimpleNamespace(triton=SimpleNamespace())),
            patch("rfdetr.training.module_model.torch.compile", side_effect=lambda model, **_: model),
        ):
            module, _, _, _ = _build_module(model_config=mc, train_config=tc, tmp_path=tmp_path)

        trainer = SimpleNamespace(world_size=1, precision="bf16-mixed")
        mocker.patch.object(type(module), "device", new_callable=PropertyMock, return_value=torch.device("cuda"))
        mocker.patch.object(type(module), "trainer", new_callable=PropertyMock, return_value=trainer)
        runner_type = mocker.patch("rfdetr.training.module_model.CudaGraphTrainingRunner")
        module.on_train_start()

        assert module._compile_active is True
        assert module._inductor_cudagraphs is False
        runner_type.assert_not_called()
        assert module._cuda_graph_runner is None

    @pytest.mark.parametrize(
        "trainer",
        [
            pytest.param(SimpleNamespace(world_size=1, accumulate_grad_batches=2), id="accumulation"),
            pytest.param(SimpleNamespace(world_size=2, accumulate_grad_batches=1), id="distributed"),
        ],
    )
    def test_on_train_start_stops_when_trainer_leaves_inductor_scope(self, mocker, trainer, tmp_path: Path) -> None:
        """A trainer that resolved accumulation or several processes stops an Inductor graph run at train start.

        The construction-time gate reads ``TrainConfig``, but ``trainer_kwargs`` can override
        ``accumulate_grad_batches`` and ``devices="auto"`` can resolve to several GPUs. The model is already compiled
        with cudagraphs by then, so the run must stop with a clear message instead of failing on the second microbatch
        inside cudagraph trees.
        """
        mc = _base_model_config(cuda_graphs=True, compile=True, fused_optimizer=False)
        module, _, _, _ = _build_module(model_config=mc, train_config=_base_train_config(tmp_path))
        module._inductor_cudagraphs = True

        mocker.patch.object(type(module), "device", new_callable=PropertyMock, return_value=torch.device("cuda"))
        mocker.patch.object(type(module), "trainer", new_callable=PropertyMock, return_value=trainer)
        with pytest.raises(RuntimeError) as exc_info:
            module.on_train_start()

        assert "validated for single-GPU training without gradient accumulation" in str(exc_info.value)

    def test_on_train_start_disables_inductor_replay_when_trainer_resolves_cpu(self, mocker, tmp_path: Path) -> None:
        """A CUDA-capable construction must not mark graph steps after Lightning places the module on CPU."""
        mc = _base_model_config(cuda_graphs=True, compile=True, fused_optimizer=False)
        module, _, _, _ = _build_module(model_config=mc, train_config=_base_train_config(tmp_path))
        module._inductor_cudagraphs = True
        trainer = SimpleNamespace(world_size=1, accumulate_grad_batches=1, precision="bf16-mixed")

        mocker.patch.object(type(module), "device", new_callable=PropertyMock, return_value=torch.device("cpu"))
        mocker.patch.object(type(module), "trainer", new_callable=PropertyMock, return_value=trainer)
        runner_type = mocker.patch("rfdetr.training.module_model.CudaGraphTrainingRunner")
        module.on_train_start()

        assert module._inductor_cudagraphs is False
        runner_type.assert_not_called()

    def test_on_train_start_rejects_te_precision_override_of_inductor(self, mocker, tmp_path: Path) -> None:
        """A precision-plugin override cannot bypass the FP8 compile/capture separation."""
        mc = RFDETRNanoConfig(
            pretrain_weights=None, device="cpu", cuda_graphs=True, compile=True, fused_optimizer=False
        )
        module, _, _, _ = _build_module(model_config=mc, train_config=_base_train_config(tmp_path))
        module._inductor_cudagraphs = True
        trainer = SimpleNamespace(world_size=1, accumulate_grad_batches=1, precision="transformer-engine")
        mocker.patch.object(type(module), "device", new_callable=PropertyMock, return_value=torch.device("cuda"))
        mocker.patch.object(type(module), "trainer", new_callable=PropertyMock, return_value=trainer)
        with pytest.raises(RuntimeError) as exc_info:
            module.on_train_start()
        assert "FP8 CUDA graphs require compile=False" in str(exc_info.value)

    def test_on_train_start_keeps_cpu_training_eager(
        self, mocker, tmp_path: Path, caplog: pytest.LogCaptureFixture, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """An explicit graph request on CPU degrades visibly to eager training."""
        mc = _base_model_config(cuda_graphs=True, fused_optimizer=False)
        module, _, _, _ = _build_module(model_config=mc, train_config=_base_train_config(tmp_path))
        trainer = SimpleNamespace(world_size=1)
        monkeypatch.setattr(logging.getLogger("rf-detr"), "propagate", True)

        mocker.patch.object(type(module), "device", new_callable=PropertyMock, return_value=torch.device("cpu"))
        mocker.patch.object(type(module), "trainer", new_callable=PropertyMock, return_value=trainer)
        runner_type = mocker.patch("rfdetr.training.module_model.CudaGraphTrainingRunner")
        with caplog.at_level(logging.WARNING, logger="rf-detr"):
            module.on_train_start()

        runner_type.assert_not_called()
        assert module._cuda_graph_runner is None
        assert any("model is on 'cpu'" in record.getMessage() for record in caplog.records)

    def test_on_train_start_keeps_distributed_training_eager(self, mocker, tmp_path: Path) -> None:
        """DDP remains on its established eager path."""
        mc = _base_model_config(cuda_graphs=True, fused_optimizer=False)
        module, _, _, _ = _build_module(model_config=mc, train_config=_base_train_config(tmp_path))
        trainer = SimpleNamespace(world_size=2)

        mocker.patch.object(type(module), "device", new_callable=PropertyMock, return_value=torch.device("cuda"))
        mocker.patch.object(type(module), "trainer", new_callable=PropertyMock, return_value=trainer)
        runner_type = mocker.patch("rfdetr.training.module_model.CudaGraphTrainingRunner")
        module.on_train_start()

        runner_type.assert_not_called()
        assert module._cuda_graph_runner is None

    @pytest.mark.parametrize(
        "config_overrides",
        [
            pytest.param({"segmentation_head": True}, id="segmentation"),
            pytest.param(
                {"use_grouppose_keypoints": True, "num_keypoints_per_class": [1]},
                id="keypoints",
            ),
            pytest.param({"gradient_checkpointing": True}, id="gradient-checkpointing"),
        ],
    )
    def test_on_train_start_keeps_unsupported_model_modes_eager(
        self, mocker, config_overrides: dict[str, object], tmp_path: Path
    ) -> None:
        """Known-unsupported model modes never enter capture."""
        mc = _base_model_config(cuda_graphs=True, fused_optimizer=False, **config_overrides)
        module, _, _, _ = _build_module(model_config=mc, train_config=_base_train_config(tmp_path))
        trainer = SimpleNamespace(world_size=1)

        mocker.patch.object(type(module), "device", new_callable=PropertyMock, return_value=torch.device("cuda"))
        mocker.patch.object(type(module), "trainer", new_callable=PropertyMock, return_value=trainer)
        runner_type = mocker.patch("rfdetr.training.module_model.CudaGraphTrainingRunner")
        module.on_train_start()

        runner_type.assert_not_called()
        assert module._cuda_graph_runner is None

    def test_on_train_start_routes_fp8_to_te_with_live_recipe(self, mocker, tmp_path: Path) -> None:
        """FP8 capture receives the actual post-conversion Lightning recipe, not a new default."""
        mc = RFDETRNanoConfig(pretrain_weights=None, device="cpu", cuda_graphs=True, fused_optimizer=False)
        tc = _base_train_config(tmp_path, amp_dtype="fp8")
        module, model, _, _ = _build_module(model_config=mc, train_config=tc)
        recipe = object()
        trainer = SimpleNamespace(
            world_size=1,
            precision="transformer-engine",
            accumulate_grad_batches=1,
            precision_plugin=SimpleNamespace(recipe=recipe),
        )
        mocker.patch.object(type(module), "device", new_callable=PropertyMock, return_value=torch.device("cuda"))
        mocker.patch.object(type(module), "trainer", new_callable=PropertyMock, return_value=trainer)
        runner_type = mocker.patch("rfdetr.training.module_model.CudaGraphTrainingRunner")
        module.on_train_start()

        runner_type.assert_called_once_with(model, fp8_recipe=recipe)
        assert module._cuda_graph_runner is runner_type.return_value

    @pytest.mark.parametrize(
        ("train_overrides", "accumulation"),
        [
            pytest.param({"multi_scale": "per-batch"}, 1, id="per-batch-multi-scale"),
            pytest.param({"square_resize_div_64": False}, 1, id="aspect-ratio-resize"),
            pytest.param({"multi_scale": "per-sample"}, 1, id="per-sample-multi-scale"),
            pytest.param({}, 2, id="trainer-overrides-accumulation"),
        ],
    )
    def test_on_train_start_keeps_fp8_outside_fixed_shape_scope_eager(
        self, mocker, train_overrides: dict[str, object], accumulation: int, tmp_path: Path
    ) -> None:
        """FP8 scope is checked at final trainer placement, including accumulation overrides."""
        mc = RFDETRNanoConfig(pretrain_weights=None, device="cpu", cuda_graphs=True, fused_optimizer=False)
        tc = _base_train_config(tmp_path, amp_dtype="fp8", **train_overrides)
        module, _, _, _ = _build_module(model_config=mc, train_config=tc)
        trainer = SimpleNamespace(
            world_size=1,
            precision="transformer-engine",
            accumulate_grad_batches=accumulation,
            precision_plugin=SimpleNamespace(recipe=object()),
        )
        mocker.patch.object(type(module), "device", new_callable=PropertyMock, return_value=torch.device("cuda"))
        mocker.patch.object(type(module), "trainer", new_callable=PropertyMock, return_value=trainer)
        runner_type = mocker.patch("rfdetr.training.module_model.CudaGraphTrainingRunner")
        module.on_train_start()

        runner_type.assert_not_called()
        assert module._cuda_graph_runner is None

    def test_on_train_start_rejects_fp8_plugin_without_recipe(self, mocker, tmp_path: Path) -> None:
        """A missing Transformer Engine recipe cannot accidentally select the BF16 capture backend."""
        mc = RFDETRNanoConfig(pretrain_weights=None, device="cpu", cuda_graphs=True, fused_optimizer=False)
        module, _, _, _ = _build_module(model_config=mc, train_config=_base_train_config(tmp_path, amp_dtype="fp8"))
        trainer = SimpleNamespace(world_size=1, precision="transformer-engine", precision_plugin=SimpleNamespace())
        mocker.patch.object(type(module), "device", new_callable=PropertyMock, return_value=torch.device("cuda"))
        mocker.patch.object(type(module), "trainer", new_callable=PropertyMock, return_value=trainer)
        with pytest.raises(RuntimeError) as exc_info:
            module.on_train_start()
        assert "recipe" in str(exc_info.value)

    @pytest.mark.parametrize("precision", ["16-mixed", "32-true", "transformer-engine-float16"])
    def test_on_train_start_keeps_non_bf16_precision_eager(self, mocker, precision: str, tmp_path: Path) -> None:
        """FP16, FP32 and Transformer Engine with FP16 fallback stay outside the supported capture paths."""
        mc = _base_model_config(cuda_graphs=True, fused_optimizer=False)
        module, _, _, _ = _build_module(model_config=mc, train_config=_base_train_config(tmp_path))
        trainer = SimpleNamespace(world_size=1, precision=precision)

        mocker.patch.object(type(module), "device", new_callable=PropertyMock, return_value=torch.device("cuda"))
        mocker.patch.object(type(module), "trainer", new_callable=PropertyMock, return_value=trainer)
        runner_type = mocker.patch("rfdetr.training.module_model.CudaGraphTrainingRunner")
        module.on_train_start()

        runner_type.assert_not_called()
        assert module._cuda_graph_runner is None


def _module_with_restored_optimizer(
    tmp_path: Path, configured: list[tuple[float, float | None]], *, restarts: bool
) -> tuple[RFDETRModelModule, torch.optim.Optimizer]:
    """Build a module whose optimizer holds one group restored from an older ``ReduceLROnPlateau`` checkpoint.

    The group trained at 0.1 and was reduced to 0.025, and records no ``initial_lr``. The module is marked as resuming
    with an explicit setting, as ``on_load_checkpoint`` leaves it.

    Args:
        tmp_path: Directory for the module's config.
        configured: What ``configure_optimizers`` recorded; empty when a subclass replaced it.
        restarts: Whether a learning-rate setting changed, so groups without a base restart.

    Returns:
        The module and its restored optimizer.

    Examples:
        >>> import tempfile
        >>> with tempfile.TemporaryDirectory() as directory:
        ...     module, optimizer = _module_with_restored_optimizer(Path(directory), [(0.1, 0.0)], restarts=True)
        >>> optimizer.param_groups[0]["lr"], module._reapplied_param_group_settings
        (0.025, ['lr'])
    """
    module, *_ = _build_module(tmp_path=tmp_path)
    optimizer = torch.optim.AdamW([nn.Parameter(torch.zeros(1))], lr=0.025, weight_decay=0.0)
    module.optimizers = MagicMock(return_value=optimizer)
    module._current_lr_scheduler = MagicMock(return_value=None)
    module._configured_param_group_settings = configured
    module._reapplied_param_group_settings = ["lr"]
    module._restarts_groups_without_base = restarts
    return module, optimizer


class TestReapplyConfiguredParamGroupSettings:
    """``on_train_start`` puts the configured settings back over a resumed checkpoint's optimizer state (#1613)."""

    @pytest.fixture(autouse=True)
    def fed_by(self, monkeypatch: pytest.MonkeyPatch) -> MagicMock:
        """Stand in for the model-dependent mask: every explicit setting feeds every group.

        Examples:
            >>> fed_by  # doctest: +SKIP
            A pytest fixture; it needs monkeypatch.
        """
        mock = MagicMock(side_effect=lambda names, configured, *_: configured)
        monkeypatch.setattr("rfdetr.training.module_model._configured_settings_fed_by", mock)
        return mock

    def test_explicit_settings_mask_configured_ones(self, tmp_path: Path, fed_by: MagicMock) -> None:
        """A group no explicit setting feeds keeps what the checkpoint's optimizer holds, stale ``args`` or not."""
        module, optimizer = _module_with_restored_optimizer(tmp_path, [(0.1, 0.0)], restarts=True)
        module._reapplied_param_group_settings = ["weight_decay"]
        fed_by.side_effect = lambda names, configured, *_: [(None, weight_decay) for _, weight_decay in configured]

        module._reapply_configured_param_group_settings()

        assert fed_by.call_args.args[0] == ["weight_decay"]
        assert optimizer.param_groups[0]["lr"] == 0.025

    @pytest.mark.parametrize(("restarts", "expected_lr"), [(True, 0.1), (False, 0.025)])
    def test_group_without_base_restarts_only_for_lr_change(
        self, tmp_path: Path, restarts: bool, expected_lr: float
    ) -> None:
        """A param group with no base lr is restarted only when the reapplied setting is a learning rate."""
        module, optimizer = _module_with_restored_optimizer(tmp_path, [(0.1, 0.0)], restarts=restarts)

        module._reapply_configured_param_group_settings()

        assert optimizer.param_groups[0]["lr"] == expected_lr

    def test_unfed_settings_leave_optimizer_alone_and_warn(
        self,
        tmp_path: Path,
        fed_by: MagicMock,
        caplog: pytest.LogCaptureFixture,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """Parameters the model does not own (FSDP, DeepSpeed) match no group; the resume must not pass silently."""
        module, optimizer = _module_with_restored_optimizer(tmp_path, [(0.1, 0.0)], restarts=True)
        fed_by.side_effect = lambda names, configured, *_: [(None, None)] * len(configured)
        monkeypatch.setattr(logging.getLogger("rf-detr"), "propagate", True)
        caplog.set_level(logging.WARNING, logger="rf-detr")

        module._reapply_configured_param_group_settings()

        assert optimizer.param_groups[0]["lr"] == 0.025
        assert "No parameter group of the resumed optimizer is fed by lr" in caplog.text

    def test_weight_decay_alone_is_put_back(self, tmp_path: Path, fed_by: MagicMock) -> None:
        """A resume that passes only ``weight_decay`` feeds no learning rate, but its weight decay still applies."""
        module, optimizer = _module_with_restored_optimizer(tmp_path, [(0.1, 0.05)], restarts=False)
        module._reapplied_param_group_settings = ["weight_decay"]
        fed_by.side_effect = lambda names, configured, *_: [(None, weight_decay) for _, weight_decay in configured]

        module._reapply_configured_param_group_settings()

        assert optimizer.param_groups[0]["weight_decay"] == 0.05

    def test_on_train_start_reapplies_once(self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
        """A second ``fit`` of the module carries no resumed state to put back."""
        module, _ = _module_with_restored_optimizer(tmp_path, [(0.1, 0.0)], restarts=True)
        module._reapply_configured_param_group_settings = MagicMock()
        module._configure_cuda_graph_runner = MagicMock()
        monkeypatch.setattr(RFDETRModelModule, "_use_fused_optimizer", False)

        module.on_train_start()
        module.on_train_start()

        assert module._reapply_configured_param_group_settings.call_count == 1

    def test_logs_how_many_groups_changed(
        self, tmp_path: Path, caplog: pytest.LogCaptureFixture, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """A resume hit by #1613 recorded the new ``lr`` already, so only this line reports the change."""
        module, _ = _module_with_restored_optimizer(tmp_path, [(0.1, 0.0)], restarts=True)
        monkeypatch.setattr(logging.getLogger("rf-detr"), "propagate", True)
        caplog.set_level(logging.INFO, logger="rf-detr")

        module._reapply_configured_param_group_settings()

        assert "Gave the learning rate and weight decay set for this run to 1 resumed parameter group(s)" in caplog.text

    def test_replaced_configure_optimizers_keeps_restored_optimizer(self, tmp_path: Path) -> None:
        """A subclass's own ``configure_optimizers`` records no settings, so there is nothing to compare with."""
        module, optimizer = _module_with_restored_optimizer(tmp_path, [], restarts=True)

        module._reapply_configured_param_group_settings()

        assert optimizer.param_groups[0]["lr"] == 0.025

    def test_replaced_configure_optimizers_is_reported(
        self, tmp_path: Path, caplog: pytest.LogCaptureFixture, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """A user-replaced ``configure_optimizers`` is reported with a warning when settings are reapplied."""
        module, _ = _module_with_restored_optimizer(tmp_path, [], restarts=True)
        monkeypatch.setattr(logging.getLogger("rf-detr"), "propagate", True)
        caplog.set_level(logging.WARNING, logger="rf-detr")

        module._reapply_configured_param_group_settings()

        assert "configure_optimizers was replaced" in caplog.text

    def test_several_optimizers_from_replaced_configure_optimizers_left_alone(self, tmp_path: Path) -> None:
        """Lightning returns a list when ``configure_optimizers`` built more than one optimizer."""
        module, optimizer = _module_with_restored_optimizer(tmp_path, [(0.1, 0.0)], restarts=True)
        module.optimizers = MagicMock(return_value=[optimizer, optimizer])

        module._reapply_configured_param_group_settings()

        assert optimizer.param_groups[0]["lr"] == 0.025


class TestFusedOptimizerResumeStateNormalization:
    """Resume-time fused AdamW state normalization in on_train_start()."""

    @pytest.fixture
    def fused_module(self, mocker) -> RFDETRModelModule:
        """Return a bare fused-AdamW module on bf16-mixed with CUDA reported available and ``optimizers`` mocked.

        Examples:
            >>> fused_module  # doctest: +SKIP
            A pytest fixture; it needs mocker.
        """
        mocker.patch("rfdetr.training.module_model.torch.cuda.is_available", return_value=True)
        mocker.patch("rfdetr.training.module_model.torch.cuda.is_bf16_supported", return_value=True)
        module = RFDETRModelModule.__new__(RFDETRModelModule)
        module.model_config = SimpleNamespace(fused_optimizer=True)
        module.train_config = SimpleNamespace(optimizer="adamw")
        module._reapplied_param_group_settings = []
        trainer = MagicMock()
        trainer.precision = "bf16-mixed"
        trainer.is_global_zero = True
        module._trainer = trainer
        module.optimizers = MagicMock()
        mocker.patch.object(type(module), "trainer", new_callable=PropertyMock, return_value=trainer)
        return module

    @pytest.mark.parametrize(
        ("wrapped", "exp_avg_value", "exp_avg_sq_value"),
        [
            pytest.param(False, 2.0, 3.0, id="plain-optimizer"),
            pytest.param(True, 4.0, 5.0, id="lightning-optimizer-wrapper"),
        ],
    )
    def test_on_train_start_normalizes_restored_fused_optimizer_state(
        self, fused_module, wrapped: bool, exp_avg_value: float, exp_avg_sq_value: float
    ) -> None:
        """Resumed fused AdamW state tensors must match the live parameter layout before the first step.

        A Lightning-style optimizer wrapper (exposing ``.optimizer``) must be unwrapped and normalized the same way.
        """
        optimizer_param = nn.Parameter(torch.arange(6.0, dtype=torch.bfloat16).reshape(2, 3).t())
        optimizer = torch.optim.AdamW([optimizer_param], lr=1e-3)
        optimizer.state[optimizer_param] = {
            "exp_avg": torch.full((3, 2), exp_avg_value, dtype=torch.float32),
            "exp_avg_sq": torch.full((3, 2), exp_avg_sq_value, dtype=torch.float64),
        }
        fused_module.optimizers.return_value = SimpleNamespace(optimizer=optimizer) if wrapped else optimizer

        fused_module.on_train_start()

        fused_module.optimizers.assert_called_once_with(use_pl_optimizer=False)
        state = optimizer.state[optimizer_param]
        assert state["exp_avg"].dtype == optimizer_param.dtype
        assert state["exp_avg"].stride() == optimizer_param.stride()
        assert state["exp_avg_sq"].dtype == optimizer_param.dtype
        assert state["exp_avg_sq"].stride() == optimizer_param.stride()
        torch.testing.assert_close(state["exp_avg"], torch.full_like(optimizer_param, exp_avg_value))
        torch.testing.assert_close(state["exp_avg_sq"], torch.full_like(optimizer_param, exp_avg_sq_value))

    def test_on_train_start_leaves_empty_optimizer_state_untouched(self, fused_module) -> None:
        """Fresh fused-optimizer runs with no restored state should remain a no-op."""
        optimizer_param = nn.Parameter(torch.ones((2, 2), dtype=torch.bfloat16))
        optimizer = torch.optim.AdamW([optimizer_param], lr=1e-3)
        fused_module.optimizers.return_value = optimizer

        fused_module.on_train_start()

        assert optimizer.state == {}


class TestConfigureGradientClipping:
    """Tests for configure_gradient_clipping() — verifies precision gating mirrors configure_optimizers()."""

    def _setup_module(self, tmp_path, precision: str):
        tc = _base_train_config(tmp_path)
        module, _, _, _ = _build_module(train_config=tc)
        _attach_trainer(module, precision=precision)
        return module

    @pytest.mark.parametrize(
        "precision",
        [
            pytest.param("32-true", id="fp32"),
            pytest.param("16-mixed", id="fp16-mixed"),
        ],
    )
    def test_delegates_to_clip_gradients_when_not_bf16(self, mocker, precision, tmp_path):
        """configure_gradient_clipping must delegate to clip_gradients() when trainer precision is not a BF16 variant.

        On Ampere+ GPUs is_bf16_supported() is True regardless of actual precision. The method must check
        trainer.precision before choosing the fused path, mirroring the same gate in configure_optimizers() to prevent
        silent divergence. ``clip_gradients`` itself is never overridden (PTL documents it as "do not override"), so the
        un-overridden base implementation on the module's own class is patched directly.
        """
        mocker.patch("rfdetr.training.module_model.torch.cuda.is_available", return_value=True)
        mocker.patch("rfdetr.training.module_model.torch.cuda.is_bf16_supported", return_value=True)
        module = self._setup_module(tmp_path, precision=precision)

        mock_clip_gradients = mocker.patch.object(type(module), "clip_gradients")
        module.configure_gradient_clipping(MagicMock(), gradient_clip_val=0.1)

        mock_clip_gradients.assert_called_once()

    def test_configure_gradient_clipping_uses_clip_grad_norm_when_bf16_mixed(self, mocker, tmp_path):
        """configure_gradient_clipping must call clip_grad_norm_ directly when precision is bf16-mixed.

        When fused AdamW is active (BF16, no GradScaler), the standard PTL AMP plugin refuses to clip gradients.
        clip_grad_norm_ is called directly instead, bypassing the scaler-aware path that would otherwise raise.
        """
        mock_clip_grad_norm = mocker.patch("rfdetr.training.module_model.torch.nn.utils.clip_grad_norm_")
        mocker.patch("rfdetr.training.module_model.torch.cuda.is_available", return_value=True)
        mocker.patch("rfdetr.training.module_model.torch.cuda.is_bf16_supported", return_value=True)
        module = self._setup_module(tmp_path, precision="bf16-mixed")

        module.configure_gradient_clipping(MagicMock(), gradient_clip_val=0.5)

        mock_clip_grad_norm.assert_called_once()
        _, _call_kwargs = mock_clip_grad_norm.call_args
        # Positional arg[1] is max_norm
        assert mock_clip_grad_norm.call_args[0][1] == pytest.approx(0.5)


class TestPredictStep:
    """Tests for predict_step().

    Verifies that only samples (not targets) are passed to the model, that postprocess receives the correct original
    sizes, and that the postprocessor output is returned directly to the caller.
    """

    def test_calls_postprocess_with_orig_sizes(self, build_module):
        """Postprocessor must receive a (batch, 2) tensor of original image sizes."""
        module, fake_model, _, fake_pp = build_module()
        samples, targets = _make_batch(batch_size=3)
        fake_model.return_value = {}

        module.predict_step((samples, targets), batch_idx=0)

        fake_pp.assert_called_once()
        orig_sizes = fake_pp.call_args[0][1]
        assert orig_sizes.shape == (3, 2)

    def test_returns_postprocess_output(self, build_module):
        """predict_step must return the postprocessor output directly to the caller."""
        module, fake_model, _, fake_pp = build_module()
        samples, targets = _make_batch()
        fake_model.return_value = {}
        expected_output = [{"boxes": torch.zeros(1, 4)}]
        fake_pp.return_value = expected_output

        assert module.predict_step((samples, targets), batch_idx=0) is expected_output

    def test_model_called_with_samples_only(self, build_module):
        """Inference must pass only samples (not targets) to the model forward."""
        module, fake_model, _, _ = build_module()
        samples, targets = _make_batch()
        fake_model.return_value = {}

        module.predict_step((samples, targets), batch_idx=0)

        fake_model.assert_called_once_with(samples)

    def test_default_dataloader_idx_is_zero(self, build_module):
        """predict_step must work with the default dataloader_idx without errors."""
        module, fake_model, _, _ = build_module()
        fake_model.return_value = {}

        # Should not raise with default dataloader_idx.
        module.predict_step(_make_batch(), batch_idx=0)


class TestReinitializeDetectionHead:
    """Tests for reinitialize_detection_head().

    Verifies that the module delegates to the underlying model and that arbitrary class counts are forwarded unchanged.
    """

    def test_delegates_to_model(self, build_module):
        """Module must delegate head reinitialization to the underlying model."""
        module, fake_model, _, _ = build_module()

        module.reinitialize_detection_head(num_classes=42)

        fake_model.reinitialize_detection_head.assert_called_once_with(42)

    @pytest.mark.parametrize(
        "num_classes",
        [
            pytest.param(1, id="single-class"),
            pytest.param(80, id="coco-80"),
            pytest.param(365, id="objects365"),
        ],
    )
    def test_passes_various_class_counts(self, num_classes, build_module):
        """Arbitrary class counts must be forwarded to the underlying model unchanged."""
        module, fake_model, _, _ = build_module()

        module.reinitialize_detection_head(num_classes=num_classes)

        fake_model.reinitialize_detection_head.assert_called_once_with(num_classes)


class TestOnLoadCheckpoint:
    """Tests for on_load_checkpoint().

    Covers legacy .pth normalisation and positional-embedding interpolation for custom-resolution PTL checkpoints.

    Regression: issue #998 — resume with custom resolution crashed because
    on_load_checkpoint did not interpolate PE before PTL applied the state dict.
    """

    _PE_KEY = "model.backbone.0.encoder.encoder.embeddings.position_embeddings"

    @pytest.mark.parametrize(
        ("optimizer_states", "expected_lr_encoder"),
        [
            pytest.param([{"state": {}, "param_groups": []}], 0.123, id="full-checkpoint"),
            pytest.param([], TrainConfig.model_fields["lr_encoder"].default, id="lightweight-checkpoint"),
        ],
    )
    def test_resolves_resumed_settings_without_a_trainer(
        self, optimizer_states: list[dict[str, Any]], expected_lr_encoder: float, tmp_path: Path
    ) -> None:
        """``load_from_checkpoint`` calls the hook before any trainer exists.

        Only a checkpoint carrying optimizer state supplies the settings left out (#1613); a lightweight one restarts
        the optimizer from the config.
        """
        module, *_ = _build_module(train_config=TrainConfig(dataset_dir=str(tmp_path)), tmp_path=tmp_path)

        module.on_load_checkpoint({"optimizer_states": optimizer_states, "args": {"lr_encoder": 0.123}})

        assert module.train_config.lr_encoder == expected_lr_encoder

    def _make_ptl_checkpoint(self, pe_size_src: int, _pe_size_tgt: int, dim: int = 16) -> dict:
        """Build a minimal PTL checkpoint with mismatched PE shape.

        Args:
            pe_size_src: Source grid side length (checkpoint was saved with this PE).
            _pe_size_tgt: Target grid side length (model was built with this PE),
                accepted for test readability but intentionally unused here.
            dim: Embedding dimension (small value for fast tests).

        Returns:
            Checkpoint dict in PTL format with ``state_dict`` key.
        """
        n_src = pe_size_src * pe_size_src + 1  # +1 for class token
        return {
            "state_dict": {
                self._PE_KEY: torch.randn(1, n_src, dim),
                "model.other_layer.weight": torch.randn(4, 4),
            },
            "epoch": 44,
            "global_step": 1000,
        }

    def _make_legacy_pth_checkpoint(self, pe_size_src: int, dim: int = 16) -> dict:
        """Build a minimal legacy .pth checkpoint (no ``state_dict`` key).

        Args:
            pe_size_src: Source grid side length.
            dim: Embedding dimension.

        Returns:
            Checkpoint dict in legacy format with ``model`` key only.
        """
        n_src = pe_size_src * pe_size_src + 1
        pe_key_no_prefix = self._PE_KEY[len("model.") :]
        return {
            "model": {
                pe_key_no_prefix: torch.randn(1, n_src, dim),
                "other_layer.weight": torch.randn(4, 4),
            }
        }

    @pytest.mark.parametrize(
        "pe_src,pe_tgt",
        [
            pytest.param(36, 56, id="pe_interpolated_in_ptl_checkpoint"),
            pytest.param(36, 36, id="pe_unchanged_when_shapes_match"),
        ],
    )
    def test_ptl_checkpoint_pe_shape(self, pe_src, pe_tgt, build_module):
        """on_load_checkpoint must produce PE with tokens matching the model's positional_encoding_size.

        Regression for #998: resume from .ckpt with custom resolution crashed because PTL applied the checkpoint state
        dict before PE shapes were reconciled.
        """
        checkpoint = self._make_ptl_checkpoint(pe_size_src=pe_src, _pe_size_tgt=pe_tgt)

        module, _, _, _ = build_module(model_config=_base_model_config(positional_encoding_size=pe_tgt))
        module.on_load_checkpoint(checkpoint)

        pe_after = checkpoint["state_dict"][self._PE_KEY]
        expected_tokens = pe_tgt * pe_tgt + 1
        assert pe_after.shape == (
            1,
            expected_tokens,
            16,
        ), f"PE should have {expected_tokens} tokens, got shape {tuple(pe_after.shape)}"

    def test_legacy_pth_normalised_and_pe_interpolated(self, build_module):
        """Legacy .pth checkpoint (no state_dict key) must be normalised and PE interpolated.

        on_load_checkpoint converts the raw "model" dict to PTL format and must also interpolate PE so that PTL's
        subsequent load_state_dict does not crash.
        """
        pe_src, pe_tgt = 36, 56
        checkpoint = self._make_legacy_pth_checkpoint(pe_size_src=pe_src)

        module, _, _, _ = build_module(model_config=_base_model_config(positional_encoding_size=pe_tgt))
        module.on_load_checkpoint(checkpoint)

        assert "state_dict" in checkpoint, "Legacy checkpoint must be normalised to PTL format."
        pe_after = checkpoint["state_dict"][self._PE_KEY]
        expected_tokens = pe_tgt * pe_tgt + 1
        assert pe_after.shape == (1, expected_tokens, 16)

    def test_non_pe_tensors_not_modified(self, build_module):
        """on_load_checkpoint must not alter non-PE tensors in the state dict."""
        pe_src, pe_tgt = 36, 56
        checkpoint = self._make_ptl_checkpoint(pe_size_src=pe_src, _pe_size_tgt=pe_tgt)
        original_other = checkpoint["state_dict"]["model.other_layer.weight"].clone()

        module, _, _, _ = build_module(model_config=_base_model_config(positional_encoding_size=pe_tgt))
        module.on_load_checkpoint(checkpoint)

        assert torch.equal(checkpoint["state_dict"]["model.other_layer.weight"], original_other)

    def test_state_dict_without_pe_or_extra_state_keys_is_unchanged(self, build_module):
        """on_load_checkpoint neither raises nor alters keys when state_dict has no PE and no `_extra_state` entries."""
        checkpoint = {
            "state_dict": {"model.some_layer.weight": torch.randn(4, 4)},
            "epoch": 1,
        }
        original_keys = set(checkpoint["state_dict"].keys())

        module, _, _, _ = build_module(model_config=_base_model_config(positional_encoding_size=36))
        module.on_load_checkpoint(checkpoint)

        assert set(checkpoint["state_dict"].keys()) == original_keys

    def test_extra_state_keys_stripped_from_state_dict(self, build_module):
        """on_load_checkpoint must remove `_extra_state` entries before PTL applies the state dict.

        Under FP8, the live module's checkpointed state_dict carries Transformer Engine `_extra_state` entries recording
        FP8 scaling history. `strict_loading=False` only tolerates their presence/absence after the fact — it does not
        stop `load_state_dict()` from calling `set_extra_state()` for a key present in both the checkpoint and the
        module, which Transformer Engine rejects on a pickle round-trip. The entries must therefore be excluded from
        `checkpoint["state_dict"]` here, before PTL ever applies it.
        """
        checkpoint = {
            "state_dict": {
                "model.some_layer.weight": torch.randn(4, 4),
                "model.some_layer._extra_state": b"fp8-scaling-history",
            },
            "epoch": 1,
        }

        module, _, _, _ = build_module(model_config=_base_model_config(positional_encoding_size=36))
        module.on_load_checkpoint(checkpoint)

        assert "model.some_layer._extra_state" not in checkpoint["state_dict"]
        assert "model.some_layer.weight" in checkpoint["state_dict"]


class TestManualOptLRSchedulerStepping:
    """Manual-optimization (keypoint) path steps LR schedulers itself, honoring interval and plateau semantics."""

    def _module(self, tmp_path, **overrides):
        tc = _base_train_config(tmp_path, **overrides)
        module, _, _, _ = _build_module(train_config=tc)
        module.automatic_optimization = False
        return module

    @pytest.mark.parametrize(
        "interval, method_name, assert_scheduler_state",
        [
            pytest.param(
                "step",
                "_step_lr_scheduler",
                lambda scheduler: scheduler.step.assert_called_once_with(),
                id="step-interval-stepped-per-optimizer-step",
            ),
            pytest.param(
                "epoch",
                "_step_lr_scheduler",
                lambda scheduler: scheduler.step.assert_not_called(),
                id="epoch-interval-not-stepped-by-the-per-optimizer-step-hook",
            ),
            pytest.param(
                "epoch",
                "on_train_epoch_end",
                lambda scheduler: scheduler.step.assert_called_once_with(),
                id="epoch-interval-stepped-on-train-epoch-end-manual-path",
            ),
        ],
    )
    def test_lr_scheduler_stepped_according_to_interval(
        self, mocker, tmp_path, interval: str, method_name: str, assert_scheduler_state
    ):
        """The manual LR-scheduler step hooks respect ``_lr_scheduler_interval``.

        A step-interval scheduler is stepped on every optimizer step (``_step_lr_scheduler``); an epoch-interval
        scheduler is not stepped by that hook, only by ``on_train_epoch_end``.
        """
        module = self._module(tmp_path)
        module._lr_scheduler_interval = interval
        scheduler = MagicMock(spec=torch.optim.lr_scheduler.StepLR)
        mocker.patch.object(module, "lr_schedulers", return_value=scheduler)
        getattr(module, method_name)()

        assert_scheduler_state(scheduler)

    def test_plateau_stepped_from_monitor_metric_on_validation_epoch_end(self, mocker, tmp_path):
        """on_validation_epoch_end steps ReduceLROnPlateau with the monitored metric."""
        module = self._module(tmp_path)
        module._lr_scheduler_monitor = "val/loss"
        scheduler = MagicMock(spec=torch.optim.lr_scheduler.ReduceLROnPlateau)
        _attach_trainer(module, sanity_checking=False, callback_metrics={"val/loss": torch.tensor(1.23)})
        mocker.patch.object(module, "lr_schedulers", return_value=scheduler)
        module.on_validation_epoch_end()

        scheduler.step.assert_called_once()

    def test_plateau_raises_when_monitor_metric_missing(self, mocker, tmp_path):
        """on_validation_epoch_end fails loud (not silent warn) when the monitored metric is absent."""
        module = self._module(tmp_path)
        module._lr_scheduler_monitor = "val/loss"
        scheduler = MagicMock(spec=torch.optim.lr_scheduler.ReduceLROnPlateau)
        _attach_trainer(module, sanity_checking=False, callback_metrics={})
        mocker.patch.object(module, "lr_schedulers", return_value=scheduler)
        with pytest.raises(RuntimeError) as exc_info:
            module.on_validation_epoch_end()
        assert "never be reduced" in str(exc_info.value)

        scheduler.step.assert_not_called()

    def test_plateau_not_stepped_during_sanity_check(self, mocker, tmp_path):
        """on_validation_epoch_end must not step plateau during Lightning's pre-training sanity check."""
        module = self._module(tmp_path)
        module._lr_scheduler_monitor = "val/loss"
        scheduler = MagicMock(spec=torch.optim.lr_scheduler.ReduceLROnPlateau)
        _attach_trainer(module, sanity_checking=True, callback_metrics={"val/loss": torch.tensor(1.23)})
        mocker.patch.object(module, "lr_schedulers", return_value=scheduler)
        module.on_validation_epoch_end()

        scheduler.step.assert_not_called()
