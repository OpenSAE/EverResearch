# ------------------------------------------------------------------------
# RF-DETR
# Copyright (c) 2025 Roboflow. All Rights Reserved.
# Licensed under the Apache License, Version 2.0 [see LICENSE for details]
# ------------------------------------------------------------------------
"""Tests for the ONNX → TFLite export pipeline.

Tests cover:
* ``TFLiteExporter.convert_onnx()`` — the main conversion entry point (mocked ``onnx2tf``)
* ``_check_onnx2tf_available()`` — import-based availability check
* ``_numpy_allow_pickle()`` — NumPy monkey-patch context manager
* ``_patch_validation_download()`` — validation download redirect
* ``_interpreter_scripts_on_path()`` — PATH helper for onnx2tf's onnxsim subprocess
* ``TFLiteExporter.convert_onnx()`` applies that helper around ``onnx2tf.convert()``
* ``_get_onnx_input_info()`` — ONNX model input metadata reader
* ``_prepare_calibration_data()`` — calibration data preparation
* ``format="tflite"`` parameter wiring through ``RFDETR.export()``
"""

from __future__ import annotations

import logging
import os
import re
import sys
import sysconfig
import types
import warnings
from pathlib import Path
from typing import Any
from unittest import mock

import numpy as np
import pytest

from rfdetr.export._tflite import _IS_ONNX2TF_AVAILABLE
from rfdetr.export._tflite.exporter import (
    _DEFAULT_CALIB_SAMPLES,
    _DEFAULT_DIR_CALIB_SAMPLES,
    _IMAGE_EXTENSIONS,
    _NUMPY_LOAD_PATCH_LOCK,
    _VALID_QUANTIZATIONS,
    TFLiteConfig,
    TFLiteExporter,
    _check_onnx2tf_available,
    _check_single_onnxsim_owner,
    _check_tf_keras_available,
    _get_onnx_input_info,
    _interpreter_scripts_on_path,
    _load_calibration_images,
    _numpy_allow_pickle,
    _patch_validation_download,
    _prepare_calibration_data,
)
from rfdetr.export.imports import _IS_ONNX_GRAPHSURGEON_INSTALLED, _IS_ONNX_INSTALLED, _IS_ONNXRUNTIME_INSTALLED
from tests._markers import _requires_onnx

_requires_onnx2tf = pytest.mark.skipif(not _IS_ONNX2TF_AVAILABLE, reason="onnx2tf not installed")

_CALIB_IGNORED = "`calibration_data` has no effect on the exported .tflite"

# ---------------------------------------------------------------------------
# Helpers — fake onnx2tf module injected into sys.modules
# ---------------------------------------------------------------------------


class _FakeOnnx2tfModule:
    """Namespace that mimics ``onnx2tf`` for testing."""

    def __init__(self) -> None:
        self.convert = mock.MagicMock()


_ONNX2TF_KEYS = ("onnx2tf", "onnx2tf.onnx2tf", "onnx2tf.utils", "onnx2tf.utils.common_functions")


def _install_fake_onnx2tf() -> tuple[_FakeOnnx2tfModule, mock.MagicMock, dict[str, object]]:
    """Insert a fake ``onnx2tf`` package into ``sys.modules``.

    Saves any pre-existing real modules under the same keys so they can be restored by ``_remove_fake_onnx2tf``
    (Copilot: do not silently clobber real modules that a prior test may have imported).

    Returns:
        Tuple of (fake_module, convert_mock, saved_originals).

    Examples:
        >>> fake, convert_mock, saved = _install_fake_onnx2tf()
        >>> import sys
        >>> "onnx2tf" in sys.modules
        True
        >>> _remove_fake_onnx2tf(saved)
    """
    # Snapshot originals before overwriting (None means the key was absent).
    saved: dict[str, object] = {k: sys.modules.get(k) for k in _ONNX2TF_KEYS}

    fake = _FakeOnnx2tfModule()
    pkg = types.ModuleType("onnx2tf")
    pkg.convert = fake.convert  # type: ignore[attr-defined]
    pkg.__version__ = "2.4.0"  # type: ignore[attr-defined]

    # onnx2tf.onnx2tf — force-imported by TFLiteExporter before patching
    inner_mod = types.ModuleType("onnx2tf.onnx2tf")
    inner_mod.download_test_image_data = mock.MagicMock(  # type: ignore[attr-defined]
        return_value=np.zeros((20, 128, 128, 3), dtype=np.float32),
    )

    # onnx2tf.utils and onnx2tf.utils.common_functions
    utils_mod = types.ModuleType("onnx2tf.utils")
    cf_mod = types.ModuleType("onnx2tf.utils.common_functions")
    cf_mod.download_test_image_data = mock.MagicMock(  # type: ignore[attr-defined]
        return_value=np.zeros((20, 128, 128, 3), dtype=np.float32),
    )

    # Wire up module hierarchy
    pkg.onnx2tf = inner_mod  # type: ignore[attr-defined]
    pkg.utils = utils_mod  # type: ignore[attr-defined]
    utils_mod.common_functions = cf_mod  # type: ignore[attr-defined]

    sys.modules["onnx2tf"] = pkg
    sys.modules["onnx2tf.onnx2tf"] = inner_mod
    sys.modules["onnx2tf.utils"] = utils_mod
    sys.modules["onnx2tf.utils.common_functions"] = cf_mod
    return fake, fake.convert, saved


def _remove_fake_onnx2tf(saved: dict[str, object] | None = None) -> None:
    """Remove fake ``onnx2tf`` entries from ``sys.modules`` and restore originals.

    Args:
        saved: Snapshot returned by ``_install_fake_onnx2tf``.  If a key was
            present before installation its original value is restored; if it was absent it is deleted.  When *saved* is
            ``None`` all ``onnx2tf*`` keys are simply deleted (legacy behaviour).

    Examples:
        >>> import sys
        >>> original = sys.modules.get("onnx2tf")
        >>> _, _, saved = _install_fake_onnx2tf()
        >>> sys.modules["onnx2tf"] is original
        False
        >>> _remove_fake_onnx2tf(saved)
        >>> sys.modules.get("onnx2tf") is original
        True
    """
    if saved is not None:
        for key in _ONNX2TF_KEYS:
            original = saved.get(key)
            if original is None:
                sys.modules.pop(key, None)
            else:
                sys.modules[key] = original  # type: ignore[assignment]
    else:
        for key in list(sys.modules):
            if key == "onnx2tf" or key.startswith("onnx2tf."):
                del sys.modules[key]


def _run_convert_onnx(
    onnx_path: str | os.PathLike[str],
    output_dir: str | os.PathLike[str],
    **config_kwargs: Any,
) -> Path:
    """Convert *onnx_path* to TFLite through a freshly built ``TFLiteExporter``.

    ``TFLiteConfig`` defaults ``verbose`` to ``True``; the exporter is built with ``verbose=False`` unless a
    case overrides it, so ``onnx2tf`` is invoked silently as the conversion's own default has always been.
    Construction emits the format's "experimental" ``UserWarning``, suppressed here so it cannot interfere
    with what a case arranges or asserts.

    Args:
        onnx_path: Path to the source ``.onnx`` file.
        output_dir: Directory the TFLite artifacts are written to.
        **config_kwargs: Further ``TFLiteConfig`` settings, e.g. ``quantization`` or ``max_images``.

    Returns:
        Path to the primary ``.tflite`` artifact.

    Examples:
        Needs a fake ``onnx2tf`` installed in ``sys.modules`` by the ``fake_onnx2tf`` fixture, so the live
        call is covered by the tests below rather than by a doctest.

        >>> callable(_run_convert_onnx)  # doctest: +SKIP
        True
    """
    config_kwargs.setdefault("verbose", False)
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", UserWarning)
        exporter = TFLiteExporter(TFLiteConfig(output_dir=Path(output_dir), **config_kwargs))
    return exporter.convert_onnx(onnx_path)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture()
def fake_onnx2tf(monkeypatch: pytest.MonkeyPatch):
    """Provide a fake ``onnx2tf`` that records *convert()* calls.

    Also patches ``_replace_gridsample_for_tflite`` to return the input path unchanged so tests that supply stub ONNX
    bytes do not depend on ``onnx.load`` tolerating those bytes.
    """
    fake, convert_mock, saved = _install_fake_onnx2tf()
    monkeypatch.setattr("rfdetr.export._tflite.exporter._replace_gridsample_for_tflite", lambda path, _dir: path)
    yield fake, convert_mock
    _remove_fake_onnx2tf(saved)


@pytest.fixture()
def onnx_model(tmp_path: Path) -> Path:
    """Create a dummy ``.onnx`` file."""
    p = tmp_path / "model.onnx"
    p.write_bytes(b"\x08\x06")  # minimal bytes
    return p


@pytest.fixture()
def mock_prepare_calib(tmp_path: Path, mocker) -> mock.MagicMock:
    """Mock ``_prepare_calibration_data`` so dummy ONNX files work.

    ``TFLiteExporter.convert_onnx`` calls ``_prepare_calibration_data`` which calls ``_get_onnx_input_info`` (requiring
    a real ONNX file).  Since the ``onnx_model`` fixture writes only stub bytes, this mock prevents the ONNX parse from
    being attempted.
    """
    dummy_npy = tmp_path / "_rfdetr_calib_data.npy"
    np.save(str(dummy_npy), np.zeros((1, 64, 64, 3), dtype=np.float32))
    return mocker.patch("rfdetr.export._tflite.exporter._prepare_calibration_data", return_value=dummy_npy)


@pytest.fixture()
def tflite_output(tmp_path: Path, onnx_model: Path) -> Path:
    """Create expected TFLite output file so the conversion finds it."""
    out = tmp_path / "output"
    out.mkdir()
    (out / f"{onnx_model.stem}_float32.tflite").write_bytes(b"tflite")
    return out


# ---------------------------------------------------------------------------
# TestTFLiteQuantizationCheck, TestExportTfliteConverter
# ---------------------------------------------------------------------------


class TestTFLiteQuantizationCheck:
    """An unknown ``quantization`` is refused when the exporter is built, before the ONNX stage and without onnx2tf."""

    @pytest.mark.parametrize("quantization", ["q4", "int8_static", "full_int8", "integer_quant"])
    def test_unknown_mode_is_refused_at_construction(self, tmp_path: Path, quantization: str) -> None:
        """Static / full-integer INT8 spellings get the same refusal: only dynamic-range ``"int8"`` is offered."""
        with pytest.raises(ValueError) as exc_info:
            TFLiteExporter(TFLiteConfig(output_dir=tmp_path, quantization=quantization))
        assert "Unsupported quantization mode" in str(exc_info.value)
        assert "Static / full-integer INT8 is not" in str(exc_info.value)


class TestTFLiteCalibrationDataWarning:
    """``calibration_data`` never changes the ``.tflite`` artifact, so passing it warns when the exporter is built."""

    @pytest.mark.parametrize("quantization", [None, "fp16", "int8"])
    def test_calibration_data_warns_at_construction(self, tmp_path: Path, quantization: str | None) -> None:
        """Passing ``calibration_data`` warns that it has no effect, whatever the quantization mode."""
        with pytest.warns(UserWarning) as record:
            TFLiteExporter(TFLiteConfig(output_dir=tmp_path, quantization=quantization, calibration_data=tmp_path))
        assert any(_CALIB_IGNORED in str(w.message) for w in record)

    def test_no_calibration_data_does_not_warn(self, tmp_path: Path) -> None:
        """No calibration warning is raised when ``calibration_data`` is unset."""
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            TFLiteExporter(TFLiteConfig(output_dir=tmp_path, quantization="int8"))
        assert not [w for w in caught if "calibration_data" in str(w.message)]

    def test_configured_calibration_data_is_never_read(self, tmp_path: Path, mock_prepare_calib: Any) -> None:
        """A configured ``calibration_data`` never reaches ``_prepare_calibration_data``; ``None`` is passed instead.

        The value is documented as ignored, so it must not be read or validated either: forwarding it would turn a
        missing path into a ``FileNotFoundError`` raised after the full forward pass and ONNX stage. Runs without
        ``onnx2tf``, so the CPU job covers it.
        """
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", UserWarning)
            exporter = TFLiteExporter(TFLiteConfig(output_dir=tmp_path, calibration_data="/nonexistent/calib.npy"))

        exporter._prepare_calibration(tmp_path / "model.onnx", tmp_path)

        assert mock_prepare_calib.call_args[0][1] is None  # second positional arg


class TestTFLiteMetadataArtifacts:
    """Select metadata artifacts from filenames without running TensorFlow."""

    @pytest.mark.parametrize("precision", ["fp32", "fp16"])
    def test_precision_primary_with_sibling(self, tmp_path: Path, precision: str) -> None:
        """Include both precision files once, in FP32 then FP16 order."""
        exporter = TFLiteExporter(TFLiteConfig(output_dir=tmp_path))
        fp32 = tmp_path / "model_fp32.tflite"
        fp16 = tmp_path / "model_fp16.tflite"
        fp32.touch()
        fp16.touch()

        assert exporter._metadata_artifacts(tmp_path / f"model_{precision}.tflite") == (fp32, fp16)

    def test_dynamic_range_primary_with_siblings(self, tmp_path: Path) -> None:
        """Append the dynamic-range primary after its FP32 and FP16 siblings."""
        exporter = TFLiteExporter(TFLiteConfig(output_dir=tmp_path, quantization="int8"))
        fp32 = tmp_path / "model_fp32.tflite"
        fp16 = tmp_path / "model_fp16.tflite"
        primary = tmp_path / "model_dynamic_range_quant.tflite"
        fp32.touch()
        fp16.touch()
        primary.touch()

        assert exporter._metadata_artifacts(primary) == (fp32, fp16, primary)

    def test_unknown_token_primary(self, tmp_path: Path) -> None:
        """Keep an unknown fallback token intact even when precision files exist."""
        exporter = TFLiteExporter(TFLiteConfig(output_dir=tmp_path))
        primary = tmp_path / "model_custom.tflite"
        primary.touch()
        (tmp_path / "model_fp32.tflite").touch()
        (tmp_path / "model_fp16.tflite").touch()

        assert exporter._metadata_artifacts(primary) == (primary,)

    def test_missing_sibling_and_directory_are_excluded(self, tmp_path: Path) -> None:
        """Ignore absent precision files and directories with artifact names."""
        exporter = TFLiteExporter(TFLiteConfig(output_dir=tmp_path, quantization="int8"))
        primary = tmp_path / "model_dynamic_range_quant.tflite"
        primary.touch()
        (tmp_path / "model_fp16.tflite").mkdir()

        assert exporter._metadata_artifacts(primary) == (primary,)


@_requires_onnx2tf
class TestExportTfliteConverter:
    """Tests for ``TFLiteExporter.convert_onnx()``."""

    def test_missing_onnx_raises_file_not_found(self, tmp_path: Path, fake_onnx2tf: Any) -> None:
        """A non-existent ONNX source is refused with FileNotFoundError."""
        with pytest.raises(FileNotFoundError) as exc_info:
            _run_convert_onnx(tmp_path / "nope.onnx", tmp_path / "out")
        assert "ONNX model not found" in str(exc_info.value)

    def test_default_quantization_calls_convert(
        self,
        onnx_model: Path,
        tflite_output: Path,
        fake_onnx2tf: Any,
        mock_prepare_calib: Any,
    ) -> None:
        """Default quantization calls onnx2tf once with the ONNX input, output folder and signature defs."""
        _, convert_mock = fake_onnx2tf
        result = _run_convert_onnx(onnx_model, tflite_output)

        convert_mock.assert_called_once()
        kwargs = convert_mock.call_args.kwargs
        assert kwargs["input_onnx_file_path"] == str(onnx_model)
        assert kwargs["output_folder_path"] == str(tflite_output)
        assert kwargs["output_signaturedefs"] is True
        assert kwargs["non_verbose"] is True
        assert "output_integer_quantized_tflite" not in kwargs
        assert result == tflite_output / "model_fp32.tflite"

    def test_custom_input_not_passed_to_convert(
        self,
        onnx_model: Path,
        tflite_output: Path,
        fake_onnx2tf: Any,
        mock_prepare_calib: Any,
    ) -> None:
        """custom_input_op_name_np_data_path must NOT be passed to convert().

        The onnx2tf custom_input code path triggers a tf.tile rank mismatch with DINOv2-style backbones when N > 1.
        """
        _, convert_mock = fake_onnx2tf
        _run_convert_onnx(onnx_model, tflite_output)

        kwargs = convert_mock.call_args.kwargs
        assert "custom_input_op_name_np_data_path" not in kwargs

    def test_output_signaturedefs_always_enabled(
        self,
        onnx_model: Path,
        tflite_output: Path,
        fake_onnx2tf: Any,
        mock_prepare_calib: Any,
    ) -> None:
        """output_signaturedefs must always be True.

        Segmentation models produce ONNX node names with leading "/" characters that violate the TF saved_model naming
        pattern. Enabling signature defs bypasses this restriction.
        """
        _, convert_mock = fake_onnx2tf
        _run_convert_onnx(onnx_model, tflite_output)

        kwargs = convert_mock.call_args.kwargs
        assert kwargs["output_signaturedefs"] is True

    def test_tflite_backend_forced_to_tf_converter(
        self,
        onnx_model: Path,
        tflite_output: Path,
        fake_onnx2tf: Any,
        mock_prepare_calib: Any,
    ) -> None:
        """tflite_backend must always be 'tf_converter' to avoid the TFLite TopK_V2 kernel check.

        onnx2tf 2.x defaults to flatbuffer_direct, which trips a "k > internal dimension" error at AllocateTensors()
        time on RF-DETR's encoder TopK node.  tf_converter is forced unconditionally.
        """
        _, convert_mock = fake_onnx2tf
        _run_convert_onnx(onnx_model, tflite_output)

        assert convert_mock.call_args.kwargs["tflite_backend"] == "tf_converter"

    def test_replace_to_pseudo_operators_contains_erf_and_gelu(
        self,
        onnx_model: Path,
        tflite_output: Path,
        fake_onnx2tf: Any,
        mock_prepare_calib: Any,
    ) -> None:
        """replace_to_pseudo_operators must include Erf and GeLU.

        Without this, AllocateTensors() fails with "FlexErf failed to prepare" because the TFLite runtime lacks native
        Erf / GeLU kernels.
        """
        _, convert_mock = fake_onnx2tf
        _run_convert_onnx(onnx_model, tflite_output)

        pseudo_ops = convert_mock.call_args.kwargs.get("replace_to_pseudo_operators", [])
        assert "Erf" in pseudo_ops
        assert "GeLU" in pseudo_ops

    @pytest.mark.parametrize("quantization", ["fp32", "fp16"])
    def test_float_quantization_has_no_int8_flag(
        self,
        onnx_model: Path,
        tflite_output: Path,
        fake_onnx2tf: Any,
        mock_prepare_calib: Any,
        quantization: str,
    ) -> None:
        """Float quantization modes never enable onnx2tf's integer-quantization output."""
        _, convert_mock = fake_onnx2tf
        _run_convert_onnx(onnx_model, tflite_output, quantization=quantization)
        assert "output_integer_quantized_tflite" not in convert_mock.call_args.kwargs

    @pytest.mark.parametrize(
        "calibration_data",
        [
            None,
            pytest.param(Path("/some/calib_dir"), id="directory"),
            pytest.param(np.zeros((2, 64, 64, 3), dtype=np.float32), id="ndarray"),
        ],
    )
    def test_int8_builds_dynamic_range_model(
        self,
        onnx_model: Path,
        tflite_output: Path,
        fake_onnx2tf: Any,
        mock_prepare_calib: Any,
        mocker,
        calibration_data: Path | np.ndarray | None,
    ) -> None:
        """Int8 export derives a dynamic-range model and avoids onnx2tf's -oiqt path, regardless of calibration_data.

        onnx2tf's ``output_integer_quantized_tflite`` (-oiqt) only yields static quantization, which RF-DETR's
        transformer activations do not survive. The converter instead builds dynamic-range INT8 from the SavedModel via
        ``_quantize_dynamic_range``, which accepts no calibration data at all -- so neither the
        ``output_integer_quantized_tflite`` flag nor a ``representative_dataset`` ever reaches onnx2tf's ``convert()``
        call, no matter whether ``calibration_data`` is ``None``, a directory, or an ndarray.
        """
        _, convert_mock = fake_onnx2tf
        dyn_path = tflite_output / "model_dynamic_range_quant.tflite"
        quant_mock = mocker.patch("rfdetr.export._tflite.exporter._quantize_dynamic_range", return_value=dyn_path)
        result = _run_convert_onnx(onnx_model, tflite_output, quantization="int8", calibration_data=calibration_data)
        kwargs = convert_mock.call_args.kwargs
        assert "output_integer_quantized_tflite" not in kwargs
        assert "representative_dataset" not in kwargs
        quant_mock.assert_called_once()
        assert result == dyn_path

    @pytest.mark.parametrize(
        ("verbose", "expected_verbosity"),
        [
            pytest.param(True, "info", id="verbose"),
            pytest.param(False, "error", id="silent"),
        ],
    )
    def test_verbosity_forwarded(
        self,
        onnx_model: Path,
        tflite_output: Path,
        fake_onnx2tf: Any,
        mock_prepare_calib: Any,
        verbose: bool,
        expected_verbosity: str,
    ) -> None:
        """The configured ``verbose`` flag selects the ``verbosity`` level onnx2tf is called with.

        ``verbosity`` is not a knob of its own on the exporter — it is derived from ``TFLiteConfig.verbose``, so a
        regression that stopped forwarding it would leave onnx2tf silent on a verbose export.
        """
        _, convert_mock = fake_onnx2tf
        _run_convert_onnx(onnx_model, tflite_output, verbose=verbose)
        assert convert_mock.call_args.kwargs["verbosity"] == expected_verbosity

    def test_convert_failure_raises_runtime_error(
        self,
        onnx_model: Path,
        tmp_path: Path,
        fake_onnx2tf: Any,
        mock_prepare_calib: Any,
    ) -> None:
        """An onnx2tf failure is re-raised as RuntimeError naming the failed conversion."""
        _, convert_mock = fake_onnx2tf
        convert_mock.side_effect = RuntimeError("boom")
        with pytest.raises(RuntimeError) as exc_info:
            _run_convert_onnx(onnx_model, tmp_path / "out")
        assert "onnx2tf conversion failed" in str(exc_info.value)

    def test_fallback_when_primary_tflite_missing(
        self,
        onnx_model: Path,
        tmp_path: Path,
        fake_onnx2tf: Any,
        mock_prepare_calib: Any,
    ) -> None:
        """Fallback returns a stem-scoped file when the primary *_fp32.tflite is absent."""
        out = tmp_path / "out"
        out.mkdir()
        # Scoped fallback: must match {stem}_*.tflite (stem == "model" here). Written pre-renamed
        # ("_float16") to mirror onnx2tf's real output naming -- _rename_precision_outputs renames it
        # to "_fp16" before the fallback glob runs.
        (out / "model_float16.tflite").write_bytes(b"fb")
        result = _run_convert_onnx(onnx_model, out)
        assert result.name == "model_fp16.tflite"

    def test_fallback_does_not_return_unrelated_tflite(
        self,
        onnx_model: Path,
        tmp_path: Path,
        fake_onnx2tf: Any,
        mock_prepare_calib: Any,
    ) -> None:
        """Stale artifacts from a different export are never returned as fallback."""
        out = tmp_path / "out"
        out.mkdir()
        # Unrelated file — does NOT match model_*.tflite.
        (out / "other_model.tflite").write_bytes(b"stale")
        with pytest.raises(RuntimeError) as exc_info:
            _run_convert_onnx(onnx_model, out)
        assert "no .tflite file matching" in str(exc_info.value)

    def test_no_tflite_output_raises_runtime_error(
        self,
        onnx_model: Path,
        tmp_path: Path,
        fake_onnx2tf: Any,
        mock_prepare_calib: Any,
    ) -> None:
        """Empty output directory raises RuntimeError after conversion."""
        out = tmp_path / "empty_out"
        out.mkdir()
        with pytest.raises(RuntimeError) as exc_info:
            _run_convert_onnx(onnx_model, out)
        assert "no .tflite file matching" in str(exc_info.value)

    def test_returns_path_object(
        self,
        onnx_model: Path,
        tflite_output: Path,
        fake_onnx2tf: Any,
        mock_prepare_calib: Any,
    ) -> None:
        """The converted artifact is returned as a ``Path``."""
        result = _run_convert_onnx(onnx_model, tflite_output)
        assert isinstance(result, Path)

    @pytest.mark.parametrize(
        ("config_kwargs", "expected"),
        [pytest.param({"max_images": 42}, 42, id="explicit"), pytest.param({}, 100, id="default")],
    )
    def test_max_images_forwarded_to_prepare(
        self,
        onnx_model: Path,
        tflite_output: Path,
        fake_onnx2tf: Any,
        mock_prepare_calib: Any,
        config_kwargs: dict[str, int],
        expected: int,
    ) -> None:
        """``max_images`` reaches ``_prepare_calibration_data``; it defaults to 100 when unset."""
        _run_convert_onnx(onnx_model, tflite_output, **config_kwargs)
        assert mock_prepare_calib.call_args.kwargs.get("max_images") == expected

    def test_valid_quantizations_set(self) -> None:
        """The accepted quantization modes are None, fp32, fp16 and int8."""
        assert _VALID_QUANTIZATIONS == {None, "fp32", "fp16", "int8"}

    def test_output_name_end_to_end_filename_includes_gs_patched(
        self,
        tmp_path: Path,
        fake_onnx2tf: Any,
        mock_prepare_calib: Any,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """A real RF-DETR export always contains GridSample nodes (module docstring), so
        ``_replace_gridsample_for_tflite`` always renames the ONNX stem with a ``_gs_patched`` infix before ``onnx2tf``
        ever runs. ``output_name="my-model"`` (already baked into the ONNX filename by ``export_onnx``, per
        ``TFLiteExporter``'s ONNX stage) must therefore produce ``my-model_gs_patched_fp32.tflite`` — not ``my-
        model_fp32.tflite`` — confirming the actually-produced filename rather than the docstring's simplified "inherits
        its stem" claim.

        The ``fake_onnx2tf`` fixture stubs ``_replace_gridsample_for_tflite`` as a pure passthrough (no rename), so this
        test overrides that stub to reflect the real rename step.
        """
        onnx_path = tmp_path / "my-model.onnx"
        onnx_path.write_bytes(b"\x08\x06")
        out_dir = tmp_path / "out"
        out_dir.mkdir()
        (out_dir / "my-model_gs_patched_float32.tflite").write_bytes(b"tflite")

        monkeypatch.setattr(
            "rfdetr.export._tflite.exporter._replace_gridsample_for_tflite",
            lambda path, output_dir: output_dir / f"{path.stem}_gs_patched.onnx",
        )
        result = _run_convert_onnx(onnx_path, out_dir)

        assert result.name == "my-model_gs_patched_fp32.tflite"


# ---------------------------------------------------------------------------
# TestExportFormatParameter
# ---------------------------------------------------------------------------


class TestExportFormatParameter:
    """Tests for ``format="tflite"`` wiring through ``RFDETR.export()``."""

    @pytest.fixture(autouse=True)
    def _patch_export_deps(self, tmp_path: Path, mocker) -> None:
        """Mock the heavy export dependencies so ``RFDETR.export()`` is fast."""
        import torch

        self._tmp_path = tmp_path
        onnx_out = tmp_path / "inference_model.onnx"
        onnx_out.write_bytes(b"onnx")

        mocker.patch("rfdetr.export.base.write_metadata")
        mocker.patch("rfdetr.export._tflite.exporter.TFLiteExporter._metadata_for_artifact")
        self._mock_export_onnx = mocker.patch(
            "rfdetr.export._onnx.exporter.OnnxExporter._convert", return_value=str(onnx_out)
        )
        mocker.patch("rfdetr.export.prepare.make_infer_image", return_value=torch.zeros(1, 3, 560, 560))
        # autospec captures the exporter, whose config carries the settings RFDETR.export() forwarded.
        self._mock_convert_onnx = mocker.patch(
            "rfdetr.export._tflite.exporter.TFLiteExporter.convert_onnx",
            autospec=True,
            return_value=tmp_path / "inference_model_fp32.tflite",
        )
        # The CPU job has no onnx2tf, which RFDETR.export() checks for before the forward pass.
        mocker.patch("rfdetr.export._tflite.exporter.TFLiteExporter.check_dependencies")

    @staticmethod
    def _make_rfdetr() -> Any:
        """Create a minimal RFDETR instance with mocked internals."""
        from rfdetr.detr import RFDETR

        obj = RFDETR.__new__(RFDETR)
        obj.model = mock.MagicMock()
        obj.model.resolution = 560
        obj.model.device = "cpu"
        obj.model.model.to.return_value = obj.model.model
        obj.model.args = None
        obj.model.class_names = ["object"]
        obj.model.postprocess.num_select = 100
        obj.model.postprocess.trace_alpha = 0.2
        obj.model.postprocess.upsample_masks_to_image_size = True
        obj.means = [0.485, 0.456, 0.406]
        obj.stds = [0.229, 0.224, 0.225]
        obj.model_config = mock.MagicMock()
        obj.model_config.segmentation_head = False
        obj.model_config.use_grouppose_keypoints = False
        obj.model_config.patch_size = 14
        obj.model_config.num_windows = 1
        obj.model_config.num_channels = 3
        obj.model_config.num_classes = 1
        obj.model_config.num_keypoints_per_class = []
        return obj

    def _exported_config(self) -> Any:
        """Return the ``TFLiteConfig`` the exporter was built with on the last export.

        Returns:
            The configuration carried by the ``TFLiteExporter`` whose ``convert_onnx`` was called.
        """
        return self._mock_convert_onnx.call_args[0][0].config

    @pytest.mark.parametrize(("fmt", "convert_calls"), [("tflite", 1), ("onnx", 0)])
    def test_convert_onnx_called_only_for_tflite_format(self, fmt: str, convert_calls: int) -> None:
        """``RFDETR.export`` runs the ONNX -> TFLite conversion for ``format="tflite"`` and not for ``"onnx"``."""
        obj = self._make_rfdetr()
        obj.export(format=fmt, output_dir=str(self._tmp_path / "out"))
        assert self._mock_convert_onnx.call_count == convert_calls

    def test_tflite_format_preloads_tensorflow_before_first_onnx_package_import(
        self, monkeypatch: pytest.MonkeyPatch, mocker
    ) -> None:
        """TensorFlow is preloaded before anything in the export imports ``onnx``.

        ``onnx`` is dropped from ``sys.modules``, so the export has to import it again, and a finder first on
        ``sys.meta_path`` stops it there. The finder sees an ``import`` statement and ``importlib.import_module`` alike;
        with this class's stubs, that first import is the ONNX stage's own dependency check. Loading the ONNX exporter
        module imports no ONNX package; ``TestExportDependencyCheck`` pins that.

        ``RFDETR.export()`` legitimately preloads more than once — the registry's ``preimport`` runs before it imports
        the exporter module, and ``TFLiteExporter.check_dependencies`` runs it again — so this pins the ordering, not
        the count. This class stubs ``check_dependencies``, so the preload observed here is the registry's; the check's
        own ordering is pinned by ``TestTFLiteDependencyCheckOrder``.
        """
        obj = self._make_rfdetr()
        preloads: list[str] = []
        monkeypatch.delitem(sys.modules, "onnx", raising=False)
        monkeypatch.setattr(sys, "meta_path", [types.SimpleNamespace(find_spec=_stop_at_onnx_import), *sys.meta_path])

        mocker.patch(
            "rfdetr.export._backend.preload_tensorflow_before_onnx", side_effect=lambda: preloads.append("preload")
        )
        with pytest.raises(RuntimeError, match="first onnx import"):
            obj.export(format="tflite", output_dir=str(self._tmp_path / "out"))

        assert preloads, "the export imported onnx before it preloaded TensorFlow"

    def test_onnx_format_does_not_preload_tensorflow(self, mocker) -> None:
        """Non-TFLite formats never import TensorFlow."""
        preload_mock = mocker.patch("rfdetr.export._backend.preload_tensorflow_before_onnx")
        obj = self._make_rfdetr()
        obj.export(format="onnx", output_dir=str(self._tmp_path / "out"))

        preload_mock.assert_not_called()

    def test_quantization_forwarded(self) -> None:
        """The ``quantization`` kwarg reaches the TFLite exporter's config."""
        obj = self._make_rfdetr()
        obj.export(format="tflite", output_dir=str(self._tmp_path / "out"), quantization="int8")
        assert self._exported_config().quantization == "int8"

    @pytest.mark.parametrize("quant", [None, "fp32", "fp16", "int8"])
    def test_all_quantization_modes_accepted(self, quant: str | None) -> None:
        """Every documented quantization mode exports without error."""
        obj = self._make_rfdetr()
        obj.export(format="tflite", output_dir=str(self._tmp_path / "out"), quantization=quant)
        self._mock_convert_onnx.assert_called_once()

    def test_unsupported_format_raises(self) -> None:
        """An unknown export format is refused with ValueError."""
        obj = self._make_rfdetr()
        with pytest.raises(ValueError, match="[Uu]nsupported.*format"):
            obj.export(format="banana", output_dir=str(self._tmp_path / "out"))

    def test_calibration_data_forwarded(self) -> None:
        """Verify calibration_data kwarg reaches the TFLite exporter's config, warning that it is ignored."""
        obj = self._make_rfdetr()
        calib = "/my/calib.npy"
        with pytest.warns(UserWarning) as record:
            obj.export(format="tflite", output_dir=str(self._tmp_path / "out"), calibration_data=calib)
        assert any(_CALIB_IGNORED in str(w.message) for w in record)
        assert self._exported_config().calibration_data == calib

    def test_calibration_data_warning_points_at_the_export_call(self) -> None:
        """The ignored-``calibration_data`` warning is attributed to the line calling ``RFDETR.export``.

        A ``stacklevel`` off by one frame reports ``detr.py`` (or an exporter module) instead, which breaks
        ``warnings.filterwarnings(..., module=...)`` filters and hides which notebook cell passed the argument.
        """
        obj = self._make_rfdetr()
        with pytest.warns(UserWarning) as record:
            obj.export(format="tflite", output_dir=str(self._tmp_path / "out"), calibration_data="/my/calib.npy")
        assert [w.filename for w in record if "calibration_data" in str(w.message)] == [__file__]

    @pytest.mark.parametrize(
        ("export_kwargs", "expected"),
        [pytest.param({"max_images": 50}, 50, id="explicit"), pytest.param({}, 100, id="default")],
    )
    def test_max_images_forwarded(self, export_kwargs: dict[str, int], expected: int) -> None:
        """``max_images`` reaches the TFLite config; it defaults to 100 when unset."""
        obj = self._make_rfdetr()
        obj.export(format="tflite", output_dir=str(self._tmp_path / "out"), **export_kwargs)
        assert self._exported_config().max_images == expected


# ---------------------------------------------------------------------------
# TestNumpyAllowPickle
# ---------------------------------------------------------------------------


class TestNumpyAllowPickle:
    """Tests for ``_numpy_allow_pickle()`` context manager."""

    def test_patches_np_load(self) -> None:
        """``np.load`` is replaced inside the context and restored on exit."""
        original = np.load
        with _numpy_allow_pickle():
            assert np.load is not original
        assert np.load is original

    def test_sets_allow_pickle_default(self) -> None:
        """Inside the context ``np.load`` is called with ``allow_pickle=True``."""
        calls: list[dict[str, Any]] = []
        original = np.load

        def _spy(*args: Any, **kwargs: Any) -> Any:
            calls.append(kwargs.copy())
            raise ValueError("stop")

        np.load = _spy  # type: ignore[assignment]
        try:
            with _numpy_allow_pickle():
                with pytest.raises(ValueError, match="stop"):
                    np.load("dummy.npy")
            assert calls[0].get("allow_pickle") is True
        finally:
            np.load = original  # type: ignore[assignment]

    def test_restores_on_exception(self) -> None:
        """Patch is restored even when an exception propagates out of the context."""
        original = np.load
        try:
            with _numpy_allow_pickle():
                raise RuntimeError("boom")
        except RuntimeError:
            pass
        assert np.load is original

    def test_concurrent_access_lock_not_reentrant(self) -> None:
        """Lock prevents a second context from patching np.load while the first is still active."""
        import threading

        entered = threading.Event()
        released = threading.Event()

        def _hold_context() -> None:
            with _numpy_allow_pickle():
                entered.set()
                released.wait(timeout=2.0)

        holder = threading.Thread(target=_hold_context)
        holder.start()
        entered.wait(timeout=2.0)

        acquired = _NUMPY_LOAD_PATCH_LOCK.acquire(blocking=False)
        released.set()
        holder.join(timeout=2.0)

        assert not acquired, "Lock must remain held while first context is active"


# ---------------------------------------------------------------------------
# TestPatchValidationDownload
# ---------------------------------------------------------------------------


class TestPatchValidationDownload:
    """Tests for ``_patch_validation_download()`` context manager."""

    def test_patches_download_in_common_functions(self, tmp_path: Path, fake_onnx2tf: Any) -> None:
        """The patch replaces download_test_image_data in common_functions."""
        data = np.random.rand(5, 128, 128, 3).astype(np.float32)
        npy_path = tmp_path / "calib.npy"
        np.save(str(npy_path), data)

        cf_mod = sys.modules["onnx2tf.utils.common_functions"]
        original_fn = cf_mod.download_test_image_data

        with _patch_validation_download(str(npy_path)):
            assert cf_mod.download_test_image_data is not original_fn
            result = cf_mod.download_test_image_data()
            np.testing.assert_array_equal(result, data)

        # Restored after exit
        assert cf_mod.download_test_image_data is original_fn

    def test_patches_download_in_onnx2tf_module(self, tmp_path: Path, fake_onnx2tf: Any) -> None:
        """The patch also covers onnx2tf.onnx2tf if it has the function."""
        data = np.random.rand(3, 64, 64, 3).astype(np.float32)
        npy_path = tmp_path / "calib.npy"
        np.save(str(npy_path), data)

        # Create onnx2tf.onnx2tf submodule with download_test_image_data
        onnx2tf_inner = types.ModuleType("onnx2tf.onnx2tf")
        original_fn = mock.MagicMock()
        onnx2tf_inner.download_test_image_data = original_fn  # type: ignore[attr-defined]
        sys.modules["onnx2tf.onnx2tf"] = onnx2tf_inner

        try:
            with _patch_validation_download(str(npy_path)):
                assert onnx2tf_inner.download_test_image_data is not original_fn
                result = onnx2tf_inner.download_test_image_data()
                np.testing.assert_array_equal(result, data)

            assert onnx2tf_inner.download_test_image_data is original_fn
        finally:
            sys.modules.pop("onnx2tf.onnx2tf", None)

    def test_restores_on_exception(self, tmp_path: Path, fake_onnx2tf: Any) -> None:
        """Functions are restored even when an exception occurs."""
        npy_path = tmp_path / "calib.npy"
        np.save(str(npy_path), np.zeros((1, 8, 8, 3), dtype=np.float32))

        cf_mod = sys.modules["onnx2tf.utils.common_functions"]
        original_fn = cf_mod.download_test_image_data

        try:
            with _patch_validation_download(str(npy_path)):
                raise RuntimeError("boom")
        except RuntimeError:
            pass

        assert cf_mod.download_test_image_data is original_fn

    def test_skips_missing_modules(self, tmp_path: Path) -> None:
        """Does not raise when onnx2tf modules are not in sys.modules."""
        npy_path = tmp_path / "calib.npy"
        np.save(str(npy_path), np.zeros((1, 8, 8, 3), dtype=np.float32))

        # Ensure onnx2tf is NOT in sys.modules
        keys = [k for k in sys.modules if k == "onnx2tf" or k.startswith("onnx2tf.")]
        saved = {k: sys.modules.pop(k) for k in keys}

        try:
            with _patch_validation_download(str(npy_path)):
                pass  # should not raise
        finally:
            sys.modules.update(saved)


@_requires_onnx
class TestGetOnnxInputInfo:
    """Tests for ``_get_onnx_input_info()``."""

    @pytest.mark.parametrize(
        ("input_name", "dims"),
        [
            pytest.param("images", [1, 3, 560, 560], id="square"),
            pytest.param("input", [1, 3, 448, 640], id="non-square"),
        ],
    )
    def test_reads_input_name_and_shape(self, tmp_path: Path, input_name: str, dims: list[int]) -> None:
        """A minimal ONNX model's input name and static shape are read back, square or not."""
        import onnx

        TensorProto, helper = onnx.TensorProto, onnx.helper  # noqa: N806

        inp = helper.make_tensor_value_info(input_name, TensorProto.FLOAT, dims)
        out = helper.make_tensor_value_info("output", TensorProto.FLOAT, [1, 100, 4])
        node = helper.make_node("Identity", inputs=[input_name], outputs=["output"])
        graph = helper.make_graph([node], "test", [inp], [out])
        model = helper.make_model(graph, opset_imports=[helper.make_opsetid("", 13)])
        onnx_path = tmp_path / "test_model.onnx"
        onnx.save(model, str(onnx_path))

        name, read_dims = _get_onnx_input_info(onnx_path)
        assert name == input_name
        assert read_dims == dims


# ---------------------------------------------------------------------------
# TestPrepareCalibrationData
# ---------------------------------------------------------------------------


class TestPrepareCalibrationData:
    """Tests for ``_prepare_calibration_data()``."""

    @pytest.fixture()
    def _mock_onnx_info(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Mock ``_get_onnx_input_info`` to return a known shape."""
        monkeypatch.setattr(
            "rfdetr.export._tflite.exporter._get_onnx_input_info", lambda _path: ("input", [1, 3, 256, 256])
        )

    def test_none_generates_random_data(self, tmp_path: Path, _mock_onnx_info: None) -> None:
        """Without calibration data a float32 random batch shaped from the ONNX input is saved to ``.npy``."""
        onnx_path = tmp_path / "model.onnx"
        onnx_path.write_bytes(b"\x00")

        npy_path = _prepare_calibration_data(onnx_path, None, tmp_path)

        assert isinstance(npy_path, Path)
        assert npy_path.is_file()

        data = np.load(str(npy_path))
        assert data.shape == (_DEFAULT_CALIB_SAMPLES, 256, 256, 3)
        assert data.dtype == np.float32

    def test_generated_data_is_not_reported_as_an_accuracy_problem(
        self, tmp_path: Path, _mock_onnx_info: None, mocker
    ) -> None:
        """Auto-generated validation data must not trigger any warning."""
        onnx_path = tmp_path / "model.onnx"
        onnx_path.write_bytes(b"\x00")

        mock_logger = mocker.patch("rfdetr.export._tflite.exporter.logger")
        _prepare_calibration_data(onnx_path, None, tmp_path)

        mock_logger.warning.assert_not_called()

    def test_ndarray_saves_to_npy(self, tmp_path: Path, _mock_onnx_info: None) -> None:
        """An ndarray is saved unchanged to a ``.npy`` file."""
        onnx_path = tmp_path / "model.onnx"
        onnx_path.write_bytes(b"\x00")
        calib = np.random.rand(10, 256, 256, 3).astype(np.float32)

        npy_path = _prepare_calibration_data(onnx_path, calib, tmp_path)

        loaded = np.load(str(npy_path))
        np.testing.assert_array_equal(loaded, calib)

    def test_path_string_used_directly(self, tmp_path: Path, _mock_onnx_info: None) -> None:
        """A path to an existing ``.npy`` file is returned as is."""
        onnx_path = tmp_path / "model.onnx"
        onnx_path.write_bytes(b"\x00")
        npy_file = tmp_path / "my_calib.npy"
        np.save(str(npy_file), np.zeros((5, 256, 256, 3), dtype=np.float32))

        npy_path = _prepare_calibration_data(onnx_path, str(npy_file), tmp_path)

        assert npy_path == npy_file

    def test_directory_loads_images(self, tmp_path: Path, _mock_onnx_info: None) -> None:
        """A directory path triggers image loading and .npy creation."""
        from PIL import Image

        onnx_path = tmp_path / "model.onnx"
        onnx_path.write_bytes(b"\x00")
        img_dir = tmp_path / "images"
        img_dir.mkdir()
        for i in range(5):
            img = Image.new("RGB", (100, 80), color=(i * 50, 0, 0))
            img.save(img_dir / f"img_{i:03d}.jpg")

        npy_path = _prepare_calibration_data(onnx_path, str(img_dir), tmp_path)

        assert npy_path.is_file()
        data = np.load(str(npy_path))
        # _mock_onnx_info returns [1, 3, 256, 256] → H=256, W=256
        assert data.shape == (5, 256, 256, 3)
        assert data.dtype == np.float32

    def test_directory_respects_max_images(self, tmp_path: Path, _mock_onnx_info: None) -> None:
        """Verify that max_images limits the number of images loaded from a directory."""
        from PIL import Image

        onnx_path = tmp_path / "model.onnx"
        onnx_path.write_bytes(b"\x00")
        img_dir = tmp_path / "images"
        img_dir.mkdir()
        for i in range(10):
            img = Image.new("RGB", (100, 80), color=(i * 25, 0, 0))
            img.save(img_dir / f"img_{i:03d}.jpg")

        npy_path = _prepare_calibration_data(onnx_path, str(img_dir), tmp_path, max_images=3)

        assert npy_path.is_file()
        data = np.load(str(npy_path))
        assert data.shape[0] == 3  # only 3 of 10 images loaded

    def test_missing_path_raises_file_not_found(self, tmp_path: Path, _mock_onnx_info: None) -> None:
        """A non-existent calibration path is refused with FileNotFoundError."""
        onnx_path = tmp_path / "model.onnx"
        onnx_path.write_bytes(b"\x00")

        with pytest.raises(FileNotFoundError) as exc_info:
            _prepare_calibration_data(onnx_path, "/nonexistent/calib.npy", tmp_path)
        assert "Calibration data path not found" in str(exc_info.value)


# ---------------------------------------------------------------------------
# TestLoadCalibrationImages
# ---------------------------------------------------------------------------


class TestLoadCalibrationImages:
    """Tests for ``_load_calibration_images()``."""

    @staticmethod
    def _make_images(directory: Path, count: int = 5, size: tuple[int, int] = (100, 80)) -> list[Path]:
        """Create *count* small JPEG images in *directory*."""
        from PIL import Image

        paths: list[Path] = []
        for i in range(count):
            p = directory / f"img_{i:04d}.jpg"
            Image.new("RGB", size, color=(i * 40 % 256, 0, 0)).save(p)
            paths.append(p)
        return paths

    def test_loads_images_as_unit_range_float32_batch(self, tmp_path: Path) -> None:
        """Images load as a float32 batch resized to the requested size, with values in [0, 1]."""
        self._make_images(tmp_path, count=3)
        result = _load_calibration_images(tmp_path, height=128, width=256)

        assert isinstance(result, np.ndarray)
        assert result.shape == (3, 128, 256, 3)
        assert result.dtype == np.float32
        assert result.min() >= 0.0
        assert result.max() <= 1.0

    def test_resize_matches_predict_convention(self, tmp_path: Path) -> None:
        """The calibration resize must follow predict()'s convention: bilinear, half-pixel, antialias-free.

        Guards the #1206 alignment: PIL's default resize (BICUBIC + adaptive antialias when downscaling) produces a
        different pixel distribution from predict(), reducing fidelity if the conditional validation hook uses it.
        """
        import torchvision.transforms.functional as F  # noqa: N812
        from PIL import Image

        rng = np.random.default_rng(11)
        base = rng.integers(0, 256, size=(40, 50, 3), dtype=np.uint8)
        nearest = getattr(Image, "Resampling", Image).NEAREST
        pil = Image.fromarray(base, mode="RGB").resize((400, 320), nearest)
        pil.save(tmp_path / "img.png")

        result = _load_calibration_images(tmp_path, height=128, width=160)

        ref = F.resize(F.to_tensor(pil), [128, 160], antialias=False).numpy().transpose(1, 2, 0)
        max_diff = float(np.abs(result[0] - ref).max())
        assert max_diff < 1e-3, (
            f"Calibration resize diverged from predict()'s antialias-free convention: "
            f"max|diff|={max_diff:.4f}. _load_calibration_images must resize with "
            f"_bilinear_resize_half_pixel, not PIL."
        )

        # PIL's default resample (the old behaviour) must stay far from the reference, so the check discriminates.
        pil_default = np.asarray(pil.resize((160, 128)), dtype=np.float32) / np.float32(255.0)
        assert float(np.abs(pil_default - ref).max()) > 0.05, (
            "PIL's default resize unexpectedly matches the reference; this test no longer discriminates."
        )

    def test_respects_max_images(self, tmp_path: Path) -> None:
        """At most ``max_images`` images are loaded from the directory."""
        self._make_images(tmp_path, count=10)
        result = _load_calibration_images(tmp_path, height=64, width=64, max_images=4)
        assert result.shape[0] == 4

    def test_empty_directory_raises(self, tmp_path: Path) -> None:
        """A directory without supported image files is refused with FileNotFoundError."""
        empty = tmp_path / "empty"
        empty.mkdir()
        with pytest.raises(FileNotFoundError) as exc_info:
            _load_calibration_images(empty, height=64, width=64)
        assert "No supported image files" in str(exc_info.value)

    def test_nonexistent_directory_raises(self, tmp_path: Path) -> None:
        """A non-existent directory is refused with FileNotFoundError."""
        with pytest.raises(FileNotFoundError) as exc_info:
            _load_calibration_images(tmp_path / "does_not_exist", height=64, width=64)
        assert "Calibration image directory not found" in str(exc_info.value)

    def test_unsupported_extensions_ignored(self, tmp_path: Path) -> None:
        """Only image extensions are loaded; .txt files are skipped."""
        self._make_images(tmp_path, count=2)
        (tmp_path / "readme.txt").write_text("hello")
        (tmp_path / "data.csv").write_text("a,b")

        result = _load_calibration_images(tmp_path, height=32, width=32)
        assert result.shape[0] == 2

    def test_skips_unreadable_files(self, tmp_path: Path) -> None:
        """Corrupt images are skipped without raising."""
        self._make_images(tmp_path, count=3)
        (tmp_path / "corrupt.jpg").write_bytes(b"not-a-jpeg")

        result = _load_calibration_images(tmp_path, height=32, width=32)
        assert result.shape[0] == 3  # only the 3 valid images

    def test_all_unreadable_raises(self, tmp_path: Path) -> None:
        """If all files are unreadable, raises FileNotFoundError."""
        (tmp_path / "bad1.jpg").write_bytes(b"garbage")
        (tmp_path / "bad2.png").write_bytes(b"garbage")

        with pytest.raises(FileNotFoundError) as exc_info:
            _load_calibration_images(tmp_path, height=32, width=32)
        assert "No readable images" in str(exc_info.value)

    def test_png_and_jpeg_both_loaded(self, tmp_path: Path) -> None:
        """Both .jpg and .png formats are loaded."""
        from PIL import Image

        Image.new("RGB", (50, 50), "red").save(tmp_path / "a.jpg")
        Image.new("RGB", (50, 50), "blue").save(tmp_path / "b.png")

        result = _load_calibration_images(tmp_path, height=32, width=32)
        assert result.shape[0] == 2

    def test_constants_are_reasonable(self) -> None:
        """Sanity-check the module-level constants."""
        assert _DEFAULT_DIR_CALIB_SAMPLES > 0
        assert ".jpg" in _IMAGE_EXTENSIONS
        assert ".png" in _IMAGE_EXTENSIONS


# ---------------------------------------------------------------------------
# TestCheckOnnx2tfAvailable
# ---------------------------------------------------------------------------


@_requires_onnx2tf
class TestCheckOnnx2tfAvailable:
    """Tests for ``_check_onnx2tf_available()``."""

    def test_available_when_importable(self, fake_onnx2tf: Any) -> None:
        """No error is raised when onnx2tf is importable."""
        _check_onnx2tf_available()  # should not raise

    def test_raises_when_not_importable(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """ImportError is raised with install hint when onnx2tf is absent."""
        _remove_fake_onnx2tf()
        monkeypatch.setitem(sys.modules, "onnx2tf", None)
        with pytest.raises(ImportError) as exc_info:
            _check_onnx2tf_available()
        assert "onnx2tf is not installed" in str(exc_info.value)


# ---------------------------------------------------------------------------
# TestGridSampleOnnxRewrite
# ---------------------------------------------------------------------------

_requires_onnx_graphsurgeon = pytest.mark.skipif(
    not (_IS_ONNX_INSTALLED and _IS_ONNX_GRAPHSURGEON_INSTALLED and _IS_ONNXRUNTIME_INSTALLED),
    reason="onnx, onnx_graphsurgeon, and onnxruntime required",
)


def _build_gridsample_onnx(
    path: Path,
    *,
    n: int = 1,
    c: int = 4,
    h: int = 8,
    w: int = 8,
    h_out: int = 4,
    w_out: int = 4,
) -> None:
    """Write a minimal ONNX model with one GridSample node to *path*.

    Examples:
        Requires ``onnx`` and ``onnx_graphsurgeon`` which are optional — skipped in the doctest runner.

        >>> callable(_build_gridsample_onnx)  # doctest: +SKIP
        True
    """
    import onnx
    from onnx import TensorProto, helper

    im = helper.make_tensor_value_info("im", TensorProto.FLOAT, [n, c, h, w])
    grid = helper.make_tensor_value_info("grid", TensorProto.FLOAT, [n, h_out, w_out, 2])
    out = helper.make_tensor_value_info("out", TensorProto.FLOAT, [n, c, h_out, w_out])
    node = helper.make_node(
        "GridSample",
        inputs=["im", "grid"],
        outputs=["out"],
        mode="bilinear",
        padding_mode="zeros",
        align_corners=0,
    )
    graph = helper.make_graph([node], "gs_test", [im, grid], [out])
    model = helper.make_model(graph, opset_imports=[helper.make_opsetid("", 16)])
    onnx.save(model, str(path))


@pytest.fixture()
def gridsample_onnx(tmp_path: Path) -> Path:
    """Build a tiny ONNX file with a single GridSample node."""
    p = tmp_path / "gs_model.onnx"
    _build_gridsample_onnx(p)
    return p


class TestGridSampleOnnxRewrite:
    """Tests for the ONNX-level GridSample → Gather(axis=0) rewrite."""

    def test_module_import_does_not_raise(self) -> None:
        """Importing the converter module must succeed regardless of onnx2tf version."""
        import rfdetr.export._tflite.exporter  # noqa: F401

    def test_skipped_rewrite_names_the_package_to_install(
        self, monkeypatch: pytest.MonkeyPatch, caplog: pytest.LogCaptureFixture, tmp_path: Path
    ) -> None:
        """Without ``onnx_graphsurgeon``, the warning advises only an install that works on every Python version.

        ``rfdetr[onnx]`` does not install it, and ``rfdetr[tflite]`` installs nothing outside Python 3.12, so advice
        naming only the extra leaves an ``onnx2tf`` installed next to ``rfdetr[onnx]`` without the rewrite. The warning
        quotes the rewrite's own error, so the real import failure runs here, not a stub of the rewrite: a second
        "Install with" in that error would contradict the warning's.
        """
        monkeypatch.setitem(sys.modules, "onnx_graphsurgeon", None)
        monkeypatch.setattr(logging.getLogger("rf-detr"), "propagate", True)
        exporter = TFLiteExporter(TFLiteConfig(output_dir=tmp_path))

        with caplog.at_level(logging.WARNING, logger="rf-detr"):
            exporter._rewrite_gridsample(tmp_path / "model.onnx", tmp_path)

        # pytest>=9.1 also attaches caplog to the non-propagating "rf-detr" logger, so with propagation forced on above
        # each record is captured twice, as the same object; dropping repeated objects keeps a warning logged twice.
        messages = [record.getMessage() for record in dict.fromkeys(caplog.records)]
        assert [re.findall(r"Install with: pip install (\S+)", m) for m in messages] == [["onnx_graphsurgeon"]]

    @_requires_onnx_graphsurgeon
    def test_no_gridsample_nodes_after_rewrite(self, gridsample_onnx: Path, tmp_path: Path) -> None:
        """_replace_gridsample_for_tflite removes all GridSample nodes from the graph."""
        import onnx
        import onnx_graphsurgeon as gs

        from rfdetr.export._tflite.exporter import _replace_gridsample_for_tflite

        patched_path = _replace_gridsample_for_tflite(gridsample_onnx, tmp_path)

        model = onnx.load(str(patched_path))
        graph = gs.import_onnx(model)
        remaining = [n for n in graph.nodes if n.op == "GridSample"]
        assert remaining == [], f"Expected no GridSample nodes; found {len(remaining)}"

    @_requires_onnx_graphsurgeon
    def test_gather_nodes_present_after_rewrite(self, gridsample_onnx: Path, tmp_path: Path) -> None:
        """Rewritten graph contains Gather nodes (the TFLite-safe replacement ops)."""
        import onnx
        import onnx_graphsurgeon as gs

        from rfdetr.export._tflite.exporter import _replace_gridsample_for_tflite

        patched_path = _replace_gridsample_for_tflite(gridsample_onnx, tmp_path)

        model = onnx.load(str(patched_path))
        graph = gs.import_onnx(model)
        gather_nodes = [n for n in graph.nodes if n.op == "Gather"]
        assert len(gather_nodes) >= 4, f"Expected ≥4 Gather nodes (one per bilinear corner); found {len(gather_nodes)}"

    @_requires_onnx_graphsurgeon
    def test_numerical_equivalence_vs_pytorch(self, gridsample_onnx: Path, tmp_path: Path) -> None:
        """Rewritten ONNX output matches torch.nn.functional.grid_sample within 1e-5."""
        import onnxruntime as ort
        import torch
        import torch.nn.functional as F  # noqa: N812

        from rfdetr.export._tflite.exporter import _replace_gridsample_for_tflite

        rng = np.random.default_rng(0)
        im_np = rng.standard_normal((1, 4, 8, 8)).astype(np.float32)
        grid_np = rng.uniform(-1, 1, (1, 4, 4, 2)).astype(np.float32)

        ref = F.grid_sample(
            torch.from_numpy(im_np),
            torch.from_numpy(grid_np),
            mode="bilinear",
            padding_mode="zeros",
            align_corners=False,
        ).numpy()

        patched_path = _replace_gridsample_for_tflite(gridsample_onnx, tmp_path)
        sess = ort.InferenceSession(str(patched_path), providers=["CPUExecutionProvider"])
        (result,) = sess.run(None, {"im": im_np, "grid": grid_np})

        np.testing.assert_allclose(
            result, ref, atol=1e-5, rtol=0, err_msg="Gather(axis=0) rewrite output diverges from F.grid_sample"
        )


# ---------------------------------------------------------------------------
# TestConstantGatherElementsOnnxRewrite
# ---------------------------------------------------------------------------

#: Shape of the gathered tensor; RF-DETR's two-stage proposal gather reads boxes from a ``(1, queries, 4)`` constant.
_GATHER_DATA_SHAPE: tuple[int, int, int] = (2, 6, 4)


def _gather_indices_shape(axis: int) -> tuple[int, ...]:
    """Shape of an index tensor that selects 3 entries along *axis* of the test data.

    Examples:
        >>> _gather_indices_shape(1)
        (2, 3, 4)
    """
    return tuple(3 if dim == axis else size for dim, size in enumerate(_GATHER_DATA_SHAPE))


def _build_gather_elements_onnx(
    path: Path, data: np.ndarray, *, axis: int, constant_data: bool, cast_data: bool = False
) -> None:
    """Write a minimal ONNX model with one ``GatherElements`` node whose indices are a graph input.

    With *cast_data*, the constant reaches the gather through a ``Cast``, so the node reads a computed tensor that
    constant folding turns into a constant, as onnx2tf's own simplification pass does.

    Examples:
        Requires ``onnx`` which is optional — skipped in the doctest runner.

        >>> data = np.zeros((2, 6, 4), np.float32)
        >>> _build_gather_elements_onnx(Path("m.onnx"), data, axis=1, constant_data=True)  # doctest: +SKIP
    """
    import onnx
    from onnx import TensorProto, helper, numpy_helper

    indices = helper.make_tensor_value_info("indices", TensorProto.INT64, list(_gather_indices_shape(axis)))
    out = helper.make_tensor_value_info("out", TensorProto.FLOAT, list(_gather_indices_shape(axis)))
    nodes = [helper.make_node("GatherElements", inputs=["data", "indices"], outputs=["out"], axis=axis)]
    if constant_data:
        source = "data_initializer" if cast_data else "data"
        inputs, initializers = [indices], [numpy_helper.from_array(data, name=source)]
        if cast_data:
            nodes.insert(0, helper.make_node("Cast", inputs=[source], outputs=["data"], to=TensorProto.FLOAT))
    else:
        inputs, initializers = [helper.make_tensor_value_info("data", TensorProto.FLOAT, list(data.shape)), indices], []
    graph = helper.make_graph(nodes, "gather_elements_test", inputs, [out], initializer=initializers)
    onnx.save(helper.make_model(graph, opset_imports=[helper.make_opsetid("", 17)]), str(path))


class TestConstantGatherElementsOnnxRewrite:
    """Onnx2tf transposes a constant ``GatherElements`` input but not its indices; the rewrite keeps both in place."""

    @_requires_onnx_graphsurgeon
    @pytest.mark.parametrize("axis", [0, 1, 2])
    def test_rewritten_gather_matches_take_along_axis(self, axis: int, tmp_path: Path) -> None:
        """The rank-1 ``Gather`` replacement returns what ``GatherElements`` returns, negative indices included."""
        import onnxruntime as ort

        from rfdetr.export._tflite.exporter import _replace_gridsample_for_tflite

        rng = np.random.default_rng(0)
        data = rng.standard_normal(_GATHER_DATA_SHAPE).astype(np.float32)
        dim = _GATHER_DATA_SHAPE[axis]
        indices = rng.integers(-dim, dim, size=_gather_indices_shape(axis), dtype=np.int64)
        source = tmp_path / "gather_elements.onnx"
        _build_gather_elements_onnx(source, data, axis=axis, constant_data=True)

        patched_path = _replace_gridsample_for_tflite(source, tmp_path)
        sess = ort.InferenceSession(str(patched_path), providers=["CPUExecutionProvider"])
        (result,) = sess.run(None, {"indices": indices})

        np.testing.assert_array_equal(result, np.take_along_axis(data, indices, axis=axis))

    @_requires_onnx_graphsurgeon
    @pytest.mark.parametrize("cast_data", [False, True])
    def test_constant_data_gather_elements_is_removed(self, cast_data: bool, tmp_path: Path) -> None:
        """No ``GatherElements`` reading a constant, or a tensor that folds to one, reaches onnx2tf."""
        import onnx

        from rfdetr.export._tflite.exporter import _replace_gridsample_for_tflite

        source = tmp_path / "gather_elements.onnx"
        data = np.zeros(_GATHER_DATA_SHAPE, np.float32)
        _build_gather_elements_onnx(source, data, axis=1, constant_data=True, cast_data=cast_data)

        patched = onnx.load(str(_replace_gridsample_for_tflite(source, tmp_path)))

        assert [node.op_type for node in patched.graph.node if node.op_type == "GatherElements"] == []

    @_requires_onnx_graphsurgeon
    def test_constant_gather_with_folded_expand_shape_is_rewritten(self, tmp_path: Path) -> None:
        """Constant folding resolves an Expand target before its symbolic index dimensions are matched."""
        import onnx
        import onnxruntime as ort
        from onnx import helper, numpy_helper

        from rfdetr.export._tflite.exporter import _replace_gridsample_for_tflite

        source = tmp_path / "expanded_gather.onnx"
        data = np.arange(np.prod(_GATHER_DATA_SHAPE), dtype=np.float32).reshape(_GATHER_DATA_SHAPE)
        _build_gather_elements_onnx(source, data, axis=1, constant_data=True)
        model = onnx.load(str(source))
        model.graph.input[0].type.tensor_type.shape.dim[2].dim_value = 1
        model.graph.initializer.extend(
            [
                numpy_helper.from_array(np.array([2, 0, 4], dtype=np.int64), name="base_shape"),
                numpy_helper.from_array(np.array([0, 3, 0], dtype=np.int64), name="extra_shape"),
            ]
        )
        model.graph.node[0].input[1] = "expanded_indices"
        model.graph.node.insert(0, helper.make_node("Add", ["base_shape", "extra_shape"], ["expanded_shape"]))
        model.graph.node.insert(1, helper.make_node("Expand", ["indices", "expanded_shape"], ["expanded_indices"]))
        onnx.save(model, str(source))

        patched_path = _replace_gridsample_for_tflite(source, tmp_path)

        patched = onnx.load(str(patched_path))
        assert not any(node.op_type == "GatherElements" for node in patched.graph.node)
        indices = np.array([[[0], [3], [-1]], [[2], [1], [-2]]], dtype=np.int64)
        session = ort.InferenceSession(str(patched_path), providers=["CPUExecutionProvider"])
        (actual,) = session.run(None, {"indices": indices})
        expected = np.take_along_axis(data, np.broadcast_to(indices, _gather_indices_shape(1)), axis=1)
        np.testing.assert_array_equal(actual, expected)

    @_requires_onnx_graphsurgeon
    def test_variable_data_gather_elements_is_kept(self, tmp_path: Path) -> None:
        """A ``GatherElements`` reading a computed tensor converts correctly in onnx2tf, so it is left alone."""
        from rfdetr.export._tflite.exporter import _replace_gridsample_for_tflite

        source = tmp_path / "gather_elements.onnx"
        _build_gather_elements_onnx(source, np.zeros(_GATHER_DATA_SHAPE, np.float32), axis=1, constant_data=False)

        assert _replace_gridsample_for_tflite(source, tmp_path) == source


class TestNamedTFLiteOutputs:
    """Real conversion must preserve semantic names when signature outputs are reordered."""

    @_requires_onnx2tf
    def test_keypoint_output_names_preserve_their_tensors(self, tmp_path: Path) -> None:
        """Alphabetically sorted signatures must not swap logits and keypoint tensors."""
        import onnx
        from onnx import TensorProto, helper, numpy_helper

        from rfdetr.export._tflite.inference import _create_interpreter

        source = tmp_path / "named_outputs.onnx"
        nodes = [
            helper.make_node("ReduceMean", ["input"], ["dets"], axes=[1], keepdims=0),
            helper.make_node("Slice", ["dets", "starts", "ends", "slice_axes"], ["labels"]),
            helper.make_node("Unsqueeze", ["dets", "expand_axes"], ["keypoints"]),
        ]
        shapes = {"dets": [1, 4, 4], "labels": [1, 4, 3], "keypoints": [1, 4, 1, 4]}
        graph = helper.make_graph(
            nodes,
            "named_outputs",
            [helper.make_tensor_value_info("input", TensorProto.FLOAT, [1, 3, 4, 4])],
            [helper.make_tensor_value_info(name, TensorProto.FLOAT, shape) for name, shape in shapes.items()],
            initializer=[
                numpy_helper.from_array(np.asarray(value, dtype=np.int64), name=name)
                for name, value in {"starts": [0], "ends": [3], "slice_axes": [2], "expand_axes": [2]}.items()
            ],
        )
        onnx.save(helper.make_model(graph, opset_imports=[helper.make_opsetid("", 17)]), str(source))

        artifact = TFLiteExporter(TFLiteConfig(output_dir=tmp_path, verbose=False)).convert_onnx(source)

        interpreter = _create_interpreter(artifact)
        outputs = interpreter.get_signature_runner().get_output_details()
        assert {name: len(details["shape"]) for name, details in outputs.items()} == {
            "dets": 3,
            "labels": 3,
            "keypoints": 4,
        }


class TestStaticUnsqueezeOnnxRewrite:
    """Static singleton insertion must preserve coordinate axes through onnx2tf conversion."""

    @_requires_onnx_graphsurgeon
    def test_coordinate_broadcast_uses_reshape(self, tmp_path: Path) -> None:
        """Equal query and coordinate widths cannot confuse Unsqueeze's channel-layout handling."""
        import onnx
        import onnxruntime as ort
        from onnx import TensorProto, helper, numpy_helper

        from rfdetr.export._tflite.exporter import _replace_gridsample_for_tflite

        source = tmp_path / "coordinate_broadcast.onnx"
        node = helper.make_node("Unsqueeze", ["coordinates", "axes"], ["expanded"])
        graph = helper.make_graph(
            [node],
            "coordinate_broadcast",
            [helper.make_tensor_value_info("coordinates", TensorProto.FLOAT, [1, 4, 4])],
            [helper.make_tensor_value_info("expanded", TensorProto.FLOAT, [1, 4, 1, 1, 4])],
            initializer=[numpy_helper.from_array(np.array([2, 3], dtype=np.int64), name="axes")],
        )
        onnx.save(helper.make_model(graph, opset_imports=[helper.make_opsetid("", 17)]), str(source))

        patched_path = _replace_gridsample_for_tflite(source, tmp_path)

        patched = onnx.load(str(patched_path))
        assert not any(node.op_type == "Unsqueeze" for node in patched.graph.node)
        coordinates = np.arange(16, dtype=np.float32).reshape(1, 4, 4)
        session = ort.InferenceSession(str(patched_path), providers=["CPUExecutionProvider"])
        (actual,) = session.run(None, {"coordinates": coordinates})
        np.testing.assert_array_equal(actual, coordinates[:, :, None, None, :])


# ---------------------------------------------------------------------------
# TestPreloadTensorflowBeforeOnnx
# ---------------------------------------------------------------------------


def _drop_from_sys_modules(monkeypatch: pytest.MonkeyPatch, top_level: str) -> None:
    """Remove *top_level* and every already-imported submodule of it from ``sys.modules`` for one test.

    Import state leaks across tests — other tests in this suite import ``onnx``, and an environment with the ``tflite``
    extra installed may have TensorFlow loaded — which would otherwise make the import-order assertions below depend on
    test ordering. Submodules matter as much as the top-level name: a leftover ``tensorflow.python`` entry means
    TensorFlow is loaded, and it sits ahead of any freshly inserted key. ``monkeypatch.delitem`` restores every entry at
    teardown.

    Args:
        monkeypatch: Fixture used to delete and later restore the entries.
        top_level: Top-level package name, e.g. ``"onnx"`` or ``"tensorflow"``.

    Examples:
        >>> import sys, types
        >>> mp = pytest.MonkeyPatch()
        >>> mp.setitem(sys.modules, "onnx", types.ModuleType("onnx"))
        >>> mp.setitem(sys.modules, "onnx.helper", types.ModuleType("onnx.helper"))
        >>> _drop_from_sys_modules(mp, "onnx")
        >>> any(n == "onnx" or n.startswith("onnx.") for n in sys.modules)
        False
        >>> mp.undo()
    """
    for name in [n for n in list(sys.modules) if n == top_level or n.startswith(f"{top_level}.")]:
        monkeypatch.delitem(sys.modules, name)


class TestPreloadTensorflowBeforeOnnx:
    """Tests for ``preload_tensorflow_before_onnx()`` — the TFLite Abseil-deadlock guard."""

    @staticmethod
    def _call_with_fake_tf(monkeypatch: pytest.MonkeyPatch) -> mock.MagicMock:
        """Run the preload with a stubbed ``importlib.import_module`` and return the stub.

        Args:
            monkeypatch: Fixture used to stub the import and undo it afterwards.

        Returns:
            The stubbed ``import_module``, for asserting whether TensorFlow was imported.

        Examples:
            Needs pytest's ``monkeypatch`` fixture, so the live call is covered by tests rather than doctest.

            >>> callable(TestPreloadTensorflowBeforeOnnx._call_with_fake_tf)  # doctest: +SKIP
            True
        """
        import_mock = mock.MagicMock(return_value=types.ModuleType("tensorflow"))
        monkeypatch.setattr("rfdetr.export._backend.importlib.import_module", import_mock)
        from rfdetr.export._backend import preload_tensorflow_before_onnx

        preload_tensorflow_before_onnx()
        return import_mock

    def test_imports_tensorflow_when_absent(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """TensorFlow is imported when it is not yet in sys.modules."""
        _drop_from_sys_modules(monkeypatch, "tensorflow")

        import_mock = self._call_with_fake_tf(monkeypatch)

        import_mock.assert_called_once_with("tensorflow")

    def test_noop_when_tensorflow_already_imported(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Already-imported TensorFlow short-circuits the import (the load order is already fixed)."""
        monkeypatch.setitem(sys.modules, "tensorflow", types.ModuleType("tensorflow"))

        import_mock = self._call_with_fake_tf(monkeypatch)

        import_mock.assert_not_called()

    def test_silent_when_tensorflow_not_installed(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """A missing TensorFlow is swallowed — ``_check_onnx2tf_available`` reports it with install instructions."""
        _drop_from_sys_modules(monkeypatch, "tensorflow")
        monkeypatch.setattr(
            "rfdetr.export._backend.importlib.import_module",
            mock.MagicMock(side_effect=ModuleNotFoundError("No module named 'tensorflow'", name="tensorflow")),
        )
        from rfdetr.export._backend import preload_tensorflow_before_onnx

        preload_tensorflow_before_onnx()  # must not raise

    def test_surfaces_transitive_tensorflow_import_error(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """A missing dependency imported by TensorFlow is not mistaken for TensorFlow being absent."""
        _drop_from_sys_modules(monkeypatch, "tensorflow")
        missing_absl = ModuleNotFoundError("No module named 'absl'", name="absl")
        monkeypatch.setattr(
            "rfdetr.export._backend.importlib.import_module",
            mock.MagicMock(side_effect=missing_absl),
        )
        from rfdetr.export._backend import preload_tensorflow_before_onnx

        with pytest.raises(ModuleNotFoundError, match="No module named 'absl'") as caught:
            preload_tensorflow_before_onnx()

        assert caught.value.name == "absl"

    @pytest.mark.parametrize(
        ("preloaded", "expect_warning"),
        [
            pytest.param(("onnx",), True, id="onnx-only"),
            pytest.param((), False, id="neither"),
            pytest.param(("onnx", "tensorflow"), True, id="onnx-then-tensorflow"),
            pytest.param(("tensorflow", "onnx"), False, id="tensorflow-then-onnx"),
        ],
    )
    def test_warning_tracks_import_order(
        self,
        preloaded: tuple[str, ...],
        expect_warning: bool,
        monkeypatch: pytest.MonkeyPatch,
        caplog: Any,
    ) -> None:
        """Warn only when ``onnx`` entered ``sys.modules`` ahead of ``tensorflow``.

        ``onnx`` first is unrecoverable in-process, so the deadlock risk is logged.  ``tensorflow`` first — the safe
        order — must stay quiet, otherwise the warning trains callers who did the right thing to ignore it.
        """
        # The warning is logged once per process, so every case starts from an unwarned module.
        monkeypatch.setattr("rfdetr.export._backend._ONNX_ORDER_WARNED", False)
        for package in ("onnx", "tensorflow"):
            _drop_from_sys_modules(monkeypatch, package)
        for package in preloaded:
            monkeypatch.setitem(sys.modules, package, types.ModuleType(package))
        rf_detr_logger = logging.getLogger("rf-detr")
        monkeypatch.setattr(rf_detr_logger, "propagate", True)

        with caplog.at_level(logging.WARNING, logger="rf-detr"):
            self._call_with_fake_tf(monkeypatch)

        messages = [r.getMessage() for r in caplog.records if r.levelno >= logging.WARNING]
        warned = any("onnx was imported before TensorFlow" in msg for msg in messages)
        assert warned is expect_warning, (
            f"Preloaded {preloaded or '()'}: expected warning={expect_warning}, got messages: {messages}"
        )


class TestExportTflitePreloadOrder:
    """``TFLiteExporter.convert_onnx()`` preloads TensorFlow before it touches onnx.

    Deliberately **not** gated on ``_requires_onnx2tf``: the ``fake_onnx2tf`` fixture injects a stub module and the
    availability check is patched out, so this runs — and covers the preload call inside ``convert_onnx()`` — in CI,
    which never installs the ``tflite`` extra.
    """

    def test_preload_runs_before_onnx2tf_check(
        self,
        onnx_model: Path,
        tflite_output: Path,
        fake_onnx2tf: Any,
        mock_prepare_calib: Any,
        mocker,
    ) -> None:
        """The preload is the first thing ``convert_onnx`` does, ahead of the onnx2tf availability check."""
        calls: list[str] = []
        mocker.patch(
            "rfdetr.export._backend.preload_tensorflow_before_onnx", side_effect=lambda: calls.append("preload")
        )
        mocker.patch(
            "rfdetr.export._tflite.exporter._check_onnx2tf_available", side_effect=lambda: calls.append("check")
        )
        mocker.patch("rfdetr.export._tflite.exporter._check_tf_keras_available")

        _run_convert_onnx(onnx_model, tflite_output)

        assert calls == ["preload", "check"], f"Expected preload before the onnx2tf check, got {calls}"


class TestTFKerasCheck:
    """``_check_tf_keras_available`` passes an installed tf-keras; a missing one is covered in ``test_export``.

    No CI job installs the ``[tflite]`` extra, so these stand in for the real package the check must not refuse.
    """

    def test_installed_tf_keras_passes_without_being_imported(
        self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path
    ) -> None:
        """A findable ``tf_keras`` passes, and is left for the conversion to import: Keras need not load earlier."""
        (tmp_path / "tf_keras").mkdir()
        (tmp_path / "tf_keras" / "__init__.py").write_text("")
        monkeypatch.delitem(sys.modules, "tf_keras", raising=False)
        monkeypatch.syspath_prepend(str(tmp_path))

        _check_tf_keras_available()

        assert "tf_keras" not in sys.modules

    def test_already_imported_tf_keras_passes(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """A ``tf_keras`` already in ``sys.modules`` passes, even one without the ``__spec__`` a lookup would need."""
        monkeypatch.setitem(sys.modules, "tf_keras", types.ModuleType("tf_keras"))

        _check_tf_keras_available()


class TestSingleOnnxsimOwnerCheck:
    """``_check_single_onnxsim_owner`` refuses a host where two distributions install the ``onnxsim`` package.

    onnx2tf 2.4.x simplifies the ONNX graph through the ``onnxsim`` console script of its pinned ``onnxsim-prebuilt``. A
    separately installed ``onnxsim`` wheel writes the same ``onnxsim/`` package and script, the one installed last
    replaces the other, and onnx2tf then runs a simplifier it does not pin: ``onnxsim`` 0.8.1 made the conversion crash.
    """

    @pytest.mark.parametrize(
        "owners",
        [
            pytest.param({"onnxsim": ["onnxsim-prebuilt"]}, id="prebuilt-only"),
            pytest.param({"onnxsim": ["onnxsim"]}, id="onnxsim-only"),
            pytest.param({}, id="neither"),
        ],
    )
    def test_single_or_no_owner_passes(self, monkeypatch: pytest.MonkeyPatch, owners: dict[str, list[str]]) -> None:
        """One distribution owning ``onnxsim``, or none, passes: there is no second copy to replace the first.

        onnx2tf 2.4.x depends on ``onnxsim-prebuilt`` and 2.5+ on ``onnxsim``, so either owner alone is a consistent
        install; a host without either fails later, in onnx2tf's own simplification step, not here.
        """
        monkeypatch.setattr("rfdetr.export._tflite.exporter.packages_distributions", lambda: owners)

        _check_single_onnxsim_owner()

    @pytest.mark.parametrize(
        "owners",
        [
            pytest.param(["onnxsim", "onnxsim-prebuilt"], id="hyphenated"),
            pytest.param(["onnxsim_prebuilt", "onnxsim"], id="underscored"),
        ],
    )
    def test_both_owners_are_refused(self, monkeypatch: pytest.MonkeyPatch, owners: list[str]) -> None:
        """``onnxsim`` and ``onnxsim-prebuilt`` installed together are refused, naming the reinstall that fixes it.

        This is the environment the ``onnxsim>=0.7.0`` line in ``rfdetr[tflite]`` produced; dropping the line from the
        extra does not remove the wheel from an environment that already has it. Distribution names are compared in
        normalized form, since metadata may spell the prebuilt with an underscore.
        """
        monkeypatch.setattr("rfdetr.export._tflite.exporter.packages_distributions", lambda: {"onnxsim": owners})

        with pytest.raises(ImportError, match="pip uninstall -y onnxsim onnxsim-prebuilt"):
            _check_single_onnxsim_owner()

    def test_check_environment_refuses_both_owners(self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
        """``TFLiteExporter.check_environment`` runs the owner check, refusing the host before the forward pass.

        ``RFDETR.export`` and ``Exporter.__call__`` call ``check_environment`` before any work on the model starts.
        """
        monkeypatch.setattr(
            "rfdetr.export._tflite.exporter.packages_distributions",
            lambda: {"onnxsim": ["onnxsim", "onnxsim-prebuilt"]},
        )
        exporter = TFLiteExporter(TFLiteConfig(output_dir=str(tmp_path)))

        with pytest.raises(ImportError, match="onnxsim-prebuilt"):
            exporter.check_environment()

    def test_convert_onnx_refuses_both_owners(self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
        """``convert_onnx``, a public entry point that bypasses ``Exporter.__call__``, runs the owner check first.

        The source path does not exist, so reaching the source validation would raise ``FileNotFoundError`` instead.
        """
        monkeypatch.setattr(
            "rfdetr.export._tflite.exporter.packages_distributions",
            lambda: {"onnxsim": ["onnxsim", "onnxsim-prebuilt"]},
        )
        exporter = TFLiteExporter(TFLiteConfig(output_dir=str(tmp_path)))

        with pytest.raises(ImportError, match="onnxsim-prebuilt"):
            exporter.convert_onnx(tmp_path / "missing.onnx")


def _stop_at_onnx_import(name: str, path: object, target: object = None) -> None:
    """``find_spec`` of a ``sys.meta_path`` finder that raises at an import of ``onnx`` and passes on every other one.

    Returning ``None`` hands the import to the next finder, so only ``onnx`` is affected.

    Args:
        name: Fully qualified name of the module being imported.
        path: Parent package's ``__path__``, or ``None`` for a top-level import.
        target: Module object being reloaded, if any.

    Examples:
        >>> _stop_at_onnx_import("json", None) is None
        True
        >>> _stop_at_onnx_import("onnx", None)
        Traceback (most recent call last):
        ...
        RuntimeError: stopped at the first onnx import
    """
    if name == "onnx":
        raise RuntimeError("stopped at the first onnx import")


class TestTFLiteDependencyCheckOrder:
    """``TFLiteExporter.check_dependencies`` loads TensorFlow before anything imports onnx (issue #1322), and imports
    nothing whose import has side effects the forward pass must not see.

    Not gated on ``onnx2tf``: TensorFlow is a stand-in module and the tf-keras check is stubbed, so this runs in the CPU
    job.
    """

    def test_tensorflow_is_loaded_before_onnx_is_imported(
        self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path
    ) -> None:
        """The preload runs before the first import of ``onnx``.

        ``onnx`` is dropped from ``sys.modules``, so the check has to import it again, and a finder first on
        ``sys.meta_path`` stops the check the moment ``onnx`` is asked for: a preload placed after that import never
        runs. The finder sees an ``import`` statement and ``importlib.import_module`` alike; recording calls alone would
        miss an import placed above the preload.
        """
        events: list[str] = []
        exporter = TFLiteExporter(TFLiteConfig(output_dir=tmp_path))
        monkeypatch.delitem(sys.modules, "onnx", raising=False)
        monkeypatch.setitem(sys.modules, "tensorflow", types.ModuleType("tensorflow"))
        monkeypatch.setattr("rfdetr.export._backend.preload_tensorflow_before_onnx", lambda: events.append("preload"))
        monkeypatch.setattr("rfdetr.export._tflite.exporter._check_tf_keras_available", lambda: None)
        monkeypatch.setattr(sys, "meta_path", [types.SimpleNamespace(find_spec=_stop_at_onnx_import), *sys.meta_path])

        with pytest.raises(RuntimeError, match="first onnx import"):
            exporter.check_dependencies()

        assert events == ["preload"], "the check imported onnx before it preloaded TensorFlow"

    def test_onnx2tf_converter_module_is_not_imported(self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
        """The check imports the top-level ``onnx2tf`` only, never its converter module ``onnx2tf.onnx2tf``.

        Importing the converter module seeds ``random``/``numpy`` and installs a warnings filter, which must wait until
        after the forward pass. A stand-in ``onnx2tf`` package that has both modules is put first on ``sys.path``.
        """
        package = tmp_path / "onnx2tf"
        package.mkdir()
        (package / "__init__.py").write_text("")
        (package / "onnx2tf.py").write_text("")
        monkeypatch.setattr("rfdetr.export._backend.preload_tensorflow_before_onnx", lambda: None)
        monkeypatch.setattr("rfdetr.export._tflite.exporter._check_tf_keras_available", lambda: None)
        monkeypatch.setattr("rfdetr.export._backend.check_onnx_available", lambda install_hint, *, stage: None)
        monkeypatch.setattr("rfdetr.export._tflite.exporter._check_onnx_graphsurgeon_available", lambda: None)
        monkeypatch.syspath_prepend(str(tmp_path))

        # Restores sys.modules afterwards, dropping the stand-in package this test imports.
        with mock.patch.dict(sys.modules, {"tensorflow": types.ModuleType("tensorflow")}):
            sys.modules.pop("onnx2tf", None)
            sys.modules.pop("onnx2tf.onnx2tf", None)
            TFLiteExporter.check_dependencies()
            converter_imported = "onnx2tf.onnx2tf" in sys.modules

        assert not converter_imported


class TestExportTfliteAppliesInterpreterPath:
    """``convert_onnx()`` must apply :func:`_interpreter_scripts_on_path` around ``onnx2tf.convert``.

    Deliberately **not** gated on ``_requires_onnx2tf``: ``fake_onnx2tf`` injects a stub so this runs in CI.
    """

    def test_convert_sees_interpreter_scripts_dir_on_path(
        self,
        onnx_model: Path,
        tflite_output: Path,
        fake_onnx2tf: Any,
        mock_prepare_calib: Any,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """``onnx2tf.convert`` runs with the interpreter script directory first on ``PATH``."""
        monkeypatch.setenv("PATH", "/usr/bin")
        monkeypatch.setattr("rfdetr.export._tflite.exporter._check_tf_keras_available", lambda: None)
        seen: list[str] = []
        _, convert_mock = fake_onnx2tf

        def _capture_path(*_args: Any, **_kwargs: Any) -> None:
            seen.append(os.environ.get("PATH", ""))

        convert_mock.side_effect = _capture_path

        _run_convert_onnx(onnx_model, tflite_output)

        assert seen, "onnx2tf.convert was not called"
        first = seen[0].split(os.pathsep)[0]
        assert first == str(Path(sys.executable).parent), (
            f"Expected the interpreter script dir first during convert(), got {first!r}"
        )
        assert os.environ["PATH"] == "/usr/bin", "PATH must be restored after convert_onnx() returns"


# ---------------------------------------------------------------------------
# TestInterpreterScriptsOnPath
# ---------------------------------------------------------------------------


class TestInterpreterScriptsOnPath:
    """Tests for ``_interpreter_scripts_on_path()`` — makes onnx2tf's ``onnxsim`` subprocess resolvable."""

    @pytest.mark.parametrize(
        ("original_path", "expected_path"),
        [
            pytest.param("/usr/bin", "/usr/bin", id="nonempty"),
            pytest.param("", "", id="explicit-empty"),
            pytest.param(None, None, id="unset"),
        ],
    )
    def test_restores_path_on_exception(
        self,
        monkeypatch: pytest.MonkeyPatch,
        original_path: str | None,
        expected_path: str | None,
    ) -> None:
        """PATH value and presence are restored even when the wrapped conversion raises."""
        if original_path is None:
            monkeypatch.delenv("PATH", raising=False)
        else:
            monkeypatch.setenv("PATH", original_path)

        with pytest.raises(RuntimeError, match="boom"), _interpreter_scripts_on_path():
            raise RuntimeError("boom")

        if expected_path is None:
            assert "PATH" not in os.environ
        else:
            assert os.environ["PATH"] == expected_path

    def test_no_duplicate_when_already_on_path(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Preferred script directories already at the front are not duplicated or reordered."""
        preferred = list(dict.fromkeys([str(Path(sys.executable).parent), sysconfig.get_path("scripts")]))
        monkeypatch.setenv("PATH", os.pathsep.join([*preferred, "/usr/bin"]))
        before = os.environ["PATH"]

        with _interpreter_scripts_on_path():
            inside = os.environ["PATH"]

        assert inside == before, f"PATH was modified unnecessarily: {inside!r}"

    def test_moves_existing_script_dirs_to_front(self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
        """Preferred script directories move ahead of unrelated PATH entries without duplicates."""
        preferred = list(dict.fromkeys([str(Path(sys.executable).parent), sysconfig.get_path("scripts")]))
        unrelated = str(tmp_path)
        monkeypatch.setenv("PATH", os.pathsep.join([unrelated, *preferred, unrelated]))

        with _interpreter_scripts_on_path():
            entries = os.environ["PATH"].split(os.pathsep)

        assert entries[: len(preferred)] == preferred
        assert entries[len(preferred) :] == [unrelated, unrelated]

    @pytest.mark.parametrize(
        "executable",
        [pytest.param("", id="empty"), pytest.param("python", id="relative")],
    )
    def test_skips_empty_or_relative_executable(self, monkeypatch: pytest.MonkeyPatch, executable: str) -> None:
        """Invalid executable paths do not add the current directory to PATH."""
        monkeypatch.setattr("rfdetr.export._tflite.exporter.sys.executable", executable)
        scripts_dir = sysconfig.get_path("scripts")
        monkeypatch.setenv("PATH", "/usr/bin")

        with _interpreter_scripts_on_path():
            entries = os.environ["PATH"].split(os.pathsep)

        assert entries[0] == scripts_dir
        assert "." not in entries

    def test_restores_explicit_empty_path(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """An explicitly empty PATH remains present and empty after cleanup."""
        monkeypatch.setenv("PATH", "")

        with _interpreter_scripts_on_path():
            assert os.environ["PATH"]

        assert "PATH" in os.environ
        assert os.environ["PATH"] == ""

    def test_restores_unset_path(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """An originally unset PATH remains absent after cleanup."""
        monkeypatch.delenv("PATH", raising=False)

        with _interpreter_scripts_on_path():
            assert os.environ["PATH"]

        assert "PATH" not in os.environ


class TestTFLitePreloadOrdering:
    """The TensorFlow preload must still happen before anything on the TFLite path imports ONNX.

    ``onnx``'s C extension and TensorFlow both statically link Abseil and export its symbols weakly, so whichever loads
    first supplies them to both. When ONNX wins, the TFLite conversion blocks forever restoring the SavedModel bundle —
    a 0%-CPU hang with no traceback (issue #1322). ``TFLiteExporter`` guards that by calling
    ``preload_tensorflow_before_onnx()`` before it touches the ONNX stage. This class pins that the preload really does
    run first; that loading the exporter module imports no ONNX package is pinned by
    ``TestExportDependencyCheck::test_loading_the_exporter_imports_no_onnx_package`` in ``test_export.py``.
    """

    def test_preload_runs_before_the_onnx_stage(self, tmp_path: Path, mocker) -> None:
        """``TFLiteExporter`` must call the preload before it runs its ONNX export, not after."""
        calls: list[str] = []
        graph = mock.MagicMock()
        graph.backbone_only = False
        exporter = TFLiteExporter(TFLiteConfig(output_dir=tmp_path))
        mocker.patch(
            "rfdetr.export._backend.preload_tensorflow_before_onnx", side_effect=lambda: calls.append("preload")
        )
        mocker.patch(
            "rfdetr.export._onnx.exporter.OnnxExporter._convert",
            side_effect=lambda _self, _graph: (calls.append("onnx"), str(tmp_path / "model.onnx"))[1],
            autospec=True,
        )
        mocker.patch(
            "rfdetr.export._tflite.exporter.TFLiteExporter.convert_onnx",
            side_effect=lambda *_a, **_kw: (calls.append("tflite"), tmp_path / "model_fp32.tflite")[1],
        )
        # The preload runs inside check_dependencies, which also wants TensorFlow, tf-keras, onnx_graphsurgeon and
        # onnx2tf; the CPU job has none of them, so TensorFlow is a stand-in module and the other three are stubbed.
        mocker.patch.dict(sys.modules, {"tensorflow": types.ModuleType("tensorflow")})
        mocker.patch("rfdetr.export._tflite.exporter._check_tf_keras_available")
        mocker.patch("rfdetr.export._tflite.exporter._check_onnx_graphsurgeon_available")
        mocker.patch("rfdetr.export._tflite.exporter._check_onnx2tf_available")

        exporter(graph)

        assert calls == ["preload", "onnx", "tflite"]
