# ------------------------------------------------------------------------
# RF-DETR
# Copyright (c) 2025 Roboflow. All Rights Reserved.
# Licensed under the Apache License, Version 2.0 [see LICENSE for details]
# ------------------------------------------------------------------------
"""Tests for native CoreML (``.mlpackage``) export.

Covers:
* ``CoreMLExporter`` — argument/dependency behaviour (``coremltools`` mocked where needed)
* ``format="coreml"`` wiring through ``RFDETR.export()``
* End-to-end convert + numerical parity (``@pytest.mark.e2e_coreml``, opt-in)

Parity inputs are spatially structured (gradient + checkerboard) and
``download_assets(ImageAssets.PEOPLE_WALKING)`` under ``e2e_coreml`` (no committed images).
Random Gaussian noise is intentionally avoided: it can hide export/runtime divergence that
only appears on correlated image structure.
"""

from __future__ import annotations

import contextlib
import json
import logging
import os
from collections import Counter
from pathlib import Path
from types import SimpleNamespace
from typing import Any
from unittest import mock

import numpy as np
import pytest
import torch
from PIL import Image
from pytest_mock import MockerFixture
from supervision.assets import ImageAssets, download_assets

import rfdetr
from rfdetr.export._backend import _BackboneExport
from rfdetr.export._coreml import _IS_COREMLTOOLS_AVAILABLE
from rfdetr.export._coreml.exporter import CoreMLConfig, CoreMLExporter, _check_coremltools_available, _CoreMLApi
from rfdetr.export._naming import resolve_export_stem
from rfdetr.utilities.package import get_version
from rfdetr.utilities.reproducibility import seed_all
from tests.export.conftest import (
    _export_graph,
    _make_rfdetr,
    _parity_input_from_image,
    _structured_parity_input,
    eager_reference_tensors,
    max_abs_output_diffs,
)
from tests.export.coreml.test_coreml_ane import _IOS15_SPEC_VERSION

_requires_coremltools = pytest.mark.skipif(not _IS_COREMLTOOLS_AVAILABLE, reason="coremltools not installed")

# FLOAT32 CoreML convert matches eager to ~1e-5 on boxes/logits; masks need a bit more
# headroom (~8e-5 observed on SegNano; keypoints ~1e-5 observed on KeypointPreview). Bound stays
# well under structural-failure scale (>=1e-3).
_COREML_MAX_ABS_DIFF = 1e-4


def _coreml_parity_diffs(
    mlpackage_path: Path,
    pytorch_model: torch.nn.Module,
    example_input: torch.Tensor,
) -> list[float]:
    """Run *example_input* through eager export-mode PyTorch and CoreML; return per-output max-abs-diff.

    Export-mode ``forward`` can mutate its input, so each side gets a fresh clone. CoreML outputs are
    taken in ``MLModel`` spec order and paired with the eager tuple in the same order.

    Args:
        mlpackage_path: Path to the exported ``.mlpackage``.
        pytorch_model: Export-mode PyTorch module on CPU.
        example_input: ``(N, C, H, W)`` example tensor.

    Returns:
        One max-abs-diff per output tensor.

    Raises:
        AssertionError: If output counts or shapes disagree.
        ImportError: If ``coremltools`` is not installed.

    Examples:
        Requires a real exported ``.mlpackage`` and ``coremltools`` — not runnable standalone.
        See ``TestCoreMLEndToEnd`` for real invocations.

        >>> callable(_coreml_parity_diffs)
        True
    """
    import coremltools as ct

    eager_tensors = eager_reference_tensors(pytorch_model, example_input)

    # CPU_ONLY avoids ANE/GPU fp16 execution drift when validating FLOAT32 bundles.
    mlmodel = ct.models.MLModel(str(mlpackage_path), compute_units=ct.ComputeUnit.CPU_ONLY)
    spec = mlmodel.get_spec()
    input_name = spec.description.input[0].name
    output_names = [o.name for o in spec.description.output]
    prediction = mlmodel.predict({input_name: np.ascontiguousarray(example_input.detach().cpu().numpy())})
    coreml_tensors = [torch.from_numpy(np.asarray(prediction[name], dtype=np.float32)) for name in output_names]

    return max_abs_output_diffs(eager_tensors, coreml_tensors, check_shape=True, names=output_names)


def _validate_coreml_vs_pytorch(
    mlpackage_path: Path,
    pytorch_model: torch.nn.Module,
    example_input: torch.Tensor,
    *,
    output_labels: tuple[str, ...],
) -> None:
    """Compare every CoreML output to eager export-mode PyTorch and assert parity within tolerance.

    ``output_labels`` names the outputs the export is expected to yield, in order — ``("boxes", "logits")`` for
    detection, plus ``"masks"`` or ``"keypoints"`` as the third slot for segmentation and keypoint heads. Masks and
    keypoints share that slot and are both rank-4, so the count alone does not distinguish them; per-output shapes
    are asserted by :func:`_coreml_parity_diffs` against eager.

    Args:
        mlpackage_path: Path to the exported ``.mlpackage``.
        pytorch_model: Export-mode PyTorch module on CPU.
        example_input: ``(N, C, H, W)`` tensor used for both forwards.
        output_labels: Expected output names in export order; the count must match the exported outputs.

    Raises:
        AssertionError: When output count/shape disagrees or max-abs-diff exceeds tolerance.

    Examples:
        Stub the CoreML comparison so the validator can run without a real export.

        >>> with mock.patch(
        ...     f"{_validate_coreml_vs_pytorch.__module__}._coreml_parity_diffs",
        ...     return_value=[0.0, 0.0],
        ... ):
        ...     _validate_coreml_vs_pytorch(
        ...         Path("model.mlpackage"),
        ...         torch.nn.Identity(),
        ...         torch.zeros(1, 3, 1, 1),
        ...         output_labels=("boxes", "logits"),
        ...     )

        A mismatched output count is reported against the expected labels.

        >>> with mock.patch(
        ...     f"{_validate_coreml_vs_pytorch.__module__}._coreml_parity_diffs",
        ...     return_value=[0.0, 0.0],
        ... ):
        ...     _validate_coreml_vs_pytorch(
        ...         Path("model.mlpackage"),
        ...         torch.nn.Identity(),
        ...         torch.zeros(1, 3, 1, 1),
        ...         output_labels=("boxes", "logits", "masks"),
        ...     )
        Traceback (most recent call last):
            ...
        AssertionError: CoreML export must yield ('boxes', 'logits', 'masks'), got 2 outputs
        ...
    """
    diffs = _coreml_parity_diffs(mlpackage_path, pytorch_model, example_input)
    assert len(diffs) == len(output_labels), f"CoreML export must yield {output_labels}, got {len(diffs)} outputs"
    per_output = ", ".join(f"{label}={diff}" for label, diff in zip(output_labels, diffs))
    assert max(diffs) < _COREML_MAX_ABS_DIFF, (
        f"CoreML outputs diverge from PyTorch: max abs diff {max(diffs)} ({per_output}, bound={_COREML_MAX_ABS_DIFF})"
    )


def _mil_op_counts(spec: Any) -> Counter[str]:
    """Return per-type MIL operation counts in *spec*'s active ``main`` block, nested blocks included.

    A multiset rather than a set of types: type membership alone cannot see a shape-driven lowering route that
    reuses an op type both graphs already contain but emits far more of it. ``cond``/``while_loop`` carry their
    body in ``Operation.blocks``, so a top-level-only walk would silently stop reporting once such an op appears.

    Args:
        spec: A CoreML ``Model`` protobuf (``coremltools.utils.load_spec``) holding an ``mlProgram``.

    Returns:
        A count of every ``Operation.type`` reachable from the ``main`` function's active block specialization.
        Empty when *spec* holds no ``mlProgram``: protobuf message maps default-construct on lookup rather than
        raising, so callers must treat an empty result as "traversal found nothing", not as "the graphs agree".

    Examples:
        >>> from types import SimpleNamespace
        >>> def op(type_, *blocks):
        ...     return SimpleNamespace(type=type_, blocks=list(blocks))
        >>> main = SimpleNamespace(
        ...     opset="CoreML8",
        ...     block_specializations={
        ...         "CoreML8": SimpleNamespace(
        ...             operations=[op("const"), op("const"), op("cond", SimpleNamespace(operations=[op("linear")]))]
        ...         ),
        ...         "CoreML7": SimpleNamespace(operations=[op("matmul")]),
        ...     },
        ... )
        >>> sorted(_mil_op_counts(SimpleNamespace(mlProgram=SimpleNamespace(functions={"main": main}))).items())
        [('cond', 1), ('const', 2), ('linear', 1)]
    """
    main = spec.mlProgram.functions["main"]
    counts: Counter[str] = Counter()
    pending = list(main.block_specializations[main.opset].operations)
    while pending:
        operation = pending.pop()
        counts[operation.type] += 1
        pending.extend(nested_op for block in operation.blocks for nested_op in block.operations)
    return counts


def _mil_op_types(spec: Any) -> set[str]:
    """Return the distinct MIL operation types in *spec*'s active ``main`` block, nested blocks included.

    Args:
        spec: A CoreML ``Model`` protobuf (``coremltools.utils.load_spec``) holding an ``mlProgram``.

    Returns:
        Every ``Operation.type`` reachable from the ``main`` function's active block specialization (see
        :func:`_mil_op_counts` for the traversal and the empty-result caveat).

    Examples:
        >>> from types import SimpleNamespace
        >>> def op(type_, *blocks):
        ...     return SimpleNamespace(type=type_, blocks=list(blocks))
        >>> main = SimpleNamespace(
        ...     opset="CoreML8",
        ...     block_specializations={
        ...         "CoreML8": SimpleNamespace(
        ...             operations=[op("const"), op("cond", SimpleNamespace(operations=[op("linear")]))]
        ...         ),
        ...         "CoreML7": SimpleNamespace(operations=[op("matmul")]),
        ...     },
        ... )
        >>> sorted(_mil_op_types(SimpleNamespace(mlProgram=SimpleNamespace(functions={"main": main}))))
        ['cond', 'const', 'linear']
    """
    return set(_mil_op_counts(spec))


#: Max per-op-type count the shipped-query graph may exceed the value-checked (5-query) graph by before
#: ``test_default_query_count_lowers_through_no_unchecked_operation`` flags it. Constant folding at the larger shipped
#: shape can trim a few ``const``/``reshape`` nodes; a conservative starting point, not a measurement: widen if noisy.
_MIL_OP_COUNT_TOLERANCE = 2


def _mil_op_count_regressions(
    shipped: Counter[str], checked: Counter[str], *, tolerance: int
) -> dict[str, tuple[int, int]]:
    """Return MIL op types where *shipped* exceeds *checked* by more than *tolerance* occurrences.

    One-directional by design: an op type *shipped* reaches far more than *checked* (including one *checked*
    never reaches at all, i.e. a checked count of 0) is the gap worth flagging; the reverse -- a node folded away
    only at the larger shipped shape -- is benign, same rationale as :func:`_mil_op_types`.

    Args:
        shipped: Op-type counts from the shipped-query-count graph.
        checked: Op-type counts from the value-checked (5-query) graph.
        tolerance: Maximum benign per-type count difference before a type is reported.

    Returns:
        ``{op_type: (shipped_count, checked_count)}`` for every regression found; empty when none.

    Examples:
        >>> _mil_op_count_regressions(
        ...     Counter(const=5, slice_by_index=3), Counter(const=4, slice_by_index=0), tolerance=2
        ... )
        {'slice_by_index': (3, 0)}
        >>> _mil_op_count_regressions(Counter(const=5), Counter(const=4), tolerance=2)
        {}
    """
    return {
        op_type: (shipped_count, checked[op_type])
        for op_type, shipped_count in shipped.items()
        if shipped_count - checked[op_type] > tolerance
    }


# ---------------------------------------------------------------------------
# CoreMLExporter — unit / dependency behaviour
# ---------------------------------------------------------------------------


class TestCheckCoremltoolsAvailable:
    """Tests for ``_check_coremltools_available``."""

    def test_returns_false_when_missing(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Missing ``coremltools`` must return ``False``."""
        # The check reads the import-time flag as bound into the exporter module, not coremltools itself.
        monkeypatch.setattr("rfdetr.export._coreml.exporter._IS_COREMLTOOLS_AVAILABLE", False)
        assert _check_coremltools_available(raise_error=False) is False

    @_requires_coremltools
    def test_returns_true_when_installed(self) -> None:
        """Installed ``coremltools`` must return ``True``."""
        assert _check_coremltools_available() is True


class TestExportCoremlValidation:
    """Argument and dependency behaviour of ``CoreMLExporter`` (no real convert)."""

    def test_missing_coremltools_raises_import_error(self, tmp_path: Path, mocker: MockerFixture) -> None:
        """``CoreMLExporter`` must surface the install hint when coremltools is absent."""
        mocker.patch(
            "rfdetr.export._coreml.exporter._check_coremltools_available",
            side_effect=ImportError("pip install rfdetr[coreml]"),
        )
        exporter = CoreMLExporter(CoreMLConfig(output_dir=tmp_path))
        with pytest.raises(ImportError) as exc_info:
            exporter(_export_graph(torch.nn.Linear(1, 1)))

        assert "rfdetr[coreml]" in str(exc_info.value)

    def test_unknown_precision_string_is_refused_at_construction(self, tmp_path: Path) -> None:
        """A precision string that names neither float32 nor float16 fails before the forward pass."""
        with pytest.raises(ValueError) as exc_info:
            CoreMLExporter(CoreMLConfig(output_dir=tmp_path, compute_precision="int8"))

        assert "compute_precision must be" in str(exc_info.value)

    def test_non_string_precision_is_left_to_coremltools(self, tmp_path: Path) -> None:
        """A ``coremltools.precision`` value cannot be recognized without coremltools, so construction accepts it."""
        CoreMLExporter(CoreMLConfig(output_dir=tmp_path, compute_precision=object()))

    @pytest.mark.parametrize(
        ("neural_engine", "compute_precision", "expect_warning"),
        [
            (True, None, True),
            (True, "float32", True),
            (True, "float16", False),
            (False, None, False),
        ],
    )
    def test_neural_engine_at_float32_warns_at_construction(
        self,
        tmp_path: Path,
        monkeypatch: pytest.MonkeyPatch,
        caplog: pytest.LogCaptureFixture,
        neural_engine: bool,
        compute_precision: str | None,
        expect_warning: bool,
    ) -> None:
        """The Neural Engine rewrite at float32 is legal but warns, since that artifact never reaches the ANE.

        The end-to-end parity rows export the rewrite at the default float32 precision, so it must stay an export rather
        than an error; the warning tells everyone else that they built the slower artifact.
        """
        monkeypatch.setattr(logging.getLogger("rf-detr"), "propagate", True)

        with caplog.at_level(logging.WARNING, logger="rf-detr"):
            CoreMLExporter(
                CoreMLConfig(output_dir=tmp_path, compute_precision=compute_precision, neural_engine=neural_engine)
            )

        messages = [record.getMessage() for record in caplog.records]
        assert any("the Neural Engine runs float16 only" in message for message in messages) is expect_warning


#: Stand-in for a ``coremltools.precision`` member a caller passes directly; the mapper must hand it on unchanged.
_PRECISION_MEMBER = object()


class TestResolveComputePrecision:
    """``_resolve_compute_precision`` maps a validated precision onto the bound ``coremltools.precision`` members."""

    @pytest.mark.parametrize(
        "precision, expected",
        [
            (None, "fp32-member"),
            ("float32", "fp32-member"),
            ("float16", "fp16-member"),
            pytest.param(_PRECISION_MEMBER, _PRECISION_MEMBER, id="coremltools-member"),
        ],
    )
    def test_maps_the_configured_precision_to_a_member(
        self, tmp_path: Path, precision: object, expected: object
    ) -> None:
        """Each name reaches its own member, no precision means float32, and a member is passed through."""
        api = _CoreMLApi(convert=mock.Mock(), target=mock.Mock(), float32="fp32-member", float16="fp16-member")
        exporter = CoreMLExporter(CoreMLConfig(output_dir=tmp_path, compute_precision=precision))

        assert exporter._resolve_compute_precision(api) is expected


class TestConvertDeploymentTarget:
    """``_build_mlmodel`` must hand ``coremltools.convert`` the iOS15 deployment target."""

    @pytest.mark.parametrize("precision_member", ["fp32-member", "fp16-member"])
    def test_converts_for_ios15_so_the_neural_engine_runs_a_spec_6_program(
        self, tmp_path: Path, precision_member: str, mocker: MockerFixture
    ) -> None:
        """The whole convert call is pinned: mlprogram, the iOS15 target, the precision member, and the pass pipeline.

        The target selects the program generation; spec 7 (iOS16) loses ~3 box AP on the Neural Engine. Measured on an
        M3 Pro: pretrained RFDETRNano at fp16 under ``CPU_AND_NE`` scores 45.06 AP on all 5000 COCO val2017 images at
        iOS16 and 48.04 at iOS15, against 48.03 for eager. ``tests/export/coreml/test_coreml_ane.py`` pins the resulting
        spec version on a real bundle; this test needs no coremltools.
        """
        target = mock.Mock()
        convert = mock.Mock(return_value="mlmodel")
        api = _CoreMLApi(convert=convert, target=target, float32="fp32-member", float16="fp16-member")
        exporter = CoreMLExporter(CoreMLConfig(output_dir=tmp_path))

        export_program = mocker.patch.object(exporter, "_export_program")
        mocker.patch.object(exporter, "_check_op_coverage")
        rfdetr_pass_pipeline = mocker.patch("rfdetr.export._coreml.exporter.rfdetr_pass_pipeline")

        exporter._build_mlmodel(mock.Mock(), precision_member, api)

        convert.assert_called_once_with(
            export_program.return_value,
            convert_to="mlprogram",
            minimum_deployment_target=target.iOS15,
            compute_precision=precision_member,
            pass_pipeline=rfdetr_pass_pipeline.return_value,
        )


class TestPassPipelineGuard:
    """``_build_mlmodel`` builds the pass pipeline inside the conversion's error guard."""

    def test_a_failing_pipeline_build_surfaces_as_a_runtime_error(self, tmp_path: Path, mocker: MockerFixture) -> None:
        """A pipeline that cannot be built fails the export as ``RuntimeError``, not as the raw registry error.

        Every Core ML export builds the pipeline, detection included. Before it moved into the guard, a registry
        ``KeyError`` escaped ``_import_coreml_api`` unclassified, so a coremltools release that breaks the pass
        registration broke every export with an error that did not mention Core ML.
        """
        api = _CoreMLApi(convert=mock.Mock(), target=mock.Mock(), float32="fp32-member", float16="fp16-member")
        exporter = CoreMLExporter(CoreMLConfig(output_dir=tmp_path))

        mocker.patch.object(exporter, "_export_program")
        mocker.patch.object(exporter, "_check_op_coverage")
        mocker.patch("rfdetr.export._coreml.exporter.rfdetr_pass_pipeline", side_effect=KeyError("already registered"))

        with pytest.raises(RuntimeError) as exc_info:
            exporter._build_mlmodel(mock.Mock(), "fp32-member", api)

        assert "CoreML export failed" in str(exc_info.value)


class TestSaveMlmodelMetadata:
    """``_save_mlmodel`` stamps the RF-DETR provenance into ``MLModel.user_defined_metadata`` before it saves.

    ``coremltools`` is not needed: the converted model is a stand-in whose ``user_defined_metadata`` is a plain dict,
    the same mapping interface the real one exposes. ``rfdetr_notes`` and its encoding match the ONNX export,
    ``rfdetr_version`` the Core AI export.
    """

    @staticmethod
    def _save(tmp_path: Path, *, notes: object = None, existing: dict[str, str] | None = None) -> mock.MagicMock:
        """Run ``_save_mlmodel`` on a stand-in model and return it.

        Args:
            tmp_path: Directory the bundle path is built in; nothing is written because ``save`` is mocked.
            notes: The ``notes`` the export was asked to embed.
            existing: Keys already in the metadata, as ``ct.convert`` leaves them.

        Returns:
            The stand-in model; ``saved_metadata`` holds a copy of the metadata taken when ``save`` ran.

        Examples:
            >>> model = TestSaveMlmodelMetadata._save(Path("."), notes="hi")
            >>> model.saved_metadata["rfdetr_notes"]
            'hi'
        """
        mlmodel = mock.MagicMock()
        mlmodel.user_defined_metadata = dict(existing or {})
        mlmodel.save.side_effect = lambda _path: setattr(mlmodel, "saved_metadata", dict(mlmodel.user_defined_metadata))
        exporter = CoreMLExporter(CoreMLConfig(output_dir=tmp_path, notes=notes, verbose=False))
        exporter._save_mlmodel(mlmodel, tmp_path / "model.mlpackage")
        return mlmodel

    @pytest.mark.parametrize(
        "notes, stored",
        [
            pytest.param("trained on pallets", "trained on pallets", id="string"),
            pytest.param({"run": 3, "classes": ["box"]}, json.dumps({"run": 3, "classes": ["box"]}), id="json"),
            pytest.param("", "", id="empty-string"),
            pytest.param(0, "0", id="zero"),
            pytest.param(False, "false", id="false"),
            pytest.param([], "[]", id="empty-list"),
        ],
    )
    def test_notes_are_stored_under_the_onnx_key(self, tmp_path: Path, notes: object, stored: str) -> None:
        """A string is stored as is and anything else as JSON, under ``rfdetr_notes``."""
        assert self._save(tmp_path, notes=notes).saved_metadata["rfdetr_notes"] == stored

    def test_no_notes_writes_no_notes_key(self, tmp_path: Path) -> None:
        """Without ``notes`` the key is absent, as in the ONNX export."""
        assert "rfdetr_notes" not in self._save(tmp_path).saved_metadata

    def test_rfdetr_version_is_stored(self, tmp_path: Path, mocker: MockerFixture) -> None:
        """The installed RF-DETR version is stored under ``rfdetr_version``."""
        mocker.patch("rfdetr.export._coreml.exporter.get_version", return_value="9.9.9")

        model = self._save(tmp_path)

        assert model.saved_metadata["rfdetr_version"] == "9.9.9"

    def test_unknown_version_writes_no_version_key(self, tmp_path: Path, mocker: MockerFixture) -> None:
        """A source checkout without package metadata has no version to record."""
        mocker.patch("rfdetr.export._coreml.exporter.get_version", return_value=None)

        model = self._save(tmp_path)

        assert "rfdetr_version" not in model.saved_metadata

    def test_coremltools_own_keys_are_kept(self, tmp_path: Path) -> None:
        """``ct.convert`` fills ``com.github.apple.coremltools.*``; stamping must add to it, not replace it."""
        key = "com.github.apple.coremltools.version"
        assert self._save(tmp_path, notes="x", existing={key: "9.0"}).saved_metadata[key] == "9.0"

    def test_metadata_is_written_before_the_bundle_is_saved(self, tmp_path: Path) -> None:
        """``save`` persists the spec, so a key set after it would never reach the ``.mlpackage``."""
        model = self._save(tmp_path, notes="x")
        model.save.assert_called_once_with(str(tmp_path / "model.mlpackage"))
        assert model.saved_metadata["rfdetr_notes"] == "x"


class TestExportCoremlBareDefaultNaming:
    """``variant_name=None`` + ``output_name=None`` combined with a non-default ``compute_precision`` (fp16).

    Real ``coremltools.convert``/``torch.export.export`` are mocked out so this stays a fast unit test — only the naming
    path (``resolve_export_stem`` -> precision-suffix branch) is under test, not conversion correctness (that is covered
    by ``TestCoreMLEndToEnd``, gated on a real ``coremltools`` install).
    """

    @_requires_coremltools
    def test_bare_default_stem_with_non_default_fp16_precision(self, tmp_path: Path, mocker: MockerFixture) -> None:
        """A bare default stem with fp16 precision still yields ``inference_model_fp16.mlpackage``.

        The precision suffix is not dropped just because the stem is generic.
        """
        mock_exported_program = mock.MagicMock()
        mock_exported_program.run_decompositions.return_value = mock_exported_program
        mock_mlmodel = mock.MagicMock()

        mocker.patch("torch.export.export", return_value=mock_exported_program)
        mocker.patch("rfdetr.export._coreml.exporter.unsupported_coreml_ops", return_value={})
        mocker.patch("coremltools.convert", return_value=mock_mlmodel)
        exporter = CoreMLExporter(
            CoreMLConfig(
                output_dir=tmp_path, variant_name=None, output_name=None, compute_precision="float16", verbose=False
            )
        )

        output_file = exporter(_export_graph())

        assert output_file.name == "inference_model_fp16.mlpackage"
        mock_mlmodel.save.assert_called_once_with(str(output_file))

    @pytest.mark.parametrize(
        "variant_name, output_name, neural_engine, full_name, backbone_name",
        [
            ("rfdetr-nano", None, False, "rfdetr-nano_fp32.mlpackage", "rfdetr-nano_fp32-backbone.mlpackage"),
            ("rfdetr-nano", "custom", False, "custom.mlpackage", "custom-backbone.mlpackage"),
            (None, None, False, "inference_model_fp32.mlpackage", "backbone_model_fp32.mlpackage"),
            ("rfdetr-nano", None, True, "rfdetr-nano_fp32-ane.mlpackage", "rfdetr-nano_fp32-ane-backbone.mlpackage"),
            ("rfdetr-nano", "custom", True, "custom.mlpackage", "custom-backbone.mlpackage"),
            (None, None, True, "inference_model_fp32-ane.mlpackage", "backbone_model_fp32-ane.mlpackage"),
        ],
    )
    def test_backbone_only_does_not_collide_with_full_detector_export(
        self,
        tmp_path: Path,
        variant_name: str | None,
        output_name: str | None,
        neural_engine: bool,
        full_name: str,
        backbone_name: str,
        mocker: MockerFixture,
    ) -> None:
        """Backbone and detector paths stay distinct with variant, custom, and default names.

        A derived name also carries ``-ane`` for the Neural Engine rewrite, between the precision and the backbone
        marker, so it never overwrites the default export of the same model; an explicit ``output_name`` stays as given.
        """
        coremltools = mock.MagicMock()
        full_model, backbone_model = mock.MagicMock(), mock.MagicMock()
        coremltools.convert.side_effect = [full_model, backbone_model]
        exported_program = mock.MagicMock()
        exported_program.run_decompositions.return_value = exported_program
        mocker.patch.dict("sys.modules", {"coremltools": coremltools})
        mocker.patch("rfdetr.export._coreml.exporter._IS_COREMLTOOLS_AVAILABLE", True)
        mocker.patch("torch.export.export", return_value=exported_program)
        mocker.patch("rfdetr.export._coreml.exporter.unsupported_coreml_ops", return_value={})
        mocker.patch("rfdetr.export._coreml.exporter.rfdetr_pass_pipeline")
        config = CoreMLConfig(
            output_dir=tmp_path,
            variant_name=variant_name,
            output_name=output_name,
            neural_engine=neural_engine,
            verbose=False,
        )

        full_out = CoreMLExporter(config)(_export_graph())
        backbone_out = CoreMLExporter(config)(_export_graph(backbone_only=True))

        assert full_out != backbone_out
        assert full_out.name == full_name
        assert backbone_out.name == backbone_name
        full_model.save.assert_called_once_with(str(full_out))
        backbone_model.save.assert_called_once_with(str(backbone_out))


class TestVariantNamePathSafety:
    """Path-traversal mitigation ``CoreMLExporter`` applies to ``variant_name`` through ``resolve_export_stem``.

    Calls ``resolve_export_stem`` directly rather than through a full export: ``CoreMLExporter`` imports the real
    ``coremltools`` right after its availability check, so a full call needs coremltools installed.
    """

    @pytest.mark.parametrize(
        ("variant_name", "expected"),
        [
            pytest.param("../../etc/passwd", "passwd", id="forward-slash-traversal"),
            pytest.param("/absolute/path/rfdetr-nano", "rfdetr-nano", id="absolute-path"),
            pytest.param("rfdetr-nano.mlpackage", "rfdetr-nano", id="strips-extension"),
            pytest.param("rfdetr-nano", "rfdetr-nano", id="plain-name-unchanged"),
        ],
    )
    def test_sanitizes_directory_components(self, variant_name: str, expected: str) -> None:
        """``variant_name`` is reduced to a bare filename stem, with no directory components or extension.

        Forward-slash paths only; backslash handling is covered by ``test_naming.py``.
        """
        assert resolve_export_stem(variant_name, None) == (expected, False)


class TestExportFormatParameter:
    """Tests for ``format="coreml"`` wiring through ``RFDETR.export()``."""

    @pytest.fixture(autouse=True)
    def _patch_export_deps(self, tmp_path: Path) -> Any:
        """Mock heavy export deps so ``RFDETR.export()`` stays fast."""
        self._tmp_path = tmp_path
        mlpackage = tmp_path / "inference_model.mlpackage"
        mlpackage.mkdir()

        self._mock_stack = contextlib.ExitStack()
        self._mock_stack.enter_context(mock.patch("rfdetr.export.base.write_metadata"))
        self._mock_export_onnx = self._mock_stack.enter_context(
            mock.patch(
                "rfdetr.export._onnx.exporter.OnnxExporter._convert",
                return_value=str(tmp_path / "inference_model.onnx"),
            )
        )
        self._mock_stack.enter_context(
            mock.patch(
                "rfdetr.export.prepare.make_infer_image",
                return_value=torch.zeros(1, 3, 560, 560),
            )
        )
        self._mock_coreml_convert = self._mock_stack.enter_context(
            mock.patch(
                "rfdetr.export._coreml.exporter.CoreMLExporter._convert",
                return_value=mlpackage,
            )
        )
        # The Linux and Windows CPU jobs have no coremltools, which RFDETR.export() checks for before the forward pass.
        self._mock_stack.enter_context(mock.patch("rfdetr.export._coreml.exporter.CoreMLExporter.check_dependencies"))
        yield
        self._mock_stack.close()

    def test_dispatches_to_coreml_exporter_not_onnx(self) -> None:
        """``format="coreml"`` must dispatch to ``CoreMLExporter`` (not the ONNX one) and warn (experimental).

        Dispatch keys off ``format``, not off the head, so the default (detection) head stands for every task the format
        supports — a per-head parametrization would assert the identical thing three times. The head-specific part — the
        ``dets``/``labels``/``keypoints`` output contract — is asserted format-agnostically in
        ``tests/export/test_prepare.py``, not here: ``CoreMLExporter._convert`` is mocked out in this class.
        """
        obj = _make_rfdetr()
        with pytest.warns(UserWarning, match="experimental"):
            obj.export(format="coreml", output_dir=str(self._tmp_path / "out"))
        self._mock_coreml_convert.assert_called_once()
        self._mock_export_onnx.assert_not_called()

    def test_onnx_format_skips_coreml_exporter(self) -> None:
        """``format="onnx"`` must not import/call the CoreML converter."""
        obj = _make_rfdetr()
        obj.export(format="onnx", output_dir=str(self._tmp_path / "out"))
        self._mock_coreml_convert.assert_not_called()

    def test_notes_do_not_warn(self, recwarn: pytest.WarningsRecorder) -> None:
        """``notes`` has a slot in an ``.mlpackage`` (``user_defined_metadata``), so it must not warn as dropped."""
        obj = _make_rfdetr()
        obj.export(format="coreml", output_dir=str(self._tmp_path / "out"), notes="hello")
        self._mock_coreml_convert.assert_called_once()
        assert not [w for w in recwarn if "notes" in str(w.message)]

    def test_dynamic_batch_raises_before_converter(self) -> None:
        """``dynamic_batch=True`` is refused by ``RFDETR.export()`` before the converter is invoked."""
        obj = _make_rfdetr()
        with pytest.raises(NotImplementedError) as exc_info:
            obj.export(format="coreml", output_dir=str(self._tmp_path / "out"), dynamic_batch=True)

        assert "dynamic_batch" in str(exc_info.value)
        self._mock_coreml_convert.assert_not_called()

    def test_invalid_format_raises_value_error(self) -> None:
        """Unknown ``format`` must raise ``ValueError`` listing supported formats.

        Facade-level: proves ``RFDETR.export()`` validates before any format dispatch, so one instance covers
        every format (this used to be copy-pasted per exporter test file; ``TestResolveExporter`` in
        ``test_registry.py`` separately covers the underlying guard, parametrized per registered format).
        """
        obj = _make_rfdetr()
        with pytest.raises(ValueError) as exc_info:
            obj.export(format="bogus", output_dir=str(self._tmp_path / "out"))

        assert "Unsupported export format" in str(exc_info.value)


# ---------------------------------------------------------------------------
# End-to-end (gated) — real convert + FLOAT32 CPU parity vs eager PyTorch
# ---------------------------------------------------------------------------


# (model class name, expected output labels, coreml_neural_engine): the e2e fixtures and tests are parametrized over
# this triple; the neural-engine rows hold the rewritten graph to the same eager reference.
_COREML_E2E_VARIANTS = [
    pytest.param(("RFDETRNano", ("boxes", "logits"), False), id="detection"),
    pytest.param(("RFDETRSegNano", ("boxes", "logits", "masks"), False), id="segmentation"),
    pytest.param(("RFDETRNano", ("boxes", "logits"), True), id="detection-neural_engine"),
    pytest.param(("RFDETRSegNano", ("boxes", "logits", "masks"), True), id="segmentation-neural_engine"),
    # Keypoints are preview-only (XLarge, resolution 576): several times the work of the Nano variants, so the slow row.
    pytest.param(("RFDETRKeypointPreview", ("boxes", "logits", "keypoints"), False), id="keypoint"),
]

# Raw parity needs a two-stage `torch.topk` ranking without near-ties: at 300 queries untrained weights put neighbouring
# scores ~1e-6 apart, so fp32 rounding swaps queries (0.5-1.5 logit diffs; the real cause of the flakiness once blamed
# on a `torch<2.12` pin). Measured over 54 cases on M3 Pro / coremltools 9.0: scores move <=1e-5, top-6 gaps >=3.1e-4.
#: Queries the e2e parity exports select, small enough that their two-stage ranking is well separated.
_COREML_E2E_NUM_QUERIES = 5

#: ``notes`` the e2e export embeds, read back from the saved bundle's metadata.
_COREML_E2E_NOTES = "provenance"
#: Minimum eager gap between neighbouring top-ranked scores: 5x the worst swap (two scores drifting 1e-5 apart).
_MIN_TWO_STAGE_RANK_MARGIN = 1e-4
#: Seed the module-scoped e2e fixtures set themselves: they run before the autouse per-test ``reset_random_seeds``.
_COREML_EXPORT_SEED = 0


def _two_stage_rank_margin(model: torch.nn.Module, example_input: torch.Tensor) -> float:
    """Return the smallest gap between neighbouring scores that decide the model's two-stage ``torch.topk``.

    Only the top ``k + 1`` scores matter: a swap among them reorders the selected queries or changes which
    ones are selected, and a swap below them changes nothing.

    Args:
        model: Export-mode module whose forward makes exactly one ``torch.topk`` call over its last dimension.
        example_input: ``(N, C, H, W)`` input; every image in the batch is measured.

    Returns:
        The smallest gap between neighbouring scores among the top ``k + 1`` of any image.

    Raises:
        AssertionError: If the forward does not call ``torch.topk`` exactly once, or if the call does not rank
            along the scores tensor's last axis (the margin below is only meaningful there).

    Examples:
        >>> _two_stage_rank_margin(_TopkRanker(2), torch.tensor([[1.0, 0.5, 0.25, 0.0]]))
        0.25
    """
    with mock.patch("torch.topk", wraps=torch.topk) as topk, torch.no_grad():
        model(example_input.clone())
    assert topk.call_count == 1, f"expected one two-stage torch.topk call, got {topk.call_count}"
    assert len(topk.call_args.args) >= 2, (
        "expected the two-stage torch.topk call to pass scores and k positionally, got "
        f"args={topk.call_args.args!r} kwargs={topk.call_args.kwargs!r}"
    )
    scores, k = topk.call_args.args[:2]
    # `dim` may be positional or a keyword (as in production); the margin only means something on the last axis.
    dim = topk.call_args.kwargs.get("dim", topk.call_args.args[2] if len(topk.call_args.args) > 2 else -1)
    assert dim % scores.ndim == scores.ndim - 1, (
        "expected the two-stage torch.topk call to rank along the scores tensor's last axis, got "
        f"dim={dim!r} for a {scores.ndim}-D scores tensor"
    )
    top = scores.sort(dim=-1, descending=True).values[..., : k + 1]
    return float((top[..., :-1] - top[..., 1:]).min())


def _assert_well_conditioned(
    model: torch.nn.Module,
    example_input: torch.Tensor,
    *,
    hint: str = "lower _COREML_E2E_NUM_QUERIES or change the parity input rather than loosening the parity bound",
) -> None:
    """Fail with an explicit precondition message when the input's two-stage ranking has a near-tie.

    The runtime and eager PyTorch round differently in fp32. Two neighbouring selection scores that sit closer
    together than that fp32 drift can swap which queries ``torch.topk`` selects. Each selected proposal is paired with a
    positional learned embedding, so a swap changes the decoder output and not only its order. Shared with the
    ExecuTorch suite.

    Args:
        model: Export-mode module whose forward makes exactly one ``torch.topk`` call.
        example_input: ``(N, C, H, W)`` parity input.
        hint: Remedy the failure message suggests, naming the calling suite's query-count constant.

    Raises:
        AssertionError: If the ranking margin is below ``_MIN_TWO_STAGE_RANK_MARGIN``.

    Examples:
        >>> _assert_well_conditioned(_TopkRanker(1), torch.tensor([[1.0, 0.0]]))
        >>> _assert_well_conditioned(_TopkRanker(1), torch.tensor([[0.5, 0.5]]))
        Traceback (most recent call last):
            ...
        AssertionError: parity input is ill-conditioned: ...
    """
    margin = _two_stage_rank_margin(model, example_input)
    assert margin >= _MIN_TWO_STAGE_RANK_MARGIN, (
        f"parity input is ill-conditioned: two-stage topk scores are only {margin:.2e} apart "
        f"(< {_MIN_TWO_STAGE_RANK_MARGIN}), so fp32 rounding can swap selected queries and the outputs cannot "
        f"match; {hint}"
    )


@pytest.fixture(scope="module")
def people_walking_image_path(tmp_path_factory: pytest.TempPathFactory) -> Path:
    """Download supervision's ``PEOPLE_WALKING`` asset once, shared across CoreML e2e tests."""
    asset_dir = tmp_path_factory.mktemp("coreml_assets")
    cwd = Path.cwd()
    os.chdir(asset_dir)
    try:
        return Path(download_assets(ImageAssets.PEOPLE_WALKING)).resolve()
    finally:
        os.chdir(cwd)


@pytest.fixture(scope="module", params=_COREML_E2E_VARIANTS)
def coreml_export(
    request: pytest.FixtureRequest, tmp_path_factory: pytest.TempPathFactory
) -> tuple[tuple[str, tuple[str, ...], bool], Any, torch.Tensor, Path, tuple[str, ...]]:
    """Export RFDETRNano/RFDETRSegNano/RFDETRKeypointPreview to a ``.mlpackage`` once per variant for e2e tests.

    Exports ``_COREML_E2E_NUM_QUERIES`` queries so the two-stage ranking is well separated (see the module-level
    comment), and reseeds itself because it runs before the autouse per-test seed reset. The variant comes back with
    it so ``coreml_default_queries_export`` can depend on this fixture and inherit its parametrization, rather than
    declaring the same ``params`` again and producing a cross product.

    Examples:
        Skipped: a pytest fixture, and a real ``coremltools`` conversion, so it cannot run standalone.

        >>> variant, model, example, mlpackage_path, output_labels = coreml_export  # doctest: +SKIP
        >>> variant, example.shape[0], mlpackage_path.suffix  # doctest: +SKIP
        (('RFDETRNano', ('boxes', 'logits'), False), 1, '.mlpackage')
    """
    model_cls_name, output_labels, neural_engine = request.param
    model_cls = getattr(rfdetr, model_cls_name)
    out_dir = tmp_path_factory.mktemp(f"coreml_{model_cls_name.lower()}")
    seed_all(_COREML_EXPORT_SEED)
    detector = model_cls(pretrain_weights=None, num_queries=_COREML_E2E_NUM_QUERIES)
    mlpackage_path = detector.export(
        output_dir=str(out_dir),
        format="coreml",
        coreml_neural_engine=neural_engine,
        notes=_COREML_E2E_NOTES,
        verbose=False,
    )

    model = detector.model.model.to("cpu").eval()
    model.export()
    resolution = int(detector.model.resolution)
    example = _structured_parity_input(1, 3, resolution, resolution)
    return request.param, model, example, Path(mlpackage_path), output_labels


@pytest.fixture(scope="module")
def coreml_backbone_export(tmp_path_factory: pytest.TempPathFactory) -> tuple[torch.nn.Module, torch.Tensor, Path]:
    """Export RFDETRNano's backbone and return its eager feature-map reference module.

    Uses the public ``backbone_only=True`` route so the CoreML runtime executes the same list-valued ``_BackboneExport``
    graph that users receive, rather than a mocked converter dispatch.
    """
    out_dir = tmp_path_factory.mktemp("coreml_backbone")
    seed_all(_COREML_EXPORT_SEED)
    detector = rfdetr.RFDETRNano(pretrain_weights=None)
    mlpackage_path = detector.export(output_dir=str(out_dir), format="coreml", backbone_only=True, verbose=False)
    backbone = detector.model.model.backbone[0].to("cpu").eval()
    reference_model = _BackboneExport(backbone)
    resolution = int(detector.model.resolution)
    example = _structured_parity_input(1, 3, resolution, resolution)
    return reference_model, example, Path(mlpackage_path)


@pytest.fixture(scope="module")
def coreml_default_queries_export(
    coreml_export: tuple[tuple[str, tuple[str, ...], bool], Any, torch.Tensor, Path, tuple[str, ...]],
    tmp_path_factory: pytest.TempPathFactory,
) -> tuple[torch.nn.Module, torch.Tensor, Path, Path, tuple[str, ...]]:
    """Export each e2e variant with its shipped query count, which ``coreml_export`` trades for a separated ranking.

    Those counts differ per variant (300 for detection, 100 for segmentation and keypoints), and the mask and keypoint
    output shapes follow them, so every shipped graph is converted and run rather than only the detection one. Depends
    on ``coreml_export`` for the variant *and* for its 5-query ``.mlpackage``, which the graph comparison below is
    measured against.

    Examples:
        Skipped: a pytest fixture, and a real ``coremltools`` conversion, so it cannot run standalone.

        >>> model, example, mlpackage_path, few_queries_path, output_labels = (
        ...     coreml_default_queries_export
        ... )  # doctest: +SKIP
        >>> mlpackage_path != few_queries_path, example.shape[0], output_labels  # doctest: +SKIP
        (True, 1, ('boxes', 'logits'))
    """
    (model_cls_name, _, neural_engine), _, _, few_queries_path, output_labels = coreml_export
    out_dir = tmp_path_factory.mktemp(f"coreml_default_queries_{model_cls_name.lower()}")
    seed_all(_COREML_EXPORT_SEED)
    detector = getattr(rfdetr, model_cls_name)(pretrain_weights=None)
    mlpackage_path = detector.export(
        output_dir=str(out_dir), format="coreml", coreml_neural_engine=neural_engine, verbose=False
    )
    model = detector.model.model.to("cpu").eval()
    model.export()
    resolution = int(detector.model.resolution)
    example = _structured_parity_input(1, 3, resolution, resolution)
    return model, example, Path(mlpackage_path), few_queries_path, output_labels


#: Two keypoint classes, so the keypoint self-attention mask blocks the cross-class pairs (one class blocks nothing).
_MULTICLASS_KEYPOINT_SCHEMA = [9, 8]


@pytest.fixture(scope="module")
def coreml_multiclass_keypoint_export(
    tmp_path_factory: pytest.TempPathFactory,
) -> tuple[Any, torch.Tensor, Path]:
    """Export a KeypointPreview with two keypoint classes, whose keypoint self-attention mask blocks pairs.

    The keypoint output heads start at zero, which makes the keypoints of an untrained model independent of the
    keypoint attention; they get small seeded weights so a wrong mask shows up in the outputs.

    Examples:
        Skipped: a pytest fixture, and a real ``coremltools`` conversion, so it cannot run standalone.

        >>> model, example, mlpackage_path = coreml_multiclass_keypoint_export  # doctest: +SKIP
        >>> bool(model.transformer.decoder.keypoint_class_mask.any())  # doctest: +SKIP
        True
    """
    out_dir = tmp_path_factory.mktemp("coreml_multiclass_keypoint")
    seed_all(_COREML_EXPORT_SEED)
    detector = rfdetr.RFDETRKeypointPreview(
        pretrain_weights=None,
        num_queries=_COREML_E2E_NUM_QUERIES,
        num_classes=len(_MULTICLASS_KEYPOINT_SCHEMA),
    )
    module = detector.model.model
    module.reinitialize_keypoint_head(_MULTICLASS_KEYPOINT_SCHEMA)
    generator = torch.Generator().manual_seed(_COREML_EXPORT_SEED)
    with torch.no_grad():
        for name, param in module.named_parameters():
            if "keypoint_embed" in name and not param.any():
                param.copy_(0.02 * torch.randn(param.shape, generator=generator))
    mlpackage_path = detector.export(output_dir=str(out_dir), format="coreml", verbose=False)
    model = module.to("cpu").eval()
    model.export()
    resolution = int(detector.model.resolution)
    example = _structured_parity_input(1, 3, resolution, resolution)
    return model, example, Path(mlpackage_path)


@_requires_coremltools
@pytest.mark.integration
@pytest.mark.e2e_coreml
class TestCoreMLEndToEnd:
    """Real CoreML export + FLOAT32 CPU numerical parity (``-m e2e_coreml``)."""

    def test_mlpackage_written(
        self, coreml_export: tuple[tuple[str, tuple[str, ...], bool], Any, torch.Tensor, Path, tuple[str, ...]]
    ) -> None:
        """Export must write a non-empty ``.mlpackage`` directory/bundle, named with the resolved precision.

        The bundle of every variant (detection, segmentation, keypoints) must also be an iOS15 (spec 6) program, the
        generation whose Neural Engine results match eager; see ``TestConvertDeploymentTarget``.
        """
        import coremltools as ct

        (_, _, neural_engine), _, _, mlpackage_path, _ = coreml_export
        assert mlpackage_path.exists()
        # Default compute_precision resolves to FLOAT32 (see the exporter module docstring); the filename must
        # always encode it, since precision materially changes the artifact, followed by ``-ane`` for the rewrite.
        assert mlpackage_path.stem.endswith("_fp32-ane" if neural_engine else "_fp32")
        assert mlpackage_path.suffix == ".mlpackage" or mlpackage_path.name.endswith(".mlpackage")
        assert ct.utils.load_spec(str(mlpackage_path)).specificationVersion == _IOS15_SPEC_VERSION

    def test_mlpackage_metadata_round_trips(
        self, coreml_export: tuple[tuple[str, tuple[str, ...], bool], Any, torch.Tensor, Path, tuple[str, ...]]
    ) -> None:
        """``notes`` and the RF-DETR version survive save and reload, beside coremltools' keys."""
        import coremltools as ct

        _, _, _, mlpackage_path, _ = coreml_export
        metadata = ct.models.MLModel(str(mlpackage_path), skip_model_load=True).user_defined_metadata
        assert metadata["rfdetr_notes"] == _COREML_E2E_NOTES
        assert metadata.get("rfdetr_version") == get_version()
        assert "com.github.apple.coremltools.version" in metadata

    def test_outputs_match_pytorch_structured(
        self, coreml_export: tuple[tuple[str, tuple[str, ...], bool], Any, torch.Tensor, Path, tuple[str, ...]]
    ) -> None:
        """CoreML output matches eager on structured (gradient+checkerboard) input."""
        _, model, example, mlpackage_path, output_labels = coreml_export
        _assert_well_conditioned(model, example)
        _validate_coreml_vs_pytorch(mlpackage_path, model, example, output_labels=output_labels)

    def test_multiclass_keypoint_mask_matches_pytorch(
        self, coreml_multiclass_keypoint_export: tuple[Any, torch.Tensor, Path]
    ) -> None:
        """A keypoint self-attention mask that blocks cross-class pairs must convert with its meaning intact."""
        model, example, mlpackage_path = coreml_multiclass_keypoint_export
        assert bool(model.transformer.decoder.keypoint_class_mask.any())
        _assert_well_conditioned(model, example)
        _validate_coreml_vs_pytorch(mlpackage_path, model, example, output_labels=("boxes", "logits", "keypoints"))

    def test_outputs_match_pytorch_supervision_image(
        self,
        coreml_export: tuple[tuple[str, tuple[str, ...], bool], Any, torch.Tensor, Path, tuple[str, ...]],
        people_walking_image_path: Path,
    ) -> None:
        """CoreML output matches eager on ``ImageAssets.PEOPLE_WALKING``."""
        _, model, structured, mlpackage_path, output_labels = coreml_export
        example = _parity_input_from_image(people_walking_image_path, int(structured.shape[-1]))
        _assert_well_conditioned(model, example)
        _validate_coreml_vs_pytorch(mlpackage_path, model, example, output_labels=output_labels)

    def test_backbone_outputs_match_pytorch_structured(
        self, coreml_backbone_export: tuple[torch.nn.Module, torch.Tensor, Path]
    ) -> None:
        """CoreML must run every backbone feature-map output from the public backbone-only export."""
        model, example, mlpackage_path = coreml_backbone_export
        assert "-backbone" in mlpackage_path.stem
        diffs = _coreml_parity_diffs(mlpackage_path, model, example)
        assert max(diffs) < _COREML_MAX_ABS_DIFF, (
            f"CoreML backbone outputs diverge from PyTorch: max abs diff {max(diffs)} (bound={_COREML_MAX_ABS_DIFF})"
        )

    def test_backbone_mlpackage_is_an_ios15_program(
        self, coreml_backbone_export: tuple[torch.nn.Module, torch.Tensor, Path]
    ) -> None:
        """The backbone-only bundle is converted through the same iOS15 target as the full model (spec 6)."""
        import coremltools as ct

        _, _, mlpackage_path = coreml_backbone_export

        assert ct.utils.load_spec(str(mlpackage_path)).specificationVersion == _IOS15_SPEC_VERSION

    def test_default_query_count_runs_with_eager_shapes(
        self, coreml_default_queries_export: tuple[torch.nn.Module, torch.Tensor, Path, Path, tuple[str, ...]]
    ) -> None:
        """The shipped-query-count export must run on CoreML with eager's output count, shapes and finite values.

        Values are deliberately not bounded here. At the shipped query count the untrained two-stage ranking always has
        near-ties, so a legitimate fp32 swap can move every output, and no value comparison is both tight and stable
        (post-processed scores drift up to ~1e-3 on a swap). The strict 1e-4 value parity is carried by the 5-query
        export; this test covers what the shipped graph adds on top of it: the shipped output shapes.
        """
        model, example, mlpackage_path, _, output_labels = coreml_default_queries_export
        diffs = _coreml_parity_diffs(mlpackage_path, model, example)
        assert len(diffs) == len(output_labels), f"CoreML export must yield {output_labels}, got {len(diffs)} outputs"
        assert all(np.isfinite(diffs)), f"CoreML produced non-finite outputs: max abs diffs {diffs}"

    def test_default_query_count_lowers_through_no_unchecked_operation(
        self, coreml_default_queries_export: tuple[torch.nn.Module, torch.Tensor, Path, Path, tuple[str, ...]]
    ) -> None:
        """The shipped-query graph must reach no MIL operation, nor far more of one, than the checked graph does.

        Deliberately a *structural* guard, not a numerical one, and it does not make the 5-query parity stand in for
        the shipped graph: the historical CoreML parity failures this suite was rewritten around happened with an
        identical op set on both sides, so bare op-type membership cannot discriminate drift on its own. Op *counts*
        (within ``_MIL_OP_COUNT_TOLERANCE``, since constant folding legitimately trims a handful of `const`/`reshape`
        nodes between shapes) additionally catch the shipped shapes reusing a familiar op type far more heavily —
        say, a live ``slice_by_index`` chain at 300 queries where 5 queries folded most of it away to ``const``.

        One-directional on purpose: an op type the shipped graph reaches far more of (including one the checked
        graph never reaches at all) is the gap; the reverse (a node fused away only at the larger shape) is benign
        and must not turn the macOS-only parity job red.
        """
        import coremltools as ct

        _, _, mlpackage_path, few_queries_path, _ = coreml_default_queries_export

        shipped_counts = _mil_op_counts(ct.utils.load_spec(str(mlpackage_path)))
        few_queries_counts = _mil_op_counts(ct.utils.load_spec(str(few_queries_path)))

        # Protobuf message maps default-construct on lookup, so a spec this traversal does not understand yields
        # an empty count on both sides and the regression check below would pass while inspecting nothing.
        assert shipped_counts, f"no MIL operations found in {mlpackage_path.name}: the spec traversal is wrong"
        regressions = _mil_op_count_regressions(shipped_counts, few_queries_counts, tolerance=_MIL_OP_COUNT_TOLERANCE)
        assert not regressions, (
            f"shipped-query graph reaches these MIL ops far more than the {_COREML_E2E_NUM_QUERIES}-query parity "
            f"graph does, beyond the folding tolerance of {_MIL_OP_COUNT_TOLERANCE} -- {{op: (shipped, checked)}}: "
            f"{regressions}"
        )


class TestCoreMLParityInputHelpers:
    """Unit checks for CoreML-local parity input builders (no coremltools required)."""

    def test_structured_parity_input_shape_and_determinism(self) -> None:
        """Structured tensor must be ``NCHW``, finite, and seed-independent-deterministic."""
        a = _structured_parity_input(1, 3, 64, 64)
        b = _structured_parity_input(1, 3, 64, 64)
        assert a.shape == (1, 3, 64, 64)
        assert torch.isfinite(a).all()
        assert torch.equal(a, b)
        # Spatially varying — not a constant fill.
        assert float(a.std()) > 1e-3

    def test_parity_input_from_image_loads_rgb(self, tmp_path: Path) -> None:
        """``_parity_input_from_image`` must normalize a local RGB file to ``1x3xHxW``."""
        image_path = tmp_path / "tiny.png"
        Image.new("RGB", (32, 24), color=(20, 40, 60)).save(image_path)
        tensor = _parity_input_from_image(image_path, 64)
        assert tensor.shape == (1, 3, 64, 64)
        assert torch.isfinite(tensor).all()


class _TopkRanker(torch.nn.Module):
    """Stand-in for a two-stage ranker: one ``torch.topk`` over the last dimension per configured ``k``.

    Every ``k`` re-ranks the same input rather than chaining, so the call *count* is what varies — that is what
    ``_two_stage_rank_margin``'s guard reads, and chaining would shrink the tensor out from under later ``k``s.

    Examples:
        >>> _TopkRanker(1)(torch.tensor([[0.25, 0.75]])).tolist()
        [[0.75]]
        >>> _TopkRanker()(torch.tensor([[0.25]])).tolist()
        [[0.25]]
    """

    def __init__(self, *ks: int) -> None:
        super().__init__()
        self.ks = ks

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Rank ``x`` once per configured ``k`` and return the last ranking (``x`` itself when none)."""
        out = x
        for k in self.ks:
            out = torch.topk(x, k, dim=-1).values
        return out


class _RaisingRanker(torch.nn.Module):
    """Stand-in ranker whose forward calls ``torch.topk`` once, then always raises.

    Covers the restore-on-exception path of the ``mock.patch("torch.topk", ...)`` spy in
    :func:`_two_stage_rank_margin`: a model that blows up mid-forward, after its one ranking call, must not
    leave ``torch.topk`` patched for every test that runs after it.

    Examples:
        >>> _RaisingRanker()(torch.tensor([[0.9, 0.1]]))
        Traceback (most recent call last):
            ...
        RuntimeError: boom
    """

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Call ``torch.topk`` once, then unconditionally raise ``RuntimeError("boom")``."""
        torch.topk(x, 1, dim=-1)
        raise RuntimeError("boom")


class TestTwoStageRankMargin:
    """``_two_stage_rank_margin`` must measure exactly the gaps that decide the two-stage selection."""

    @pytest.mark.parametrize(
        ("scores", "k", "expected"),
        [
            pytest.param([[0.9, 0.5, 0.49, 0.1]], 2, 0.01, id="gap-at-selection-boundary-counts"),
            pytest.param([[0.9, 0.5, 0.1, 0.1]], 1, 0.4, id="tie-below-boundary-ignored"),
            pytest.param([[0.1, 0.9, 0.5]], 1, 0.4, id="input-order-irrelevant"),
            pytest.param([[0.7, 0.7, 0.1]], 1, 0.0, id="exact-tie-inside-selection"),
            pytest.param([[0.9, 0.1], [0.5, 0.5]], 1, 0.0, id="tie-in-second-image"),
            pytest.param([[0.9, 0.9, 0.9, 0.1]], 2, 0.0, id="three-way-tie-at-selection-boundary"),
            pytest.param(
                [[0.9, 0.5, 0.1], [0.9, 0.85, 0.1], [0.9, 0.6, 0.1]],
                1,
                0.05,
                id="min-gap-in-middle-image-of-three",
            ),
        ],
    )
    def test_margin(self, scores: list[list[float]], k: int, expected: float) -> None:
        """The margin is the smallest neighbouring gap among the top ``k + 1`` scores of any image."""
        assert _two_stage_rank_margin(_TopkRanker(k), torch.tensor(scores)) == pytest.approx(expected, abs=1e-6)

    @pytest.mark.parametrize("ks", [pytest.param((), id="no-topk"), pytest.param((1, 1), id="two-topk")])
    def test_rejects_forward_without_exactly_one_topk(self, ks: tuple[int, ...]) -> None:
        """Measuring the wrong ranking would silently vouch for parity, so any other call count must fail."""
        with pytest.raises(AssertionError) as exc_info:
            _two_stage_rank_margin(_TopkRanker(*ks), torch.tensor([[0.9, 0.1]]))

        assert "expected one two-stage torch.topk call" in str(exc_info.value)

    def test_raises_on_k_equal_zero(self) -> None:
        """``k=0`` leaves no neighbouring pair to diff, so torch's own empty-tensor reduction error surfaces raw.

        Documents actual behaviour rather than a documented contract: ``_two_stage_rank_margin`` has no ``k=0``
        guard, so a caller hits ``Tensor.min()`` on an empty tensor instead of an actionable assertion.
        """
        with pytest.raises(RuntimeError) as exc_info:
            _two_stage_rank_margin(_TopkRanker(0), torch.tensor([[0.9, 0.1]]))

        assert "numel() == 0" in str(exc_info.value)

    def test_restores_torch_topk(self) -> None:
        """The spy must not leak: ``torch.topk`` is the original function after a measurement."""
        original = torch.topk
        _two_stage_rank_margin(_TopkRanker(1), torch.tensor([[0.9, 0.1]]))
        assert torch.topk is original

    def test_restores_torch_topk_after_forward_raises(self) -> None:
        """The spy must not leak even when the model's forward raises after its one ``torch.topk`` call."""
        original = torch.topk
        with pytest.raises(RuntimeError) as exc_info:
            _two_stage_rank_margin(_RaisingRanker(), torch.tensor([[0.9, 0.1]]))

        assert "boom" in str(exc_info.value)
        assert torch.topk is original


class _ProtoMapDouble(dict):
    """Minimal double for a protobuf message-map: reads default-construct a missing key instead of raising.

    Protobuf map fields (e.g. ``ModelSpecification.mlProgram.functions``, ``Function.block_specializations``)
    return a fresh default-constructed message on ``some_map[missing_key]`` rather than raising ``KeyError`` --
    exactly the semantics :func:`_mil_op_types`'s docstring documents, and a plain ``dict`` (raises ``KeyError``)
    or ``SimpleNamespace`` (no ``__getitem__`` at all) cannot reproduce.

    Args:
        default_factory: Builds (and caches, matching protobuf's own auto-vivify-on-read behaviour) the value
            returned for a key not already present.

    Examples:
        >>> m = _ProtoMapDouble(lambda: "default")
        >>> m["missing"]
        'default'
        >>> m["missing"] is m["missing"]
        True
    """

    def __init__(self, default_factory: Any) -> None:
        super().__init__()
        self._default_factory = default_factory

    def __missing__(self, key: str) -> Any:
        """Default-construct, cache, and return the value for *key* instead of raising ``KeyError``."""
        value = self._default_factory()
        self[key] = value
        return value


class TestMilOpTypesMalformedSpec:
    """``_mil_op_types`` must not raise on a spec whose ``"main"`` function is entirely absent."""

    def test_returns_empty_set_on_default_constructed_main(self) -> None:
        """A spec with no ``"main"`` entry in ``functions`` must traverse to the empty set, never raise.

        Mirrors real protobuf behaviour end to end: ``functions["main"]`` default-constructs an empty
        ``Function`` (``opset=""``), and that function's ``block_specializations[""]`` in turn default-constructs
        an empty operation list -- no key anywhere actually exists, yet nothing raises.
        """
        block_specializations = _ProtoMapDouble(lambda: SimpleNamespace(operations=[]))
        functions = _ProtoMapDouble(lambda: SimpleNamespace(opset="", block_specializations=block_specializations))
        spec = SimpleNamespace(mlProgram=SimpleNamespace(functions=functions))

        assert _mil_op_types(spec) == set()


class TestE2EParityPrecondition:
    """The e2e query count must leave every exported variant's two-stage ranking well separated.

    Needs no ``coremltools``, so a model or initialisation change that breaks the precondition is caught by the regular
    CPU suite instead of first surfacing as a CoreML parity failure on the macOS-only ``e2e_coreml`` job.
    """

    @pytest.mark.parametrize("variant", _COREML_E2E_VARIANTS)
    def test_structured_input_is_well_conditioned(self, variant: tuple[str, tuple[str, ...], bool]) -> None:
        """Seeded exactly like ``coreml_export``, the structured parity input must pass the margin check."""
        model_cls_name, _, _ = variant
        seed_all(_COREML_EXPORT_SEED)
        detector = getattr(rfdetr, model_cls_name)(pretrain_weights=None, num_queries=_COREML_E2E_NUM_QUERIES)
        model = detector.model.model.to("cpu").eval()
        model.export()
        resolution = int(detector.model.resolution)
        _assert_well_conditioned(model, _structured_parity_input(1, 3, resolution, resolution))
