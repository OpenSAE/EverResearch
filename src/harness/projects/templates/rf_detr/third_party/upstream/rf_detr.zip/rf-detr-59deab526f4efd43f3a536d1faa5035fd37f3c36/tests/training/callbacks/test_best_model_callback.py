# ------------------------------------------------------------------------
# RF-DETR
# Copyright (c) 2025 Roboflow. All Rights Reserved.
# Licensed under the Apache License, Version 2.0 [see LICENSE for details]
# ------------------------------------------------------------------------
"""Unit tests for :class:`BestModelCallback` and :class:`RFDETREarlyStopping`."""

from __future__ import annotations

from pathlib import Path
from types import SimpleNamespace
from unittest.mock import MagicMock

import pytest
import torch
from pytest_mock import MockerFixture
from pytorch_lightning import Callback, LightningModule, Trainer
from pytorch_lightning import __version__ as ptl_version
from pytorch_lightning.trainer.states import TrainerFn
from torch import Tensor
from torch.utils.data import DataLoader, TensorDataset

from rfdetr.config import RFDETRLargeDeprecatedConfig, RFDETRMediumConfig, TrainConfig
from rfdetr.training.callbacks.best_model import BestModelCallback, RFDETREarlyStopping, _save_final_checkpoint
from rfdetr.training.callbacks.ema import RFDETREMACallback

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_trainer(
    metrics: dict[str, float],
    current_epoch: int = 1,
    is_global_zero: bool = True,
    callbacks: list[object] | None = None,
    sanity_checking: bool = False,
) -> MagicMock:
    """Create a minimal mock Trainer with controllable callback_metrics.

    Sets the attributes required by ModelCheckpoint and EarlyStopping skip-guards so that callbacks run normally in unit
    tests.

    Args:
        metrics: Validation metric names mapped to values, exposed as ``trainer.callback_metrics``.
        current_epoch: Value for ``trainer.current_epoch``.
        is_global_zero: Value for ``trainer.is_global_zero``.
        callbacks: Value for ``trainer.callbacks``; defaults to an empty list.
        sanity_checking: Value for ``trainer.sanity_checking`` — True mimics PyTorch Lightning's pre-training
            sanity-check pass (see #1348).

    Returns:
        A mock standing in for a :class:`~pytorch_lightning.Trainer`.

    Examples:
        >>> trainer = _make_trainer({"val/mAP_50_95": 0.5}, current_epoch=2, sanity_checking=True)
        >>> trainer.current_epoch, trainer.sanity_checking
        (2, True)
        >>> trainer.callback_metrics["val/mAP_50_95"].item()
        0.5
    """
    trainer = MagicMock()
    trainer.callback_metrics = {k: torch.tensor(v) for k, v in metrics.items()}
    trainer.current_epoch = current_epoch
    trainer.is_global_zero = is_global_zero
    trainer.callbacks = callbacks or []
    trainer.should_stop = False
    # Required by ModelCheckpoint._should_skip_saving_checkpoint
    trainer.fast_dev_run = False
    trainer.state.fn = TrainerFn.FITTING
    trainer.sanity_checking = sanity_checking
    trainer.global_step = 1  # int; differs from _last_global_step_saved=0
    # Required by EarlyStopping._log_info (world_size > 1 check)
    trainer.world_size = 1
    # Required by ModelCheckpoint.check_monitor_top_k and EarlyStopping (DDP reduce)
    trainer.strategy.reduce_boolean_decision.side_effect = lambda x, **kwargs: x
    # Required by BestModelCallback.on_fit_end, which broadcasts the run_test decision from the main process.
    trainer.strategy.broadcast.side_effect = lambda obj, src=0: obj
    # Prevent MagicMock auto-attribute from triggering class_names enrichment.
    trainer.datamodule.class_names = None
    return trainer


def _make_pl_module() -> MagicMock:
    """Create a minimal mock RFDETRModule with state_dict and train_config."""
    pl_module = MagicMock()
    pl_module.model.state_dict.return_value = {"w": torch.zeros(1)}
    # Use a real dict so torch.save can pickle it (MagicMock is not picklable).
    pl_module.train_config = {"lr": 0.001}
    return pl_module


_REGULAR_AND_EMA_CASES = [
    pytest.param({}, {"val/mAP_50_95": 0.5}, "checkpoint_best_regular.pth", id="regular"),
    pytest.param(
        {"monitor_ema": "val/ema_mAP_50_95"},
        {"val/mAP_50_95": 0.4, "val/ema_mAP_50_95": 0.6},
        "checkpoint_best_ema.pth",
        id="ema",
    ),
]


class _ModuleWithTestStep(LightningModule):
    """Real module defining ``test_step`` so BestModelCallback.on_fit_end considers running ``trainer.test()``."""

    def test_step(self, batch: object, batch_idx: int) -> None:
        """No-op test step."""


def _make_test_step_module(
    state_dict: dict[str, object] | None = None, missing_keys: list[str] | None = None
) -> _ModuleWithTestStep:
    """Build a real ``test_step`` module around a mocked model that reloads with the given ``missing_keys``.

    A real ``_IncompatibleKeys`` is returned from ``load_state_dict`` because a MagicMock's truthy result would fail the
    ``strict=False`` reload check.

    Args:
        state_dict: What the model's ``state_dict()`` returns; one zero tensor ``w`` by default.
        missing_keys: Keys the reload reports as missing; none by default.

    Returns:
        The module with ``model``, ``train_config`` and the mocked reload set.

    Examples:
        >>> module = _make_test_step_module(missing_keys=["w"])
        >>> module.model.load_state_dict({}, strict=False).missing_keys
        ['w']
    """
    module = _ModuleWithTestStep()
    module.model = MagicMock()
    module.model.state_dict.return_value = state_dict if state_dict is not None else {"w": torch.zeros(1)}
    module.model.load_state_dict.return_value = torch.nn.modules.module._IncompatibleKeys(missing_keys or [], [])
    module.train_config = {"lr": 0.001}
    return module


def _make_cpu_trainer(
    tmp_path: Path, max_epochs: int, callbacks: list[Callback], num_sanity_val_steps: int = 0
) -> Trainer:
    """Build a quiet CPU ``Trainer`` limited to 2 train and 1 validation batches per epoch.

    Examples:
        >>> _make_cpu_trainer(Path("."), 3, []).max_epochs
        3
    """
    return Trainer(
        max_epochs=max_epochs,
        accelerator="cpu",
        enable_progress_bar=False,
        enable_model_summary=False,
        logger=False,
        num_sanity_val_steps=num_sanity_val_steps,
        limit_train_batches=2,
        limit_val_batches=1,
        callbacks=callbacks,
        default_root_dir=str(tmp_path),
    )


@pytest.fixture
def loaders() -> tuple[DataLoader, DataLoader]:
    """Train and validation loaders over the same 8 random samples, batch size 2."""
    x = torch.randn(8, 4)
    y = torch.randn(8, 1)
    return DataLoader(TensorDataset(x, y), batch_size=2), DataLoader(TensorDataset(x, y), batch_size=2)


@pytest.fixture
def ema_callback() -> MagicMock:
    """EMA callback mock exposing weights ``{"w": ones}`` and a real-dict ``state_dict``.

    torch.save cannot pickle a MagicMock.
    """
    callback = MagicMock()
    callback.get_ema_model_state_dict.return_value = {"w": torch.ones(1)}
    callback.state_dict.return_value = {}
    return callback


class _ResumeTinyModule(LightningModule):
    """Tiny LightningModule used to validate real ckpt_path resume behavior."""

    def __init__(self) -> None:
        super().__init__()
        self.model = torch.nn.Linear(4, 1)
        self.train_config = {"lr": 0.01}

    def training_step(self, batch, batch_idx):
        x, y = batch
        pred = self.model(x)
        return torch.nn.functional.mse_loss(pred, y)

    def validation_step(self, batch, batch_idx):
        del batch, batch_idx
        self.log("val/mAP_50_95", torch.tensor(0.5), on_step=False, on_epoch=True, prog_bar=False)

    def configure_optimizers(self):
        return torch.optim.SGD(self.model.parameters(), lr=0.01)


class _MetricModule(LightningModule):
    """LightningModule that logs a caller-controlled ``val/mAP_50_95`` value each epoch.

    Used to discriminate a genuinely *restored* ``best_model_score``/checkpoint from one a
    fresh callback happened to compute or overwrite on its own: the pre- and post-resume
    phases log different values (the post-resume one always worse), so a restored
    high-water mark and a wrongly-reset one diverge, and a wrongly-reset one would let the
    worse post-resume epoch overwrite the good on-disk checkpoint.
    """

    def __init__(self, metric_value: float) -> None:
        """Initialize with the fixed ``val/mAP_50_95`` value to log every epoch.

        Args:
            metric_value: Value logged as ``val/mAP_50_95`` on every validation epoch.
        """
        super().__init__()
        self.model = torch.nn.Linear(4, 1)
        self.train_config = {"lr": 0.01}
        self._metric_value = metric_value

    def training_step(self, batch: tuple[Tensor, Tensor], batch_idx: int) -> Tensor:
        """Compute MSE loss for one training batch.

        Args:
            batch: ``(x, y)`` tensors from the ``TensorDataset`` loader.
            batch_idx: Index of the batch within the current epoch (unused).

        Returns:
            Scalar MSE loss.
        """
        del batch_idx
        x, y = batch
        pred = self.model(x)
        return torch.nn.functional.mse_loss(pred, y)

    def validation_step(self, batch: tuple[Tensor, Tensor], batch_idx: int) -> None:
        """Log the fixed ``val/mAP_50_95`` value, ignoring the actual batch contents.

        Args:
            batch: Unused; only the epoch-level log call matters for these tests.
            batch_idx: Unused.
        """
        del batch, batch_idx
        self.log("val/mAP_50_95", torch.tensor(self._metric_value), on_step=False, on_epoch=True, prog_bar=False)

    def configure_optimizers(self) -> torch.optim.Optimizer:
        """Return a plain SGD optimizer sufficient to drive ``Trainer.fit()``."""
        return torch.optim.SGD(self.model.parameters(), lr=0.01)


class _EvalIntervalModule(LightningModule):
    """Tiny module that only logs val/mAP_50_95 every ``eval_interval`` epochs.

    Simulates RF-DETR's COCO-eval skip behaviour: validation runs every epoch but the metric key is absent on non-eval
    epochs.
    """

    def __init__(self, eval_interval: int = 2) -> None:
        super().__init__()
        self.model = torch.nn.Linear(4, 1)
        self.train_config = {"lr": 0.01}
        self._eval_interval = eval_interval

    def training_step(self, batch, batch_idx):
        x, y = batch
        return torch.nn.functional.mse_loss(self.model(x), y)

    def validation_step(self, batch, batch_idx):
        del batch, batch_idx
        if self.current_epoch % self._eval_interval == 0:
            self.log("val/mAP_50_95", torch.tensor(0.5), on_step=False, on_epoch=True, prog_bar=False)

    def configure_optimizers(self):
        return torch.optim.SGD(self.model.parameters(), lr=0.01)


class _ResumeProbeCallback(Callback):
    """Capture the first train epoch index for resume assertions."""

    def __init__(self) -> None:
        super().__init__()
        self.first_train_epoch: int | None = None

    def on_train_epoch_start(self, trainer, pl_module):
        del pl_module
        if self.first_train_epoch is None:
            self.first_train_epoch = trainer.current_epoch


class _VaryingMetricModule(LightningModule):
    """LightningModule that logs a different ``val/mAP_50_95`` value on each successive epoch.

    ``values`` is consumed one entry per validation epoch (indexed by ``self.current_epoch``, clamped to the last entry
    once exhausted), letting a single ``Trainer.fit()`` call drive stateful callbacks (e.g. ``RFDETREarlyStopping``'s
    ``wait_count``) through both improving and non-improving epochs.
    """

    def __init__(self, values: list[float]) -> None:
        """Initialize with the per-epoch ``val/mAP_50_95`` sequence.

        Args:
            values: One value per validation epoch; the last entry repeats once exhausted.
        """
        super().__init__()
        self.model = torch.nn.Linear(4, 1)
        self.train_config = {"lr": 0.01}
        self._values = values

    def training_step(self, batch: tuple[Tensor, Tensor], batch_idx: int) -> Tensor:
        """Compute MSE loss for one training batch.

        Args:
            batch: ``(x, y)`` tensors from the ``TensorDataset`` loader.
            batch_idx: Index of the batch within the current epoch (unused).

        Returns:
            Scalar MSE loss.
        """
        del batch_idx
        x, y = batch
        return torch.nn.functional.mse_loss(self.model(x), y)

    def validation_step(self, batch: tuple[Tensor, Tensor], batch_idx: int) -> None:
        """Log ``values[current_epoch]`` (clamped to the last entry) as ``val/mAP_50_95``.

        Args:
            batch: Unused; only the epoch-level log call matters for these tests.
            batch_idx: Unused.
        """
        del batch, batch_idx
        idx = min(self.current_epoch, len(self._values) - 1)
        self.log("val/mAP_50_95", torch.tensor(self._values[idx]), on_step=False, on_epoch=True, prog_bar=False)

    def configure_optimizers(self) -> torch.optim.Optimizer:
        """Return a plain SGD optimizer sufficient to drive ``Trainer.fit()``."""
        return torch.optim.SGD(self.model.parameters(), lr=0.01)


class _EmaMetricModule(LightningModule):
    """LightningModule that logs independently controlled ``val/mAP_50_95`` and ``val/ema_mAP_50_95`` values.

    Used to drive :class:`BestModelCallback`'s EMA-checkpoint bookkeeping (``checkpoint_best_ema.pth``) with a
    real, trainable model, so :class:`~rfdetr.training.callbacks.ema.RFDETREMACallback` produces genuinely
    different EMA weights per :class:`~pytorch_lightning.Trainer` phase.
    """

    def __init__(self, regular_value: float, ema_value: float) -> None:
        """Initialize with the fixed regular/EMA metric values to log every epoch.

        Args:
            regular_value: Value logged as ``val/mAP_50_95`` on every validation epoch.
            ema_value: Value logged as ``val/ema_mAP_50_95`` on every validation epoch.
        """
        super().__init__()
        self.model = torch.nn.Linear(4, 1)
        self.train_config = {"lr": 0.01}
        self._regular_value = regular_value
        self._ema_value = ema_value

    def training_step(self, batch: tuple[Tensor, Tensor], batch_idx: int) -> Tensor:
        """Compute MSE loss for one training batch.

        Args:
            batch: ``(x, y)`` tensors from the ``TensorDataset`` loader.
            batch_idx: Index of the batch within the current epoch (unused).

        Returns:
            Scalar MSE loss.
        """
        del batch_idx
        x, y = batch
        pred = self.model(x)
        return torch.nn.functional.mse_loss(pred, y)

    def validation_step(self, batch: tuple[Tensor, Tensor], batch_idx: int) -> None:
        """Log the fixed regular and EMA metric values, ignoring the actual batch contents.

        Args:
            batch: Unused; only the epoch-level log calls matter for these tests.
            batch_idx: Unused.
        """
        del batch, batch_idx
        self.log("val/mAP_50_95", torch.tensor(self._regular_value), on_step=False, on_epoch=True, prog_bar=False)
        self.log("val/ema_mAP_50_95", torch.tensor(self._ema_value), on_step=False, on_epoch=True, prog_bar=False)

    def configure_optimizers(self) -> torch.optim.Optimizer:
        """Return a plain SGD optimizer sufficient to drive ``Trainer.fit()``."""
        return torch.optim.SGD(self.model.parameters(), lr=0.01)


class _CallbackStateCaptureCallback(Callback):
    """Snapshot other callbacks' resumed state at the first post-resume train-epoch start.

    Runs before any post-resume training step can mutate ``ema_callback``/``early_stop_callback``, so the captured
    values reflect exactly what PTL's ``_call_callbacks_load_state_dict`` restored from the checkpoint.
    """

    def __init__(self, ema_callback: RFDETREMACallback, early_stop_callback: RFDETREarlyStopping) -> None:
        """Store the callbacks to snapshot once training resumes.

        Args:
            ema_callback: The resumed ``RFDETREMACallback`` instance to read state from.
            early_stop_callback: The resumed ``RFDETREarlyStopping`` instance to read state from.
        """
        super().__init__()
        self._ema_callback = ema_callback
        self._early_stop_callback = early_stop_callback
        self.ema_latest_update_step: int | None = None
        self.early_stop_wait_count: int | None = None

    def on_train_epoch_start(self, trainer: Trainer, pl_module: LightningModule) -> None:
        """Capture ``ema_callback``/``early_stop_callback`` state on the first post-resume epoch.

        Args:
            trainer: Unused; required by the ``Callback`` hook signature.
            pl_module: Unused; required by the ``Callback`` hook signature.
        """
        del trainer, pl_module
        if self.ema_latest_update_step is None:
            self.ema_latest_update_step = self._ema_callback._latest_update_step
            self.early_stop_wait_count = self._early_stop_callback.wait_count


class _SanityCheckEndProbe(Callback):
    """Snapshot whether a checkpoint path exists at the exact moment PTL's sanity check ends.

    ``on_sanity_check_end`` fires between the sanity-check validation pass and the first real training epoch, so it
    catches a checkpoint written from sanity-check contamination before a real epoch's own (possibly identical) score
    could produce the same file for a legitimate reason.
    """

    def __init__(self, checkpoint_path: Path) -> None:
        """Store the checkpoint path to check for at sanity-check end.

        Args:
            checkpoint_path: File whose existence is snapshotted in ``on_sanity_check_end``.
        """
        super().__init__()
        self._checkpoint_path = checkpoint_path
        self.existed_after_sanity_check: bool | None = None

    def on_sanity_check_end(self, trainer: Trainer, pl_module: LightningModule) -> None:
        """Record whether ``checkpoint_path`` exists right as the sanity check ends.

        Args:
            trainer: Unused; required by the ``Callback`` hook signature.
            pl_module: Unused; required by the ``Callback`` hook signature.
        """
        del trainer, pl_module
        self.existed_after_sanity_check = self._checkpoint_path.exists()


# ---------------------------------------------------------------------------
# TestBestModelCallback
# ---------------------------------------------------------------------------


class TestCheckpointLifecycle:
    """Checkpoint files and tracking state belong only to ordinary fit validation."""

    @pytest.mark.parametrize(
        ("fast_dev_run", "trainer_fn", "sanity_checking"),
        [
            pytest.param(True, TrainerFn.FITTING, False, id="fast-dev-run"),
            pytest.param(False, TrainerFn.VALIDATING, False, id="standalone-validate"),
            pytest.param(False, TrainerFn.TESTING, False, id="standalone-test"),
            pytest.param(False, TrainerFn.PREDICTING, False, id="standalone-predict"),
            pytest.param(False, TrainerFn.FITTING, True, id="sanity-check"),
        ],
    )
    def test_suppressed_validation_preserves_tracking_state(
        self, tmp_path: Path, fast_dev_run: bool, trainer_fn: TrainerFn, sanity_checking: bool
    ) -> None:
        """Suppressed hooks must neither write files nor seed resumed metric bookkeeping."""
        callback = BestModelCallback(output_dir=str(tmp_path), monitor_ema="val/ema_mAP_50_95", smooth_alpha=0.5)
        previous_module = _make_pl_module()
        callback._current_pl_module = previous_module
        callback._best_ema = 0.2
        callback._smoothed_regular = 0.1
        before = callback.state_dict()
        trainer = _make_trainer({"val/mAP_50_95": 0.8, "val/ema_mAP_50_95": 0.9})
        trainer.fast_dev_run = fast_dev_run
        trainer.state.fn = trainer_fn
        trainer.sanity_checking = sanity_checking

        callback.on_validation_end(trainer, _make_pl_module())

        assert callback.state_dict() == before
        assert callback._current_pl_module is previous_module
        assert not list(tmp_path.glob("*.pth"))

    @pytest.mark.parametrize("evaluates_base_model", [True, False])
    def test_ema_tracking_is_independent_of_regular_save_step(self, tmp_path: Path, evaluates_base_model: bool) -> None:
        """Validation before the first optimizer step can still update the independent EMA track."""
        callback = BestModelCallback(
            output_dir=str(tmp_path),
            monitor_ema="val/ema_mAP_50_95",
            evaluates_base_model=evaluates_base_model,
        )
        trainer = _make_trainer({"val/mAP_50_95": 0.2, "val/ema_mAP_50_95": 0.8})
        trainer.global_step = 0

        callback.on_validation_end(trainer, _make_pl_module())

        assert (tmp_path / "checkpoint_best_ema.pth").exists()
        assert callback._best_ema == pytest.approx(0.8)
        assert not (tmp_path / "checkpoint_best_regular.pth").exists()

    @pytest.mark.parametrize("is_global_zero", [True, False])
    def test_fast_dev_fit_end_preserves_existing_checkpoint(self, tmp_path: Path, is_global_zero: bool) -> None:
        """A dry run must not promote, reload or test an earlier run's checkpoints on any rank."""
        module = _make_test_step_module()
        callback = BestModelCallback(output_dir=str(tmp_path), monitor_ema="val/ema_mAP_50_95")
        trainer = _make_trainer({}, is_global_zero=is_global_zero)
        trainer.fast_dev_run = True
        checkpoint = tmp_path / "checkpoint_best_total.pth"
        torch.save({"model": {"w": torch.ones(1)}, "args": {}}, checkpoint)
        before = checkpoint.read_bytes()

        callback.on_fit_end(trainer, module)

        assert checkpoint.read_bytes() == before
        assert {p.name for p in tmp_path.glob("*.pth")} == {checkpoint.name}
        module.model.load_state_dict.assert_not_called()
        trainer.test.assert_not_called()
        trainer.strategy.barrier.assert_not_called()
        trainer.strategy.broadcast.assert_not_called()

    @pytest.mark.parametrize(
        ("operation", "fast_dev_run", "evaluates_base_model", "expected"),
        [
            pytest.param("fit", True, True, set(), id="fast-dev-base"),
            pytest.param("fit", True, False, set(), id="fast-dev-ema"),
            pytest.param("validate", False, True, set(), id="validate-base"),
            pytest.param("validate", False, False, set(), id="validate-ema"),
            pytest.param(
                "fit",
                False,
                True,
                {"checkpoint_best_ema.pth", "checkpoint_best_total.pth", "last_ema.pth", "checkpoint_best_regular.pth"},
                id="fit-base",
            ),
            pytest.param(
                "fit",
                False,
                False,
                {"checkpoint_best_ema.pth", "checkpoint_best_total.pth", "last_ema.pth"},
                id="fit-ema",
            ),
        ],
    )
    def test_real_trainer_checkpoint_lifecycle(
        self,
        tmp_path: Path,
        loaders: tuple[DataLoader, DataLoader],
        operation: str,
        fast_dev_run: bool,
        evaluates_base_model: bool,
        expected: set[str],
    ) -> None:
        """Real Lightning hooks suppress dry-run/standalone writes while retaining both fit policies."""
        train_loader, val_loader = loaders
        callback = BestModelCallback(
            output_dir=str(tmp_path),
            monitor_ema="val/ema_mAP_50_95",
            evaluates_base_model=evaluates_base_model,
            run_test=False,
        )
        trainer = Trainer(
            accelerator="cpu",
            max_epochs=1,
            fast_dev_run=fast_dev_run,
            logger=False,
            enable_model_summary=False,
            enable_progress_bar=False,
            num_sanity_val_steps=0,
            limit_train_batches=1,
            limit_val_batches=1,
            callbacks=[callback, RFDETREMACallback()],
            default_root_dir=str(tmp_path),
        )
        module = _EmaMetricModule(regular_value=0.2, ema_value=0.8)

        loader_args = {
            "fit": {"train_dataloaders": train_loader, "val_dataloaders": val_loader},
            "validate": {"dataloaders": val_loader, "verbose": False},
        }
        getattr(trainer, operation)(module, **loader_args[operation])

        assert {p.name for p in tmp_path.glob("*.pth")} == expected


class TestEvaluatesBaseModel:
    """Regular-track behaviour when validation does not evaluate the base model (``TrainConfig.eval_base_model``)."""

    def test_regular_checkpoint_skipped_when_base_model_unevaluated(self, tmp_path: Path) -> None:
        """No base-weights checkpoint may be saved while the primary key carries the EMA score.

        Under the default eval policy COCOEvalCallback mirrors the EMA score onto ``val/mAP_50_95``, so the key is
        present and the parent ModelCheckpoint would happily save the base weights against it — checkpointing one model
        on the other model's score. Only the EMA track is entitled to write this epoch.
        """
        cb = BestModelCallback(output_dir=str(tmp_path), evaluates_base_model=False)
        trainer = _make_trainer({"val/mAP_50_95": 0.9})

        cb.on_validation_end(trainer, _make_pl_module())

        assert not (tmp_path / "checkpoint_best_regular.pth").exists()

    def test_ema_checkpoint_written_when_base_model_unevaluated(self, tmp_path: Path) -> None:
        """Suppressing the regular track must not also suppress the EMA track.

        The EMA track is the only checkpoint tracking that runs under the default policy (#1285); disabling both would
        leave a run with no best checkpoint at all.
        """
        cb = BestModelCallback(output_dir=str(tmp_path), monitor_ema="val/ema_mAP_50_95", evaluates_base_model=False)
        trainer = _make_trainer({"val/mAP_50_95": 0.9, "val/ema_mAP_50_95": 0.9})

        cb.on_validation_end(trainer, _make_pl_module())

        assert (tmp_path / "checkpoint_best_ema.pth").exists()

    def test_regular_checkpoint_written_when_base_model_evaluated(self, tmp_path: Path) -> None:
        """eval_base_model=True (and every use_ema=False run) keeps the regular track working as before.

        The suppression must be scoped to the configuration that actually stops evaluating the base model, not applied
        whenever EMA happens to be enabled.
        """
        cb = BestModelCallback(output_dir=str(tmp_path), evaluates_base_model=True)
        trainer = _make_trainer({"val/mAP_50_95": 0.9})

        cb.on_validation_end(trainer, _make_pl_module())

        assert (tmp_path / "checkpoint_best_regular.pth").exists()

    def test_smoothing_ignores_mirrored_ema_score(self, tmp_path: Path) -> None:
        """The regular smoothing accumulator must not absorb EMA values it will never checkpoint against.

        ``_smoothed_regular`` is persisted in the callback state and compared against the raw EMA score in
        ``on_fit_end``; letting the mirrored EMA score feed it would corrupt that comparison on a later resume.
        """
        cb = BestModelCallback(output_dir=str(tmp_path), evaluates_base_model=False, smooth_alpha=0.5)
        trainer = _make_trainer({"val/mAP_50_95": 0.9})

        cb.on_validation_end(trainer, _make_pl_module())

        assert cb._smoothed_regular == 0.0


class TestBestModelCallback:
    """Verify best-model checkpoint saving and selection."""

    def test_legacy_positional_argument_order(self, tmp_path: Path) -> None:
        """Appending the new base-model flag preserves the legacy positional constructor order."""
        callback = BestModelCallback(str(tmp_path), "val/mAP_50_95", None, False, 3, 0.2)

        assert callback._run_test is False
        assert callback._skip_best_epochs == 3
        assert callback._smooth_alpha == pytest.approx(0.2)
        assert callback._evaluates_base_model is True

    def test_checkpoint_payload_includes_model_config_when_provided(self) -> None:
        """Saved ``.pth`` checkpoints should carry the architecture schema needed for reload."""
        trainer = _make_trainer({"val/mAP_50_95": 0.5})
        payload = BestModelCallback._build_checkpoint_payload(
            {"w": torch.zeros(1)},
            {"num_classes": 1},
            trainer,
            model_name="RFDETRKeypointPreview",
            model_config_dict={"num_keypoints_per_class": [0, 17], "use_grouppose_keypoints": True},
        )

        assert payload["model_config"] == {"num_keypoints_per_class": [0, 17], "use_grouppose_keypoints": True}

    def test_checkpoint_payload_loops_include_validate_and_test_stubs(self) -> None:
        """Checkpoint loops dict must include validate_loop and test_loop stubs.

        trainer.validate(ckpt_path=...) and trainer.test(ckpt_path=...) call restore_loops() which does
        checkpoint["loops"]["validate_loop"] / checkpoint["loops"]["test_loop"] — KeyError if absent.
        """
        trainer = _make_trainer({"val/mAP_50_95": 0.5})
        payload = BestModelCallback._build_checkpoint_payload(
            {"w": torch.zeros(1)},
            {"num_classes": 1},
            trainer,
        )

        loops = payload["loops"]
        assert "validate_loop" in loops, "validate_loop missing — trainer.validate(ckpt_path=...) will KeyError"
        assert "test_loop" in loops, "test_loop missing — trainer.test(ckpt_path=...) will KeyError"
        assert "state_dict" in loops["validate_loop"]
        assert "state_dict" in loops["test_loop"]

    @pytest.mark.parametrize(
        "monitor_ema, metrics, checkpoint_file",
        [
            pytest.param(None, {"val/mAP_50_95": 0.9}, "checkpoint_best_regular.pth", id="regular"),
            pytest.param(
                "val/ema_mAP_50_95",
                {"val/mAP_50_95": 0.5, "val/ema_mAP_50_95": 0.9},
                "checkpoint_best_ema.pth",
                id="ema",
            ),
        ],
    )
    def test_skip_best_epochs_no_checkpoint_during_skip_window(
        self, tmp_path: Path, monitor_ema: str | None, metrics: dict, checkpoint_file: str
    ) -> None:
        """No checkpoint written for epochs before skip_best_epochs."""
        cb = BestModelCallback(output_dir=str(tmp_path), monitor_ema=monitor_ema, skip_best_epochs=2)
        pl_module = _make_pl_module()
        cb.on_validation_end(_make_trainer(metrics, current_epoch=0), pl_module)
        cb.on_validation_end(_make_trainer(metrics, current_epoch=1), pl_module)
        assert not (tmp_path / checkpoint_file).exists()

    @pytest.mark.parametrize(
        "monitor_ema, skip_metrics, eligible_metrics, checkpoint_file",
        [
            pytest.param(
                None,
                {"val/mAP_50_95": 0.9},
                {"val/mAP_50_95": 0.7},
                "checkpoint_best_regular.pth",
                id="regular",
            ),
            pytest.param(
                "val/ema_mAP_50_95",
                {"val/mAP_50_95": 0.5, "val/ema_mAP_50_95": 0.9},
                {"val/mAP_50_95": 0.5, "val/ema_mAP_50_95": 0.7},
                "checkpoint_best_ema.pth",
                id="ema",
            ),
        ],
    )
    def test_skip_best_epochs_checkpoint_saved_on_first_eligible_epoch(
        self,
        tmp_path: Path,
        monitor_ema: str | None,
        skip_metrics: dict,
        eligible_metrics: dict,
        checkpoint_file: str,
    ) -> None:
        """Checkpoint written on the first epoch at or after skip_best_epochs."""
        cb = BestModelCallback(output_dir=str(tmp_path), monitor_ema=monitor_ema, skip_best_epochs=2)
        pl_module = _make_pl_module()
        cb.on_validation_end(_make_trainer(skip_metrics, current_epoch=0), pl_module)
        cb.on_validation_end(_make_trainer(skip_metrics, current_epoch=1), pl_module)
        cb.on_validation_end(_make_trainer(eligible_metrics, current_epoch=2), pl_module)
        assert (tmp_path / checkpoint_file).exists()

    @pytest.mark.parametrize(
        "kwargs",
        [
            pytest.param({}, id="default"),
            pytest.param({"skip_best_epochs": 0}, id="explicit-zero"),
        ],
    )
    def test_skip_best_epochs_zero_does_not_defer_epoch_zero(self, tmp_path: Path, kwargs: dict) -> None:
        """skip_best_epochs=0 (explicit or default) makes epoch 0 eligible for checkpoint."""
        cb = BestModelCallback(output_dir=str(tmp_path), **kwargs)
        trainer = _make_trainer({"val/mAP_50_95": 0.5}, current_epoch=0)
        pl_module = _make_pl_module()

        cb.on_validation_end(trainer, pl_module)

        assert (tmp_path / "checkpoint_best_regular.pth").exists()
        assert cb.best_model_score is not None

    def test_skip_best_epochs_exceeds_total_epochs_produces_no_checkpoint(self, tmp_path: Path) -> None:
        """No checkpoint when skip_best_epochs >= total epochs (all epochs skipped)."""
        cb = BestModelCallback(output_dir=str(tmp_path), skip_best_epochs=3)
        pl_module = _make_pl_module()

        for epoch in range(2):
            trainer = _make_trainer({"val/mAP_50_95": 0.9}, current_epoch=epoch)
            cb.on_validation_end(trainer, pl_module)

        assert not (tmp_path / "checkpoint_best_regular.pth").exists()
        assert cb.best_model_score is None

    @pytest.mark.parametrize(
        "invalid_value, exc_type",
        [
            pytest.param(True, TypeError, id="bool-true"),
            pytest.param(2.5, TypeError, id="float"),
            pytest.param("3", TypeError, id="string"),
            pytest.param(-1, ValueError, id="negative"),
        ],
    )
    def test_skip_best_epochs_invalid_input_raises(
        self, tmp_path: Path, invalid_value: object, exc_type: type[Exception]
    ) -> None:
        """BestModelCallback raises TypeError for non-int and ValueError for negative skip_best_epochs."""
        with pytest.raises(exc_type):
            BestModelCallback(output_dir=str(tmp_path), skip_best_epochs=invalid_value)  # type: ignore[arg-type]

    def test_regular_checkpoint_saved_on_improvement(self, tmp_path: Path) -> None:
        """Metric 0.5 > initial 0.0 causes checkpoint_best_regular.pth to be saved."""
        cb = BestModelCallback(output_dir=str(tmp_path))
        trainer = _make_trainer({"val/mAP_50_95": 0.5})
        pl_module = _make_pl_module()

        cb.on_validation_end(trainer, pl_module)

        assert (tmp_path / "checkpoint_best_regular.pth").exists()

    def test_regular_checkpoint_not_saved_on_no_improvement(self, tmp_path: Path) -> None:
        """Metric 0.3 after best 0.5 does not create a checkpoint file."""
        cb = BestModelCallback(output_dir=str(tmp_path))
        pl_module = _make_pl_module()

        # First call sets best to 0.5
        trainer1 = _make_trainer({"val/mAP_50_95": 0.5})
        cb.on_validation_end(trainer1, pl_module)

        # Record mtime to verify no overwrite
        path = tmp_path / "checkpoint_best_regular.pth"
        stat_before = path.stat().st_mtime_ns

        # Second call with worse metric (same global_step → ModelCheckpoint skip guard fires)
        trainer2 = _make_trainer({"val/mAP_50_95": 0.3})
        cb.on_validation_end(trainer2, pl_module)

        assert path.stat().st_mtime_ns == stat_before

    def test_ema_checkpoint_saved_on_ema_improvement(self, tmp_path: Path) -> None:
        """When monitor_ema is set and EMA metric improves, EMA checkpoint is saved."""
        cb = BestModelCallback(
            output_dir=str(tmp_path),
            monitor_ema="val/ema_mAP_50_95",
        )
        trainer = _make_trainer({"val/mAP_50_95": 0.4, "val/ema_mAP_50_95": 0.6})
        pl_module = _make_pl_module()

        cb.on_validation_end(trainer, pl_module)

        assert (tmp_path / "checkpoint_best_ema.pth").exists()

    def test_ema_checkpoint_not_written_during_sanity_check(self, tmp_path: Path) -> None:
        """PTL's pre-training sanity check must not seed checkpoint_best_ema.pth.

        Regression test for #1348: PyTorch Lightning's sanity-check validation pass (which runs before any real training
        epoch) was landing straight into the EMA improvement check below, so any positive sanity-check score — common
        when starting a new training run initialized with pretrain_weights from a checkpoint pretrained on a different
        dataset — got written out as the permanent "best" EMA checkpoint before a single real epoch ran. The regular-
        checkpoint path already skips this via ModelCheckpoint._should_skip_saving_checkpoint's own
        trainer.sanity_checking guard; the EMA block reimplements its own saving logic and never inherited that guard.
        """
        cb = BestModelCallback(output_dir=str(tmp_path), monitor_ema="val/ema_mAP_50_95")
        pl_module = _make_pl_module()
        trainer = _make_trainer(
            {"val/mAP_50_95": 0.1, "val/ema_mAP_50_95": 0.83},
            current_epoch=0,
            sanity_checking=True,
        )

        cb.on_validation_end(trainer, pl_module)

        assert not (tmp_path / "checkpoint_best_ema.pth").exists()
        assert cb._best_ema == 0.0

    def test_ema_checkpoint_written_on_first_real_epoch_after_sanity_check(self, tmp_path: Path) -> None:
        """A genuine epoch 0 right after the sanity check still saves the EMA checkpoint.

        Confirms the sanity_checking guard is specific to the sanity-check pass, not a blanket "never write at epoch 0"
        — the correct guard is trainer.sanity_checking, not trainer.current_epoch == 0.
        """
        cb = BestModelCallback(output_dir=str(tmp_path), monitor_ema="val/ema_mAP_50_95")
        pl_module = _make_pl_module()

        sanity_trainer = _make_trainer(
            {"val/mAP_50_95": 0.1, "val/ema_mAP_50_95": 0.83},
            current_epoch=0,
            sanity_checking=True,
        )
        cb.on_validation_end(sanity_trainer, pl_module)

        real_trainer = _make_trainer(
            {"val/mAP_50_95": 0.2, "val/ema_mAP_50_95": 0.35},
            current_epoch=0,
            sanity_checking=False,
        )
        cb.on_validation_end(real_trainer, pl_module)

        assert (tmp_path / "checkpoint_best_ema.pth").exists()
        assert cb._best_ema == pytest.approx(0.35)

    def test_smoothed_regular_not_updated_during_sanity_check(self, tmp_path: Path) -> None:
        """The regular-monitor smoothing accumulator must not warm up from the sanity check.

        Guards the secondary smoothing state (smooth_alpha > 0) alongside the EMA checkpoint above: both are custom
        bookkeeping that sits outside ModelCheckpoint's own sanity-check guard.
        """
        cb = BestModelCallback(output_dir=str(tmp_path), smooth_alpha=0.9)
        pl_module = _make_pl_module()
        trainer = _make_trainer({"val/mAP_50_95": 0.83}, current_epoch=0, sanity_checking=True)

        cb.on_validation_end(trainer, pl_module)

        assert cb._smoothed_regular == 0.0

    def test_ema_checkpoint_not_written_during_real_ptl_sanity_check(
        self, tmp_path: Path, loaders: tuple[DataLoader, DataLoader]
    ) -> None:
        """End-to-end: an unmodified Trainer with the sanity check enabled must not seed checkpoint_best_ema.pth.

        The three tests above call on_validation_end directly with trainer.sanity_checking mocked True — they pin the
        callback's own guard logic but not the premise it depends on: that PyTorch Lightning actually invokes
        on_validation_end with trainer.sanity_checking=True during its real sanity-check pass
        (Trainer._run_sanity_check, which reuses the same evaluation loop as real validation). This test runs a real
        Trainer with num_sanity_val_steps left enabled to close that gap, using a probe callback's on_sanity_check_end
        hook to pin down that no checkpoint exists at that exact moment — before a same-valued real epoch 0 could
        produce the same file for a legitimate reason.
        """
        train_loader, val_loader = loaders

        checkpoint_path = tmp_path / "checkpoint_best_ema.pth"
        save_cb = BestModelCallback(output_dir=str(tmp_path), monitor_ema="val/ema_mAP_50_95", run_test=False)
        ema_cb = RFDETREMACallback()
        probe = _SanityCheckEndProbe(checkpoint_path)
        trainer = _make_cpu_trainer(tmp_path, 1, [save_cb, ema_cb, probe], num_sanity_val_steps=2)
        # Same value on every validation call (sanity check and the real epoch both log unconditionally) —
        # reproduces #1348 exactly. The probe below, not the end-state checkpoint, is what pins the timing down.
        trainer.fit(
            _EmaMetricModule(regular_value=0.2, ema_value=0.83),
            train_dataloaders=train_loader,
            val_dataloaders=val_loader,
        )

        assert probe.existed_after_sanity_check is False, (
            "checkpoint_best_ema.pth existed right after PTL's sanity check ended — the sanity-check validation pass "
            "wrote it before any real epoch ran"
        )
        assert checkpoint_path.exists()
        assert save_cb._best_ema == pytest.approx(0.83)

    def test_ema_checkpoint_saved_when_regular_monitor_absent(self, tmp_path: Path) -> None:
        """Under `eval_ema_only`, val/mAP_50_95 is never logged — only val/ema_mAP_50_95 is.

        Regression test for #1285: the regular-monitor guard in on_validation_end used to `return` before reaching the
        EMA block, so checkpoint_best_ema.pth was never written in this mode even though the EMA metric had real data
        every epoch.
        """
        cb = BestModelCallback(
            output_dir=str(tmp_path),
            monitor_ema="val/ema_mAP_50_95",
        )
        # No "val/mAP_50_95" key at all — matches eval_ema_only routing (config.py:1068-1074).
        trainer = _make_trainer({"val/ema_mAP_50_95": 0.6})
        pl_module = _make_pl_module()

        cb.on_validation_end(trainer, pl_module)

        assert (tmp_path / "checkpoint_best_ema.pth").exists()
        assert not (tmp_path / "checkpoint_best_regular.pth").exists()

    def test_ema_checkpoint_saves_ema_callback_weights(self, tmp_path: Path, ema_callback: MagicMock) -> None:
        """EMA checkpoint must store EMA callback weights, not live model weights."""
        cb = BestModelCallback(output_dir=str(tmp_path), monitor_ema="val/ema_mAP_50_95")
        trainer = _make_trainer({"val/mAP_50_95": 0.4, "val/ema_mAP_50_95": 0.6}, callbacks=[ema_callback])

        cb.on_validation_end(trainer, _make_pl_module())

        checkpoint = torch.load(tmp_path / "checkpoint_best_ema.pth", map_location="cpu", weights_only=False)
        assert checkpoint["model"] == ema_callback.get_ema_model_state_dict.return_value

    def test_regular_checkpoint_uses_live_weights_when_ema_enabled(
        self, tmp_path: Path, ema_callback: MagicMock
    ) -> None:
        """Regular checkpoint must store live weights even when EMA is tracked separately."""
        cb = BestModelCallback(output_dir=str(tmp_path), monitor_ema="val/ema_mAP_50_95")
        trainer = _make_trainer({"val/mAP_50_95": 0.6, "val/ema_mAP_50_95": 0.6}, callbacks=[ema_callback])

        cb.on_validation_end(trainer, _make_pl_module())

        checkpoint = torch.load(tmp_path / "checkpoint_best_regular.pth", map_location="cpu", weights_only=False)
        assert checkpoint["model"] == {"w": torch.zeros(1)}

    @pytest.mark.parametrize(
        ("regular", "ema", "winner"),
        [
            pytest.param(0.6, 0.5, "regular", id="regular-wins"),
            pytest.param(0.5, 0.7, "ema", id="ema-wins"),
            pytest.param(0.6, 0.6, "regular", id="tie-goes-to-regular"),
        ],
    )
    def test_best_total_comes_from_winning_source(
        self, tmp_path: Path, regular: float, ema: float, winner: str
    ) -> None:
        """checkpoint_best_total.pth is built from the better track; EMA must strictly beat regular to win."""
        cb = BestModelCallback(output_dir=str(tmp_path), monitor_ema="val/ema_mAP_50_95", run_test=False)
        pl_module = _make_pl_module()
        trainer = _make_trainer({"val/mAP_50_95": regular, "val/ema_mAP_50_95": ema})
        cb.on_validation_end(trainer, pl_module)

        cb.on_fit_end(trainer, pl_module)

        total_data = torch.load(tmp_path / "checkpoint_best_total.pth", map_location="cpu", weights_only=False)
        source_data = torch.load(tmp_path / f"checkpoint_best_{winner}.pth", map_location="cpu", weights_only=False)
        # total is stripped but keeps provenance keys (e.g. best_total_source) beyond model + args
        assert "args" in total_data
        assert total_data["model"] == source_data["model"]
        assert total_data["best_total_source"] == winner

    @pytest.mark.parametrize(
        ("monitor_ema", "metrics", "expect_file"),
        [
            pytest.param("val/ema_mAP_50_95", {"val/mAP_50_95": 0.6, "val/ema_mAP_50_95": 0.7}, True, id="ema-enabled"),
            pytest.param(None, {"val/mAP_50_95": 0.6}, False, id="ema-disabled"),
        ],
    )
    def test_last_ema_written_only_when_ema_enabled(
        self, tmp_path: Path, monitor_ema: str | None, metrics: dict, expect_file: bool
    ) -> None:
        """on_fit_end writes last_ema.pth with the final EMA weights only when EMA tracking is enabled."""
        cb = BestModelCallback(output_dir=str(tmp_path), monitor_ema=monitor_ema, run_test=False)
        pl_module = _make_pl_module()
        trainer = _make_trainer(metrics)
        cb.on_validation_end(trainer, pl_module)

        cb.on_fit_end(trainer, pl_module)

        assert (tmp_path / "last_ema.pth").exists() is expect_file

    def test_best_ema_backfilled_when_metric_never_improved(self, tmp_path: Path) -> None:
        """When the EMA metric never beats 0.0, on_fit_end backfills checkpoint_best_ema.pth with final EMA weights."""
        cb = BestModelCallback(output_dir=str(tmp_path), monitor_ema="val/ema_mAP_50_95", run_test=False)
        pl_module = _make_pl_module()
        # EMA metric stays at 0.0 so on_validation_end never saves checkpoint_best_ema.pth.
        trainer = _make_trainer({"val/mAP_50_95": 0.6, "val/ema_mAP_50_95": 0.0})
        cb.on_validation_end(trainer, pl_module)
        assert not (tmp_path / "checkpoint_best_ema.pth").exists()

        cb.on_fit_end(trainer, pl_module)

        assert (tmp_path / "checkpoint_best_ema.pth").exists()

    def test_zero_ema_score_promotes_ema_checkpoint_for_ema_only_runs(self, tmp_path: Path) -> None:
        """A valid zero EMA score still produces and promotes the total checkpoint when no base model was evaluated."""
        callback = BestModelCallback(
            output_dir=str(tmp_path),
            monitor_ema="val/ema_mAP_50_95",
            evaluates_base_model=False,
            run_test=False,
        )
        trainer = _make_trainer({"val/ema_mAP_50_95": 0.0})

        callback.on_validation_end(trainer, _make_pl_module())
        callback.on_fit_end(trainer, _make_pl_module())

        assert (tmp_path / "checkpoint_best_ema.pth").exists()
        total = torch.load(tmp_path / "checkpoint_best_total.pth", map_location="cpu", weights_only=False)
        assert total["best_total_source"] == "ema"

    def test_best_ema_not_overwritten_when_metric_improved(self, tmp_path: Path) -> None:
        """on_fit_end must not rewrite checkpoint_best_ema.pth when a true best was saved during training."""
        cb = BestModelCallback(output_dir=str(tmp_path), monitor_ema="val/ema_mAP_50_95", run_test=False)
        pl_module = _make_pl_module()
        trainer = _make_trainer({"val/mAP_50_95": 0.5, "val/ema_mAP_50_95": 0.7})
        cb.on_validation_end(trainer, pl_module)
        assert (tmp_path / "checkpoint_best_ema.pth").exists()

        # Spy that records each destination while delegating to the real writer.
        written: list[str] = []
        real_writer = cb._write_ema_checkpoint

        def _spy(trainer_arg, module_arg, state_dict_arg, dest) -> None:
            written.append(Path(dest).name)
            real_writer(trainer_arg, module_arg, state_dict_arg, dest)

        cb._write_ema_checkpoint = _spy  # type: ignore[method-assign]
        cb.on_fit_end(trainer, pl_module)

        assert "checkpoint_best_ema.pth" not in written
        assert "last_ema.pth" in written

    def test_best_total_stripped_of_optimizer(self, tmp_path: Path) -> None:
        """checkpoint_best_total.pth must NOT contain optimizer or lr_scheduler keys."""
        cb = BestModelCallback(
            output_dir=str(tmp_path),
            run_test=False,
        )
        pl_module = _make_pl_module()
        trainer = _make_trainer({"val/mAP_50_95": 0.5})

        cb.on_validation_end(trainer, pl_module)
        cb.on_fit_end(trainer, pl_module)

        total = tmp_path / "checkpoint_best_total.pth"
        data = torch.load(total, map_location="cpu", weights_only=False)
        assert "optimizer" not in data
        assert "lr_scheduler" not in data
        # Must contain model and args
        assert "model" in data
        assert "args" in data

    def test_run_test_true_calls_trainer_test(self, tmp_path: Path) -> None:
        """run_test=True causes trainer.test() when module defines test_step()."""
        pl_module = _make_test_step_module()

        cb = BestModelCallback(output_dir=str(tmp_path), run_test=True)
        trainer = _make_trainer({"val/mAP_50_95": 0.5})

        cb.on_validation_end(trainer, pl_module)
        cb.on_fit_end(trainer, pl_module)

        trainer.test.assert_called_once_with(pl_module, datamodule=trainer.datamodule, verbose=False)

    def test_run_test_true_enters_trainer_test_on_non_main_rank(self, tmp_path: Path) -> None:
        """A non-main rank must still enter the collective trainer.test() once the main process broadcasts go.

        Regression test: ``on_fit_end`` used to return early on every rank but the main one, so under DDP the main
        process called the collective ``trainer.test()`` alone and hung waiting for the others.
        """
        pl_module = _make_test_step_module()
        torch.save({"model": {"w": torch.zeros(1)}}, tmp_path / "checkpoint_best_total.pth")

        cb = BestModelCallback(output_dir=str(tmp_path), run_test=True)
        trainer = _make_trainer({"val/mAP_50_95": 0.5}, is_global_zero=False)
        # The main process decides; this rank receives (should_test, chose_ema) from the broadcast.
        trainer.strategy.broadcast.side_effect = lambda obj, src=0: (True, False)

        cb.on_fit_end(trainer, pl_module)

        trainer.strategy.barrier.assert_called_once()
        pl_module.model.load_state_dict.assert_called_once()
        trainer.test.assert_called_once_with(pl_module, datamodule=trainer.datamodule, verbose=False)

    def test_run_test_true_skips_trainer_test_inside_spawned_worker(self, tmp_path: Path) -> None:
        """Inside a spawn-launcher worker, run_test=True must warn and skip instead of launching a second time.

        Regression test: calling ``trainer.test()`` from a ``ddp_spawn`` worker made ``_MultiProcessingLauncher``
        spawn another set of processes and fail with ``DistNetworkError: EADDRINUSE``.
        """
        from pytorch_lightning.strategies.launchers.multiprocessing import _MultiProcessingLauncher

        pl_module = _make_test_step_module()

        cb = BestModelCallback(output_dir=str(tmp_path), run_test=True)
        trainer = _make_trainer({"val/mAP_50_95": 0.5})
        trainer.strategy.launcher = MagicMock(spec=_MultiProcessingLauncher)

        cb.on_validation_end(trainer, pl_module)
        cb.on_fit_end(trainer, pl_module)

        assert (tmp_path / "checkpoint_best_total.pth").exists()
        trainer.strategy.barrier.assert_not_called()
        trainer.test.assert_not_called()

    def test_run_test_true_without_test_step_skips_trainer_test(self, tmp_path: Path) -> None:
        """run_test=True but no test_step override — trainer.test() is NOT called.

        The guard in BestModelCallback.on_fit_end() skips trainer.test() for modules that do not override
        LightningModule.test_step() to avoid a MisconfigurationException from PTL.
        """
        cb = BestModelCallback(output_dir=str(tmp_path), run_test=True)
        pl_module = _make_pl_module()  # MagicMock — no test_step on its class
        trainer = _make_trainer({"val/mAP_50_95": 0.5})

        cb.on_validation_end(trainer, pl_module)
        cb.on_fit_end(trainer, pl_module)

        trainer.test.assert_not_called()

    def test_run_test_true_without_best_checkpoint_skips_trainer_test(self, tmp_path: Path) -> None:
        """run_test=True must not test final weights when no best checkpoint was produced."""
        pl_module = _make_test_step_module()

        cb = BestModelCallback(output_dir=str(tmp_path), run_test=True, skip_best_epochs=2)
        trainer = _make_trainer({"val/mAP_50_95": 0.5}, current_epoch=0)

        cb.on_validation_end(trainer, pl_module)
        cb.on_fit_end(trainer, pl_module)

        assert not (tmp_path / "checkpoint_best_total.pth").exists()
        trainer.test.assert_not_called()

    def test_run_test_loads_best_weights_before_test(self, tmp_path: Path) -> None:
        """on_fit_end loads checkpoint_best_total.pth weights before trainer.test().

        Mirrors legacy main.py:602-609 which loads the best checkpoint into the model before running test evaluation so
        the test loop measures the best model, not the end-of-training state.
        """
        pl_module = _make_test_step_module()

        cb = BestModelCallback(output_dir=str(tmp_path), run_test=True)
        trainer = _make_trainer({"val/mAP_50_95": 0.5})

        cb.on_validation_end(trainer, pl_module)
        cb.on_fit_end(trainer, pl_module)

        # Weights come from checkpoint_best_total.pth with strict=False plus a manual missing/unexpected-key check.
        pl_module.model.load_state_dict.assert_called_once()
        call_args, call_kwargs = pl_module.model.load_state_dict.call_args
        assert call_kwargs.get("strict") is False, "load_state_dict must be called with strict=False"
        assert call_args[0] == {"w": torch.zeros(1)}, "no _extra_state keys to filter — dict passes through unchanged"

    def test_run_test_strips_extra_state_from_regular_weights_before_load(self, tmp_path: Path) -> None:
        """A live-model checkpoint's Transformer Engine `_extra_state` entries must not reach load_state_dict.

        Under FP8, ``_get_live_model_state_dict`` writes the regular checkpoint straight from the live module's
        ``state_dict()``, which — unlike the EMA export — still carries ``_extra_state`` keys. Transformer Engine
        rejects their pickle round-trip via ``set_extra_state()``, so they must be excluded from the dict handed to
        ``load_state_dict`` rather than merely tolerated afterward via ``strict=False``.
        """
        # The model itself is missing the "w" tensor after reload — a genuine mismatch that must still raise.
        pl_module = _make_test_step_module(
            {"w": torch.zeros(1), "layer._extra_state": b"fp8-scaling-history"}, missing_keys=["w"]
        )

        cb = BestModelCallback(output_dir=str(tmp_path), run_test=True)
        trainer = _make_trainer({"val/mAP_50_95": 0.5})

        cb.on_validation_end(trainer, pl_module)
        with pytest.raises(RuntimeError) as exc_info:
            cb.on_fit_end(trainer, pl_module)

        assert "Error loading best regular weights" in str(exc_info.value)
        assert "'w'" in str(exc_info.value)

        loaded_dict = pl_module.model.load_state_dict.call_args[0][0]
        assert "layer._extra_state" not in loaded_dict, "_extra_state must be filtered out before load_state_dict"
        assert loaded_dict == {"w": torch.zeros(1)}

    def test_run_test_false_skips_trainer_test(self, tmp_path: Path) -> None:
        """run_test=False means trainer.test() is never called."""
        cb = BestModelCallback(output_dir=str(tmp_path), run_test=False)
        pl_module = _make_pl_module()
        trainer = _make_trainer({"val/mAP_50_95": 0.5})

        cb.on_validation_end(trainer, pl_module)
        cb.on_fit_end(trainer, pl_module)

        trainer.test.assert_not_called()

    @pytest.mark.parametrize(("cb_kwargs", "metrics", "checkpoint_filename"), _REGULAR_AND_EMA_CASES)
    @pytest.mark.parametrize(
        ("datamodule_class_names", "train_config_kwargs", "expected"),
        [
            pytest.param(["cat", "dog"], {}, ["cat", "dog"], id="unset-config-uses-datamodule-names"),
            # The datamodule names would overwrite the explicit ones if the bug existed.
            pytest.param(["other_class"], {"class_names": ["defect"]}, ["defect"], id="explicit-names-kept"),
            # Guard-bypass regression: `not getattr(..., "class_names", None)` treated an explicit empty list like
            # None (both falsy); the fix uses an `is None` identity check.
            pytest.param(["cat", "dog"], {"class_names": []}, [], id="explicit-empty-names-kept"),
            pytest.param([], {}, [], id="unset-config-uses-empty-datamodule-names"),
        ],
    )
    def test_checkpoint_class_names_reflects_datamodule_and_train_config(
        self,
        tmp_path: Path,
        cb_kwargs: dict,
        metrics: dict,
        checkpoint_filename: str,
        datamodule_class_names: list,
        train_config_kwargs: dict,
        expected: list,
    ) -> None:
        """Saved checkpoint args.class_names reflects dataset class names, explicit TrainConfig values winning.

        Regression tests for #509: checkpoints were saved with class_names=None when the user did not pass class_names
        explicitly (fixed by falling back to the datamodule), and a separate guard-bypass let an explicit empty list get
        silently overwritten by the datamodule's names. Covers both the regular and EMA checkpoint paths across unset,
        explicit, and explicit-empty class_names in TrainConfig.
        """
        cb = BestModelCallback(output_dir=str(tmp_path), **cb_kwargs)
        trainer = _make_trainer(metrics)
        trainer.datamodule.class_names = datamodule_class_names

        pl_module = _make_pl_module()
        pl_module.train_config = TrainConfig(dataset_dir=str(tmp_path / "ds"), tensorboard=False, **train_config_kwargs)

        cb.on_validation_end(trainer, pl_module)

        checkpoint = torch.load(tmp_path / checkpoint_filename, map_location="cpu", weights_only=False)
        assert checkpoint["args"]["class_names"] == expected

    # --- PTL-compatible format tests ---

    def test_regular_checkpoint_args_is_dict(self, tmp_path: Path) -> None:
        """Saved args must be a plain dict (not a Pydantic object) for weights_only=True compat."""
        cb = BestModelCallback(output_dir=str(tmp_path))
        trainer = _make_trainer({"val/mAP_50_95": 0.5})
        pl_module = _make_pl_module()
        pl_module.train_config = TrainConfig(dataset_dir=str(tmp_path / "ds"), tensorboard=False)

        cb.on_validation_end(trainer, pl_module)

        # weights_only=True must succeed now that args is a plain dict.
        ckpt = torch.load(tmp_path / "checkpoint_best_regular.pth", map_location="cpu", weights_only=True)
        assert isinstance(ckpt["args"], dict)

    @pytest.mark.parametrize(("cb_kwargs", "metrics", "checkpoint_filename"), _REGULAR_AND_EMA_CASES)
    def test_checkpoint_has_ptl_state_dict_key(
        self, tmp_path: Path, cb_kwargs: dict, metrics: dict, checkpoint_filename: str
    ) -> None:
        """Saved regular and EMA checkpoints include a 'state_dict' whose keys carry the 'model.' prefix."""
        cb = BestModelCallback(output_dir=str(tmp_path), **cb_kwargs)

        cb.on_validation_end(_make_trainer(metrics), _make_pl_module())

        ckpt = torch.load(tmp_path / checkpoint_filename, map_location="cpu", weights_only=False)
        assert "state_dict" in ckpt
        assert all(k.startswith("model.") for k in ckpt["state_dict"])

    @pytest.mark.parametrize(("cb_kwargs", "metrics", "checkpoint_filename"), _REGULAR_AND_EMA_CASES)
    @pytest.mark.parametrize("current_epoch", [3, 5])
    def test_checkpoint_has_loops_key(
        self, tmp_path: Path, cb_kwargs: dict, metrics: dict, checkpoint_filename: str, current_epoch: int
    ) -> None:
        """Saved regular and EMA checkpoints include 'loops' whose fit_loop completed-epoch counter is epoch + 1."""
        cb = BestModelCallback(output_dir=str(tmp_path), **cb_kwargs)

        cb.on_validation_end(_make_trainer(metrics, current_epoch=current_epoch), _make_pl_module())

        ckpt = torch.load(tmp_path / checkpoint_filename, map_location="cpu", weights_only=False)
        assert "loops" in ckpt
        assert ckpt["loops"]["fit_loop"]["epoch_progress"]["current"]["completed"] == current_epoch + 1

    def test_regular_checkpoint_has_ptl_version_key(self, tmp_path: Path) -> None:
        """Saved regular checkpoint must include 'pytorch-lightning_version'."""
        cb = BestModelCallback(output_dir=str(tmp_path))
        trainer = _make_trainer({"val/mAP_50_95": 0.5})
        pl_module = _make_pl_module()

        cb.on_validation_end(trainer, pl_module)

        ckpt = torch.load(tmp_path / "checkpoint_best_regular.pth", map_location="cpu", weights_only=False)
        assert ckpt.get("pytorch-lightning_version") == ptl_version

    def test_state_dict_values_match_model_weights(self, tmp_path: Path) -> None:
        """state_dict values must be identical to the original model weights."""
        cb = BestModelCallback(output_dir=str(tmp_path))
        trainer = _make_trainer({"val/mAP_50_95": 0.5})
        pl_module = _make_pl_module()
        weights = {"w": torch.randn(3, 3)}
        pl_module.model.state_dict.return_value = weights

        cb.on_validation_end(trainer, pl_module)

        ckpt = torch.load(tmp_path / "checkpoint_best_regular.pth", map_location="cpu", weights_only=False)
        assert torch.equal(ckpt["state_dict"]["model.w"], weights["w"])

    def test_best_total_preserves_ptl_keys_after_strip(self, tmp_path: Path) -> None:
        """strip_checkpoint must preserve state_dict and loops in the final file."""
        cb = BestModelCallback(output_dir=str(tmp_path), run_test=False)
        trainer = _make_trainer({"val/mAP_50_95": 0.5})
        pl_module = _make_pl_module()

        cb.on_validation_end(trainer, pl_module)
        cb.on_fit_end(trainer, pl_module)

        total = tmp_path / "checkpoint_best_total.pth"
        data = torch.load(total, map_location="cpu", weights_only=False)
        assert "state_dict" in data, "strip_checkpoint must preserve 'state_dict'"
        assert "loops" in data, "strip_checkpoint must preserve 'loops'"
        assert "pytorch-lightning_version" in data, "strip_checkpoint must preserve 'pytorch-lightning_version'"
        assert "optimizer_states" in data, "strip_checkpoint must preserve 'optimizer_states'"
        assert "lr_schedulers" in data, "strip_checkpoint must preserve 'lr_schedulers'"

    def test_not_global_zero_does_not_save(self, tmp_path: Path) -> None:
        """Non-main process (is_global_zero=False) must not write any files."""
        cb = BestModelCallback(
            output_dir=str(tmp_path),
            monitor_ema="val/ema_mAP_50_95",
        )
        pl_module = _make_pl_module()
        trainer = _make_trainer(
            {"val/mAP_50_95": 0.9, "val/ema_mAP_50_95": 0.9},
            is_global_zero=False,
        )

        cb.on_validation_end(trainer, pl_module)
        cb.on_fit_end(trainer, pl_module)

        assert not (tmp_path / "checkpoint_best_regular.pth").exists()
        assert not (tmp_path / "checkpoint_best_ema.pth").exists()
        assert not (tmp_path / "checkpoint_best_total.pth").exists()

    def test_train_epoch_end_ignores_missing_validation_metrics(self, tmp_path: Path) -> None:
        """Train-epoch end must not try to checkpoint when validation metrics were not logged."""
        cb = BestModelCallback(output_dir=str(tmp_path))
        trainer = _make_trainer({})

        cb.on_train_epoch_end(trainer, _make_pl_module())

        assert not (tmp_path / "checkpoint_best_regular.pth").exists()

    def test_validation_end_ignores_missing_validation_metrics(self, tmp_path: Path) -> None:
        """on_validation_end must not raise when val/mAP_50_95 was not logged (non-eval epoch)."""
        cb = BestModelCallback(output_dir=str(tmp_path))
        trainer = _make_trainer({})  # empty metrics — no val/mAP_50_95 key
        trainer.fit_loop.epoch_loop.val_loop._has_run = True

        cb.on_validation_end(trainer, _make_pl_module())  # must not raise

        assert not (tmp_path / "checkpoint_best_regular.pth").exists()

    def test_fit_completes_when_metric_missing_on_some_epochs(
        self, tmp_path: Path, loaders: tuple[DataLoader, DataLoader]
    ) -> None:
        """BestModelCallback must not crash over 3 epochs when metrics are only logged every 2nd epoch."""
        train_loader, val_loader = loaders

        cb = BestModelCallback(output_dir=str(tmp_path), run_test=False)
        trainer = _make_cpu_trainer(tmp_path, 3, [cb])
        trainer.fit(_EvalIntervalModule(eval_interval=2), train_dataloaders=train_loader, val_dataloaders=val_loader)

        # Checkpoint must be written on eval epochs (0 and 2) — at least one must exist.
        assert (tmp_path / "checkpoint_best_regular.pth").exists()

    def test_best_total_checkpoint_resumes_via_trainer_fit_ckpt_path(
        self, tmp_path: Path, loaders: tuple[DataLoader, DataLoader]
    ) -> None:
        """checkpoint_best_total.pth must restore epoch/step when passed to Trainer.fit(ckpt_path=...)."""
        train_loader, val_loader = loaders

        save_cb = BestModelCallback(output_dir=str(tmp_path), run_test=False)
        trainer_first = _make_cpu_trainer(tmp_path, 1, [save_cb])
        trainer_first.fit(_ResumeTinyModule(), train_dataloaders=train_loader, val_dataloaders=val_loader)

        ckpt_path = tmp_path / "checkpoint_best_total.pth"
        assert ckpt_path.exists()
        first_phase_global_step = trainer_first.global_step
        assert first_phase_global_step == 2
        ckpt_data = torch.load(ckpt_path, map_location="cpu", weights_only=False)
        assert ckpt_data["global_step"] == first_phase_global_step

        resume_probe = _ResumeProbeCallback()
        trainer_second = _make_cpu_trainer(tmp_path, 2, [resume_probe])
        trainer_second.fit(
            _ResumeTinyModule(),
            train_dataloaders=train_loader,
            val_dataloaders=val_loader,
            ckpt_path=str(ckpt_path),
        )

        # PTL applies loop restoration by the first train epoch start.
        assert resume_probe.first_train_epoch == 1
        # Optimizer state is intentionally fresh on a stripped-checkpoint resume: one epoch of 2 steps.
        assert trainer_second.current_epoch == 2
        assert trainer_second.global_step == 2

    @pytest.mark.parametrize("checkpoint_name", ["checkpoint_best_regular.pth", "checkpoint_best_total.pth"])
    def test_best_model_score_survives_real_trainer_fit_resume(
        self, tmp_path: Path, loaders: tuple[DataLoader, DataLoader], checkpoint_name: str
    ) -> None:
        """``best_model_score`` and the on-disk checkpoint must survive a real ``trainer.fit(ckpt_path=...)`` resume.

        Regression test for the "callbacks" key being absent from ``_build_checkpoint_payload``'s output — the bug this
        PR fixes. Every existing regression test for callback-state persistence (``TestBestEmaStatePersistence``) calls
        ``state_dict()``/``load_state_dict()`` directly in Python, never through PTL's own
        ``_call_callbacks_load_state_dict``, so none of them would catch the payload missing the "callbacks" key.
        Parametrized over ``checkpoint_best_regular.pth`` (built directly by ``_build_checkpoint_payload``) and
        ``checkpoint_best_total.pth`` (built via ``shutil.copy2`` + ``strip_checkpoint``, a separate code path that
        needs ``"callbacks"`` in ``_PTL_COMPAT_KEYS``).
        """
        train_loader, val_loader = loaders

        save_cb = BestModelCallback(output_dir=str(tmp_path), run_test=False)
        trainer_first = _make_cpu_trainer(tmp_path, 1, [save_cb])
        trainer_first.fit(_MetricModule(0.7), train_dataloaders=train_loader, val_dataloaders=val_loader)
        assert save_cb.best_model_score is not None
        assert save_cb.best_model_score.item() == pytest.approx(0.7)

        ckpt_path = tmp_path / checkpoint_name
        assert ckpt_path.exists()
        first_weights = {
            k: v.clone() for k, v in torch.load(ckpt_path, map_location="cpu", weights_only=False)["model"].items()
        }

        # Fresh callback instance, resumed via a real Trainer.fit(ckpt_path=...) — exercises PTL's
        # own `_call_callbacks_load_state_dict`, not a direct load_state_dict() call.
        resumed_cb = BestModelCallback(output_dir=str(tmp_path), run_test=False)
        trainer_second = _make_cpu_trainer(tmp_path, 2, [resumed_cb])
        # Post-resume epoch logs a *worse* metric (0.3): without the fix, best_model_score resets to
        # None on a fresh callback and 0.3 trivially "improves" on it, overwriting the on-disk
        # checkpoint with worse weights — the exact failure mode from the issue this PR fixes.
        trainer_second.fit(
            _MetricModule(0.3),
            train_dataloaders=train_loader,
            val_dataloaders=val_loader,
            ckpt_path=str(ckpt_path),
        )

        assert resumed_cb.best_model_score is not None
        assert resumed_cb.best_model_score.item() == pytest.approx(0.7), (
            'best_model_score must be restored from the checkpoint\'s "callbacks" key; without the '
            "fix a fresh BestModelCallback starts with best_model_score=None and 0.3 wins by default"
        )
        # Only checked for the regular file: checkpoint_best_total.pth is re-copied by the second fit's on_fit_end, so
        # equality there would not prove the regular checkpoint survived.
        if checkpoint_name == "checkpoint_best_regular.pth":
            reloaded = torch.load(ckpt_path, map_location="cpu", weights_only=False)
            for key, value in reloaded["model"].items():
                assert torch.equal(value, first_weights[key]), (
                    f"checkpoint_best_regular.pth weights for {key!r} changed after a worse post-resume "
                    "epoch — the good checkpoint was overwritten"
                )

    def test_ema_and_early_stopping_state_survive_real_trainer_fit_resume(
        self, tmp_path: Path, loaders: tuple[DataLoader, DataLoader]
    ) -> None:
        """RFDETREMACallback and RFDETREarlyStopping state must also survive a real ``ckpt_path`` resume.

        ``test_best_model_score_survives_real_trainer_fit_resume`` only registers ``BestModelCallback`` on the
        trainer, so it exercises restoration of best-score tracking alone. The warning added to ``RFDETR.train()``
        promises "best-score tracking, EMA, early stopping" all resume correctly together — this test registers
        all three callbacks so ``_build_checkpoint_payload``'s generic ``trainer.callbacks`` loop is actually
        exercised for the other two, not just ``BestModelCallback`` itself. Lightweight checkpoints reset the
        optimizer loop's global step, so EMA restores its averaged weights but resets its step guard to permit the
        first new batch update.
        """
        train_loader, val_loader = loaders

        # last_ema.pth (enabled by monitor_ema) is rebuilt in on_fit_end with live callback state, so it can hold a
        # nonzero wait_count; checkpoint_best_regular.pth is only rewritten on improvement, which resets wait_count.
        save_cb = BestModelCallback(output_dir=str(tmp_path), monitor_ema="val/ema_mAP_50_95", run_test=False)
        ema_cb = RFDETREMACallback()
        early_stop_cb = RFDETREarlyStopping(patience=5, min_delta=0.001, verbose=False)
        trainer_first = _make_cpu_trainer(tmp_path, 2, [save_cb, ema_cb, early_stop_cb])
        # Epoch 0: 0.7 (best, wait_count 0->0). Epoch 1: 0.5 (worse, wait_count 0->1) — training ends
        # with wait_count=1 and ema_cb mid-averaging, both captured live into last_ema.pth.
        trainer_first.fit(_VaryingMetricModule([0.7, 0.5]), train_dataloaders=train_loader, val_dataloaders=val_loader)

        ckpt_path = tmp_path / "last_ema.pth"
        assert ckpt_path.exists()
        persisted_callbacks = torch.load(ckpt_path, map_location="cpu", weights_only=False)["callbacks"]
        persisted_ema_step = persisted_callbacks[ema_cb.state_key]["latest_update_step"]
        persisted_wait_count = persisted_callbacks[early_stop_cb.state_key]["wait_count"]
        # Both must be genuinely non-default so a fresh, un-restored callback (which starts at 0) cannot
        # accidentally satisfy the post-resume assertions below.
        assert persisted_ema_step > 0
        assert persisted_wait_count > 0

        ema_callback = RFDETREMACallback()
        early_stop_callback = RFDETREarlyStopping(patience=5, min_delta=0.001, verbose=False)
        capture = _CallbackStateCaptureCallback(ema_callback, early_stop_callback)
        # last_ema.pth is built in on_fit_end, after the epoch counter reached 2, so PTL's restored fit_loop counts 3
        # epochs as completed: max_epochs must be 4 (not 3) for one real epoch to run.
        trainer_second = _make_cpu_trainer(
            tmp_path,
            4,
            [
                BestModelCallback(output_dir=str(tmp_path), monitor_ema="val/ema_mAP_50_95", run_test=False),
                ema_callback,
                early_stop_callback,
                capture,
            ],
        )
        trainer_second.fit(
            _VaryingMetricModule([0.7, 0.5, 0.9, 0.9]),
            train_dataloaders=train_loader,
            val_dataloaders=val_loader,
            ckpt_path=str(ckpt_path),
        )

        assert capture.ema_latest_update_step == 0, (
            "RFDETREMACallback must reset its absolute step guard when a lightweight checkpoint resets "
            "trainer.global_step, otherwise the resumed phase skips EMA updates"
        )
        assert capture.early_stop_wait_count == persisted_wait_count, (
            "RFDETREarlyStopping.wait_count must be restored from the checkpoint's 'callbacks' key; "
            "without the fix a fresh callback starts at 0"
        )

    def test_ema_checkpoint_weights_survive_real_trainer_fit_resume(
        self, tmp_path: Path, loaders: tuple[DataLoader, DataLoader]
    ) -> None:
        """``checkpoint_best_ema.pth`` weights must survive a real ``ckpt_path`` resume too.

        ``test_best_model_score_survives_real_trainer_fit_resume`` only parametrizes over
        ``checkpoint_best_regular.pth``/``checkpoint_best_total.pth`` and never asserts weight
        preservation for the EMA track. The fix in ``_build_checkpoint_payload`` applies identically to
        ``checkpoint_best_ema.pth`` (same code path, via ``_write_ema_checkpoint``), but without a
        dedicated regression test a broken ``_best_ema`` restoration on this specific file would slip
        through: a worse post-resume EMA epoch would trivially beat a reset ``_best_ema=0.0`` and
        overwrite the good EMA checkpoint on disk, exactly like the regular-checkpoint failure mode this
        PR fixes.
        """
        train_loader, val_loader = loaders

        save_cb = BestModelCallback(output_dir=str(tmp_path), monitor_ema="val/ema_mAP_50_95", run_test=False)
        ema_cb = RFDETREMACallback()
        trainer_first = _make_cpu_trainer(tmp_path, 1, [save_cb, ema_cb])
        trainer_first.fit(
            _EmaMetricModule(regular_value=0.4, ema_value=0.75),
            train_dataloaders=train_loader,
            val_dataloaders=val_loader,
        )
        assert save_cb._best_ema == pytest.approx(0.75)

        ckpt_path = tmp_path / "checkpoint_best_ema.pth"
        assert ckpt_path.exists()
        first_ema_weights = {
            k: v.clone() for k, v in torch.load(ckpt_path, map_location="cpu", weights_only=False)["model"].items()
        }

        # Fresh callbacks, resumed via a real Trainer.fit(ckpt_path=...) — exercises PTL's own
        # _call_callbacks_load_state_dict for both BestModelCallback._best_ema and the EMA callback's
        # own averaging state, not a direct load_state_dict() call.
        resumed_save_cb = BestModelCallback(output_dir=str(tmp_path), monitor_ema="val/ema_mAP_50_95", run_test=False)
        resumed_ema_cb = RFDETREMACallback()
        trainer_second = _make_cpu_trainer(tmp_path, 2, [resumed_save_cb, resumed_ema_cb])
        # Post-resume epoch logs a *worse* EMA metric (0.3): without the fix, _best_ema resets to 0.0 on
        # a fresh callback and 0.3 trivially "improves" on it, overwriting the on-disk EMA checkpoint.
        trainer_second.fit(
            _EmaMetricModule(regular_value=0.35, ema_value=0.3),
            train_dataloaders=train_loader,
            val_dataloaders=val_loader,
            ckpt_path=str(ckpt_path),
        )

        assert resumed_save_cb._best_ema == pytest.approx(0.75), (
            '_best_ema must be restored from the checkpoint\'s "callbacks" key; without the fix a '
            "fresh BestModelCallback starts with _best_ema=0.0 and the worse post-resume EMA (0.3) "
            "wins by default"
        )
        reloaded = torch.load(ckpt_path, map_location="cpu", weights_only=False)
        for key, value in reloaded["model"].items():
            assert torch.equal(value, first_ema_weights[key]), (
                f"checkpoint_best_ema.pth weights for {key!r} changed after a worse post-resume EMA "
                "epoch — the good EMA checkpoint was overwritten"
            )

    def test_best_model_score_not_restored_when_output_dir_changes(
        self, tmp_path: Path, loaders: tuple[DataLoader, DataLoader]
    ) -> None:
        """A resumed ``output_dir`` different from the checkpoint's own does not restore ``best_model_score``.

        Pins PTL's own ``ModelCheckpoint.load_state_dict()`` gate (installed pytorch-lightning,
        ``model_checkpoint.py``): it only restores ``best_model_score``/``best_k_models`` when the resumed callback's
        ``dirpath`` matches the value stored in the checkpoint's ``"callbacks"`` state exactly; on a mismatch it warns
        and restores only ``best_model_path``. RF-DETR's ``resume`` and ``output_dir`` config fields are independent
        (``config.py``), so pointing ``resume=`` at one directory while writing to another is a config-permitted
        combination, not a corrupted setup — this test locks in the resulting (previously untested) behavior.

        ``max_epochs=1`` on both phases means the checkpoint's restored fit-loop progress (1 epoch already completed)
        leaves zero epochs left to run in phase two: the assertions below capture exactly what ``load_state_dict()``
        restored, with no confound from a subsequent training epoch overwriting ``best_model_score``/``best_model_path``
        again on its own.
        """
        train_loader, val_loader = loaders

        save_cb = BestModelCallback(output_dir=str(tmp_path), run_test=False)
        trainer_first = _make_cpu_trainer(tmp_path, 1, [save_cb])
        trainer_first.fit(_MetricModule(0.7), train_dataloaders=train_loader, val_dataloaders=val_loader)
        assert save_cb.best_model_score.item() == pytest.approx(0.7)

        ckpt_path = tmp_path / "checkpoint_best_regular.pth"
        assert ckpt_path.exists()

        # Resume into a DIFFERENT output_dir than the one the checkpoint was saved under.
        other_output_dir = tmp_path / "other_output_dir"
        other_output_dir.mkdir()
        resumed_cb = BestModelCallback(output_dir=str(other_output_dir), run_test=False)
        trainer_second = _make_cpu_trainer(tmp_path, 1, [resumed_cb])
        with pytest.warns(UserWarning, match="dirpath has changed"):
            trainer_second.fit(
                _MetricModule(0.3),
                train_dataloaders=train_loader,
                val_dataloaders=val_loader,
                ckpt_path=str(ckpt_path),
            )

        # No epoch ran post-resume (fit_loop already shows 1/1 epochs completed), so these values are
        # exactly what load_state_dict() produced, undisturbed by any further training.
        assert trainer_second.global_step == 0
        # best_model_score was NOT carried over — the dirpath mismatch skips it, leaving the fresh
        # callback's own default (None), exactly as if it had never resumed at all.
        assert resumed_cb.best_model_score is None
        # best_model_path IS still carried over regardless of the dirpath mismatch (PTL restores it
        # unconditionally), even though it now points at a path under the OLD output_dir.
        assert resumed_cb.best_model_path == str(ckpt_path)


# ---------------------------------------------------------------------------
# TestRFDETREarlyStopping
# ---------------------------------------------------------------------------


class TestRFDETREarlyStopping:
    """Verify early stopping logic mirrors legacy EarlyStoppingCallback."""

    def test_patience_not_counted_during_skip_window(self) -> None:
        """Patience wait_count stays 0 and training does not stop during skipped epochs."""
        cb = RFDETREarlyStopping(patience=1, min_delta=0.001, skip_best_epochs=2)
        pl_module = _make_pl_module()
        cb.on_validation_end(_make_trainer({"val/mAP_50_95": 0.9}, current_epoch=0), pl_module)
        trainer = _make_trainer({"val/mAP_50_95": 0.8}, current_epoch=1)
        cb.on_validation_end(trainer, pl_module)
        assert cb.wait_count == 0
        assert trainer.should_stop is False

    @pytest.mark.parametrize(
        ("patience", "metrics", "baseline"),
        [
            pytest.param(1, [0.9, 0.8, 0.7], 0.7, id="patience-1-gentle-decline"),
            pytest.param(2, [0.95, 0.85, 0.40], 0.40, id="patience-2-stronger-skipped-epochs"),
        ],
    )
    def test_first_eligible_epoch_sets_baseline_with_zero_wait(
        self, patience: int, metrics: list[float], baseline: float
    ) -> None:
        """The first eligible epoch becomes the best_score baseline even if skipped epochs scored higher.

        With skip_best_epochs=2 the third epoch is the first eligible one; patience wait_count stays 0.
        """
        cb = RFDETREarlyStopping(patience=patience, min_delta=0.001, skip_best_epochs=2)
        pl_module = _make_pl_module()

        for epoch, value in enumerate(metrics):
            cb.on_validation_end(_make_trainer({"val/mAP_50_95": value}, current_epoch=epoch), pl_module)

        assert cb.best_score.item() == pytest.approx(baseline)
        assert cb.wait_count == 0

    def test_patience_triggers_stop_after_skip_window(self) -> None:
        """Patience counts normally after skip window; triggers stop when exhausted."""
        cb = RFDETREarlyStopping(patience=1, min_delta=0.001, skip_best_epochs=2)
        pl_module = _make_pl_module()
        cb.on_validation_end(_make_trainer({"val/mAP_50_95": 0.9}, current_epoch=0), pl_module)
        cb.on_validation_end(_make_trainer({"val/mAP_50_95": 0.8}, current_epoch=1), pl_module)
        cb.on_validation_end(_make_trainer({"val/mAP_50_95": 0.7}, current_epoch=2), pl_module)
        trainer = _make_trainer({"val/mAP_50_95": 0.7}, current_epoch=3)
        cb.on_validation_end(trainer, pl_module)
        assert trainer.should_stop is True

    @pytest.mark.parametrize(
        "kwargs",
        [
            pytest.param({}, id="default"),
            pytest.param({"skip_best_epochs": 0}, id="explicit-zero"),
        ],
    )
    def test_skip_best_epochs_zero_does_not_defer_epoch_zero(self, kwargs: dict) -> None:
        """skip_best_epochs=0 (explicit or default) makes epoch 0 eligible for patience tracking."""
        cb = RFDETREarlyStopping(patience=5, min_delta=0.001, **kwargs)
        pl_module = _make_pl_module()

        trainer = _make_trainer({"val/mAP_50_95": 0.5}, current_epoch=0)
        cb.on_validation_end(trainer, pl_module)

        assert cb.best_score is not None
        assert cb.best_score.item() == pytest.approx(0.5)

    @pytest.mark.parametrize(
        "invalid_value, exc_type",
        [
            pytest.param(True, TypeError, id="bool-true"),
            pytest.param(2.5, TypeError, id="float"),
            pytest.param("3", TypeError, id="string"),
            pytest.param(-1, ValueError, id="negative"),
        ],
    )
    def test_skip_best_epochs_invalid_input_raises(self, invalid_value: object, exc_type: type[Exception]) -> None:
        """RFDETREarlyStopping raises TypeError for non-int and ValueError for negative skip_best_epochs."""
        with pytest.raises(exc_type):
            RFDETREarlyStopping(patience=5, skip_best_epochs=invalid_value)  # type: ignore[arg-type]

    @pytest.mark.parametrize(
        ("patience", "expect_stop"),
        [(5, False), (3, True)],
    )
    def test_stop_follows_patience_after_stagnation(self, patience: int, expect_stop: bool) -> None:
        """Three epochs without improvement stop training only once ``patience`` is exhausted."""
        cb = RFDETREarlyStopping(patience=patience, min_delta=0.001)
        pl_module = _make_pl_module()
        cb.on_validation_end(_make_trainer({"val/mAP_50_95": 0.5}), pl_module)  # baseline

        for _ in range(3):
            trainer = _make_trainer({"val/mAP_50_95": 0.5})
            cb.on_validation_end(trainer, pl_module)

        assert trainer.should_stop is expect_stop
        assert cb.wait_count == 3

    def test_counter_resets_on_improvement(self) -> None:
        """2 stagnant epochs then 1 improvement resets counter to 0."""
        cb = RFDETREarlyStopping(patience=5, min_delta=0.001)
        pl_module = _make_pl_module()

        # Set baseline
        trainer = _make_trainer({"val/mAP_50_95": 0.5})
        cb.on_validation_end(trainer, pl_module)

        # 2 stagnant
        for _ in range(2):
            trainer = _make_trainer({"val/mAP_50_95": 0.5})
            cb.on_validation_end(trainer, pl_module)
        assert cb.wait_count == 2

        # Improvement
        trainer = _make_trainer({"val/mAP_50_95": 0.6})
        cb.on_validation_end(trainer, pl_module)
        assert cb.wait_count == 0

    def test_min_delta_respected(self) -> None:
        """Improvement smaller than min_delta does not reset counter."""
        cb = RFDETREarlyStopping(patience=5, min_delta=0.01)
        pl_module = _make_pl_module()

        # Set baseline at 0.5
        trainer = _make_trainer({"val/mAP_50_95": 0.5})
        cb.on_validation_end(trainer, pl_module)

        # Improve by only half of min_delta
        trainer = _make_trainer({"val/mAP_50_95": 0.505})
        cb.on_validation_end(trainer, pl_module)
        assert cb.wait_count == 1  # not reset

    @pytest.mark.parametrize(
        ("use_ema", "metrics", "expected_best"),
        [
            pytest.param(
                True, {"val/mAP_50_95": 0.8, "val/ema_mAP_50_95": 0.3}, 0.3, id="use-ema-true-tracks-ema-only"
            ),
            pytest.param(False, {"val/mAP_50_95": 0.4, "val/ema_mAP_50_95": 0.6}, 0.6, id="use-ema-false-tracks-max"),
        ],
    )
    def test_best_score_follows_use_ema(self, use_ema: bool, metrics: dict, expected_best: float) -> None:
        """With both metrics logged, use_ema=True tracks the EMA value alone and use_ema=False tracks their max."""
        cb = RFDETREarlyStopping(patience=5, min_delta=0.001, use_ema=use_ema)

        cb.on_validation_end(_make_trainer(metrics), _make_pl_module())

        assert cb.best_score.item() == pytest.approx(expected_best)

    @pytest.mark.parametrize(
        ("metrics", "expected_best"),
        [
            pytest.param({"val/mAP_50_95": 0.45}, 0.45, id="only-regular"),
            pytest.param({"val/ema_mAP_50_95": 0.55}, 0.55, id="only-ema"),
        ],
    )
    def test_single_available_metric_is_tracked(self, metrics: dict, expected_best: float) -> None:
        """When only the regular or only the EMA monitor key is logged, that metric alone sets the baseline.

        Only-EMA is the shape ``eval_ema_only`` produces (``val/mAP_50_95`` never populated, see #1285). Unlike
        ``BestModelCallback.on_validation_end``, where that shape was an outright bug (see
        ``test_ema_checkpoint_saved_when_regular_monitor_absent``), this callback's ``regular_val is None`` branching
        already handled it; this case locks that in.
        """
        cb = RFDETREarlyStopping(patience=5, min_delta=0.001)

        cb.on_validation_end(_make_trainer(metrics), _make_pl_module())

        assert cb.best_score.item() == pytest.approx(expected_best)
        assert cb.wait_count == 0

    @pytest.mark.parametrize("hook", ["on_validation_end", "on_train_epoch_end"])
    def test_hook_without_validation_metrics_is_noop(self, hook: str) -> None:
        """With no validation metric logged, neither hook counts patience or stops training."""
        cb = RFDETREarlyStopping(patience=1, min_delta=0.001)
        trainer = _make_trainer({})

        getattr(cb, hook)(trainer, _make_pl_module())

        assert cb.wait_count == 0
        assert trainer.should_stop is False

    @pytest.mark.parametrize(
        ("use_ema", "maps", "patience", "min_delta", "expected_stop_epoch"),
        [
            pytest.param(
                False,
                [0.10, 0.20, 0.30, 0.30, 0.30, 0.30, 0.30, 0.30],
                3,
                0.01,
                5,
                id="use-ema-false-plateau",
            ),
            pytest.param(
                True,
                [0.05, 0.15, 0.25, 0.25, 0.25, 0.25, 0.25, 0.25],
                3,
                0.01,
                5,
                id="use-ema-true-plateau",
            ),
        ],
    )
    def test_trigger_epoch_matches_expected(
        self,
        use_ema: bool,
        maps: list,
        patience: int,
        min_delta: float,
        expected_stop_epoch: int,
    ) -> None:
        """RFDETREarlyStopping stops at the expected epoch for a plateau sequence.

        Drives the callback with an identical mAP sequence and asserts the trigger epoch matches the expected value.
        """
        new_cb = RFDETREarlyStopping(
            patience=patience,
            min_delta=min_delta,
            use_ema=use_ema,
            verbose=False,
        )
        pl_module = _make_pl_module()
        new_stop_epoch: int | None = None
        for epoch, m in enumerate(maps):
            metrics = {"val/mAP_50_95": m}
            if use_ema:
                metrics["val/ema_mAP_50_95"] = m
            trainer = _make_trainer(metrics, current_epoch=epoch)
            new_cb.on_validation_end(trainer, pl_module)
            if trainer.should_stop:
                new_stop_epoch = epoch
                break

        assert new_stop_epoch == expected_stop_epoch


# ---------------------------------------------------------------------------
# model_name in checkpoint payload (#887)
# ---------------------------------------------------------------------------


class TestCheckpointModelName:
    """Verify model_name is stored in checkpoint payloads."""

    @pytest.mark.parametrize(
        ("cb_kwargs", "trainer_metrics", "model_config_factory", "checkpoint_filename", "expected_model_name"),
        [
            pytest.param(
                {},
                {"val/mAP_50_95": 0.5},
                lambda: MagicMock(model_name="RFDETRLarge"),
                "checkpoint_best_regular.pth",
                "RFDETRLarge",
                id="regular-explicit-model-name",
            ),
            pytest.param(
                {},
                {"val/mAP_50_95": 0.5},
                lambda: RFDETRMediumConfig(model_name=None),
                "checkpoint_best_regular.pth",
                "RFDETRMedium",
                id="regular-infers-model-name-from-config-type",
            ),
            pytest.param(
                {"monitor_ema": "val/ema_mAP_50_95"},
                {"val/mAP_50_95": 0.4, "val/ema_mAP_50_95": 0.6},
                lambda: MagicMock(model_name="RFDETRMedium"),
                "checkpoint_best_ema.pth",
                "RFDETRMedium",
                id="ema-explicit-model-name",
            ),
        ],
    )
    def test_checkpoint_contains_model_name(
        self,
        tmp_path: Path,
        cb_kwargs: dict,
        trainer_metrics: dict,
        model_config_factory,
        checkpoint_filename: str,
        expected_model_name: str,
    ) -> None:
        """Checkpoint payload stores model_name, explicit or inferred from the model_config type.

        Covers an explicit model_name on a mocked config, inference from a real ModelConfig subclass when unset, and the
        EMA checkpoint path.
        """
        cb = BestModelCallback(output_dir=str(tmp_path), **cb_kwargs)
        trainer = _make_trainer(trainer_metrics)
        pl_module = _make_pl_module()
        pl_module.model_config = model_config_factory()

        cb.on_validation_end(trainer, pl_module)

        ckpt = torch.load(tmp_path / checkpoint_filename, weights_only=False)
        assert ckpt["model_name"] == expected_model_name

    def test_regular_checkpoint_model_name_absent_when_not_set(self, tmp_path: Path) -> None:
        """model_name key is absent when model_config has no model_name attribute."""
        cb = BestModelCallback(output_dir=str(tmp_path))
        trainer = _make_trainer({"val/mAP_50_95": 0.5})
        pl_module = _make_pl_module()

        cb.on_validation_end(trainer, pl_module)

        ckpt = torch.load(tmp_path / "checkpoint_best_regular.pth", weights_only=False)
        assert "model_name" not in ckpt

    def test_deprecated_config_raises_runtime_error(self, tmp_path: Path) -> None:
        """RFDETRLargeDeprecatedConfig raises RuntimeError — deprecated configs are unsupported."""
        cb = BestModelCallback(output_dir=str(tmp_path))
        trainer = _make_trainer({"val/mAP_50_95": 0.5})
        pl_module = _make_pl_module()
        pl_module.model_config = RFDETRLargeDeprecatedConfig(model_name=None)

        with pytest.raises(RuntimeError) as exc_info:
            cb.on_validation_end(trainer, pl_module)
        assert "Deprecated model config" in str(exc_info.value)


# ---------------------------------------------------------------------------
# rfdetr_version in checkpoint payload
# ---------------------------------------------------------------------------


class TestCheckpointRfdetrVersion:
    """Verify rfdetr_version is stored in checkpoint payloads."""

    @pytest.mark.parametrize(("cb_kwargs", "metrics", "checkpoint_filename"), _REGULAR_AND_EMA_CASES)
    def test_checkpoint_contains_rfdetr_version(
        self, mocker: MockerFixture, tmp_path: Path, cb_kwargs: dict, metrics: dict, checkpoint_filename: str
    ) -> None:
        """Regular and EMA checkpoints include the rfdetr_version string."""
        mocker.patch("rfdetr.training.callbacks.best_model.get_version", return_value="test-version")
        cb = BestModelCallback(output_dir=str(tmp_path), **cb_kwargs)

        cb.on_validation_end(_make_trainer(metrics), _make_pl_module())

        ckpt = torch.load(tmp_path / checkpoint_filename, weights_only=False)
        assert ckpt["rfdetr_version"] == "test-version"

    def test_best_total_preserves_rfdetr_version_after_strip(self, mocker: MockerFixture, tmp_path: Path) -> None:
        """strip_checkpoint must preserve rfdetr_version in the final checkpoint."""
        mocker.patch("rfdetr.training.callbacks.best_model.get_version", return_value="test-version")
        cb = BestModelCallback(output_dir=str(tmp_path), run_test=False)
        trainer = _make_trainer({"val/mAP_50_95": 0.5})
        pl_module = _make_pl_module()

        cb.on_validation_end(trainer, pl_module)
        cb.on_fit_end(trainer, pl_module)

        data = torch.load(tmp_path / "checkpoint_best_total.pth", map_location="cpu", weights_only=False)
        assert data["rfdetr_version"] == "test-version"

    def test_rfdetr_version_absent_when_get_version_returns_none(self, mocker: MockerFixture, tmp_path: Path) -> None:
        """rfdetr_version must be omitted when get_version() cannot resolve the version."""
        mocker.patch("rfdetr.training.callbacks.best_model.get_version", return_value=None)
        cb = BestModelCallback(output_dir=str(tmp_path))
        trainer = _make_trainer({"val/mAP_50_95": 0.5})
        pl_module = _make_pl_module()

        cb.on_validation_end(trainer, pl_module)

        ckpt = torch.load(tmp_path / "checkpoint_best_regular.pth", weights_only=False)
        assert "rfdetr_version" not in ckpt


# ---------------------------------------------------------------------------
# _best_ema state persistence across resume (#969)
# ---------------------------------------------------------------------------


class TestBestEmaStatePersistence:
    """Regression tests for _best_ema not surviving Lightning checkpoint resume.

    Before the fix, BestModelCallback did not override state_dict() / load_state_dict(), so _best_ema was never included
    in the Lightning callback state bundle.  On resume via trainer.fit(ckpt_path=...) the callback was reconstructed
    fresh with _best_ema=0.0, causing any positive post-resume EMA value to trivially overwrite checkpoint_best_ema.pth
    with inferior weights.

    Regression tests for GitHub issue #969.
    """

    def test_state_dict_includes_best_ema(self, tmp_path: Path) -> None:
        """state_dict() must include _best_ema so it survives Lightning checkpointing."""
        cb = BestModelCallback(output_dir=str(tmp_path), monitor_ema="val/ema_mAP_50_95")
        pl_module = _make_pl_module()

        # Drive _best_ema to 0.75 via a validation pass.
        trainer = _make_trainer({"val/mAP_50_95": 0.4, "val/ema_mAP_50_95": 0.75})
        cb.on_validation_end(trainer, pl_module)

        state = cb.state_dict()

        assert "_best_ema" in state, "_best_ema must be present in state_dict() output"
        assert state["_best_ema"] == pytest.approx(0.75)

    def test_load_state_dict_restores_best_ema(self, tmp_path: Path) -> None:
        """load_state_dict() must restore _best_ema from the persisted state."""
        # First callback: train to _best_ema=0.75.
        cb_first = BestModelCallback(output_dir=str(tmp_path), monitor_ema="val/ema_mAP_50_95")
        pl_module = _make_pl_module()
        trainer = _make_trainer({"val/mAP_50_95": 0.4, "val/ema_mAP_50_95": 0.75})
        cb_first.on_validation_end(trainer, pl_module)
        saved_state = cb_first.state_dict()

        # Second callback: simulate a fresh resume by loading the saved state.
        cb_resumed = BestModelCallback(output_dir=str(tmp_path), monitor_ema="val/ema_mAP_50_95")
        cb_resumed.load_state_dict(saved_state)

        assert cb_resumed._best_ema == pytest.approx(0.75), (
            "load_state_dict() must restore _best_ema; without fix it stays 0.0"
        )

    def test_resume_does_not_clobber_ema_checkpoint_with_inferior_weights(self, tmp_path: Path) -> None:
        """After resume, inferior post-resume EMA must not overwrite checkpoint_best_ema.pth.

        Without the fix: _best_ema resets to 0.0 on resume, so any positive EMA metric (0.5) trivially satisfies ema_val
        > _best_ema and overwrites the checkpoint saved pre-resume (0.75).
        """
        # --- Pre-resume phase: establish EMA best of 0.75 ---
        cb_pre = BestModelCallback(output_dir=str(tmp_path), monitor_ema="val/ema_mAP_50_95")
        pl_module = _make_pl_module()
        trainer_pre = _make_trainer(
            {"val/mAP_50_95": 0.4, "val/ema_mAP_50_95": 0.75},
            current_epoch=5,
        )
        cb_pre.on_validation_end(trainer_pre, pl_module)

        ema_path = tmp_path / "checkpoint_best_ema.pth"
        assert ema_path.exists()
        baseline_epoch = torch.load(ema_path, map_location="cpu", weights_only=False)["epoch"]
        saved_state = cb_pre.state_dict()

        # --- Resume phase: fresh callback loaded from saved state ---
        cb_resumed = BestModelCallback(output_dir=str(tmp_path), monitor_ema="val/ema_mAP_50_95")
        cb_resumed.load_state_dict(saved_state)

        # Post-resume validation reports EMA=0.5 — worse than pre-resume best (0.75).
        trainer_post = _make_trainer(
            {"val/mAP_50_95": 0.45, "val/ema_mAP_50_95": 0.5},
            current_epoch=7,
        )
        cb_resumed.on_validation_end(trainer_post, pl_module)

        assert torch.load(ema_path, map_location="cpu", weights_only=False)["epoch"] == baseline_epoch, (
            "checkpoint_best_ema.pth must not be overwritten by an inferior post-resume EMA value"
        )

    def test_on_fit_end_selects_ema_winner_after_resume(self, tmp_path: Path) -> None:
        """on_fit_end picks EMA winner correctly when _best_ema is properly restored.

        Without the fix: _best_ema=0.0 after resume, so regular (0.6) wins over the true EMA best (0.8) —
        checkpoint_best_total.pth is built from the wrong source.  The payload's ``best_total_source`` field records
        which source won, so EMA selection is asserted directly instead of via a saved-epoch proxy.
        """
        # Pre-resume epoch 1: regular best=0.6.
        cb_pre = BestModelCallback(output_dir=str(tmp_path), monitor_ema="val/ema_mAP_50_95", run_test=False)
        pl_module = _make_pl_module()
        trainer_ep1 = _make_trainer({"val/mAP_50_95": 0.6, "val/ema_mAP_50_95": 0.5}, current_epoch=1)
        cb_pre.on_validation_end(trainer_ep1, pl_module)

        # Pre-resume epoch 3: EMA best=0.8 (better than epoch-1 EMA=0.5).
        trainer_ep3 = _make_trainer({"val/mAP_50_95": 0.55, "val/ema_mAP_50_95": 0.8}, current_epoch=3)
        cb_pre.on_validation_end(trainer_ep3, pl_module)

        saved_state = cb_pre.state_dict()

        # Resume: fresh callback, load state, run fit_end.
        cb_resumed = BestModelCallback(output_dir=str(tmp_path), monitor_ema="val/ema_mAP_50_95", run_test=False)
        cb_resumed.load_state_dict(saved_state)

        # fit_end uses _best_ema to decide EMA vs regular winner.
        # trainer_ep3 carries best_model_score=0.6 (regular) and _best_ema=0.8 (EMA wins).
        cb_resumed.on_fit_end(trainer_ep3, pl_module)

        total = tmp_path / "checkpoint_best_total.pth"
        assert total.exists()
        total_data = torch.load(total, map_location="cpu", weights_only=False)
        # best_total_source records the winning source directly.
        # If _best_ema was NOT restored (bug), regular wins → "regular".
        # If _best_ema IS restored (fix), EMA wins → "ema".
        source = total_data["best_total_source"]
        assert source == "ema", (
            "on_fit_end must select EMA (best=0.8) over regular (best=0.6); "
            f"got best_total_source={source!r} — _best_ema not restored from state_dict"
        )

    @pytest.mark.parametrize(
        ("mutate_state", "expected_best_ema"),
        [
            pytest.param(lambda state: state.pop("_best_ema"), 0.0, id="missing-key"),
            pytest.param(lambda state: state.__setitem__("_best_ema", 1), 1.0, id="int-coercion"),
            pytest.param(lambda state: state.__setitem__("_best_ema", "0.75"), 0.75, id="string-coercion"),
        ],
    )
    def test_load_state_dict_backward_compat(self, tmp_path: Path, mutate_state, expected_best_ema: float) -> None:
        """load_state_dict() keeps backward-compatible _best_ema restoration behavior."""
        cb = BestModelCallback(output_dir=str(tmp_path), monitor_ema="val/ema_mAP_50_95")
        state = cb.state_dict()
        mutate_state(state)

        cb.load_state_dict(state)

        assert isinstance(cb._best_ema, float)
        assert cb._best_ema == expected_best_ema

    @pytest.mark.parametrize(
        "bad_value",
        [float("nan"), float("inf"), float("-inf")],
    )
    def test_load_state_dict_non_finite_values(self, bad_value) -> None:
        """load_state_dict() resets non-finite persisted _best_ema values to 0.0."""
        cb = BestModelCallback(output_dir=".")
        cb._best_ema = 999.0
        state = cb.state_dict()
        state["_best_ema"] = bad_value

        cb.load_state_dict(state)

        assert cb._best_ema == 0.0

    def test_state_dict_round_trip_preserves_all_three_smooth_fields(self, tmp_path: Path) -> None:
        """state_dict/load_state_dict round-trip preserves _best_ema, _smoothed_regular, and _best_raw_regular.

        Scenario: user trains with smooth_alpha=0.5, two validation epochs advance all three accumulators,
        then a fresh callback is restored from the persisted state — all three fields must survive unchanged.
        """
        cb = BestModelCallback(output_dir=str(tmp_path), monitor_ema="val/ema_mAP_50_95", smooth_alpha=0.5)
        pl_module = _make_pl_module()

        # Epoch 0: raw=0.6 → smoothed=0.3, EMA=0.5 (saves EMA checkpoint)
        trainer0 = _make_trainer({"val/mAP_50_95": 0.6, "val/ema_mAP_50_95": 0.5}, current_epoch=0)
        trainer0.global_step = 1
        cb.on_validation_end(trainer0, pl_module)

        # Epoch 1: raw=0.4 → smoothed=0.35, EMA=0.7 > 0.5 (saves new EMA checkpoint); raw at smoothed-best=0.4
        trainer1 = _make_trainer({"val/mAP_50_95": 0.4, "val/ema_mAP_50_95": 0.7}, current_epoch=1)
        trainer1.global_step = 2
        cb.on_validation_end(trainer1, pl_module)

        state = cb.state_dict()

        cb_resumed = BestModelCallback(output_dir=str(tmp_path), monitor_ema="val/ema_mAP_50_95", smooth_alpha=0.5)
        cb_resumed.load_state_dict(state)

        assert cb_resumed._best_ema == pytest.approx(cb._best_ema), "_best_ema must survive round-trip"
        assert cb_resumed._smoothed_regular == pytest.approx(cb._smoothed_regular), (
            "_smoothed_regular must survive round-trip"
        )
        assert cb_resumed._best_raw_regular == pytest.approx(cb._best_raw_regular), (
            "_best_raw_regular must survive round-trip"
        )

    def test_load_state_dict_does_not_mutate_caller_dict(self, tmp_path: Path) -> None:
        """load_state_dict must not pop or mutate the caller-supplied dict."""
        cb1 = BestModelCallback(output_dir=str(tmp_path), monitor_ema="val/ema_mAP_50_95")
        cb1._best_ema = 0.75
        original_sd = cb1.state_dict()
        saved = dict(original_sd)

        cb2 = BestModelCallback(output_dir=str(tmp_path), monitor_ema="val/ema_mAP_50_95")
        cb2.load_state_dict(original_sd)

        assert original_sd["_best_ema"] == 0.75
        assert original_sd == saved

    def test_state_dict_roundtrip_initial_zero(self, tmp_path: Path) -> None:
        """state_dict/load_state_dict round-trips the default _best_ema=0.0 correctly."""
        cb1 = BestModelCallback(output_dir=str(tmp_path), monitor_ema="val/ema_mAP_50_95")
        sd = cb1.state_dict()

        assert "_best_ema" in sd
        assert sd["_best_ema"] == 0.0

        cb2 = BestModelCallback(output_dir=str(tmp_path), monitor_ema="val/ema_mAP_50_95")
        cb2.load_state_dict(sd)

        assert cb2._best_ema == 0.0


# ---------------------------------------------------------------------------
# TestBestModelSmoothAlpha
# ---------------------------------------------------------------------------


class TestBestModelSmoothAlpha:
    """Verify ``smooth_alpha`` smooths the monitored metric before checkpoint comparison.

    Without smoothing, a single noisy spike (e.g. 0.9 surrounded by 0.3-0.4 values) locks the best checkpoint to that
    spike epoch.  With ``smooth_alpha=0.5`` the EMA of the metric is what the parent ModelCheckpoint compares, so the
    later, steadily-improving epochs can overtake the early spike.
    """

    @pytest.mark.parametrize(
        ("invalid_value", "exc_type"),
        [
            pytest.param(True, TypeError, id="bool-true"),
            pytest.param("0.5", TypeError, id="string"),
            pytest.param(-0.1, ValueError, id="negative"),
            pytest.param(1.0, ValueError, id="exactly-one"),
            pytest.param(1.5, ValueError, id="greater-than-one"),
            pytest.param(float("nan"), ValueError, id="nan"),
            pytest.param(float("inf"), ValueError, id="inf"),
        ],
    )
    def test_invalid_smooth_alpha_raises(
        self, tmp_path: Path, invalid_value: object, exc_type: type[Exception]
    ) -> None:
        """BestModelCallback raises TypeError for non-numeric and ValueError for out-of-range smooth_alpha."""
        with pytest.raises(exc_type):
            BestModelCallback(output_dir=str(tmp_path), smooth_alpha=invalid_value)  # type: ignore[arg-type]

    def test_smoothing_disabled_when_alpha_zero(self, tmp_path: Path) -> None:
        """With smooth_alpha=0.0 (default), the raw metric drives checkpoint selection unchanged."""
        cb = BestModelCallback(output_dir=str(tmp_path), smooth_alpha=0.0)
        pl_module = _make_pl_module()

        trainer = _make_trainer({"val/mAP_50_95": 0.42}, current_epoch=0)
        cb.on_validation_end(trainer, pl_module)

        # best_model_score reflects the raw value because no smoothing was applied.
        assert cb.best_model_score is not None
        assert cb.best_model_score.item() == pytest.approx(0.42)
        # The smoothing accumulator must stay at its zero default when smoothing is disabled.
        assert cb._smoothed_regular == 0.0

    def test_smoothing_uses_ema_of_raw_metric(self, tmp_path: Path) -> None:
        """With smooth_alpha=0.5, best_model_score reflects the smoothed EMA, not the raw value."""
        cb = BestModelCallback(output_dir=str(tmp_path), smooth_alpha=0.5)
        pl_module = _make_pl_module()

        trainer = _make_trainer({"val/mAP_50_95": 0.8}, current_epoch=0)
        cb.on_validation_end(trainer, pl_module)

        # EMA: 0.5 * 0.0 + 0.5 * 0.8 = 0.4 — the smoothed value, not the raw 0.8.
        assert cb._smoothed_regular == pytest.approx(0.4)
        assert cb.best_model_score is not None
        assert cb.best_model_score.item() == pytest.approx(0.4)

    def test_smoothing_prefers_steady_improvement_over_early_spike(self, tmp_path: Path) -> None:
        """A late, smoothed run that beats the smoothed early spike wins the best checkpoint."""
        cb = BestModelCallback(output_dir=str(tmp_path), smooth_alpha=0.5)
        pl_module = _make_pl_module()

        # Epoch 0: raw=0.8 → smoothed=0.4
        # Epoch 1: raw=0.3 → smoothed=0.35
        # Epoch 2: raw=0.4 → smoothed=0.375
        # Epoch 3: raw=0.6 → smoothed=0.4875  (overtakes the early spike's smoothed 0.4)
        raw_per_epoch = [0.8, 0.3, 0.4, 0.6]
        for epoch, value in enumerate(raw_per_epoch):
            trainer = _make_trainer({"val/mAP_50_95": value}, current_epoch=epoch)
            # Distinct global_step per epoch so ModelCheckpoint does not skip saves on
            # the second-and-later calls due to its same-step guard.
            trainer.global_step = epoch + 1
            cb.on_validation_end(trainer, pl_module)

        # The best smoothed value should be epoch-3's 0.4875, not epoch-0's 0.4.
        assert cb._smoothed_regular == pytest.approx(0.4875)
        assert cb.best_model_score is not None
        assert cb.best_model_score.item() == pytest.approx(0.4875)

    def test_callback_metrics_restored_after_super_call(self, tmp_path: Path) -> None:
        """trainer.callback_metrics[monitor] must hold the original raw tensor after on_validation_end returns."""
        cb = BestModelCallback(output_dir=str(tmp_path), smooth_alpha=0.5)
        pl_module = _make_pl_module()
        trainer = _make_trainer({"val/mAP_50_95": 0.8}, current_epoch=0)
        raw_tensor = trainer.callback_metrics["val/mAP_50_95"]

        cb.on_validation_end(trainer, pl_module)

        # The original tensor (raw value 0.8) must be back in callback_metrics so other
        # callbacks and metrics.csv see the unsmoothed value.
        assert trainer.callback_metrics["val/mAP_50_95"] is raw_tensor
        assert trainer.callback_metrics["val/mAP_50_95"].item() == pytest.approx(0.8)

    def test_state_dict_includes_smoothed_regular(self, tmp_path: Path) -> None:
        """state_dict() must include _smoothed_regular so resumed training continues from the correct EMA value."""
        cb = BestModelCallback(output_dir=str(tmp_path), smooth_alpha=0.5)
        pl_module = _make_pl_module()
        trainer = _make_trainer({"val/mAP_50_95": 0.8}, current_epoch=0)
        cb.on_validation_end(trainer, pl_module)

        state = cb.state_dict()

        assert "_smoothed_regular" in state
        assert state["_smoothed_regular"] == pytest.approx(0.4)

    def test_load_state_dict_restores_smoothed_regular(self, tmp_path: Path) -> None:
        """load_state_dict() must restore _smoothed_regular so the EMA continues from the persisted value."""
        cb_first = BestModelCallback(output_dir=str(tmp_path), smooth_alpha=0.5)
        pl_module = _make_pl_module()
        trainer = _make_trainer({"val/mAP_50_95": 0.8}, current_epoch=0)
        cb_first.on_validation_end(trainer, pl_module)
        saved_state = cb_first.state_dict()

        cb_resumed = BestModelCallback(output_dir=str(tmp_path), smooth_alpha=0.5)
        cb_resumed.load_state_dict(saved_state)

        assert cb_resumed._smoothed_regular == pytest.approx(0.4)

    @pytest.mark.parametrize(
        "bad_value",
        [float("nan"), float("inf"), float("-inf")],
    )
    def test_load_state_dict_non_finite_smoothed_regular_resets_to_zero(self, tmp_path: Path, bad_value: float) -> None:
        """load_state_dict() resets non-finite persisted _smoothed_regular values to 0.0."""
        cb = BestModelCallback(output_dir=str(tmp_path), smooth_alpha=0.5)
        state = cb.state_dict()
        state["_smoothed_regular"] = bad_value

        cb.load_state_dict(state)

        assert cb._smoothed_regular == 0.0

    def test_load_state_dict_smoothed_regular_missing_key_defaults_to_zero(self, tmp_path: Path) -> None:
        """load_state_dict() defaults _smoothed_regular to 0.0 when key is absent (backward compat)."""
        cb = BestModelCallback(output_dir=str(tmp_path), smooth_alpha=0.5)
        cb._smoothed_regular = 0.42
        state = cb.state_dict()
        state.pop("_smoothed_regular")

        cb.load_state_dict(state)

        assert cb._smoothed_regular == 0.0

    def test_ema_accumulator_warms_up_during_skip_window(self, tmp_path: Path) -> None:
        """_smoothed_regular is pre-warmed by skip-window epochs so epoch 2 starts from a non-zero EMA.

        Scenario: skip_best_epochs=2, smooth_alpha=0.5, metric=0.5 each epoch.
        The EMA accumulator must update on epochs 0 and 1 (skip window) so that by epoch 2 it
        is already non-zero.  No checkpoint file should be written during the skip window.
        """
        skip_epochs = 2
        cb = BestModelCallback(
            output_dir=str(tmp_path), monitor_regular="val/mAP_50_95", smooth_alpha=0.5, skip_best_epochs=skip_epochs
        )
        pl_module = _make_pl_module()

        # Epochs 0 and 1 are inside the skip window.
        for epoch in range(skip_epochs):
            trainer_skip = _make_trainer({"val/mAP_50_95": 0.5}, current_epoch=epoch)
            trainer_skip.global_step = epoch + 1
            cb.on_validation_end(trainer_skip, pl_module)

        # No checkpoint must have been written during the skip window.
        assert not (tmp_path / "checkpoint_best_regular.pth").exists(), (
            "checkpoint must not be written during the skip window (epochs 0 and 1)"
        )

        # Epoch 2 is the first eligible epoch — accumulator must be pre-warmed.
        trainer_eligible = _make_trainer({"val/mAP_50_95": 0.5}, current_epoch=skip_epochs)
        trainer_eligible.global_step = skip_epochs + 1
        cb.on_validation_end(trainer_eligible, pl_module)

        assert cb._smoothed_regular > 0.0, (
            "_smoothed_regular must be > 0.0 at epoch 2 because the skip-window epochs warmed the EMA"
        )

    def test_callback_metrics_restored_when_super_raises(self, mocker: MockerFixture, tmp_path: Path) -> None:
        """trainer.callback_metrics[monitor] is restored in the finally block even when super() raises."""
        mocker.patch(
            "rfdetr.training.callbacks.best_model.ModelCheckpoint.on_validation_end",
            side_effect=RuntimeError("simulated failure"),
        )
        cb = BestModelCallback(output_dir=str(tmp_path), smooth_alpha=0.5)
        pl_module = _make_pl_module()
        trainer = _make_trainer({"val/mAP_50_95": 0.8}, current_epoch=0)
        raw_tensor = trainer.callback_metrics["val/mAP_50_95"]

        with pytest.raises(RuntimeError) as exc_info:
            cb.on_validation_end(trainer, pl_module)
        assert "simulated failure" in str(exc_info.value)

        assert trainer.callback_metrics["val/mAP_50_95"] is raw_tensor


# ---------------------------------------------------------------------------
# TestCheckpointNotes
# ---------------------------------------------------------------------------


class TestCheckpointNotes:
    """Verify user-supplied notes are persisted in .pth checkpoint files."""

    @pytest.mark.parametrize(
        "notes",
        [
            "simple string",
            pytest.param({"date": "2026-01-01", "labeller": "Alice"}, id="dict"),
            pytest.param(["class_a", "class_b"], id="list"),
            42,
            pytest.param("", id="empty-string"),
            pytest.param({}, id="empty-dict"),
            pytest.param([], id="empty-list"),
            0,
            False,
        ],
    )
    def test_notes_stored_in_args_dict(self, tmp_path: Path, notes: object) -> None:
        """Notes from TrainConfig, falsy non-None values included, are stored under checkpoint['args']['notes']."""
        cb = BestModelCallback(output_dir=str(tmp_path))
        trainer = _make_trainer({"val/mAP_50_95": 0.5})

        pl_module = _make_pl_module()
        pl_module.train_config = TrainConfig(dataset_dir=str(tmp_path / "ds"), tensorboard=False, notes=notes)

        cb.on_validation_end(trainer, pl_module)

        checkpoint = torch.load(tmp_path / "checkpoint_best_regular.pth", map_location="cpu", weights_only=False)
        assert checkpoint["args"]["notes"] == notes

    def test_notes_absent_when_not_provided(self, tmp_path: Path) -> None:
        """When notes=None (default), no top-level 'notes' key is written to checkpoint."""
        cb = BestModelCallback(output_dir=str(tmp_path))
        trainer = _make_trainer({"val/mAP_50_95": 0.5})

        pl_module = _make_pl_module()
        pl_module.train_config = TrainConfig(dataset_dir=str(tmp_path / "ds"), tensorboard=False)

        cb.on_validation_end(trainer, pl_module)

        checkpoint = torch.load(tmp_path / "checkpoint_best_regular.pth", map_location="cpu", weights_only=False)
        assert "notes" not in checkpoint


# ---------------------------------------------------------------------------
# _serialize_model_config — schema sync from live weights
# ---------------------------------------------------------------------------


def _make_kp_active_mask(schema: list[int]) -> torch.Tensor:
    """Build a bool _kp_active_mask tensor from a keypoints-per-class schema list."""
    max_kp = max(schema) if schema else 0
    mask = torch.zeros(len(schema), max_kp, dtype=torch.bool)
    for cls_idx, n in enumerate(schema):
        mask[cls_idx, :n] = True
    return mask


class TestSerializeModelConfig:
    """Verify _serialize_model_config syncs schema-critical fields from live model weights."""

    @pytest.mark.parametrize(
        ("dumped_config", "weights", "field", "expected"),
        [
            pytest.param(
                {"num_keypoints_per_class": [0, 17], "num_classes": 2},
                {"_kp_active_mask": _make_kp_active_mask([0, 33])},
                "num_keypoints_per_class",
                [0, 33],
                id="keypoint-schema-from-kp-active-mask",
            ),
            pytest.param(
                {"num_keypoints_per_class": [0, 33], "num_classes": 90},
                {"class_embed.weight": torch.zeros(3, 256)},
                "num_classes",
                2,
                id="num-classes-from-class-embed-weight",
            ),
            pytest.param(
                {"num_keypoints_per_class": [0, 17], "num_classes": 2},
                {"w": torch.zeros(1)},
                "num_keypoints_per_class",
                [0, 17],
                id="keypoint-schema-kept-without-kp-active-mask",
            ),
        ],
    )
    def test_schema_field_follows_live_weights(self, dumped_config: dict, weights: dict, field: str, expected) -> None:
        """Stale schema fields in model_config are overridden by the live weights, and left alone without them."""
        pl_module = _make_pl_module()
        pl_module.model_config = MagicMock()
        pl_module.model_config.model_dump.return_value = dumped_config
        pl_module.model.state_dict.return_value = weights

        result = BestModelCallback._serialize_model_config(pl_module)

        assert result is not None
        assert result[field] == expected

    def test_no_sync_when_field_absent_from_dumped_config(self) -> None:
        """_kp_active_mask in weights does not insert num_keypoints_per_class when key absent from config."""
        pl_module = _make_pl_module()
        pl_module.model_config = MagicMock()
        pl_module.model_config.model_dump.return_value = {"num_classes": 2}
        pl_module.model.state_dict.return_value = {
            "_kp_active_mask": _make_kp_active_mask([0, 33]),
        }

        result = BestModelCallback._serialize_model_config(pl_module)

        assert result is not None
        assert "num_keypoints_per_class" not in result

    def test_returns_none_when_model_config_absent(self) -> None:
        """Returns None when pl_module exposes no model_config."""
        pl_module = _make_pl_module()
        pl_module.model_config = None

        result = BestModelCallback._serialize_model_config(pl_module)

        assert result is None

    def test_returns_dict_directly_for_dict_model_config(self) -> None:
        """Returns a dict model_config as-is without any weight-based sync."""
        pl_module = _make_pl_module()
        raw = {"num_classes": 3, "num_keypoints_per_class": [0, 5]}
        pl_module.model_config = raw

        result = BestModelCallback._serialize_model_config(pl_module)

        assert result is raw


# ---------------------------------------------------------------------------
# TestOnFitEndEMASwapSuppression
# ---------------------------------------------------------------------------


class _TestStepLinearModule(LightningModule):
    """Real module with ``test_step`` and a tiny linear model for weight-identity assertions."""

    def __init__(self) -> None:
        super().__init__()
        self.model = torch.nn.Linear(1, 1, bias=False)
        self.train_config = {"lr": 0.001}

    def test_step(self, batch: object, batch_idx: int) -> None:
        """No-op test step so BestModelCallback.on_fit_end runs trainer.test()."""


def _fill_module_weight(pl_module: LightningModule, value: float) -> None:
    """Set the single linear weight of *pl_module* to *value* in-place."""
    with torch.no_grad():
        pl_module.model.weight.fill_(value)


class TestOnFitEndEMASwapSuppression:
    """The fit-end test run must evaluate the best checkpoint, not the final EMA weights.

    Regression tests: ``BestModelCallback.on_fit_end`` loads ``checkpoint_best_total.pth`` into the module and then
    calls ``trainer.test()`` — but ``RFDETREMACallback.on_test_epoch_start`` used to swap in the final EMA weights,
    silently overwriting the just-loaded best weights for the whole test run.
    """

    @staticmethod
    def _build_fit_end_scenario(
        tmp_path: Path,
    ) -> tuple[BestModelCallback, RFDETREMACallback, LightningModule, MagicMock, list[torch.Tensor]]:
        """Arrange best=3.0 checkpoint, EMA=5.0 average model, live=7.0 weights, and a hook-simulating trainer."""
        from torch.optim.swa_utils import AveragedModel

        pl_module = _TestStepLinearModule()
        cb = BestModelCallback(output_dir=str(tmp_path), run_test=True)
        ema_cb = RFDETREMACallback()

        # Best checkpoint saved at weight 3.0.
        _fill_module_weight(pl_module, 3.0)
        trainer = _make_trainer({"val/mAP_50_95": 0.5})
        cb.on_validation_end(trainer, pl_module)

        # EMA average model captured at weight 5.0.
        _fill_module_weight(pl_module, 5.0)
        ema_cb._average_model = AveragedModel(
            model=pl_module,
            use_buffers=True,
            avg_fn=ema_cb._avg_fn,
        )
        ema_cb._average_model.eval()

        # Final live weights end training at 7.0.
        _fill_module_weight(pl_module, 7.0)

        trainer.callbacks = [ema_cb, cb]
        observed_weights: list[torch.Tensor] = []

        def _fake_test(module: object, datamodule: object = None, verbose: bool = False) -> None:
            # Simulate the PTL test loop invoking the EMA callback's test hooks.
            ema_cb.on_test_epoch_start(trainer, pl_module)
            observed_weights.append(pl_module.model.weight.detach().clone())
            ema_cb.on_test_epoch_end(trainer, pl_module)

        trainer.test = MagicMock(side_effect=_fake_test)
        return cb, ema_cb, pl_module, trainer, observed_weights

    def test_fit_end_test_runs_on_best_weights_not_ema(self, tmp_path: Path) -> None:
        """During the fit-end test run the module must hold the best checkpoint weights (3.0), not EMA (5.0)."""
        cb, _ema_cb, pl_module, trainer, observed_weights = self._build_fit_end_scenario(tmp_path)

        cb.on_fit_end(trainer, pl_module)

        assert observed_weights, "trainer.test() must have been invoked"
        expected = torch.full_like(observed_weights[0], 3.0)
        assert torch.allclose(observed_weights[0], expected), (
            f"test ran with weight {observed_weights[0].item():.1f}; expected best-checkpoint weight 3.0"
        )

    def test_ema_swap_suppression_cleared_after_fit_end(self, tmp_path: Path) -> None:
        """After on_fit_end the EMA callback must swap again for standalone trainer.test() runs."""
        cb, ema_cb, pl_module, trainer, _observed = self._build_fit_end_scenario(tmp_path)

        cb.on_fit_end(trainer, pl_module)

        assert ema_cb.suppress_test_swap is False

    def test_ema_swap_suppression_cleared_when_test_raises(self, tmp_path: Path) -> None:
        """Suppression must be lifted even when trainer.test() raises."""
        cb, ema_cb, pl_module, trainer, _observed = self._build_fit_end_scenario(tmp_path)
        trainer.test = MagicMock(side_effect=RuntimeError("boom"))

        with pytest.raises(RuntimeError) as exc_info:
            cb.on_fit_end(trainer, pl_module)
        assert "boom" in str(exc_info.value)

        assert ema_cb.suppress_test_swap is False


class _GuardedExtraStateLinear(torch.nn.Linear):
    """Represent a converted layer whose extra-state loader forbids deserialization."""

    def get_extra_state(self) -> torch.Tensor:
        """Return a serializable stand-in for FP8 scaling history.

        Examples:
            >>> _GuardedExtraStateLinear(1, 1).get_extra_state()
            tensor([1], dtype=torch.uint8)
        """
        return torch.ones(1, dtype=torch.uint8)

    def set_extra_state(self, state: object) -> None:
        """Reject loading history, as Transformer Engine does without pickle opt-in.

        Examples:
            >>> _GuardedExtraStateLinear(1, 1).set_extra_state(None)
            Traceback (most recent call last):
            ...
            RuntimeError: extra-state deserialization forbidden
        """
        raise RuntimeError("extra-state deserialization forbidden")


class TestFP8BestEMAWeightReload:
    """Exercise real checkpoint export and reload with converted-layer extra state."""

    @pytest.mark.parametrize(
        ("damage", "errors"),
        [
            pytest.param(None, None, id="intact-ema"),
            pytest.param("missing", ("Missing", "weight"), id="missing-weight"),
            pytest.param("unexpected", ("Unexpected", "spurious"), id="unexpected-key"),
            pytest.param("shape", ("size mismatch",), id="wrong-shape"),
        ],
    )
    def test_final_ema_reload(self, tmp_path: Path, damage: str | None, errors: tuple[str, ...] | None) -> None:
        """Only absent extra state is tolerated; all tensor/key corruption remains fatal."""
        module = _TestStepLinearModule()
        module.model = torch.nn.Sequential(_GuardedExtraStateLinear(1, 1, bias=False))
        with torch.no_grad():
            module.model[0].weight.fill_(3.0)
        ema = RFDETREMACallback()
        callback = BestModelCallback(output_dir=str(tmp_path), monitor_ema="val/ema_mAP_50_95", run_test=True)
        trainer = _make_trainer({"val/ema_mAP_50_95": 0.8}, callbacks=[ema, callback])
        ema.on_fit_start(trainer, module)
        callback.on_validation_end(trainer, module)
        path = tmp_path / "checkpoint_best_ema.pth"
        checkpoint = torch.load(path, weights_only=True)
        assert set(checkpoint["model"]) == {"0.weight"}
        if damage == "missing":
            del checkpoint["model"]["0.weight"]
        elif damage == "unexpected":
            checkpoint["model"]["spurious"] = torch.ones(1)
        elif damage == "shape":
            checkpoint["model"]["0.weight"] = torch.ones(2, 1)
        torch.save(checkpoint, path)
        with torch.no_grad():
            module.model[0].weight.fill_(7.0)

        if errors is not None:
            with pytest.raises(RuntimeError) as exc_info:
                callback.on_fit_end(trainer, module)
            assert all(part in str(exc_info.value) for part in errors)
            trainer.test.assert_not_called()
        else:
            callback.on_fit_end(trainer, module)
            trainer.test.assert_called_once_with(module, datamodule=trainer.datamodule, verbose=False)
            torch.testing.assert_close(module.model[0].weight, torch.full((1, 1), 3.0), rtol=1e-4, atol=1e-6)


class TestSaveFinalCheckpoint:
    """Check the final ``.pth`` the fine-tuning cookbooks write after their trainer finishes."""

    def test_saves_the_payload_built_from_the_model_and_both_configs(
        self, mocker: MockerFixture, tmp_path: Path
    ) -> None:
        """The file holds the checkpoint payload of the live weights, the training config and the model config.

        ``from_checkpoint`` rebuilds the model from this file alone, so each of the three inputs must reach the payload
        builder together with the model name.
        """
        model = torch.nn.Linear(2, 1)
        module = SimpleNamespace(model=model)
        trainer = MagicMock()
        train_config = MagicMock(model_dump=MagicMock(return_value={"epochs": 3}))
        model_config = MagicMock(model_dump=MagicMock(return_value={"resolution": 384}))
        build = mocker.patch.object(BestModelCallback, "_build_checkpoint_payload", return_value={"marker": 1})

        _save_final_checkpoint(module, trainer, train_config, model_config, tmp_path / "final.pth", "RFDETRSmall")

        args, kwargs = build.call_args
        assert args[1:] == ({"epochs": 3}, trainer)
        assert kwargs == {"model_name": "RFDETRSmall", "model_config_dict": {"resolution": 384}}
        assert torch.load(tmp_path / "final.pth") == {"marker": 1}

    def test_unwraps_a_compiled_model_before_taking_its_weights(self, mocker: MockerFixture, tmp_path: Path) -> None:
        """A ``torch.compile`` wrapper prefixes every key with ``_orig_mod.``, so the weights come from inside it."""
        raw = torch.nn.Linear(2, 1)
        module = SimpleNamespace(model=SimpleNamespace(_orig_mod=raw))
        configs = MagicMock()
        build = mocker.patch.object(BestModelCallback, "_build_checkpoint_payload", return_value={})

        _save_final_checkpoint(module, MagicMock(), configs, configs, tmp_path / "final.pth", "RFDETRSmall")

        assert list(build.call_args.args[0]) == list(raw.state_dict())

    def test_creates_the_missing_parent_directories(self, mocker: MockerFixture, tmp_path: Path) -> None:
        """The cookbooks save under a fresh output folder, so the directory is created and the path is returned."""
        module = SimpleNamespace(model=torch.nn.Linear(2, 1))
        configs = MagicMock()
        mocker.patch.object(BestModelCallback, "_build_checkpoint_payload", return_value={})
        output_path = tmp_path / "new" / "folder" / "final.pth"

        result = _save_final_checkpoint(module, MagicMock(), configs, configs, output_path, "RFDETRSmall")

        assert result == output_path
        assert output_path.exists()
