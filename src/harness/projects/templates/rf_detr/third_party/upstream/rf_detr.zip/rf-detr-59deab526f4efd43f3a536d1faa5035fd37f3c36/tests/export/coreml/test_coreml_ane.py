# ------------------------------------------------------------------------
# RF-DETR
# Copyright (c) 2025 Roboflow. All Rights Reserved.
# Licensed under the Apache License, Version 2.0 [see LICENSE for details]
# ------------------------------------------------------------------------
"""Apple Neural Engine loadability and fallback boundary of fp16 CoreML exports (``e2e_coreml``, opt-in).

Apple's ANE compiler rejects a whole fp16 program ("Invalid layer") when the two-stage ``enc_output_norm`` still
carries its identity affine *and* the encoder token count is a multiple of 32; ``src/rfdetr/models/transformer.py``
documents the mechanism at the code it constrains. Under ``ComputeUnit.ALL`` — the default in both coremltools and
Swift — Core ML then cannot build an execution plan and ``predict`` raises.

The token count is ``(resolution / patch_size) ** 2``, so RFDETRNano's resolution picks the case: 384 px reaches
576 tokens and was rejected before the fix, while 448 px reaches 784 and was always accepted. Keeping both
separates a real regression from a broken host or toolchain.

These tests report on the machine they run on. Where no Neural Engine is available (a virtualized CI runner, for
instance) Core ML never invokes its compiler, so the load test passes regardless and the compute-plan tests skip:
the plan would then describe the host, not the exported graph. The hardware-free guard for the fix itself is
``tests/models/test_transformer.py::test_two_stage_topk_gather_reads_pre_norm_memory``.
"""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Any

import numpy as np
import pytest
import torch

from rfdetr import RFDETRNano
from rfdetr.export._coreml import _IS_COREMLTOOLS_AVAILABLE
from rfdetr.utilities.reproducibility import seed_all
from tests.export.conftest import _structured_parity_input, eager_reference_tensors

# As `_COREML_EXPORT_SEED` in test_coreml_export.py: coremltools 9.0 can constant-fold a weights-only `linear` into a
# non-finite constant on some untrained draws (including the repo default seed 7), and module-scoped fixtures run
# before the autouse `reset_random_seeds`, so the draw would otherwise depend on test order.
_EXPORT_SEED = 0

_requires_coreml_runtime = pytest.mark.skipif(
    not _IS_COREMLTOOLS_AVAILABLE or sys.platform != "darwin",
    reason="needs coremltools and the macOS CoreML runtime",
)


#: The ``nano_fp16_export`` fixture value: the ``.mlpackage`` path, the example input and the eager outputs.
_Nano16Export = tuple[Path, torch.Tensor, list[torch.Tensor]]


@pytest.fixture(scope="module", params=[384, 448])
def nano_fp16_export(request: pytest.FixtureRequest, tmp_path_factory: pytest.TempPathFactory) -> _Nano16Export:
    """Export an untrained RFDETRNano at one resolution to fp16 CoreML, with its input and eager outputs.

    Examples:
        Skipped: a pytest fixture that needs coremltools, so it cannot run standalone.

        >>> mlpackage_path, example, eager_outputs = nano_fp16_export  # doctest: +SKIP
        >>> mlpackage_path.suffix, example.shape[-1], len(eager_outputs)  # doctest: +SKIP
        ('.mlpackage', 384, 2)
    """
    resolution = request.param
    seed_all(_EXPORT_SEED)
    detector = RFDETRNano(pretrain_weights=None, resolution=resolution)
    out_dir = tmp_path_factory.mktemp(f"coreml_ane_{resolution}")
    mlpackage_path = detector.export(
        output_dir=str(out_dir), format="coreml", coreml_precision="float16", verbose=False
    )
    model = detector.model.model.to("cpu").eval()
    model.export()
    example = _structured_parity_input(1, 3, resolution, resolution)
    return Path(mlpackage_path), example, eager_reference_tensors(model, example)


@_requires_coreml_runtime
@pytest.mark.integration
@pytest.mark.e2e_coreml
class TestCoreMLNeuralEngineLoad:
    """An fp16 export must stay loadable when Core ML may schedule it onto the Neural Engine."""

    def test_predicts_eager_shaped_outputs_under_all_compute_units(self, nano_fp16_export: _Nano16Export) -> None:
        """Under ``ComputeUnit.ALL`` the bundle must build an execution plan and return the eager outputs' shapes.

        Values are not compared: fp16 drift is large on raw outputs, and the parity of the exported graph itself is
        covered at FLOAT32 by ``tests/export/coreml/test_coreml_export.py::TestCoreMLEndToEnd``.
        """
        import coremltools as ct

        mlpackage_path, example, eager_outputs = nano_fp16_export
        mlmodel = ct.models.MLModel(str(mlpackage_path), compute_units=ct.ComputeUnit.ALL)
        input_name = mlmodel.get_spec().description.input[0].name

        outputs = mlmodel.predict({input_name: example.numpy().astype(np.float32)})

        # Pair by the spec's output order, as tests/export/coreml/test_coreml_export.py does: coremltools does not
        # document the predict() dict's ordering, and the outputs differ in shape.
        runtime_arrays = [np.asarray(outputs[output.name]) for output in mlmodel.get_spec().description.output]
        assert [array.shape for array in runtime_arrays] == [tuple(tensor.shape) for tensor in eager_outputs]
        assert all(np.isfinite(array).all() for array in runtime_arrays)


#: Core ML specification version of an iOS15 ``mlprogram``. iOS16 is 7, and on the Neural Engine that program loses
#: ~3 box AP at fp16 (45.06 against 48.04 for iOS15 on all 5000 COCO val2017 images, pretrained RFDETRNano, M3 Pro).
_IOS15_SPEC_VERSION = 6


@_requires_coreml_runtime
@pytest.mark.integration
@pytest.mark.e2e_coreml
class TestCoreMLSpecificationVersion:
    """The fp16 bundle must be the program generation whose Neural Engine results match eager."""

    def test_is_ios15_program(self, nano_fp16_export: _Nano16Export) -> None:
        """A newer deployment target silently moves the ANE onto the program that costs accuracy.

        ``tests/export/coreml/test_coreml_export.py::TestConvertDeploymentTarget`` pins the keyword; this pins what
        coremltools makes of it, which is also what a bare ``None`` target would resolve to for this graph.
        """
        import coremltools as ct

        mlpackage_path, _, _ = nano_fp16_export

        assert ct.utils.load_spec(str(mlpackage_path)).specificationVersion == _IOS15_SPEC_VERSION

    def test_returns_float32_outputs(self, nano_fp16_export: _Nano16Export) -> None:
        """An iOS 15 fp16 bundle returns float32 output arrays.

        An iOS 16 program returned float16 arrays, which a consumer may have read as such; the changelog documents the
        switch, and this pins the new dtype.
        """
        import coremltools as ct

        mlpackage_path, _, _ = nano_fp16_export
        outputs = ct.utils.load_spec(str(mlpackage_path)).description.output

        assert {output.type.multiArrayType.dataType for output in outputs} == {
            ct.proto.FeatureTypes_pb2.ArrayFeatureType.FLOAT32
        }

    def test_takes_float32_input(self, nano_fp16_export: _Nano16Export) -> None:
        """The image input stays float32, so callers keep feeding float32 arrays to an fp16 bundle.

        Only the weights and arithmetic are fp16; a changed input dtype would break every existing caller that feeds
        float32 images.
        """
        import coremltools as ct

        mlpackage_path, _, _ = nano_fp16_export
        inputs = ct.utils.load_spec(str(mlpackage_path)).description.input

        assert {feature.type.multiArrayType.dataType for feature in inputs} == {
            ct.proto.FeatureTypes_pb2.ArrayFeatureType.FLOAT32
        }


#: Ops RF-DETR's graph is known to leave off the Neural Engine at iOS15 (spec 6, op names carry no ``ios16.`` prefix):
#: the two-stage query selection (``topk`` plus the index expansion and gather that consume its result) and, on this
#: opset, the two ``resample`` ops with the ``cast`` ops beside them. The budget below is about catching a *new* op
#: joining them, not about their own cost.
_ANE_UNSUPPORTED_OPS = frozenset({"topk", "gather_along_axis", "tile", "expand_dims", "cast", "resample"})

#: Minimum share of estimated work Core ML must still schedule onto the ANE under ``CPU_AND_NE``. Measured at
#: 0.997 to 0.999 for fp16 RFDETRNano, RFDETRSmall, RFDETRMedium and RFDETRSegNano (pretrained, iOS15) on an Apple M3
#: Pro running macOS 27.0.1; the untrained RFDETRNano below clears the floor on the same machine.
_MIN_ANE_COST_SHARE = 0.99


def _compute_plan(mlpackage_path: Path) -> Any:
    """Load the ``CPU_AND_NE`` compute plan of *mlpackage_path*, skipping the test when this host has no ANE.

    ``MLComputePlan`` answers for the machine it runs on: where a host exposes no Neural Engine — a virtualized CI
    runner, for instance — every op is reported as CPU-preferred and ANE-unsupported, which says nothing about the
    exported graph. Skipping there keeps that from reading as a regression.

    Args:
        mlpackage_path: The ``.mlpackage`` bundle to compile and plan.

    Returns:
        The loaded ``MLComputePlan`` for ``ComputeUnit.CPU_AND_NE``.

    Examples:
        Skipped: needs coremltools, macOS>=14.4 and a real ``.mlpackage``.

        >>> plan = _compute_plan(Path("output/rfdetr-nano_fp16.mlpackage"))  # doctest: +SKIP
        >>> plan.model_structure.program.functions["main"] is not None  # doctest: +SKIP
        True
    """
    import coremltools as ct
    from coremltools.models import compute_plan

    plan = compute_plan.MLComputePlan.load_from_path(
        path=ct.utils.compile_model(str(mlpackage_path)), compute_units=ct.ComputeUnit.CPU_AND_NE
    )
    operations = plan.model_structure.program.functions["main"].block.operations
    supports_ane = any(
        "NeuralEngine" in type(device).__name__
        for operation in operations
        if (usage := plan.get_compute_device_usage_for_mlprogram_operation(operation)) is not None
        for device in usage.supported_compute_devices
    )
    if not supports_ane:
        pytest.skip("this host exposes no Neural Engine, so the plan says nothing about the exported graph")
    return plan


@_requires_coreml_runtime
@pytest.mark.integration
@pytest.mark.e2e_coreml
class TestCoreMLNeuralEngineFallbackBoundary:
    """The ANE fallback boundary documented in ``docs/exports/coreml.md`` must stay where it is."""

    def test_only_known_ops_leave_the_neural_engine(self, nano_fp16_export: _Nano16Export) -> None:
        """Only ``_ANE_UNSUPPORTED_OPS`` may leave the Neural Engine, and ``resample`` must be one of them.

        The positive half pins the mechanism of the iOS 15 choice: the deformable-attention ``resample`` has to stay
        off the Neural Engine, because at iOS 16 it runs there in fp16 and costs ~3 box AP. Like the whole class,
        this runs only on hardware that exposes a Neural Engine; ``_compute_plan`` skips elsewhere.
        """
        mlpackage_path, _, _ = nano_fp16_export
        plan = _compute_plan(mlpackage_path)
        operations = plan.model_structure.program.functions["main"].block.operations

        unsupported = {
            operation.operator_name
            for operation in operations
            if (usage := plan.get_compute_device_usage_for_mlprogram_operation(operation)) is not None
            and not any("NeuralEngine" in type(device).__name__ for device in usage.supported_compute_devices)
        }

        assert unsupported <= _ANE_UNSUPPORTED_OPS, (
            f"ops newly unsupported on the Neural Engine: {sorted(unsupported - _ANE_UNSUPPORTED_OPS)}; "
            "update docs/exports/coreml.md's fallback boundary if this is intended"
        )
        assert "resample" in unsupported, (
            "resample now runs on the Neural Engine, which is the iOS 16 behavior that loses ~3 box AP at fp16; "
            f"ops off the Neural Engine: {sorted(unsupported)}"
        )

    def test_keeps_nearly_all_estimated_work_on_neural_engine(self, nano_fp16_export: _Nano16Export) -> None:
        """Under ``CPU_AND_NE`` the ANE must still carry the overwhelming majority of the estimated work.

        This is the one check that catches a *silent* whole-model fallback: when the ANE compiler rejects a program,
        Core ML keeps reporting most ops as ANE-supported (so the sibling test above still passes) and the model loads
        fine (so the load test still passes) — it just runs every op on the CPU, which only the preferred-device split
        reveals.
        """
        mlpackage_path, _, _ = nano_fp16_export
        plan = _compute_plan(mlpackage_path)
        operations = plan.model_structure.program.functions["main"].block.operations

        ane_cost, total_cost = 0.0, 0.0
        for operation in operations:
            usage = plan.get_compute_device_usage_for_mlprogram_operation(operation)
            estimate = plan.get_estimated_cost_for_mlprogram_operation(operation)
            if usage is None or estimate is None:
                continue
            total_cost += estimate.weight
            if "NeuralEngine" in type(usage.preferred_compute_device).__name__:
                ane_cost += estimate.weight

        assert total_cost > 0.0
        assert ane_cost / total_cost >= _MIN_ANE_COST_SHARE, (
            f"only {ane_cost / total_cost:.3f} of the estimated work stays on the Neural Engine"
        )


@pytest.fixture(scope="module")
def nano_fp16_neural_engine_export(tmp_path_factory: pytest.TempPathFactory) -> Path:
    """Export an untrained RFDETRNano to fp16 CoreML with ``coreml_neural_engine=True``.

    Examples:
        Skipped: a pytest fixture that needs coremltools, so it cannot run standalone.

        >>> nano_fp16_neural_engine_export.suffix  # doctest: +SKIP
        '.mlpackage'
    """
    seed_all(_EXPORT_SEED)
    detector = RFDETRNano(pretrain_weights=None)
    out_dir = tmp_path_factory.mktemp("coreml_neural_engine")
    return Path(
        detector.export(
            output_dir=str(out_dir),
            format="coreml",
            coreml_precision="float16",
            coreml_neural_engine=True,
            verbose=False,
        )
    )


#: The two-stage query-selection ops among ``_ANE_UNSUPPORTED_OPS``: ``topk`` and the ops that consume its indices.
#: ``coreml_neural_engine=True`` exists to take exactly these off the CPU.
_QUERY_SELECTION_OPS = frozenset({"topk", "gather_along_axis", "tile", "expand_dims"})


@_requires_coreml_runtime
@pytest.mark.integration
@pytest.mark.e2e_coreml
class TestCoreMLNeuralEngineRewrites:
    """With ``coreml_neural_engine=True``, only the iOS 15 ``resample`` boundary may stay off the Neural Engine."""

    def test_only_the_resample_boundary_prefers_the_cpu(self, nano_fp16_neural_engine_export: Path) -> None:
        """The query-selection ops leave the CPU; what stays there is within the known ``resample``/``cast`` set.

        The iOS 15 program keeps ``resample`` and the ``cast`` ops beside it off the Neural Engine on purpose (see
        ``TestCoreMLNeuralEngineFallbackBoundary``), so the rewrite cannot empty the CPU set: it must move the selection
        island of the default export off the CPU and add nothing new.
        """
        plan = _compute_plan(nano_fp16_neural_engine_export)
        operations = plan.model_structure.program.functions["main"].block.operations

        off_neural_engine = {
            operation.operator_name
            for operation in operations
            if (usage := plan.get_compute_device_usage_for_mlprogram_operation(operation)) is not None
            and "NeuralEngine" not in type(usage.preferred_compute_device).__name__
        }

        assert not off_neural_engine & _QUERY_SELECTION_OPS, (
            f"query selection still prefers the CPU: {sorted(off_neural_engine & _QUERY_SELECTION_OPS)}"
        )
        assert off_neural_engine <= _ANE_UNSUPPORTED_OPS - _QUERY_SELECTION_OPS, (
            f"ops newly off the Neural Engine: {sorted(off_neural_engine - _ANE_UNSUPPORTED_OPS)}"
        )
