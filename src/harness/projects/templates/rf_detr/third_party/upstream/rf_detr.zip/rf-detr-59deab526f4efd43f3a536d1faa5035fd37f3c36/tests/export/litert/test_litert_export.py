# ------------------------------------------------------------------------
# RF-DETR
# Copyright (c) 2025 Roboflow. All Rights Reserved.
# Licensed under the Apache License, Version 2.0 [see LICENSE for details]
# ------------------------------------------------------------------------
"""Tests for direct PyTorch -> LiteRT (``.tflite``) export via ``litert-torch``.

Covers:
* ``LiteRTExporter`` — dependency-missing path (``litert_torch`` masked out of ``sys.modules``, so it runs the same
  whether or not the package is installed), naming / path-traversal sanitization, error tiers, the ``quantization``
  guard on ``build_config``, and the internal ``ModelWrapper`` (``litert_torch.convert`` stubbed via ``sys.modules``
  injection so these run without the real package installed).
* The keypoint refusal: a graph with a ``keypoints`` output never reaches the converter.
* ``format="litert"`` wiring through ``RFDETR.export()`` (heavy deps mocked, fast).
* The single-level deformable-attention core emitting no one-output ``split`` under ``torch.export`` — the only op
  litert-torch 0.9.4 could not lower on RF-DETR's export graph.
* A real end-to-end export + numerical parity check, gated behind the ``e2e_litert`` marker and
  the ``_requires_litert_torch`` skip so it only runs where the ``[litert]`` extra is installed.
"""

from __future__ import annotations

import dataclasses
import os
import sys
import types
from pathlib import Path
from typing import Any
from unittest import mock

import numpy as np
import pytest
import torch
from numpy.typing import NDArray
from pytest_mock import MockerFixture

from rfdetr.export._backend import _switch_to_export_mode
from rfdetr.export._litert.exporter import LiteRTConfig, LiteRTExporter, ModelWrapper
from rfdetr.export.imports import _IS_LITERT_TORCH_INSTALLED
from rfdetr.export.prepare import ExportGraph, prepare_export_graph
from rfdetr.models.ops.functions import ms_deform_attn_core_pytorch
from tests.export.conftest import (
    _parity_input_from_image,
    _structured_parity_input,
    eager_reference_tensors,
    max_abs_output_diffs,
)

_requires_litert_torch = pytest.mark.skipif(
    not _IS_LITERT_TORCH_INSTALLED, reason="litert_torch not installed; skip LiteRT e2e tests"
)


def _stub_litert_torch_module() -> types.ModuleType:
    """Build a minimal fake ``litert_torch`` module exposing ``convert(...).export(path)``.

    Injected into ``sys.modules`` so ``LiteRTExporter``'s ``import litert_torch`` succeeds without the real package
    installed, letting the naming/wrapping logic run end-to-end while the actual (heavy, unavailable) conversion is a
    stub.  ``convert`` runs the wrapped module once on the example input -- so ``ModelWrapper``'s own errors surface
    the way they do through the real converter -- and ``export`` writes a placeholder file at the requested path.

    Returns:
        A fresh fake module whose ``convert`` is a ``MagicMock`` returning ``fake.edge_model``, whose ``export`` is a
        ``MagicMock`` too (exposed on the module so tests can assert on the path it received).

    Examples:
        >>> import tempfile
        >>> fake = _stub_litert_torch_module()
        >>> edge = fake.convert(torch.nn.Identity(), (torch.zeros(1),))
        >>> edge is fake.edge_model
        True
        >>> with tempfile.TemporaryDirectory() as d:
        ...     edge.export(f"{d}/m.tflite")
        ...     Path(f"{d}/m.tflite").read_bytes()
        b'TFL3'
    """
    fake = types.ModuleType("litert_torch")
    edge_model = mock.MagicMock(name="edge_model")

    def _export(path: str) -> None:
        Path(path).write_bytes(b"TFL3")

    def _convert(module: torch.nn.Module, sample_args: tuple[torch.Tensor, ...]) -> mock.MagicMock:
        module(*sample_args)
        return edge_model

    edge_model.export.side_effect = _export
    fake.convert = mock.MagicMock(side_effect=_convert)
    fake.edge_model = edge_model
    return fake


def _run_litert(tflite_path: Path, input_array: NDArray[Any]) -> tuple[NDArray[Any], ...]:
    """Run *tflite_path* through the ``ai_edge_litert`` interpreter (CPU / XNNPACK) on one input.

    Args:
        tflite_path: Path to an exported ``.tflite`` file with a single input.
        input_array: C-contiguous float32 input, shaped to match the model's input tensor.

    Returns:
        One NumPy array per model output, in the interpreter's output order (the export's positional order).

    Examples:
        Requires a real exported ``.tflite`` and ``ai_edge_litert`` — not runnable standalone.
        See ``TestLiteRTEndToEnd`` for real invocations.

        >>> callable(_run_litert)
        True
    """
    from ai_edge_litert.interpreter import Interpreter

    interpreter = Interpreter(model_path=str(tflite_path))
    interpreter.allocate_tensors()
    (input_detail,) = interpreter.get_input_details()
    interpreter.set_tensor(input_detail["index"], input_array)
    interpreter.invoke()
    return tuple(np.copy(interpreter.get_tensor(detail["index"])) for detail in interpreter.get_output_details())


def _confident_query_diffs(
    eager_tensors: list[torch.Tensor],
    other_tensors: list[torch.Tensor],
    top_k: int = 10,
    sigmoid_indices: frozenset[int] = frozenset(),
) -> list[float]:
    """Max-abs-diff per output, restricted to the ``top_k`` highest-confidence queries.

    RF-DETR's two-stage query selection keeps ~300 raw encoder proposals ranked by objectness; on a real photo only a
    handful are genuine detections, and the low-confidence rest sit close enough together that ordinary cross-backend
    floating-point differences flip their relative rank and swap which query slot each lands in.  Comparing every raw
    position would swamp the signal (do the genuine detections match?) with that background reordering, so the check
    is restricted to the confident queries, which stay positionally aligned.  Same rationale as the OpenVINO suite.

    Args:
        eager_tensors: Reference tensors from :func:`eager_reference_tensors`; ``eager_tensors[1]`` must be the
            per-query class-logit tensor (``dets, labels[, ...]`` output order).
        other_tensors: Backend output tensors, same order and shapes as *eager_tensors*.
        top_k: Number of highest-confidence queries (by eager logit max) to compare.
        sigmoid_indices: Output indices to compare in sigmoid (probability) space instead of raw logit space --
            segmentation mask logits span a much wider range than boxes/labels.

    Returns:
        One max-abs-diff per output, computed over the ``top_k`` selected queries only.

    Examples:
        >>> boxes = torch.zeros(1, 3, 4)
        >>> labels = torch.tensor([[[0.1, 0.2], [5.0, 0.1], [0.0, 0.0]]])
        >>> other_boxes = boxes.clone()
        >>> other_boxes[0, 1] += 0.5  # perturb the only confident query (index 1)
        >>> diffs = _confident_query_diffs([boxes, labels], [other_boxes, labels.clone()], top_k=1)
        >>> round(diffs[0], 4)
        0.5
    """
    scores = eager_tensors[1][0].amax(dim=-1)
    top_indices = scores.topk(min(top_k, scores.numel())).indices
    diffs: list[float] = []
    for index, (eager, other) in enumerate(zip(eager_tensors, other_tensors)):
        eager_selected = eager[0, top_indices]
        other_selected = other[0, top_indices].float()
        if index in sigmoid_indices:
            eager_selected = eager_selected.sigmoid()
            other_selected = other_selected.sigmoid()
        diffs.append((eager_selected - other_selected).abs().max().item())
    return diffs


class _TwoOutputs(torch.nn.Module):
    """Stand-in for an export-mode detector: returns a ``(dets, labels)`` tuple."""

    def forward(self, x: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        return x.new_zeros(1, 300, 4), x.new_zeros(1, 300, 91)


def _export_graph(model: torch.nn.Module | None = None, *, backbone_only: bool = False) -> ExportGraph:
    """Build a throwaway ``ExportGraph`` for driving ``LiteRTExporter`` without a real RF-DETR model.

    The exporter reads only ``model``, ``input_tensors``, and ``backbone_only`` off the graph.  The stubbed
    ``litert_torch.convert`` (see ``_stub_litert_torch_module``) runs the wrapped module once, so the default model
    is ``_TwoOutputs`` — a module whose forward already returns the tuple an export-mode detector would.  The
    remaining fields carry the values ``prepare_export_graph`` would produce for a plain detector, so the graph stays
    a faithful stand-in rather than a partially-filled one.

    Args:
        model: The module the graph carries; defaults to a fresh ``_TwoOutputs``.
        backbone_only: Whether the graph stands in for a backbone-only export, which the filename marks.

    Returns:
        A graph whose model traces trivially.

    Examples:
        >>> graph = _export_graph(backbone_only=True)
        >>> graph.backbone_only, tuple(graph.input_tensors.shape)
        (True, (1, 3, 32, 32))
    """
    return ExportGraph(
        model=_TwoOutputs() if model is None else model,
        input_tensors=torch.zeros(1, 3, 32, 32),
        input_names=("input",),
        output_names=("dets", "labels"),
        dynamic_axes=None,
        shape=(32, 32),
        backbone_only=backbone_only,
    )


# ---------------------------------------------------------------------------
# LiteRTExporter — dependency-missing path (litert_torch masked out of sys.modules)
# ---------------------------------------------------------------------------


class TestExportLitertMissingDependency:
    """``LiteRTExporter``'s ``ImportError`` path, with ``litert_torch`` masked so it runs on any environment."""

    def test_raises_import_error_naming_the_extra(self, mocker: MockerFixture, tmp_path: Path) -> None:
        """Missing ``litert_torch`` surfaces an ``ImportError`` that names the ``rfdetr[litert]`` extra to install."""
        mocker.patch.dict(sys.modules, {"litert_torch": None})
        exporter = LiteRTExporter(LiteRTConfig(output_dir=tmp_path, verbose=False))

        with pytest.raises(ImportError) as exc_info:
            exporter(_export_graph())

        assert "rfdetr[litert]" in str(exc_info.value)


# ---------------------------------------------------------------------------
# ModelWrapper — output normalization contract
# ---------------------------------------------------------------------------


class TestModelWrapper:
    """``ModelWrapper`` turns the export-mode forward's tuple/list into a tuple and refuses anything else."""

    def test_tuple_output_passes_through_unchanged(self) -> None:
        """A tuple from the export-mode forward is returned as is."""
        dets, labels = torch.zeros(1, 300, 4), torch.zeros(1, 300, 91)
        model = mock.MagicMock(spec=torch.nn.Module, return_value=(dets, labels))
        assert ModelWrapper(model)(torch.zeros(1, 3, 32, 32)) == (dets, labels)

    def test_list_output_converted_to_tuple(self) -> None:
        """The backbone-only export graph returns a list; the wrapper hands the converter a tuple."""
        features = torch.zeros(1, 256, 24, 24)
        model = mock.MagicMock(spec=torch.nn.Module, return_value=[features])
        output = ModelWrapper(model)(torch.zeros(1, 3, 32, 32))
        assert isinstance(output, tuple)
        assert output == (features,)

    def test_dict_output_raises_not_implemented(self) -> None:
        """A dict output means the caller skipped ``model.export()``; that is reported, not flattened."""
        model = mock.MagicMock(spec=torch.nn.Module, return_value={"pred_boxes": torch.zeros(1, 300, 4)})
        with pytest.raises(NotImplementedError, match="export mode"):
            ModelWrapper(model)(torch.zeros(1, 3, 32, 32))

    def test_unsupported_output_type_raises_type_error(self) -> None:
        """A bare tensor output is neither tuple, list nor dict, so the wrapper refuses it."""
        model = mock.MagicMock(spec=torch.nn.Module, return_value=torch.zeros(1, 300, 4))
        with pytest.raises(TypeError, match="Unsupported model output type"):
            ModelWrapper(model)(torch.zeros(1, 3, 32, 32))


# ---------------------------------------------------------------------------
# LiteRTExporter — configuration, naming and error tiers (litert_torch stubbed)
# ---------------------------------------------------------------------------


class TestLiteRTBuildConfig:
    """``LiteRTExporter.build_config`` validates ``quantization`` instead of storing it."""

    @pytest.mark.parametrize("quantization", [None, "fp32"])
    def test_fp32_quantization_values_are_accepted(self, quantization: str | None) -> None:
        """``None`` and ``"fp32"`` build a ``LiteRTConfig`` without complaint."""
        config = LiteRTExporter.build_config(output_dir=Path("out"), quantization=quantization)
        assert isinstance(config, LiteRTConfig)

    @pytest.mark.parametrize("quantization", ["fp16", "int8"])
    def test_other_quantization_is_refused(self, quantization: str) -> None:
        """A ``.tflite`` caller may expect ``quantization`` to apply; refusing beats silently writing float32."""
        with pytest.raises(NotImplementedError, match="quantization"):
            LiteRTExporter.build_config(output_dir=Path("out"), quantization=quantization)

    def test_settings_belonging_to_other_formats_are_dropped(self) -> None:
        """Keywords other formats read (``opset_version``, ``fp16``, ...) must not reach this configuration."""
        config = LiteRTExporter.build_config(output_dir=Path("out"), opset_version=18, fp16=False)
        assert not hasattr(config, "opset_version")


class TestExportLitertNaming:
    """Filename resolution mirrors the ONNX/CoreML/ExecuTorch/OpenVINO exporters' stem and ``-backbone`` rules."""

    @pytest.mark.parametrize(
        ("variant_name", "output_name", "backbone_only", "expected"),
        [
            pytest.param("rfdetr-nano", None, False, "rfdetr-nano.tflite", id="variant"),
            pytest.param(None, "my-model", False, "my-model.tflite", id="output-name-wins"),
            pytest.param("rfdetr-nano", "my-model", False, "my-model.tflite", id="output-name-over-variant"),
            pytest.param(None, None, False, "inference_model.tflite", id="default"),
            pytest.param("rfdetr-nano", None, True, "rfdetr-nano-backbone.tflite", id="variant-backbone"),
            pytest.param(None, "custom", True, "custom-backbone.tflite", id="output-name-backbone"),
            pytest.param(None, None, True, "backbone_model.tflite", id="default-backbone-no-marker"),
        ],
    )
    def test_resolves_expected_filename(
        self,
        mocker: MockerFixture,
        tmp_path: Path,
        variant_name: str | None,
        output_name: str | None,
        backbone_only: bool,
        expected: str,
    ) -> None:
        """The artifact stem follows output_name > variant_name > default, with ``-backbone`` for backbone exports."""
        fake = _stub_litert_torch_module()
        mocker.patch.dict(sys.modules, {"litert_torch": fake})
        exporter = LiteRTExporter(
            LiteRTConfig(output_dir=tmp_path, variant_name=variant_name, output_name=output_name, verbose=False)
        )

        result = exporter(_export_graph(backbone_only=backbone_only))

        assert result == tmp_path / expected
        assert result.read_bytes() == b"TFL3"
        fake.convert.assert_called_once()
        assert isinstance(fake.convert.call_args.args[0], ModelWrapper)
        fake.edge_model.export.assert_called_once_with(str(tmp_path / expected))

    def test_sanitizes_variant_name_directory_components(self, mocker: MockerFixture, tmp_path: Path) -> None:
        """A variant name carrying path separators/extensions must not escape *output_dir*."""
        mocker.patch.dict(sys.modules, {"litert_torch": _stub_litert_torch_module()})
        exporter = LiteRTExporter(
            LiteRTConfig(output_dir=tmp_path, variant_name="../evil/rfdetr-nano.onnx", verbose=False)
        )

        result = exporter(_export_graph())

        assert result == tmp_path / "rfdetr-nano.tflite"
        assert result.exists()

    def test_creates_missing_output_dir(self, mocker: MockerFixture, tmp_path: Path) -> None:
        """A nested output directory that does not exist yet is created for the artifact."""
        mocker.patch.dict(sys.modules, {"litert_torch": _stub_litert_torch_module()})
        exporter = LiteRTExporter(LiteRTConfig(output_dir=tmp_path / "nested" / "out", verbose=False))

        result = exporter(_export_graph())

        assert result == tmp_path / "nested" / "out" / "inference_model.tflite"


class TestExportLitertErrorTiers:
    """Converter failures become ``RuntimeError``; ``ModelWrapper``'s own contract errors pass through unchanged."""

    def test_converter_failure_is_wrapped_as_runtime_error(self, mocker: MockerFixture, tmp_path: Path) -> None:
        """A failure inside ``litert_torch.convert`` is reported as a ``RuntimeError`` naming the LiteRT export."""
        fake = _stub_litert_torch_module()
        fake.convert.side_effect = ValueError("Failed to run converter passes")
        mocker.patch.dict(sys.modules, {"litert_torch": fake})
        exporter = LiteRTExporter(LiteRTConfig(output_dir=tmp_path, verbose=False))

        with pytest.raises(RuntimeError, match="Failed to export model to LiteRT"):
            exporter(_export_graph())

    def test_dict_output_not_relabeled_as_runtime_error(self, mocker: MockerFixture, tmp_path: Path) -> None:
        """The wrapper's ``NotImplementedError`` (model not in export mode) must reach the caller as-is."""
        dict_model = mock.MagicMock(spec=torch.nn.Module, return_value={"pred_boxes": torch.zeros(1, 300, 4)})
        dict_model.eval.return_value = dict_model
        dict_model.cpu.return_value = dict_model
        mocker.patch.dict(sys.modules, {"litert_torch": _stub_litert_torch_module()})
        exporter = LiteRTExporter(LiteRTConfig(output_dir=tmp_path, verbose=False))

        with pytest.raises(NotImplementedError, match="export mode"):
            exporter(_export_graph(dict_model))


class TestLiteRTKeypointRefusal:
    """A graph with a ``keypoints`` output is refused before conversion: litert-torch cannot lower the keypoint head."""

    def test_keypoint_graph_is_refused_before_the_conversion_starts(
        self, mocker: MockerFixture, tmp_path: Path
    ) -> None:
        """The refusal comes before the converter is set up, let alone run: litert-torch cannot convert the graph."""
        graph = dataclasses.replace(_export_graph(), output_names=("dets", "labels", "keypoints"))
        exporter = LiteRTExporter(LiteRTConfig(output_dir=tmp_path, verbose=False))
        mocker.patch.object(LiteRTExporter, "check_dependencies")
        import_converter = mocker.patch.object(LiteRTExporter, "_import_converter")

        with pytest.raises(NotImplementedError, match="keypoint"):
            exporter(graph)

        import_converter.assert_not_called()

    def test_graph_without_keypoints_output_is_converted(self, mocker: MockerFixture, tmp_path: Path) -> None:
        """A backbone-only export of a keypoint model names its outputs ``features*``, and still converts."""
        fake = _stub_litert_torch_module()
        mocker.patch.dict(sys.modules, {"litert_torch": fake})
        graph = dataclasses.replace(_export_graph(backbone_only=True), output_names=("features",))

        LiteRTExporter(LiteRTConfig(output_dir=tmp_path, verbose=False))(graph)

        fake.convert.assert_called_once()

    def test_keypoint_model_is_refused_through_the_public_export(self, mocker: MockerFixture, tmp_path: Path) -> None:
        """``RFDETR.export`` names the keypoint output from the model's config, which is what the refusal keys on."""
        mocker.patch("rfdetr.export.prepare.make_infer_image", return_value=torch.zeros(1, 3, 560, 560))
        mocker.patch.object(LiteRTExporter, "check_dependencies")
        mocker.patch.dict(sys.modules, {"litert_torch": None})

        with pytest.raises(NotImplementedError, match="keypoint"):
            _make_rfdetr(use_grouppose_keypoints=True).export(format="litert", output_dir=str(tmp_path / "out"))


# ---------------------------------------------------------------------------
# format="litert" wiring through RFDETR.export() (heavy deps mocked)
# ---------------------------------------------------------------------------


def _make_rfdetr(*, segmentation_head: bool = False, use_grouppose_keypoints: bool = False) -> Any:
    """Create a minimal ``RFDETR`` instance with mocked internals (mirrors the CoreML/ExecuTorch/OpenVINO suites).

    Examples:
        >>> obj = _make_rfdetr(use_grouppose_keypoints=True)
        >>> obj.size, obj.model.resolution, obj.model_config.use_grouppose_keypoints
        ('rfdetr-nano', 560, True)
    """
    from rfdetr.detr import RFDETR

    obj = RFDETR.__new__(RFDETR)
    obj.model = mock.MagicMock()
    obj.model.resolution = 560
    obj.model.device = "cpu"
    obj.model.model.to.return_value = obj.model.model
    obj.model.args = None
    obj.model.class_names = ["object"]
    obj.model.postprocess.num_select = 100
    obj.model.postprocess.trace_alpha = 0.2
    obj.model.postprocess.upsample_masks_to_image_size = True
    obj.means = [0.485, 0.456, 0.406]
    obj.stds = [0.229, 0.224, 0.225]
    obj.model_config = mock.MagicMock()
    obj.model_config.segmentation_head = segmentation_head
    obj.model_config.use_grouppose_keypoints = use_grouppose_keypoints
    obj.model_config.patch_size = 14
    obj.model_config.num_windows = 1
    obj.model_config.num_channels = 3
    obj.model_config.num_classes = 1
    obj.model_config.num_keypoints_per_class = [3] if use_grouppose_keypoints else []
    obj.size = "rfdetr-nano"
    return obj


class TestExportFormatParameter:
    """Tests for ``format="litert"`` wiring through ``RFDETR.export()``."""

    @pytest.fixture(autouse=True)
    def _patch_export_deps(self, mocker: MockerFixture, tmp_path: Path) -> None:
        """Mock heavy export deps so ``RFDETR.export()`` reaches the format dispatch without real work."""
        self._tmp_path = tmp_path
        tflite_out = tmp_path / "rfdetr-nano.tflite"
        tflite_out.write_bytes(b"TFL3")
        mocker.patch("rfdetr.export.base.write_metadata")

        self._mock_make_infer_image = mocker.patch("rfdetr.export.prepare.make_infer_image")
        self._mock_make_infer_image.return_value = torch.zeros(1, 3, 560, 560)
        self._mock_export_onnx = mocker.patch("rfdetr.export._onnx.exporter.OnnxExporter._convert")
        self._mock_export_onnx.return_value = str(tmp_path / "inference_model.onnx")
        # autospec so the patched method records the bound exporter; forwarding tests read `config` off it.
        self._mock_litert_convert = mocker.patch(
            "rfdetr.export._litert.exporter.LiteRTExporter._convert", autospec=True, return_value=tflite_out
        )
        # The CPU job has no litert-torch, which RFDETR.export() checks for before the forward pass.
        mocker.patch("rfdetr.export._litert.exporter.LiteRTExporter.check_dependencies")

    @pytest.mark.parametrize("segmentation_head", [False, True])
    def test_litert_format_dispatches_to_litert_exporter_not_onnx(self, segmentation_head: bool) -> None:
        """``format="litert"`` must dispatch to ``LiteRTExporter`` (no ONNX step)."""
        obj = _make_rfdetr(segmentation_head=segmentation_head)
        output_path = obj.export(format="litert", output_dir=str(self._tmp_path / "out"))
        self._mock_litert_convert.assert_called_once()
        self._mock_export_onnx.assert_not_called()
        assert output_path.suffix == ".tflite"

    def test_onnx_format_does_not_call_litert_exporter(self) -> None:
        """``format="onnx"`` never reaches the LiteRT converter."""
        obj = _make_rfdetr()
        obj.export(format="onnx", output_dir=str(self._tmp_path / "out"))
        self._mock_litert_convert.assert_not_called()

    def test_variant_name_forwarded_to_exporter(self) -> None:
        """The model's size is forwarded as the exporter's ``variant_name``."""
        obj = _make_rfdetr()
        obj.export(format="litert", output_dir=str(self._tmp_path / "out"))
        exporter = self._mock_litert_convert.call_args.args[0]
        assert exporter.config.variant_name == "rfdetr-nano"

    def test_output_name_forwarded_to_exporter(self) -> None:
        """An explicit ``output_name`` reaches the exporter's config."""
        obj = _make_rfdetr()
        obj.export(format="litert", output_dir=str(self._tmp_path / "out"), output_name="my-model")
        exporter = self._mock_litert_convert.call_args.args[0]
        assert exporter.config.output_name == "my-model"

    @pytest.mark.parametrize("quantization", [None, "fp32"])
    def test_fp32_quantization_values_are_accepted(self, quantization: str | None) -> None:
        """``None`` and ``"fp32"`` pass the public export and reach the LiteRT converter once."""
        obj = _make_rfdetr()
        obj.export(format="litert", output_dir=str(self._tmp_path / "out"), quantization=quantization)
        self._mock_litert_convert.assert_called_once()

    @pytest.mark.parametrize("quantization", ["fp16", "int8"])
    def test_other_quantization_raises_before_forward_pass(self, quantization: str) -> None:
        """A ``.tflite`` caller may expect ``quantization`` to apply; refusing beats silently writing float32."""
        obj = _make_rfdetr()
        with pytest.raises(NotImplementedError, match="quantization"):
            obj.export(format="litert", output_dir=str(self._tmp_path / "out"), quantization=quantization)
        self._mock_make_infer_image.assert_not_called()
        self._mock_litert_convert.assert_not_called()

    def test_dynamic_batch_raises_before_forward_pass(self) -> None:
        """``dynamic_batch=True`` is refused from the registry's own data, before the forward pass."""
        obj = _make_rfdetr()
        with pytest.raises(NotImplementedError, match="dynamic_batch"):
            obj.export(format="litert", output_dir=str(self._tmp_path / "out"), dynamic_batch=True)
        self._mock_make_infer_image.assert_not_called()

    def test_notes_warns_and_is_dropped(self) -> None:
        """``notes`` has no slot in a ``.tflite`` file, so it warns instead of being silently ignored."""
        obj = _make_rfdetr()
        with pytest.warns(UserWarning, match="notes"):
            obj.export(format="litert", output_dir=str(self._tmp_path / "out"), notes="some metadata")

    def test_experimental_warning_is_emitted(self) -> None:
        """Every LiteRT export warns that the format is experimental."""
        obj = _make_rfdetr()
        with pytest.warns(UserWarning, match="LiteRT export is experimental"):
            obj.export(format="litert", output_dir=str(self._tmp_path / "out"))


class TestExportLitertMissingDependencyViaPublicAPI:
    """``RFDETR.export(format="litert")`` surfaces ``ImportError`` (not the registry ``ValueError``)."""

    def test_raises_import_error_not_registry_value_error(self, mocker: MockerFixture, tmp_path: Path) -> None:
        """The format must be accepted by the registry and fail only on the missing dependency."""
        mocker.patch("rfdetr.export.prepare.make_infer_image", return_value=torch.zeros(1, 3, 560, 560))
        mocker.patch.dict(sys.modules, {"litert_torch": None})
        obj = _make_rfdetr()

        with pytest.raises(ImportError) as exc_info:
            obj.export(format="litert", output_dir=str(tmp_path / "out"))

        assert "rfdetr[litert]" in str(exc_info.value)


# ---------------------------------------------------------------------------
# Deformable-attention core: no one-output split in the exported graph
# ---------------------------------------------------------------------------


class _SingleLevelCore(torch.nn.Module):
    """Call the deformable-attention core with Python ``(H, W)`` pairs, as the export path does."""

    def __init__(self, shapes_hw: list[tuple[int, int]]) -> None:
        super().__init__()
        self.shapes_hw = shapes_hw

    def forward(self, value: torch.Tensor, locations: torch.Tensor, weights: torch.Tensor) -> torch.Tensor:
        spatial_shapes = torch.tensor(self.shapes_hw, dtype=torch.long)
        return ms_deform_attn_core_pytorch(
            value, spatial_shapes, locations, weights, value_spatial_shapes_hw=self.shapes_hw
        )


class TestDeformableCoreSplit:
    """The single-level core emits no ``split`` op, the one node litert-torch 0.9.4 cannot lower for RF-DETR."""

    @staticmethod
    def _core_inputs(shapes_hw: list[tuple[int, int]]) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """Build ``(value, sampling_locations, attention_weights)`` for the rank-5 (export) core layout.

        Examples:
            >>> value, locations, weights = TestDeformableCoreSplit._core_inputs([(4, 4)])
            >>> tuple(value.shape), tuple(locations.shape), tuple(weights.shape)
            ((1, 2, 8, 16), (1, 3, 2, 4, 2), (1, 3, 2, 4))
        """
        torch.manual_seed(0)
        batch, heads, head_dim, len_q, points = 1, 2, 8, 3, 4
        total = sum(h * w for h, w in shapes_hw)
        value = torch.randn(batch, heads, head_dim, total)
        locations = torch.rand(batch, len_q, heads, len(shapes_hw) * points, 2)
        weights = torch.softmax(torch.randn(batch, len_q, heads, len(shapes_hw) * points), -1)
        return value, locations, weights

    @pytest.mark.parametrize(
        ("shapes_hw", "expects_split"),
        [
            pytest.param([(4, 4)], False, id="single-level-no-split"),
            pytest.param([(4, 4), (2, 2)], True, id="two-levels-still-split"),
        ],
    )
    def test_split_present_only_for_multiple_levels(
        self, shapes_hw: list[tuple[int, int]], expects_split: bool
    ) -> None:
        """The exported graph contains a ``split`` op only when the core spans more than one level."""
        inputs = self._core_inputs(shapes_hw)
        program = torch.export.export(_SingleLevelCore(shapes_hw), inputs, strict=False)
        targets = {str(node.target) for node in program.graph.nodes if node.op == "call_function"}
        has_split = any("split" in target for target in targets)
        assert has_split is expects_split, sorted(targets)

    def test_single_level_output_unchanged(self) -> None:
        """Skipping the split must not change the numbers: single-level equals the two-level formula on one piece."""
        shapes_hw = [(4, 4)]
        value, locations, weights = self._core_inputs(shapes_hw)
        spatial_shapes = torch.tensor(shapes_hw, dtype=torch.long)
        with_hw = ms_deform_attn_core_pytorch(
            value, spatial_shapes, locations, weights, value_spatial_shapes_hw=shapes_hw
        )
        eager = ms_deform_attn_core_pytorch(value, spatial_shapes, locations, weights)
        torch.testing.assert_close(with_hw, eager)


# ---------------------------------------------------------------------------
# End-to-end (gated) — real litert-torch convert + parity vs eager PyTorch
# ---------------------------------------------------------------------------


@pytest.fixture(scope="module")
def people_walking_image_path(tmp_path_factory: pytest.TempPathFactory) -> Path:
    """Download supervision's ``PEOPLE_WALKING`` asset once, shared across LiteRT e2e tests.

    A real photo gives genuine, well-separated detections whose query positions stay stable across backends; the
    structured synthetic input would leave every two-stage candidate at a similar low objectness and let float noise
    reorder them (see ``_confident_query_diffs``).
    """
    asset_dir = tmp_path_factory.mktemp("litert_assets")
    cwd = Path.cwd()
    os.chdir(asset_dir)
    try:
        from supervision.assets import ImageAssets, download_assets

        return Path(download_assets(ImageAssets.PEOPLE_WALKING)).resolve()
    finally:
        os.chdir(cwd)


@pytest.fixture(scope="module")
def litert_detection_export(
    tmp_path_factory: pytest.TempPathFactory, people_walking_image_path: Path
) -> tuple[Any, torch.Tensor, Path]:
    """Export RFDETRNano to LiteRT once, shared across the gated detection e2e tests."""
    import rfdetr

    out_dir = tmp_path_factory.mktemp("litert_nano")
    detector = rfdetr.RFDETRNano()
    tflite_path = detector.export(output_dir=str(out_dir), format="litert", verbose=False)

    model = detector.model.model.to("cpu").eval()
    model.export()
    resolution = int(detector.model.resolution)
    example = _parity_input_from_image(people_walking_image_path, resolution)
    return model, example, Path(tflite_path)


@pytest.fixture(scope="module")
def litert_segmentation_export(
    tmp_path_factory: pytest.TempPathFactory, people_walking_image_path: Path
) -> tuple[Any, torch.Tensor, Path]:
    """Export RFDETRSegNano to LiteRT once, shared across the gated segmentation e2e test."""
    import rfdetr

    out_dir = tmp_path_factory.mktemp("litert_seg_nano")
    detector = rfdetr.RFDETRSegNano()
    tflite_path = detector.export(output_dir=str(out_dir), format="litert", verbose=False)

    model = detector.model.model.to("cpu").eval()
    model.export()
    resolution = int(detector.model.resolution)
    example = _parity_input_from_image(people_walking_image_path, resolution)
    return model, example, Path(tflite_path)


@pytest.fixture(scope="module")
def litert_backbone_export(tmp_path_factory: pytest.TempPathFactory) -> tuple[torch.nn.Module, torch.Tensor, Path]:
    """Export RFDETRNano's backbone-only LiteRT graph once, shared across the gated backbone e2e test."""
    import rfdetr
    from rfdetr.export._backend import _BackboneExport

    out_dir = tmp_path_factory.mktemp("litert_backbone")
    detector = rfdetr.RFDETRNano(pretrain_weights=None)
    tflite_path = detector.export(output_dir=str(out_dir), format="litert", backbone_only=True, verbose=False)
    backbone = detector.model.model.backbone[0].to("cpu").eval()
    reference_model = _BackboneExport(backbone)
    resolution = int(detector.model.resolution)
    example = _structured_parity_input(1, 3, resolution, resolution)
    return reference_model, example, Path(tflite_path)


@_requires_litert_torch
@pytest.mark.integration
@pytest.mark.e2e_litert
class TestLiteRTEndToEnd:
    """Real litert-torch export + CPU (XNNPACK) numerical parity (``-m e2e_litert``, requires ``[litert]``)."""

    def test_tflite_written_with_variant_name(self, litert_detection_export: tuple[Any, torch.Tensor, Path]) -> None:
        """The detection export writes a TFLite flatbuffer named after the model variant."""
        _, _, tflite_path = litert_detection_export
        assert tflite_path.exists()
        assert tflite_path.name == "rfdetr-nano.tflite"
        assert tflite_path.read_bytes()[4:8] == b"TFL3"

    def test_detection_outputs_match_pytorch(self, litert_detection_export: tuple[Any, torch.Tensor, Path]) -> None:
        """LiteRT detection output (boxes, logits) must match eager PyTorch on confident detections.

        Compared over the top-10 highest-confidence queries (see ``_confident_query_diffs``).  Measured maxima on this
        fixture (pretrained RFDETRNano, default checkpoint, ``PEOPLE_WALKING`` photo at 384): box ~7.5e-8, logits
        ~2.0e-5 over the top-10 queries; ~6e-6 / ~4e-4 over all 300.  The tolerances are regression bounds with generous
        headroom, not the measured precision.
        """
        model, example, tflite_path = litert_detection_export
        eager_tensors = eager_reference_tensors(model, example)
        litert_tensors = [torch.from_numpy(output) for output in _run_litert(tflite_path, example.numpy())]

        assert len(litert_tensors) == 2, f"detection export must yield (boxes, logits), got {len(litert_tensors)}"
        box_diff, label_diff = _confident_query_diffs(eager_tensors, litert_tensors)
        assert box_diff < 1e-3, f"LiteRT detection boxes diverge from PyTorch: max abs diff {box_diff}"
        assert label_diff < 0.1, f"LiteRT detection logits diverge from PyTorch: max abs diff {label_diff}"

    def test_segmentation_outputs_match_pytorch(
        self, litert_segmentation_export: tuple[Any, torch.Tensor, Path]
    ) -> None:
        """LiteRT segmentation output (boxes, logits, masks) must match eager PyTorch on confident detections.

        Masks are compared in sigmoid space (mask logits span a far wider range than boxes/labels).  Measured maxima on
        this fixture (pretrained RFDETRSegNano, default checkpoint, ``PEOPLE_WALKING`` photo at 312): box ~6.0e-8,
        logits ~2.7e-5, mask (sigmoid) ~7.1e-6 over the top-10 queries; ~1.5e-6 / ~5.6e-5 / ~1.9e-3 (raw mask logits,
        ~2.6e-5 in sigmoid space) over all 300.
        """
        model, example, tflite_path = litert_segmentation_export
        eager_tensors = eager_reference_tensors(model, example)
        litert_tensors = [torch.from_numpy(output) for output in _run_litert(tflite_path, example.numpy())]

        assert len(litert_tensors) == 3, (
            f"segmentation export must yield (boxes, logits, masks), got {len(litert_tensors)}"
        )
        box_diff, label_diff, mask_diff = _confident_query_diffs(eager_tensors, litert_tensors, sigmoid_indices={2})
        assert box_diff < 1e-3, f"LiteRT segmentation boxes diverge from PyTorch: max abs diff {box_diff}"
        assert label_diff < 0.1, f"LiteRT segmentation logits diverge from PyTorch: max abs diff {label_diff}"
        assert mask_diff < 0.05, f"LiteRT segmentation masks diverge from PyTorch (sigmoid space): {mask_diff}"

    def test_backbone_outputs_match_pytorch(
        self, litert_backbone_export: tuple[torch.nn.Module, torch.Tensor, Path]
    ) -> None:
        """The backbone-only export has no two-stage selection, so a plain positional comparison applies.

        Measured maximum on this fixture (random-init RFDETRNano backbone via ``pretrain_weights=None``, structured
        synthetic input at 384): ~2.3e-5.
        """
        model, example, tflite_path = litert_backbone_export
        assert tflite_path.name == "rfdetr-nano-backbone.tflite"
        eager_tensors = eager_reference_tensors(model, example)
        litert_tensors = [torch.from_numpy(output) for output in _run_litert(tflite_path, example.numpy())]

        diffs = max_abs_output_diffs(eager_tensors, litert_tensors, check_shape=True)
        assert max(diffs) < 1e-3, f"LiteRT backbone outputs diverge from PyTorch: max abs diff {max(diffs)}"

    def test_keypoint_head_is_still_rejected_by_the_converter(self, tmp_path: Path) -> None:
        """Pins the documented limitation: litert-torch 0.9.4 rejects the keypoint head's rank-4 ``batch_matmul``.

        ``LiteRTExporter._convert`` refuses a keypoint graph before converting it, so this drives the exporter's own
        capture step on the prepared keypoint graph directly. When a litert-torch release lowers the head, this test
        fails. That is the cue to lift the refusal, drop the keypoint caveat from the ``format="litert"`` docs, and add
        a keypoint parity test next to the detection one.
        """
        import litert_torch

        import rfdetr

        detector = rfdetr.RFDETRKeypointPreview(pretrain_weights=None)
        resolution = int(detector.model.resolution)
        graph = prepare_export_graph(
            detector.model.model.to("cpu"),
            detector.model_config,
            shape=(resolution, resolution),
            device=torch.device("cpu"),
        )
        _switch_to_export_mode(graph.model)
        exporter = LiteRTExporter(LiteRTConfig(output_dir=tmp_path, verbose=False))
        wrapped_model, input_tensors = exporter._prepare_module_for_tracing(graph)
        with pytest.raises(RuntimeError, match=r"Failed to export model to LiteRT: .*'tfl\.batch_matmul'"):
            exporter._convert_and_save(litert_torch, wrapped_model, input_tensors, tmp_path / "keypoint.tflite")
