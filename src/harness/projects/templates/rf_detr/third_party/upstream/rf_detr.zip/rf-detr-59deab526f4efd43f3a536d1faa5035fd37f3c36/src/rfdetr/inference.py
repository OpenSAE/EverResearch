# ------------------------------------------------------------------------
# RF-DETR
# Copyright (c) 2025 Roboflow. All Rights Reserved.
# Licensed under the Apache License, Version 2.0 [see LICENSE for details]
# ------------------------------------------------------------------------
"""Public inference facade and model-context builder for RF-DETR."""

from __future__ import annotations

__all__ = ["ModelContext", "RFDETRInference"]

import os
from collections.abc import Callable, Generator, Mapping
from pathlib import Path
from typing import TYPE_CHECKING, Any, cast

import torch

from rfdetr._prediction.core import PredictionContext, predict
from rfdetr._prediction.types import _PredictionInput, _ThresholdInput
from rfdetr.config import TrainConfig
from rfdetr.models import PostProcess, build_model
from rfdetr.models.backbone.backbone import Backbone
from rfdetr.models.backbone.dinov2 import DinoV2
from rfdetr.models.lwdetr import LWDETR
from rfdetr.models.weights import apply_lora, load_pretrain_weights

if TYPE_CHECKING:
    from rfdetr._prediction.types import _PredictionOutput, _PredictionResult
    from rfdetr.config import ModelConfig
    from rfdetr.detr import RFDETR


class RFDETRInference:
    """Predict with a live native model, checkpoint, or exported artifact.

    This facade shares prediction behavior across native models and exported runtimes. ``model.inference()`` returns
    an owned, optimized snapshot of a live model. Passing a live model directly to this constructor borrows it instead:
    predictions follow later changes to that model, and its batches run one at a time, so each batch reads the model's
    state when it starts. A predictor that owns its model or runtime may build the next CUDA batch while one runs.

    Examples:
        Skipped when run as a doctest: requires model weights and an image file.

        >>> from rfdetr import RFDETRInference, RFDETRSmall  # doctest: +SKIP
        >>> predictor = RFDETRSmall().inference(compile=False)  # doctest: +SKIP
        >>> detections = predictor.predict("image.jpg")  # doctest: +SKIP
    """

    def __init__(
        self,
        source: RFDETR | str | os.PathLike[str],
        *,
        device: str | torch.device = "auto",
        metadata: Mapping[str, Any] | str | os.PathLike[str] | None = None,
        trust_checkpoint: bool = False,
        runtime_options: Mapping[str, Any] | None = None,
    ) -> None:
        """Create a prediction facade from native weights or an exported artifact.

        Each source accepts its own device vocabulary; a value valid for one format can be refused by another:

        | Source | Accepted ``device`` values |
        | --- | --- |
        | Live ``RFDETR`` model | ``auto`` only; configure the model's own device instead |
        | Checkpoint path | Any device ``RFDETR.from_checkpoint`` accepts; ``auto`` defers to it |
        | ONNX | ``auto`` (CUDA provider when installed, else CPU), ``cpu``, ``cuda``, ``cuda:N`` |
        | TensorRT | ``auto`` (``cuda:0``), ``cuda`` (the current CUDA device), ``cuda:N`` |
        | OpenVINO | ``auto`` (AUTO plugin), ``cpu``, ``gpu``, ``npu``, ``gpu.N``, ``npu.N``, any case |
        | TFLite, LiteRT | ``auto``, ``cpu`` |
        | CoreML | ``auto`` (all compute units), ``cpu`` (CPU only), ``cpu_and_gpu``, ``cpu_and_ne`` (preferences) |
        | Core AI | ``auto``, ``cpu``; ``gpu`` and ``ane`` are refused as mere preferences |
        | ExecuTorch | XNNPACK ``auto``/``cpu``, CoreML ``auto``, QNN ``auto``/``qnn``, TensorRT ``auto``/``cuda`` |

        The CoreML ``cpu_and_gpu`` and ``cpu_and_ne`` values are preferences; Core ML may still run on the CPU.

        The ExecuTorch TensorRT delegate runs on the current CUDA device: ``auto`` and ``cuda`` mean that device, and
        ``cuda:N`` is accepted only when ``N`` is the current CUDA device; any other index is refused.

        A live model owns its device policy. Omit ``device`` for that source;
        configure the native model itself to select its device.

        A checkpoint loaded on MPS takes the MPS rewrites of :meth:`RFDETR.inference`: fused deformable sampling and
        LayerScale folded into the Linear before it. Its predictions match the unmodified model's to float rounding,
        not bit for bit. A live model is never rewritten.

        Args:
            source: A live RFDETR model or a checkpoint or exported artifact path.
            device: Runtime device, as a string or ``torch.device`` (converted with ``str()``), or ``"auto"`` to
                inherit the source device.
            metadata: Missing inference semantics for an older exported artifact, supplied as a JSON file path or
                JSON-serializable mapping. Accepts a plain metadata object or an ``artifact_sha256`` / ``metadata``
                envelope whose digest matches the artifact. Required fields describe the format, task, input shape,
                outputs, normalization, classes and postprocessing; see "Metadata for older exports" in the export
                basics guide for the complete schema and example. Supplied values must agree with stored metadata;
                unknown fields and unsupported schema versions are rejected. Invalid for native models or checkpoints.
            trust_checkpoint: Allow loading a checkpoint that contains custom Python objects.
            runtime_options: Settings for an exported artifact's runtime. Each format reads only its own keys and
                raises ``ValueError`` for any other: TensorRT takes ``cuda_graph``, ``engine_host_code_allowed`` and
                ``verbose`` (each a ``bool``); OpenVINO takes ``cache_dir``, ``inference_precision`` and ``config``;
                TFLite and LiteRT take ``num_threads`` (a positive ``int``); the other formats take none.

        Raises:
            FileNotFoundError: If the artifact or metadata file is missing.
            ImportError: If a required format extra or runtime package is not installed.
            RuntimeError: If the host or requested device cannot run the runtime.
            TypeError: If runtime_options is not a mapping.
            ValueError: If metadata, runtime_options or device conflicts with a native source; metadata is missing,
                stale or conflicting; the format is unsupported; the artifact is backbone-only; or the loader
                refuses a device or runtime option.
        """
        # Keep RFDETR imports local because detr imports ModelContext from this module.
        from rfdetr.detr import RFDETR, _rewrite_for_mps_prediction

        # Format loaders compare device strings; RFDETR itself also accepts a torch.device.
        device = str(device)
        self._native_model: RFDETR | None = None
        self._export_context: PredictionContext | None = None
        # A path loads a model or runtime only this predictor uses; a live model passed in stays the caller's, who may
        # change it between batches.
        self._owns_source = not isinstance(source, RFDETR)
        if isinstance(source, RFDETR):
            self._set_native_model(source, device, metadata, runtime_options)
            return

        path = Path(source)
        if path.suffix.lower() in {".pt", ".pth", ".ckpt"}:
            if metadata is not None:
                raise ValueError("metadata is only valid for exported artifacts.")
            if runtime_options is not None:
                raise ValueError("runtime_options is only valid for exported artifacts.")
            checkpoint_options: dict[str, Any] = {"trust_checkpoint": trust_checkpoint}
            if device != "auto":
                checkpoint_options["device"] = device
            native_model = RFDETR.from_checkpoint(path, **checkpoint_options)
            if torch.device(native_model.model.device).type == "mps" and native_model.model.model is not None:
                # Unlike a borrowed live model, this one belongs to the facade and never trains, so it takes the same
                # MPS rewrites as an `inference()` snapshot.
                _rewrite_for_mps_prediction(native_model.model.model, fold_layer_scales=True)
            self._set_native_model(native_model, "auto", None, None)
            return

        from rfdetr.export._runtime.context import load_exported_context

        self._export_context = load_exported_context(
            path, device=device, metadata=metadata, runtime_options=runtime_options
        )

    @classmethod
    def _from_owned_model(cls, native_model: RFDETR) -> RFDETRInference:
        """Wrap a native model that only this predictor uses, such as the snapshot :meth:`RFDETR.inference` builds.

        Nothing changes an owned model between batches, so a CUDA prediction may read the next batch's model state
        while the current batch runs, which a borrowed live model must not.

        Args:
            native_model: A model no caller keeps a reference to.

        Returns:
            A predictor owning ``native_model``.
        """
        predictor = cls(native_model)
        predictor._owns_source = True
        return predictor

    def _set_native_model(
        self,
        native_model: RFDETR,
        device: str,
        metadata: Mapping[str, Any] | str | os.PathLike[str] | None,
        runtime_options: Mapping[str, Any] | None,
    ) -> None:
        """Store a native model after validating facade-only arguments."""
        if metadata is not None:
            raise ValueError("metadata is only valid for exported artifacts.")
        if runtime_options is not None:
            raise ValueError("runtime_options is only valid for exported artifacts.")
        if device != "auto":
            raise ValueError("A live model owns its device policy. Omit device or configure the native model itself.")
        self._native_model = native_model

    def _prediction_context(self) -> PredictionContext:
        """Build a fresh context for prediction or return the loaded export context."""
        if self._native_model is not None:
            return self._native_model._prediction_context()
        assert self._export_context is not None
        return self._export_context

    @property
    def class_names(self) -> list[str]:
        """Return a copy of the source class names."""
        if self._native_model is not None:
            return self._native_model.class_names
        return list(self._prediction_context().class_names)

    @property
    def runtime_info(self) -> dict[str, Any]:
        """Return runtime policy and current input constraints without preparing the model.

        ``input_shape`` uses canonical NCHW order with ``None`` for dynamic axes. ``default_shape`` is the default image
        height and width. ``batch_size`` is an exact requirement; ``max_batch_size`` is an upper bound. Neither is a
        batching request. The returned dictionary is independent of the source.
        """
        if self._native_model is not None:
            return self._native_model._runtime_info()
        context = self._prediction_context()
        return {
            **context.runtime_info,
            "input_shape": (context.batch_size, context.config.num_channels, *context.default_shape),
            "default_shape": context.default_shape,
            "batch_size": context.batch_size,
            "max_batch_size": context.max_batch_size,
        }

    def predict(
        self,
        images: _PredictionInput,
        threshold: _ThresholdInput = 0.5,
        shape: tuple[int, int] | None = None,
        patch_size: int | None = None,
        include_source_image: bool = True,
        *,
        antialias: bool | None = None,
        stream: bool = False,
        batch: int | None = None,
        vid_stride: int = 1,
        stream_buffer: bool = False,
    ) -> _PredictionOutput | Generator[_PredictionResult, None, None]:
        """Predict images, video, and live sources through the shared prediction pipeline.

        Args:
            images: An image, directory, glob, video, webcam index, stream URL, manifest, or an iterable of these.
                Images can be paths, HTTP URLs, PIL images, NumPy arrays, or tensors. Iterables other than lists and
                tuples are read into a list first. TXT/CSV manifests list sources; ``.streams`` files capture streams
                concurrently. YouTube URLs and ``screen`` capture require the optional ``rfdetr[stream]``
                dependencies. String sources are downloaded, opened or expanded without size or host limits, so pass
                only trusted strings.
            threshold: The confidence score a detection must exceed to be kept. A single float applies to every class.
                A :class:`~rfdetr.ClassThresholds`, such as ``ClassThresholds({"person": 0.35}, default=0.5)``, applies
                each class's own threshold to its detections, so that a class the model finds less reliably can be
                held to a different bar. It leaves out every detection that belongs to no entry of ``class_names``:
                the no-object slot of a fine-tuned model, the background slot of a legacy keypoint checkpoint, and the
                unused category IDs of a pretrained COCO model. A threshold of ``float("inf")`` drops every detection
                of that class.
            shape: Input height and width; exports require their recorded shape.
            patch_size: Backbone patch size for shape validation.
            include_source_image: Store RGB source pixels in each result.
            antialias: Override resize antialiasing. None uses artifact metadata for exports
                and False for native models.
            stream: Yield results lazily. Close the generator on early exit.
            batch: Maximum finite-source batch size. None runs a bare BCHW tensor or an eager image-only list as
                one batch, finite expanded or streamed sources in batches of the fixed batch size of a compiled
                snapshot or fixed-batch export, an eager directory or glob in batches of eight (or of a smaller
                export ``max_batch_size``) when the model or export has no fixed batch size, and other finite sources
                one image or frame at a time. An integer bounds these batches, including eager image lists. Live
                captures and ``.streams`` keep one frame per source in each simultaneous batch, regardless of this
                setting; the source count must match a fixed runtime batch size. Each batch must satisfy the runtime
                limits. Fixed-batch runtimes also reject a short final finite batch. Use batch-one or dynamic-batch
                runtimes for individual live sources.
            vid_stride: Read every Nth video frame.
            stream_buffer: Queue live frames instead of keeping the latest frame.

        Returns:
            A generator with stream enabled, otherwise a scalar image result or a list.

        Raises:
            TypeError: If ``threshold`` is neither a number nor a sequence of numbers.
            ValueError: If shape, batch, stride, buffer, capture, or runtime limits are violated, or if a ``threshold``
                sequence is not one-dimensional, differs in length from ``class_names`` or holds a NaN.
            FileNotFoundError: If a local file is missing or a directory/glob contains no supported media.
            ImportError: If a source needs the optional ``rfdetr[stream]`` dependencies and they are not installed.

        Examples:
            Skipped when run as a doctest: requires model weights and image files.

            >>> from rfdetr import RFDETRInference, RFDETRSmall  # doctest: +SKIP
            >>> predictor = RFDETRSmall().inference(compile=False)  # doctest: +SKIP
            >>> results = predictor.predict(["a.jpg", "b.jpg"], threshold=0.4)  # doctest: +SKIP
            >>> len(results)  # doctest: +SKIP
            2
        """
        return predict(
            self._prediction_context,
            images,
            threshold,
            shape,
            patch_size,
            include_source_image,
            antialias=antialias,
            stream=stream,
            batch=batch,
            vid_stride=vid_stride,
            stream_buffer=stream_buffer,
            prepare_ahead=self._owns_source,
        )


class ModelContext:
    """Lightweight model wrapper returned by RFDETR.get_model().

    Provides the same attribute interface as the legacy ``main.py:Model`` but without importing or depending on
    ``populate_args()`` or the legacy stack.

    Args:
        model: The underlying ``LWDETR`` module. Owned inference snapshots keep this ``None`` and store their
            optimized runtime in ``inference_model``; their source model keeps its base weights.
        postprocess: PostProcess instance for converting raw outputs to boxes.
        device: Device the model lives on. An index-less ``torch.device("cuda")`` is replaced by the concrete
            device (e.g. ``cuda:0``) that ``rfdetr.detr._move_model_context_to_device`` resolves on the deferred
            first-use move, so every later caller targets that same GPU whatever its own thread selected.
        resolution: Input resolution (square side length in pixels).
        args: Namespace of resolved training/model configuration.
        class_names: Optional list of class name strings loaded from checkpoint.
    """

    def __init__(
        self,
        model: LWDETR,
        postprocess: PostProcess,
        device: torch.device,
        resolution: int,
        args: Any,
        class_names: list[str] | None = None,
    ) -> None:
        self.model: LWDETR | None = model
        self.postprocess = postprocess
        self.device = device
        self.resolution = resolution
        self.args = args
        self.class_names = class_names
        self.inference_model = None

    def reinitialize_detection_head(self, num_classes: int) -> None:
        """Reinitialize the detection head for a different number of classes.

        Args:
            num_classes: New number of output classes (including background).

        Raises:
            RuntimeError: If the context has no base model weights, as in an owned inference snapshot.
        """
        if self.model is None:
            raise RuntimeError(
                "Cannot reinitialize the detection head without base model weights. "
                "Use the source RFDETR instance or reload the model."
            )
        reinitialize_head = cast("Callable[[int], None]", self.model.reinitialize_detection_head)
        reinitialize_head(num_classes)
        self.args.num_classes = num_classes


_ModelContext = ModelContext  # backward-compat alias


def _adapt_input_conv(num_channels: int, conv_weight: torch.Tensor) -> torch.Tensor:
    """Adapt a 3-channel pretrained conv weight tensor to *num_channels* input channels.

    When ``num_channels == 3``: returns the weight unchanged. When ``num_channels == 1``: averages weights across the
    original 3 channels.
    Otherwise (``num_channels != 1`` and ``num_channels != 3``): tiles the 3-channel
    pattern and scales by ``3 / num_channels`` to preserve activation magnitude.

    Args:
        num_channels: Target number of input channels.
        conv_weight: Original weight tensor of shape ``[out_ch, 3, H, W]``.

    Returns:
        Adapted weight tensor of shape ``[out_ch, num_channels, H, W]``.
    """
    if num_channels == 3:
        return conv_weight
    if num_channels == 1:
        return conv_weight.mean(dim=1, keepdim=True)
    # General case: tile and scale
    repeats = (num_channels + 2) // 3
    weight_out = torch.cat([conv_weight] * repeats, dim=1)[:, :num_channels]
    weight_out = weight_out * (3.0 / num_channels)
    return weight_out


def _build_model_context(model_config: ModelConfig, *, trust_checkpoint: bool = False) -> ModelContext:
    """Build a ModelContext from ModelConfig without using legacy main.py:Model.

    Replicates ``Model.__init__`` logic: builds the nn.Module, optionally loads pretrain weights and applies LoRA.  The
    model is intentionally kept on CPU; :func:`_ensure_model_on_device` in ``detr.py`` performs the deferred
    ``.to(device)`` on the first ``predict()`` / ``export()`` call. ``inference()`` moves only its owned snapshot.
    Keeping construction
    CPU-only prevents CUDA initialisation during ``__init__``, which would block DDP strategies (``ddp_notebook``,
    ``ddp_spawn``) from spawning child processes in notebook environments.

    Args:
        model_config: Architecture configuration.
        trust_checkpoint: Forwarded to :func:`~rfdetr.models.weights.load_pretrain_weights` as its
            ``trust`` argument — set ``True`` only when ``model_config.pretrain_weights`` is a
            checkpoint the caller explicitly trusts (mirrors ``RFDETR.from_checkpoint(...,
            trust_checkpoint=True)``).

    Returns:
        ModelContext with the model on CPU, ready for lazy device placement.
    """
    from rfdetr._namespace import _namespace_from_configs

    # A dummy TrainConfig is needed only for _namespace_from_configs' required fields;
    # dataset_dir/output_dir are unused during model construction.
    dummy_train_config = TrainConfig(dataset_dir=None, output_dir="output")
    args = _namespace_from_configs(model_config, dummy_train_config)
    # ``TrainConfig.expand_paths`` realpaths these to the caller's absolute CWD, which would be embedded into
    # ``args`` and serialized into exported ``weights.pt`` (see ``RFDETR.export_for_roboflow``). Reset them on the
    # namespace to placeholders so inference-built checkpoints never leak the caller's filesystem layout.
    args.dataset_dir = None
    args.output_dir = "output"
    nn_model = build_model(args)
    assert isinstance(nn_model, LWDETR), (
        "build_model() returned a non-LWDETR result even though encoder_only/backbone_only were not set."
    )

    class_names: list[str] = []
    if model_config.pretrain_weights is not None:
        class_names = load_pretrain_weights(nn_model, model_config, trust=trust_checkpoint)
        # ``load_pretrain_weights`` can mutate ``model_config.num_classes`` and
        # ``model_config.num_keypoints_per_class`` when aligning to checkpoint schema.
        # Keep the derived namespace in sync so postprocess and predict() use correct values.
        if hasattr(args, "num_classes") and args.num_classes != model_config.num_classes:
            args.num_classes = model_config.num_classes
        _mc_kp = list(getattr(model_config, "num_keypoints_per_class", []) or [])
        if (
            hasattr(args, "num_keypoints_per_class")
            and list(getattr(args, "num_keypoints_per_class", []) or []) != _mc_kp
        ):
            args.num_keypoints_per_class = _mc_kp

    if model_config.backbone_lora:
        # No-op when load_pretrain_weights already wrapped the encoder to load a LoRA checkpoint.
        apply_lora(nn_model)

    # Adapt patch-embedding projection for non-RGB channel counts
    if model_config.num_channels != 3:
        import copy

        # Channel adaptation rewrites DINOv2's patch embedding. Dispatch on the encoder name, as
        # Backbone._build_encoder does: with backbone_lora the encoder is a PEFT wrapper, not a DinoV2 instance.
        if model_config.encoder.split("_")[0] != "dinov2":
            raise ValueError(
                f"num_channels={model_config.num_channels} is supported for DINOv2 encoders only, "
                f"not encoder={model_config.encoder!r}."
            )
        backbone = cast(Backbone, nn_model.backbone[0])
        # A PEFT wrapper forwards attribute access to the wrapped DinoV2.
        encoder = cast(DinoV2, backbone.encoder)
        proj = encoder.encoder.embeddings.patch_embeddings.projection
        new_proj = copy.deepcopy(proj)
        new_proj.in_channels = model_config.num_channels
        new_weight = _adapt_input_conv(model_config.num_channels, proj.weight)
        new_proj.weight = torch.nn.Parameter(new_weight)
        new_proj.weight.requires_grad = proj.weight.requires_grad
        encoder.encoder.embeddings.patch_embeddings.projection = new_proj
        encoder.encoder.embeddings.patch_embeddings.num_channels = model_config.num_channels

    device = torch.device(args.device)
    # Keep the model on CPU here; predict() / export() move it lazily, while inference() moves only its snapshot.
    # Eagerly calling .to("cuda") would initialise the CUDA runtime during __init__(), which
    # prevents DDP strategies (ddp_notebook, ddp_spawn) from forking/spawning
    # child processes in notebook environments.
    postprocess = PostProcess(
        num_select=args.num_select,
        num_keypoints_per_class=getattr(args, "num_keypoints_per_class", []),
        # Older detection-only namespaces may omit keypoint postprocess knobs; keep the ModelConfig default.
        trace_alpha=getattr(args, "postprocess_trace_alpha", 0.2),
    )

    return ModelContext(
        model=nn_model,
        postprocess=postprocess,
        device=device,
        resolution=model_config.resolution,
        args=args,
        class_names=class_names or None,
    )
