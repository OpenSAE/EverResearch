---
description: RF-DETR benchmark results on COCO and RF100-VL for detection, segmentation, and keypoint detection. Compare accuracy and latency against YOLO, D-FINE, and LW-DETR.
---

# Benchmarks

!!! tip "Key Takeaways"

    - RF-DETR-2XL achieves 60.1 AP50:95 on COCO detection at 17.2 ms latency (T4, TensorRT FP16)
    - RF-DETR-L outperforms YOLOv11x (56.5 vs 50.9 AP50:95) at lower latency (6.8 vs 10.5 ms)
    - Segmentation models range from 40.3 AP (Nano, 3.4 ms) to 49.9 AP (2XL, 21.8 ms) on COCO
    - All latency measured on NVIDIA T4 with TensorRT 10.4, CUDA 12.4, FP16, batch size 1
    - RF100-VL results demonstrate strong domain-shift generalization across 100 diverse datasets
    - RF-DETR Keypoint (Preview) achieves 71.8 AP50:95 on COCO person keypoints at 9.7 ms (T4, TensorRT FP16)
    - RF-DETR Nano–Large detection, every segmentation size and Keypoint are Apache 2.0, so they're commercially usable out of the box. The YOLOv8, YOLO11 and YOLO26 baselines are AGPL-3.0: using them in a commercial product or service, including one users reach over a network, means open-sourcing your application code under AGPL-3.0 or buying a [commercial license](https://roboflow.com/ultralytics)

This page reports RF-DETR benchmark results for object detection, instance segmentation, and keypoint detection on Microsoft COCO and RF100-VL (detection only). All benchmark numbers and plots match the latest released checkpoints and tables shown below. Latency values are measured on an NVIDIA T4 with TensorRT in FP16 at batch size 1. For full methodology details and architectural context, see the RF-DETR paper.

## Methodology

Accuracy is reported using standard COCO metrics computed with pycocotools. For object detection, we report COCO AP50 and COCO AP50:95, and the same metrics are also reported for RF100-VL. COCO results are evaluated on the validation split, following common practice in detector benchmarking. Every model on this page — including third-party models — is re-evaluated in-house with pycocotools in [roboflow/sab](https://github.com/roboflow/single_artifact_benchmarking) under this same protocol, scored over the full 5,000-image `val2017` split, so all rows are directly comparable; numbers may therefore differ from vendor-reported figures. The sole exception is rows marked †, which are quoted from the original authors' paper and were not run through SAB; these are flagged in the table footnote and should be read as author-reported rather than independently reproduced. RF100-VL results are averaged across all 100 datasets to reflect performance under diverse real-world data distributions.

Latency is measured as single-image inference latency rather than sustained throughput. All latency numbers are obtained on an NVIDIA T4 GPU using TensorRT 10.4 and CUDA 12.4 with FP16 inference and batch size 1. To reduce variance caused by GPU power throttling and thermal effects, a 200 ms buffer is inserted between consecutive forward passes. This procedure improves reproducibility of latency measurements but is not intended to measure maximum throughput.

Accuracy and latency are always measured using the same model artifact and the same numerical precision. This avoids reporting FP32 accuracy together with FP16 latency, which can lead to misleading comparisons because naive FP16 conversion can significantly degrade accuracy for some models.

### Where each number comes from

| Number                                                   | Source and conditions                                                                                                                                                                                                                    |
| -------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| COCO AP<sub>50</sub> and AP<sub>50:95</sub> on this page | SAB with pycocotools on all 5000 val2017 images, scoring the same TensorRT 10.4 FP16 engine whose latency is reported, for RF-DETR and every baseline                                                                                    |
| RF100-VL AP<sub>50</sub> and AP<sub>50:95</sub>          | SAB, averaged over the 100 RF100-VL datasets                                                                                                                                                                                             |
| Latency (ms)                                             | SAB on an NVIDIA T4 with TensorRT 10.4 and CUDA 12.4, FP16, batch 1, with a 200 ms buffer between forward passes                                                                                                                         |
| Params (M)                                               | Deployment `nn.Module` parameter count, defined under Metric definitions below                                                                                                                                                           |
| Rows marked †                                            | Quoted from the authors' paper, not run through SAB                                                                                                                                                                                      |
| PyTorch FP32, TensorRT FP16 and INT8 AP on the Run pages | The [COCO accuracy cookbook](../../cookbooks/coco-accuracy/) through `RFDETRInference.predict` on all 5000 val2017 images, on an NVIDIA RTX PRO 6000 with TensorRT 11.4; see [Reproduce the COCO Accuracy](#reproduce-the-coco-accuracy) |

!!! info "Metric definitions"

    **AP50**: Detection accuracy at IoU threshold >= 0.50. **AP50:95**: Mean accuracy averaged over IoU thresholds 0.50 to 0.95 (step 0.05) — the primary COCO metric. **Params (M)**: Deployment (fused) `nn.Module` parameter count (`model.parameters()`) in millions, excluding training-only branches and folded normalization layers, and counting model parameters rather than the raw tensor count of the saved checkpoint. Rows marked † use the authors' reported counts rather than SAB-measured values. Latency measured on NVIDIA T4, TensorRT 10.4, CUDA 12.4, FP16, batch size 1, with 200 ms thermal buffer between passes to reduce GPU thermal variance.

--8<-- "docs/snippets/license-yolo-note.md"

RF-DETR rows marked PML 1.0 use the Roboflow Platform Model License: commercial use is included when you deploy on Roboflow, and commercial self-hosting requires the Enterprise add-on. LW-DETR and D-FINE are Apache 2.0.

## Detection

![Object detection accuracy vs latency on COCO and RF100-VL: RF-DETR against YOLO11, YOLO26, LW-DETR and D-FINE](../assets/benchmark-detection.svg)

<!-- COPIES: the Params values of the RF-DETR rows in the Detection, Segmentation and Keypoints tables are repeated in docs/learn/run/detection.md, segmentation.md and keypoints.md. Update both together. -->

| Architecture | Size | COCO AP<sub>50</sub> | COCO AP<sub>50:95</sub> | RF100VL AP<sub>50</sub> | RF100VL AP<sub>50:95</sub> | Latency (ms) | Params (M) | Resolution |  License   |
| :----------: | :--: | :------------------: | :---------------------: | :---------------------: | :------------------------: | :----------: | :--------: | :--------: | :--------: |
|   RF-DETR    |  A   |         49.4         |          30.5           |          78.2           |            48.3            |     1.0      |    7.4     |  380x380   |  PML 1.0   |
|   RF-DETR    |  F   |         55.9         |          37.8           |          82.5           |            53.8            |     1.4      |    7.9     |  384x384   |  PML 1.0   |
|   RF-DETR    |  P   |         60.2         |          41.6           |          84.1           |            56.0            |     1.7      |    8.4     |  560x560   |  PML 1.0   |
|   RF-DETR    |  N   |         67.6         |          48.4           |          85.0           |            57.7            |     2.3      |    30.5    |  384x384   | Apache 2.0 |
|   RF-DETR    |  S   |         72.1         |          53.0           |          86.7           |            60.2            |     3.5      |    32.1    |  512x512   | Apache 2.0 |
|   RF-DETR    |  M   |         73.6         |          54.7           |          87.4           |            61.2            |     4.4      |    33.7    |  576x576   | Apache 2.0 |
|   RF-DETR    |  L   |         75.1         |          56.5           |          88.2           |            62.2            |     6.8      |    33.9    |  704x704   | Apache 2.0 |
|   RF-DETR    |  XL  |         77.4         |          58.6           |          88.5           |            62.9            |     11.5     |   126.4    |  700x700   |  PML 1.0   |
|   RF-DETR    | 2XL  |         78.5         |          60.1           |          89.0           |            63.2            |     17.2     |   126.9    |  880x880   |  PML 1.0   |
|    YOLO11    |  N   |         52.0         |          37.4           |          81.4           |            55.3            |     2.5      |    2.6     |  640x640   |  AGPL-3.0  |
|    YOLO11    |  S   |         59.7         |          44.4           |          82.3           |            56.2            |     3.2      |    9.4     |  640x640   |  AGPL-3.0  |
|    YOLO11    |  M   |         64.1         |          48.6           |          82.5           |            56.5            |     5.1      |    20.1    |  640x640   |  AGPL-3.0  |
|    YOLO11    |  L   |         64.9         |          49.9           |          82.2           |            56.5            |     6.5      |    25.3    |  640x640   |  AGPL-3.0  |
|    YOLO11    |  X   |         66.1         |          50.9           |          81.7           |            56.2            |     10.5     |    56.9    |  640x640   |  AGPL-3.0  |
|    YOLO26    |  N   |         55.8         |          40.3           |          76.7           |            52.0            |     1.7      |    2.6     |  640x640   |  AGPL-3.0  |
|    YOLO26    |  S   |         64.3         |          47.7           |          82.7           |            57.0            |     2.6      |    9.4     |  640x640   |  AGPL-3.0  |
|    YOLO26    |  M   |         69.7         |          52.5           |          84.4           |            58.7            |     4.4      |    20.1    |  640x640   |  AGPL-3.0  |
|    YOLO26    |  L   |         71.1         |          54.1           |          85.0           |            59.3            |     5.7      |    25.3    |  640x640   |  AGPL-3.0  |
|    YOLO26    |  X   |         74.0         |          56.9           |          85.6           |            60.0            |     9.6      |    56.9    |  640x640   |  AGPL-3.0  |
|   LW-DETR    |  T   |         60.7         |          42.9           |          84.7           |            57.1            |     1.9      |    12.1    |  640x640   | Apache 2.0 |
|   LW-DETR    |  S   |         66.8         |          48.0           |          85.0           |            57.4            |     2.6      |    14.6    |  640x640   | Apache 2.0 |
|   LW-DETR    |  M   |         72.0         |          52.6           |          86.8           |            59.8            |     4.4      |    28.2    |  640x640   | Apache 2.0 |
|   LW-DETR    |  L   |         74.6         |          56.1           |          87.4           |            61.5            |     6.9      |    46.8    |  640x640   | Apache 2.0 |
|   LW-DETR    |  X   |         76.9         |          58.3           |          87.9           |            62.1            |     13.0     |   118.0    |  640x640   | Apache 2.0 |
|    D-FINE    |  N   |         60.2         |          42.7           |          84.4           |            58.2            |     2.1      |    3.8     |  640x640   | Apache 2.0 |
|    D-FINE    |  S   |         67.6         |          50.6           |          85.3           |            60.3            |     3.5      |    10.2    |  640x640   | Apache 2.0 |
|    D-FINE    |  M   |         72.6         |          55.0           |          85.5           |            60.6            |     5.4      |    19.2    |  640x640   | Apache 2.0 |
|    D-FINE    |  L   |         74.9         |          57.2           |          86.4           |            61.6            |     7.5      |    31.0    |  640x640   | Apache 2.0 |
|    D-FINE    |  X   |         76.8         |          59.3           |          86.9           |            62.2            |     11.5     |    62.0    |  640x640   | Apache 2.0 |
|   SAM 3 †    |  —   |          —           |            —            |            —            |            61.6            |      —       |    ~850    | 1008x1008  |    N/A     |

> † Reported by the SAM 3 authors ([arXiv:2511.16719](https://arxiv.org/abs/2511.16719), Table 36), **not** measured by us in SAB. The value is SAM 3 fine-tuned on the full RF100-VL training set — the same fully-supervised setting as the RF100VL columns above, and distinct from the 15.2 zero-shot / 36.5 10-shot numbers in the paper's main table. SAM 3's paper independently reports LW-DETR-m at 59.8 on this benchmark, matching our own measurement, which confirms the protocols align. Dashes mark results SAM 3 does not report under this protocol. Parameter count is the paper's stated ~850 M (~450 M vision + ~300 M text encoders + ~100 M detector/tracker).

## Segmentation

![Instance segmentation accuracy vs latency on COCO: RF-DETR-Seg against YOLOv8, YOLOv11 and YOLO26](../assets/benchmark-segmentation.svg)

| Architecture | Size | COCO AP<sub>50</sub> | COCO AP<sub>50:95</sub> | Latency (ms) | Params (M) | Resolution |  License   |
| :----------: | :--: | :------------------: | :---------------------: | :----------: | :--------: | :--------: | :--------: |
| RF-DETR-Seg  |  N   |         63.0         |          40.3           |     3.4      |    33.6    |  312x312   | Apache 2.0 |
| RF-DETR-Seg  |  S   |         66.2         |          43.1           |     4.4      |    33.7    |  384x384   | Apache 2.0 |
| RF-DETR-Seg  |  M   |         68.4         |          45.3           |     5.9      |    35.7    |  432x432   | Apache 2.0 |
| RF-DETR-Seg  |  L   |         70.5         |          47.1           |     8.8      |    36.2    |  504x504   | Apache 2.0 |
| RF-DETR-Seg  |  XL  |         72.2         |          48.8           |     13.5     |    38.1    |  624x624   | Apache 2.0 |
| RF-DETR-Seg  | 2XL  |         73.1         |          49.9           |     21.8     |    38.6    |  768x768   | Apache 2.0 |
|  YOLOv8-Seg  |  N   |         45.6         |          28.3           |     3.5      |    3.4     |  640x640   |  AGPL-3.0  |
|  YOLOv8-Seg  |  S   |         53.8         |          34.0           |     4.2      |    11.8    |  640x640   |  AGPL-3.0  |
|  YOLOv8-Seg  |  M   |         58.2         |          37.3           |     7.0      |    27.3    |  640x640   |  AGPL-3.0  |
|  YOLOv8-Seg  |  L   |         60.5         |          39.0           |     9.7      |    46.0    |  640x640   |  AGPL-3.0  |
|  YOLOv8-Seg  |  XL  |         61.3         |          39.5           |     14.0     |    71.8    |  640x640   |  AGPL-3.0  |
| YOLOv11-Seg  |  N   |         47.8         |          30.0           |     3.6      |    2.9     |  640x640   |  AGPL-3.0  |
| YOLOv11-Seg  |  S   |         55.4         |          35.0           |     4.6      |    10.1    |  640x640   |  AGPL-3.0  |
| YOLOv11-Seg  |  M   |         60.0         |          38.5           |     6.9      |    22.4    |  640x640   |  AGPL-3.0  |
| YOLOv11-Seg  |  L   |         61.5         |          39.5           |     8.3      |    27.6    |  640x640   |  AGPL-3.0  |
| YOLOv11-Seg  |  XL  |         62.4         |          40.1           |     13.7     |    62.1    |  640x640   |  AGPL-3.0  |
|  YOLO26-Seg  |  N   |         54.3         |          34.7           |     2.31     |    2.7     |  640x640   |  AGPL-3.0  |
|  YOLO26-Seg  |  S   |         62.4         |          40.2           |     3.47     |    10.4    |  640x640   |  AGPL-3.0  |
|  YOLO26-Seg  |  M   |         67.8         |          44.0           |     6.32     |    23.6    |  640x640   |  AGPL-3.0  |
|  YOLO26-Seg  |  L   |         69.8         |          45.5           |     7.58     |    28.0    |  640x640   |  AGPL-3.0  |
|  YOLO26-Seg  |  X   |         71.6         |          46.8           |    12.92     |    62.8    |  640x640   |  AGPL-3.0  |

## Keypoints

![RF-DETR Keypoint mAP vs latency chart comparing against YOLO26-pose and YOLO11-pose on MS COCO](../assets/benchmark-keypoints.svg)

|   Architecture   |  Size   | COCO AP<sub>50:95</sub> | Latency (ms) | Params (M) |  License   |
| :--------------: | :-----: | :---------------------: | :----------: | :--------: | :--------: |
| RF-DETR Keypoint | Preview |          71.8           |     9.7      |    40.7    | Apache 2.0 |
|   YOLO11-pose    |    N    |          48.9           |     3.2      |    2.9     |  AGPL-3.0  |
|   YOLO11-pose    |    S    |          57.5           |     3.4      |    9.9     |  AGPL-3.0  |
|   YOLO11-pose    |    M    |          64.2           |     5.2      |    20.9    |  AGPL-3.0  |
|   YOLO11-pose    |    L    |          65.2           |     6.6      |    26.2    |  AGPL-3.0  |
|   YOLO11-pose    |    X    |          68.6           |     10.6     |    58.8    |  AGPL-3.0  |
|   YOLO26-pose    |    N    |          55.9           |     1.9      |    2.9     |  AGPL-3.0  |
|   YOLO26-pose    |    S    |          62.0           |     2.7      |    10.4    |  AGPL-3.0  |
|   YOLO26-pose    |    M    |          68.0           |     4.6      |    21.5    |  AGPL-3.0  |
|   YOLO26-pose    |    L    |          69.2           |     5.9      |    25.9    |  AGPL-3.0  |
|   YOLO26-pose    |    X    |          71.0           |     9.8      |    57.6    |  AGPL-3.0  |

> Keypoint benchmarks report AP<sub>50:95</sub> (OKS-based); this is the standard COCO keypoint comparison metric.

## Reproduce the COCO Accuracy

The tables above are the official numbers, from SAB on an NVIDIA T4 with TensorRT 10.4 in FP16, using the same artifact for accuracy and latency, except for the author-reported rows marked †. The [COCO accuracy cookbook](../../cookbooks/coco-accuracy/) rescores every pretrained checkpoint on all 5000 val2017 images through `RFDETRInference.predict` at a 0.001 score floor, batch 1 and default preprocessing, as eager PyTorch FP32 on any device and as static TensorRT FP16 and INT8 engines on a CUDA GPU. Plus models need `rfdetr[plus]` and `ACCEPT_PLATFORM_MODEL_LICENSE = True` in the notebook.

The Run pages for [detection](run/detection.md#pre-trained-checkpoints), [segmentation](run/segmentation.md#pre-trained-checkpoints) and [keypoints](run/keypoints.md#pre-trained-checkpoints) list the scores of one cookbook run on an NVIDIA RTX PRO 6000 Blackwell Server Edition with TensorRT 11.4, with the exact versions under each table. Their PyTorch FP32 scores are within 0.7 AP of the official values above; small differences are expected because the harness, runtime and preprocessing differ.
