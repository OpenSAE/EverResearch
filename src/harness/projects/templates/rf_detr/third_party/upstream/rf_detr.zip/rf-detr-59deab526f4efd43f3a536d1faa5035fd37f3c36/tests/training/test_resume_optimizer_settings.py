# ------------------------------------------------------------------------
# RF-DETR
# Copyright (c) 2025 Roboflow. All Rights Reserved.
# Licensed under the Apache License, Version 2.0 [see LICENSE for details]
# ------------------------------------------------------------------------
"""A resumed run trains with the optimizer settings it records, explicit ones winning over the checkpoint (#1613).

``trainer.fit(ckpt_path=...)`` restores every parameter group's learning rate and weight decay, and the scheduler's base
learning rates, from the checkpoint. A changed ``lr`` was therefore silently ignored while ``training_config.json`` and
the checkpoints' ``args`` recorded it. Precedence is now defaults, then the checkpoint, then what the caller set.
"""

import argparse
import json
import logging
from pathlib import Path
from types import SimpleNamespace
from typing import Any
from unittest.mock import MagicMock

import pytest
import torch
from pytest_mock import MockerFixture
from torch.optim.lr_scheduler import (
    ChainedScheduler,
    CosineAnnealingLR,
    LambdaLR,
    LinearLR,
    ReduceLROnPlateau,
    SequentialLR,
)

from rfdetr import RFDETRNano
from rfdetr._namespace import _namespace_from_configs
from rfdetr.config import TrainConfig
from rfdetr.detr import _resolve_resumed_optimizer_settings
from rfdetr.training.module_model import RFDETRModelModule
from rfdetr.training.param_groups import (
    _PARAM_GROUP_SETTINGS,
    _apply_configured_param_group_settings,
    _configured_settings_fed_by,
    _resolve_resumed_param_group_settings,
    get_param_dict,
)
from rfdetr.utilities.reproducibility import seed_all
from tests.conftest import build_synthetic_dataset

#: A value no setting defaults to, so a restored value cannot be mistaken for the default.
_CHECKPOINT_VALUE = 0.123
#: A second distinct value, set explicitly on the resumed run.
_EXPLICIT_VALUE = 0.456
#: Seed for the untrained model; module-scoped fixtures run before the autouse per-test reseed.
_TRAIN_SEED = 1613
#: Learning rates and weight decay of the first run; none is the ``TrainConfig`` default.
_FIRST_RUN = {"lr": 5e-5, "lr_encoder": 3e-4, "weight_decay": 2e-4}
#: Settings the resumed run passes explicitly; ``lr_encoder`` is left out so it comes from the checkpoint.
_RESUMED_RUN = {"lr": 1e-5, "weight_decay": 5e-4}
#: ``train()`` arguments shared by both runs: an untrained Nano on the CPU at 224 px.
_TRAIN_KWARGS = {
    "batch_size": 4,
    "num_workers": 0,
    "multi_scale": False,
    "augmentation_backend": "torchvision",
    "tensorboard": False,
    "run_test": False,
    "device": "cpu",
}


def _write_checkpoint(path: Path, args: object, *, optimizer_state: bool = True) -> Path:
    """Save a stand-in Lightning checkpoint holding only what the resume resolution reads.

    Args:
        path: File to write.
        args: Recorded training settings; ``None`` leaves them out, as a ``last.ckpt`` from before 1.11.1 does.
        optimizer_state: Whether the checkpoint carries optimizer state, as ``last.ckpt`` does.

    Returns:
        ``path``.

    Examples:
        >>> import tempfile
        >>> with tempfile.TemporaryDirectory() as directory:
        ...     written = _write_checkpoint(Path(directory) / "last.ckpt", {"lr": 5e-5})
        ...     torch.load(written, weights_only=True)["args"]
        {'lr': 5e-05}
    """
    checkpoint: dict[str, Any] = {"optimizer_states": [{"state": {}, "param_groups": []}] if optimizer_state else []}
    if args is not None:
        checkpoint["args"] = args
    torch.save(checkpoint, path)
    return path


def _adopt(train_config: TrainConfig, args: dict[str, float] | None, *, global_rank: int = 0) -> SimpleNamespace:
    """Run ``RFDETRModelModule._adopt_resumed_param_group_settings`` on a stand-in holding only what it reads.

    Args:
        train_config: The module's config.
        args: The checkpoint's recorded settings, or ``None`` for a checkpoint without them.
        global_rank: The stand-in's process rank.

    Returns:
        The stand-in, with the attributes the hook set.

    Examples:
        >>> config = TrainConfig(dataset_dir="data", lr=1e-5)
        >>> module = _adopt(config, {"lr": 5e-5, "lr_encoder": 3e-4}, global_rank=1)
        >>> module.train_config.lr_encoder, module._reapplied_param_group_settings
        (0.0003, ['lr'])
    """
    module = SimpleNamespace(train_config=train_config, global_rank=global_rank)
    checkpoint: dict[str, Any] = {"optimizer_states": [{"state": {}, "param_groups": []}]}
    if args is not None:
        checkpoint["args"] = args
    RFDETRModelModule._adopt_resumed_param_group_settings(module, checkpoint)
    return module


@pytest.fixture
def rf_detr_caplog(caplog: pytest.LogCaptureFixture, monkeypatch: pytest.MonkeyPatch) -> pytest.LogCaptureFixture:
    """``caplog`` capturing the ``rf-detr`` logger at INFO; that logger does not propagate to the root logger.

    Examples:
        >>> rf_detr_caplog  # doctest: +SKIP
        A pytest fixture; it needs pytest's caplog and monkeypatch.
    """
    monkeypatch.setattr(logging.getLogger("rf-detr"), "propagate", True)
    caplog.set_level(logging.INFO, logger="rf-detr")
    return caplog


@pytest.fixture
def mock_build_trainer(mocker: MockerFixture) -> MagicMock:
    """Patch the Lightning training stack and return the ``build_trainer`` mock, so ``RFDETR.train()`` stops at fit.

    Examples:
        >>> mock_build_trainer  # doctest: +SKIP
        A pytest fixture; it needs pytest-mock's mocker.
    """
    mocker.patch("rfdetr.training.RFDETRModelModule")
    mocker.patch("rfdetr.training.RFDETRDataModule")
    return mocker.patch("rfdetr.training.build_trainer")


class TestResolveResumedParamGroupSettings:
    """Defaults, then the checkpoint's recorded ``args``, then what the caller set."""

    @pytest.mark.parametrize("setting", _PARAM_GROUP_SETTINGS)
    def test_unset_setting_takes_checkpoint_value(self, setting: str) -> None:
        """An unset setting takes the checkpoint's recorded value."""
        config = TrainConfig(dataset_dir="data")
        resolved, _, _ = _resolve_resumed_param_group_settings(config, {"args": {setting: _CHECKPOINT_VALUE}})
        assert getattr(resolved, setting) == _CHECKPOINT_VALUE

    @pytest.mark.parametrize("setting", _PARAM_GROUP_SETTINGS)
    def test_explicit_setting_wins_over_checkpoint(self, setting: str) -> None:
        """An explicitly passed setting is kept over the checkpoint's recorded value."""
        config = TrainConfig(dataset_dir="data", **{setting: _EXPLICIT_VALUE})
        resolved, _, _ = _resolve_resumed_param_group_settings(config, {"args": {setting: _CHECKPOINT_VALUE}})
        assert getattr(resolved, setting) == _EXPLICIT_VALUE

    @pytest.mark.parametrize("setting", _PARAM_GROUP_SETTINGS)
    def test_complete_mapping_preserves_explicit_defaults(self, setting: str) -> None:
        """A supplied mapping's keys are explicit even when their values equal defaults."""
        config = TrainConfig(**TrainConfig(dataset_dir="data").model_dump())
        resolved, _, _ = _resolve_resumed_param_group_settings(config, {"args": {setting: _CHECKPOINT_VALUE}})
        assert getattr(resolved, setting) == TrainConfig.model_fields[setting].default

    def test_restored_setting_is_not_marked_explicit(self) -> None:
        """A value restored from the checkpoint does not count as explicitly set on the config."""
        config = TrainConfig(dataset_dir="data")
        resolved, _, _ = _resolve_resumed_param_group_settings(config, {"args": {"lr": _CHECKPOINT_VALUE}})
        assert "lr" not in resolved.model_fields_set

    def test_setting_missing_from_checkpoint_keeps_its_default(self) -> None:
        """A setting absent from the recorded ``args`` keeps its config default."""
        config = TrainConfig(dataset_dir="data")
        resolved, _, _ = _resolve_resumed_param_group_settings(config, {"args": {"lr": _CHECKPOINT_VALUE}})
        assert resolved.weight_decay == TrainConfig.model_fields["weight_decay"].default

    def test_explicit_setting_equal_to_checkpoint_is_no_override(self) -> None:
        """An explicit value equal to the checkpoint's is not reported as an override."""
        config = TrainConfig(dataset_dir="data", lr=5e-5)
        _, _, overridden = _resolve_resumed_param_group_settings(config, {"args": {"lr": 5e-5}})
        assert overridden == {}

    def test_checkpoint_without_recorded_settings_leaves_config_alone(self) -> None:
        """A checkpoint without recorded ``args`` returns the very same config."""
        config = TrainConfig(dataset_dir="data", lr=1e-5)
        resolved, _, _ = _resolve_resumed_param_group_settings(config, {})
        assert resolved is config

    def test_config_built_from_a_complete_mapping_keeps_supplied_defaults(self) -> None:
        """Every key supplied by a Python or JSON mapping expresses caller intent."""
        config = TrainConfig(**TrainConfig(dataset_dir="data", lr=1e-5).model_dump())
        resolved, _, _ = _resolve_resumed_param_group_settings(config, {"args": {"lr_encoder": _CHECKPOINT_VALUE}})
        assert resolved.lr_encoder == TrainConfig.model_fields["lr_encoder"].default


class TestChainedSchedulerResume:
    """Restored chained schedules follow the new base without changing their absolute floor."""

    @pytest.mark.parametrize("container", [pytest.param(list, id="list"), pytest.param(tuple, id="tuple")])
    def test_single_cosine_chain_matches_fresh_current_and_next_step(self, container: type) -> None:
        """Exercise real optimizer/scheduler save and load, followed by another scheduler step."""
        parameter = torch.nn.Parameter(torch.ones(1))
        optimizer = torch.optim.SGD([parameter], lr=0.1, momentum=0.9)
        scheduler = ChainedScheduler(container([CosineAnnealingLR(optimizer, T_max=4, eta_min=0.01)]))
        for _ in range(2):
            parameter.grad = torch.ones_like(parameter)
            optimizer.step()
            scheduler.step()
        state = optimizer.state_dict()
        scheduler_state = scheduler.state_dict()
        restored = torch.optim.SGD([torch.nn.Parameter(torch.ones(1))], lr=0.05, momentum=0.9)
        restored_scheduler = ChainedScheduler(container([CosineAnnealingLR(restored, T_max=4, eta_min=0.01)]))
        restored.load_state_dict(state)
        restored_scheduler.load_state_dict(scheduler_state)
        _apply_configured_param_group_settings(restored, restored_scheduler, [(0.05, None)])
        fresh = torch.optim.SGD([torch.nn.Parameter(torch.ones(1))], lr=0.05)
        fresh_scheduler = ChainedScheduler(container([CosineAnnealingLR(fresh, T_max=4, eta_min=0.01)]))
        for _ in range(2):
            fresh.step()
            fresh_scheduler.step()
        assert restored.param_groups[0]["lr"] == pytest.approx(fresh.param_groups[0]["lr"])
        assert next(iter(restored.state.values()))["momentum_buffer"].item() == pytest.approx(1.9)
        restored.step()
        restored_scheduler.step()
        fresh.step()
        fresh_scheduler.step()
        assert restored.param_groups[0]["lr"] == pytest.approx(fresh.param_groups[0]["lr"])

    @pytest.mark.parametrize("saved_base", [0.2, 0.0, None])
    def test_unsupported_floor_composition_refuses_before_any_mutation(self, saved_base: float | None) -> None:
        """An earlier group's weight decay must also survive a later group's refusal."""
        optimizer = torch.optim.SGD(
            [{"params": [torch.nn.Parameter(torch.ones(1))], "lr": lr} for lr in (0.1, 0.2)], weight_decay=0.01
        )
        scheduler = ChainedScheduler(
            [LambdaLR(optimizer, lambda step: 0.9**step), CosineAnnealingLR(optimizer, T_max=4, eta_min=0.01)]
        )
        if saved_base is None:
            del optimizer.param_groups[1]["initial_lr"]
        else:
            optimizer.param_groups[1]["initial_lr"] = saved_base
        before_optimizer = optimizer.state_dict()
        before_scheduler = scheduler.state_dict()
        with pytest.raises(ValueError, match="ChainedScheduler"):
            _apply_configured_param_group_settings(
                optimizer, scheduler, [(None, 0.02), (0.05, None)], restart_without_base=True
            )
        assert optimizer.state_dict() == before_optimizer
        assert scheduler.state_dict() == before_scheduler

    def test_weight_decay_only_resume_accepts_multi_member_floor_chain(self) -> None:
        """The composition restriction applies only to learning-rate rescaling."""
        optimizer = torch.optim.SGD([torch.nn.Parameter(torch.ones(1))], lr=0.1)
        scheduler = ChainedScheduler(
            [LambdaLR(optimizer, lambda step: 1.0), CosineAnnealingLR(optimizer, T_max=4, eta_min=0.01)]
        )
        assert _apply_configured_param_group_settings(optimizer, scheduler, [(0.1, 0.02)]) == 1
        assert optimizer.param_groups[0]["lr"] == 0.1
        assert optimizer.param_groups[0]["weight_decay"] == 0.02

    @pytest.mark.parametrize("container", [pytest.param(list, id="list"), pytest.param(tuple, id="tuple")])
    def test_sequential_cosine_inside_single_chain_matches_fresh_step(self, container: type) -> None:
        """A chain may wrap a sequential warmup whose active member has an absolute floor."""
        optimizers = [torch.optim.SGD([torch.nn.Parameter(torch.ones(1))], lr=lr) for lr in (0.1, 0.05)]
        schedulers = [
            ChainedScheduler(
                [
                    SequentialLR(
                        optimizer,
                        container(
                            [LinearLR(optimizer, total_iters=2), CosineAnnealingLR(optimizer, T_max=4, eta_min=0.01)]
                        ),
                        milestones=container([2]),
                    )
                ]
            )
            for optimizer in optimizers
        ]
        for optimizer, scheduler in zip(optimizers, schedulers, strict=True):
            for _ in range(4):
                optimizer.step()
                scheduler.step()
        _apply_configured_param_group_settings(optimizers[0], schedulers[0], [(0.05, None)])
        assert optimizers[0].param_groups[0]["lr"] == pytest.approx(optimizers[1].param_groups[0]["lr"])

        for optimizer, scheduler in zip(optimizers, schedulers, strict=True):
            optimizer.step()
            scheduler.step()
        assert optimizers[0].param_groups[0]["lr"] == pytest.approx(optimizers[1].param_groups[0]["lr"])

    def test_multi_member_chain_sees_tuple_sequential_floor(self) -> None:
        """Nested tuple-valued sequential members cannot hide unsupported floor compositions."""
        optimizer = torch.optim.SGD([torch.nn.Parameter(torch.ones(1))], lr=0.1)
        sequential = SequentialLR(
            optimizer,
            (LinearLR(optimizer, total_iters=2), CosineAnnealingLR(optimizer, T_max=4, eta_min=0.01)),
            milestones=(2,),
        )
        scheduler = ChainedScheduler([sequential, LambdaLR(optimizer, lambda step: 1.0)])
        for _ in range(4):
            optimizer.step()
            scheduler.step()
        before_optimizer = optimizer.state_dict()
        before_scheduler = scheduler.state_dict()
        with pytest.raises(ValueError, match="ChainedScheduler"):
            _apply_configured_param_group_settings(optimizer, scheduler, [(0.05, 0.02)])
        assert optimizer.state_dict() == before_optimizer
        assert scheduler.state_dict() == before_scheduler

    def test_floorless_multi_member_chain_keeps_proportional_rescaling(self) -> None:
        """Multiple homogeneous multiplicative schedules remain supported."""
        optimizer = torch.optim.SGD([torch.nn.Parameter(torch.ones(1))], lr=0.1)
        scheduler = ChainedScheduler(
            [LambdaLR(optimizer, lambda step: 0.9**step), CosineAnnealingLR(optimizer, T_max=4)]
        )
        optimizer.step()
        scheduler.step()
        before = optimizer.param_groups[0]["lr"]
        _apply_configured_param_group_settings(optimizer, scheduler, [(0.05, None)])
        assert optimizer.param_groups[0]["lr"] == pytest.approx(before / 2)


class TestResolveResumedOptimizerSettings:
    """``RFDETR.train()`` resolves the settings from the ``resume`` file before anything records the config."""

    def test_fills_unset_settings_from_checkpoint(self, tmp_path: Path) -> None:
        """An unset setting is filled from the ``resume`` file's recorded ``args``."""
        resume = _write_checkpoint(tmp_path / "last.ckpt", {"lr_encoder": _CHECKPOINT_VALUE})
        config = TrainConfig(dataset_dir="data", resume=str(resume))
        assert _resolve_resumed_optimizer_settings(config).lr_encoder == _CHECKPOINT_VALUE

    def test_checkpoint_without_optimizer_state_leaves_config_alone(self, tmp_path: Path) -> None:
        """A lightweight ``.pth`` restarts the optimizer from the config, so nothing is taken from it."""
        resume = _write_checkpoint(tmp_path / "last_ema.pth", {"lr": _CHECKPOINT_VALUE}, optimizer_state=False)
        config = TrainConfig(dataset_dir="data", resume=str(resume))
        assert _resolve_resumed_optimizer_settings(config) is config

    @pytest.mark.parametrize("resume", ["missing.ckpt", "last"])
    def test_resume_naming_no_file_leaves_config_alone(self, tmp_path: Path, resume: str) -> None:
        """Lightning resolves a sentinel such as ``"last"`` itself, and the module resolves the settings then."""
        config = TrainConfig(dataset_dir="data", resume=str(tmp_path / resume))
        assert _resolve_resumed_optimizer_settings(config) is config

    def test_checkpoint_that_is_not_a_mapping_leaves_config_alone(self, tmp_path: Path) -> None:
        """A weights-only ``torch.load`` also reads a bare tensor; Lightning reports the unusable file itself."""
        resume = tmp_path / "weights.pth"
        torch.save(torch.zeros(3), resume)
        config = TrainConfig(dataset_dir="data", resume=str(resume))
        assert _resolve_resumed_optimizer_settings(config) is config

    @pytest.mark.parametrize("content", ["pickle-only", "truncated"])
    def test_checkpoint_unreadable_weights_only_leaves_config_alone(self, tmp_path: Path, content: str) -> None:
        """A checkpoint a weights-only ``torch.load`` cannot read leaves the config alone and is left to Lightning.

        Nothing is unpickled beyond what a weights-only load allows; a pre-Lightning ``.pth``, for one, holds argparse
        objects.
        """
        resume = tmp_path / "checkpoint.pth"
        if content == "pickle-only":
            torch.save(
                {
                    "optimizer_states": [{"state": {}, "param_groups": []}],
                    "args": {"lr": _CHECKPOINT_VALUE},
                    "legacy_args": argparse.Namespace(lr=_CHECKPOINT_VALUE),
                },
                resume,
            )
        else:
            resume.write_bytes(_write_checkpoint(tmp_path / "whole.ckpt", {"lr": _CHECKPOINT_VALUE}).read_bytes()[:64])
        config = TrainConfig(dataset_dir="data", resume=str(resume))
        assert _resolve_resumed_optimizer_settings(config) is config

    def test_training_config_written_before_fit_records_checkpoint_settings(
        self, tmp_path: Path, mock_build_trainer: MagicMock
    ) -> None:
        """A resumed run interrupted inside ``trainer.fit`` leaves only the start-of-run ``training_config.json``."""
        resume = _write_checkpoint(tmp_path / "last.ckpt", {"lr_encoder": _CHECKPOINT_VALUE})
        mock_build_trainer.return_value.fit.side_effect = KeyboardInterrupt
        with pytest.raises(KeyboardInterrupt):
            RFDETRNano(pretrain_weights=None, num_classes=3, device="cpu").train(
                dataset_dir=str(tmp_path), output_dir=str(tmp_path / "output"), resume=str(resume), device="cpu"
            )
        recorded = json.loads((tmp_path / "output" / "training_config.json").read_text())["train_config"]
        assert recorded["lr_encoder"] == _CHECKPOINT_VALUE


class TestAdoptResumedParamGroupSettings:
    """``RFDETRModelModule.on_load_checkpoint`` resolves the same order from the checkpoint Lightning loads."""

    def test_unset_setting_takes_checkpoint_value(self) -> None:
        """An unset setting takes the checkpoint's recorded ``args`` value on the module."""
        module = _adopt(TrainConfig(dataset_dir="data"), {"lr_encoder": _CHECKPOINT_VALUE})
        assert module.train_config.lr_encoder == _CHECKPOINT_VALUE

    @pytest.mark.parametrize(
        ("explicit", "args", "reapplies"),
        [
            pytest.param({}, {"lr": 5e-5}, False, id="unchanged-resume"),
            pytest.param({"lr": 5e-5}, {"lr": 5e-5}, True, id="explicit-equal-to-checkpoint"),
            pytest.param({"weight_decay": 2e-4}, {"weight_decay": 2e-4}, True, id="explicit-equal-weight-decay"),
            pytest.param({"lr": 1e-5}, {"lr": 5e-5}, True, id="explicit-change"),
            pytest.param({}, None, False, id="no-recorded-settings"),
            pytest.param({"lr": 1e-5}, None, True, id="explicit-without-recorded-settings"),
        ],
    )
    def test_reapplies_when_a_setting_is_passed_explicitly(
        self, explicit: dict[str, float], args: dict[str, float] | None, reapplies: bool
    ) -> None:
        """A resume that passes none continues exactly as saved.

        One that passes any is compared group by group, not with ``args``: a resume hit by #1613 recorded ``args`` its
        optimizer never trained with.
        """
        module = _adopt(TrainConfig(dataset_dir="data", **explicit), args)
        assert bool(module._reapplied_param_group_settings) is reapplies

    @pytest.mark.parametrize(
        ("explicit", "args", "reapplies"),
        [
            pytest.param({}, None, True, id="no-recorded-settings"),
            pytest.param({}, {"lr": 5e-5}, True, id="supplied-defaults"),
            pytest.param({"lr": 1e-5}, {"lr": 5e-5}, True, id="explicit-change"),
        ],
    )
    def test_config_built_from_a_complete_mapping_reapplies_supplied_settings(
        self, explicit: dict[str, float], args: dict[str, float] | None, reapplies: bool
    ) -> None:
        """Full mappings explicitly supply all optimizer settings, including defaults."""
        config = TrainConfig(**TrainConfig(dataset_dir="data", **explicit).model_dump())
        assert bool(_adopt(config, args)._reapplied_param_group_settings) is reapplies

    @pytest.mark.parametrize(
        ("explicit", "args", "restarts"),
        [
            pytest.param({"lr": 1e-5}, {"lr": 5e-5}, True, id="lr-changed"),
            pytest.param({"lr_encoder": 1e-5}, {"lr_encoder": 5e-5}, True, id="lr-encoder-changed"),
            pytest.param({"lr": 5e-5}, {"lr": 5e-5}, False, id="lr-unchanged"),
            pytest.param({"weight_decay": 5e-4}, {"weight_decay": 1e-4}, False, id="weight-decay-changed"),
            pytest.param({"lr": 1e-5}, None, True, id="lr-without-recorded-settings"),
            pytest.param({"weight_decay": 5e-4}, None, False, id="weight-decay-without-recorded-settings"),
        ],
    )
    def test_restarts_groups_without_a_base_only_for_a_learning_rate_change(
        self, explicit: dict[str, float], args: dict[str, float] | None, restarts: bool
    ) -> None:
        """Groups without a base restart only for an lr change, the one case that cannot be rescaled from a base.

        Restarting is the only way to apply a new lr to a group saved without ``initial_lr``, and it loses the
        reductions of an older ``ReduceLROnPlateau`` checkpoint.
        """
        module = _adopt(TrainConfig(dataset_dir="data", **explicit), args)
        assert module._restarts_groups_without_base is restarts

    def test_names_explicit_settings_to_reapply(self) -> None:
        """Only the explicitly passed settings are named for re-application, in config order.

        Only the groups these feed are put back; the others keep what the checkpoint's optimizer holds.
        """
        module = _adopt(TrainConfig(dataset_dir="data", weight_decay=5e-4, lr=1e-5), {"lr_encoder": _CHECKPOINT_VALUE})
        assert module._reapplied_param_group_settings == ["lr", "weight_decay"]

    def test_other_ranks_resolve_same_settings(self) -> None:
        """Every DDP rank must build the same optimizer; only the logging is limited to rank zero."""
        module = _adopt(TrainConfig(dataset_dir="data", lr=1e-5), {"lr_encoder": _CHECKPOINT_VALUE}, global_rank=1)
        assert (module.train_config.lr_encoder, module._reapplied_param_group_settings) == (_CHECKPOINT_VALUE, ["lr"])

    def test_logs_restored_and_overridden_settings(self, rf_detr_caplog: pytest.LogCaptureFixture) -> None:
        """The log names settings restored from the checkpoint and those overridden explicitly."""
        _adopt(TrainConfig(dataset_dir="data", lr=1e-5), {"lr": 5e-5, "lr_encoder": 3e-4})
        assert "lr_encoder=0.0003 from the checkpoint; lr=1e-05 (was 5e-05) set explicitly" in rf_detr_caplog.text

    def test_explicit_setting_equal_to_checkpoint_is_not_logged_as_set(
        self, rf_detr_caplog: pytest.LogCaptureFixture
    ) -> None:
        """An explicit value equal to the checkpoint's is not logged as set explicitly."""
        _adopt(TrainConfig(dataset_dir="data", lr=5e-5), {"lr": 5e-5, "lr_encoder": 3e-4})
        assert "set explicitly" not in rf_detr_caplog.text

    def test_logs_nothing_off_rank_zero(self, rf_detr_caplog: pytest.LogCaptureFixture) -> None:
        """Ranks other than zero log nothing about the resolved settings."""
        _adopt(TrainConfig(dataset_dir="data", lr=1e-5), {"lr": 5e-5, "lr_encoder": 3e-4}, global_rank=1)
        assert rf_detr_caplog.text == ""

    @pytest.mark.parametrize(
        ("explicit", "warns"),
        [
            pytest.param({"lr": 1e-5}, True, id="some-set"),
            pytest.param({}, False, id="none-set"),
            pytest.param(dict.fromkeys(_PARAM_GROUP_SETTINGS, 1e-5), False, id="all-set"),
        ],
    )
    def test_checkpoint_without_recorded_settings_warns_only_when_defaults_replace_it(
        self, rf_detr_caplog: pytest.LogCaptureFixture, explicit: dict[str, float], warns: bool
    ) -> None:
        """A ``last.ckpt`` written before 1.11.1 has optimizer state but no ``args``.

        Resumed with none set it keeps its saved values; with all set nothing falls back to a default.
        """
        _adopt(TrainConfig(dataset_dir="data", **explicit), None)
        assert any(record.levelno == logging.WARNING for record in rf_detr_caplog.records) is warns

    def test_warning_names_settings_that_take_their_defaults(self, rf_detr_caplog: pytest.LogCaptureFixture) -> None:
        """The warning for a checkpoint without ``args`` lists the settings falling back to defaults."""
        _adopt(TrainConfig(dataset_dir="data", lr=1e-5), None)
        assert (
            "lr_encoder, lr_vit_layer_decay, lr_component_decay, weight_decay use their defaults" in rf_detr_caplog.text
        )


def _build_optimizer_and_scheduler(
    lrs: list[float], weight_decay: float, scheduler_kind: str
) -> tuple[torch.optim.Optimizer, Any]:
    """Configure an AdamW with one single-parameter group per learning rate, and the ``scheduler_kind`` scheduler.

    Args:
        lrs: Base learning rate of each parameter group.
        weight_decay: Weight decay of every group.
        scheduler_kind: ``"lambda"`` (halves every step), ``"warmup"`` (``LinearLR`` then ``LambdaLR``), ``"cosine"``
            (``CosineAnnealingLR`` over four steps down to ``eta_min=0.01``), ``"cosine-warmup"`` (two ``LinearLR``
            steps, then that cosine), ``"plateau"`` (halves on every step) or ``"plateau-floor"`` (the same with
            ``min_lr=0.02``).

    Returns:
        ``(optimizer, scheduler)``, both fresh.

    Examples:
        >>> optimizer, scheduler = _build_optimizer_and_scheduler([0.1, 0.2], 1e-4, "cosine")
        >>> scheduler.base_lrs, scheduler.eta_min
        ([0.1, 0.2], 0.01)
    """
    params = [torch.nn.Parameter(torch.zeros(1)) for _ in lrs]
    groups = [{"params": [param], "lr": lr} for param, lr in zip(params, lrs)]
    optimizer = torch.optim.AdamW(groups, weight_decay=weight_decay)
    scheduler: Any
    if scheduler_kind.startswith("plateau"):
        min_lr = 0.02 if scheduler_kind == "plateau-floor" else 0.0
        scheduler = ReduceLROnPlateau(optimizer, factor=0.5, patience=0, min_lr=min_lr)
        for group in optimizer.param_groups:
            group.setdefault("initial_lr", group["lr"])
    elif scheduler_kind == "warmup":
        warmup = LinearLR(optimizer, start_factor=0.1, total_iters=4)
        scheduler = SequentialLR(optimizer, [warmup, LambdaLR(optimizer, lambda _: 1.0)], milestones=[4])
    elif scheduler_kind == "cosine":
        scheduler = CosineAnnealingLR(optimizer, T_max=4, eta_min=0.01)
    elif scheduler_kind == "cosine-warmup":
        warmup = LinearLR(optimizer, start_factor=0.5, total_iters=2)
        scheduler = SequentialLR(
            optimizer, [warmup, CosineAnnealingLR(optimizer, T_max=4, eta_min=0.01)], milestones=[2]
        )
    else:
        scheduler = LambdaLR(optimizer, lambda step: 0.5**step)
    return optimizer, scheduler


def _restored_optimizer(
    restored_lrs: list[float], *, scheduler_kind: str, steps: int, restored_weight_decay: float = 1e-4
) -> tuple[torch.optim.Optimizer, Any]:
    """Build an AdamW and scheduler as Lightning leaves them after restoring a checkpoint trained at ``restored_lrs``.

    A first pair is configured at ``restored_lrs`` and stepped ``steps`` times. A second pair, configured at other
    learning rates as a resumed run would, then loads its state, which is what ``trainer.fit(ckpt_path=...)`` does.

    Args:
        restored_lrs: Base learning rate of each parameter group in the checkpoint.
        scheduler_kind: A kind of :func:`_build_optimizer_and_scheduler`.
        steps: Scheduler steps taken before the checkpoint was saved.
        restored_weight_decay: Weight decay recorded in the checkpoint.

    Returns:
        ``(optimizer, scheduler)`` holding the restored state.

    Examples:
        >>> optimizer, scheduler = _restored_optimizer([0.1, 0.2], scheduler_kind="lambda", steps=2)
        >>> [round(group["lr"], 4) for group in optimizer.param_groups], scheduler.base_lrs
        ([0.025, 0.05], [0.1, 0.2])
    """
    saved_optimizer, saved_scheduler = _build_optimizer_and_scheduler(
        restored_lrs, restored_weight_decay, scheduler_kind
    )
    for _ in range(steps):
        saved_optimizer.step()
        if scheduler_kind.startswith("plateau"):
            saved_scheduler.step(1.0)
        else:
            saved_scheduler.step()
    optimizer, scheduler = _build_optimizer_and_scheduler([0.9 for _ in restored_lrs], 0.9, scheduler_kind)
    optimizer.load_state_dict(saved_optimizer.state_dict())
    scheduler.load_state_dict(saved_scheduler.state_dict())
    return optimizer, scheduler


class TestApplyConfiguredParamGroupSettings:
    """After Lightning restores a checkpoint, each group takes the configured settings and keeps its progress."""

    def test_configured_lr_becomes_schedule_base(self) -> None:
        """The configured lr replaces each scheduler's base learning rate."""
        optimizer, scheduler = _restored_optimizer([0.1, 0.2], scheduler_kind="lambda", steps=2)
        _apply_configured_param_group_settings(optimizer, scheduler, [(0.01, 1e-4), (0.02, 1e-4)])
        assert scheduler.base_lrs == [0.01, 0.02]

    def test_configured_lr_becomes_group_initial_lr(self) -> None:
        """The configured lr replaces each group's ``initial_lr``."""
        optimizer, scheduler = _restored_optimizer([0.1, 0.2], scheduler_kind="lambda", steps=2)
        _apply_configured_param_group_settings(optimizer, scheduler, [(0.01, 1e-4), (0.02, 1e-4)])
        assert [group["initial_lr"] for group in optimizer.param_groups] == [0.01, 0.02]

    def test_schedule_progress_carries_over(self) -> None:
        """Two halvings were taken before the checkpoint, so the new base starts at a quarter."""
        optimizer, scheduler = _restored_optimizer([0.1, 0.2], scheduler_kind="lambda", steps=2)
        _apply_configured_param_group_settings(optimizer, scheduler, [(0.01, 1e-4), (0.02, 1e-4)])
        assert [group["lr"] for group in optimizer.param_groups] == pytest.approx([0.0025, 0.005])

    def test_next_scheduler_step_follows_configured_base(self) -> None:
        """The scheduler step after the resume follows the configured base."""
        optimizer, scheduler = _restored_optimizer([0.1, 0.2], scheduler_kind="lambda", steps=2)
        _apply_configured_param_group_settings(optimizer, scheduler, [(0.01, 1e-4), (0.02, 1e-4)])
        optimizer.step()
        scheduler.step()
        assert [group["lr"] for group in optimizer.param_groups] == pytest.approx([0.00125, 0.0025])

    def test_nested_warmup_scheduler_bases_follow(self) -> None:
        """Both members of a warmup ``SequentialLR`` take the configured base learning rates."""
        optimizer, scheduler = _restored_optimizer([0.1, 0.2], scheduler_kind="warmup", steps=2)
        _apply_configured_param_group_settings(optimizer, scheduler, [(0.01, 1e-4), (0.02, 1e-4)])
        assert [nested.base_lrs for nested in scheduler._schedulers] == [[0.01, 0.02], [0.01, 0.02]]

    def test_warmup_reaches_configured_lr(self) -> None:
        """A warmup resumed mid-ramp ends at the configured lr, not the saved one."""
        optimizer, scheduler = _restored_optimizer([0.1, 0.2], scheduler_kind="warmup", steps=2)
        _apply_configured_param_group_settings(optimizer, scheduler, [(0.01, 1e-4), (0.02, 1e-4)])
        for _ in range(4):
            optimizer.step()
            scheduler.step()
        assert [group["lr"] for group in optimizer.param_groups] == pytest.approx([0.01, 0.02])

    def test_plateau_reductions_carry_over(self) -> None:
        """Two reductions by half were taken before the checkpoint."""
        optimizer, scheduler = _restored_optimizer([0.1, 0.2], scheduler_kind="plateau", steps=3)
        _apply_configured_param_group_settings(optimizer, scheduler, [(0.01, 1e-4), (0.02, 1e-4)])
        assert [group["lr"] for group in optimizer.param_groups] == pytest.approx([0.0025, 0.005])

    @pytest.mark.parametrize(
        ("restart_without_base", "expected_lrs"),
        [
            pytest.param(True, [0.01, 0.02], id="lr-changed"),
            pytest.param(False, [0.025, 0.05], id="lr-unchanged"),
        ],
    )
    def test_group_without_a_recorded_base_restarts_only_when_asked(
        self, restart_without_base: bool, expected_lrs: list[float]
    ) -> None:
        """A group saved without ``initial_lr`` is rescaled to a new lr only when a restart is requested.

        ``ReduceLROnPlateau`` checkpoints written before this fix record no ``initial_lr`` to scale from; two reductions
        by half were taken.
        """
        optimizer, scheduler = _restored_optimizer([0.1, 0.2], scheduler_kind="plateau", steps=3)
        for group in optimizer.param_groups:
            del group["initial_lr"]
        _apply_configured_param_group_settings(
            optimizer, scheduler, [(0.01, 1e-4), (0.02, 1e-4)], restart_without_base=restart_without_base
        )
        assert [group["lr"] for group in optimizer.param_groups] == pytest.approx(expected_lrs)

    @pytest.mark.parametrize(
        ("drop_base", "configured", "restart_without_base", "message", "reported"),
        [
            pytest.param(
                True,
                [(0.1, 1e-4), (0.2, 1e-4)],
                False,
                "2 resumed parameter groups were saved without the learning rate they started from and no",
                True,
                id="kept-without-base",
            ),
            pytest.param(
                False, [(0.1, 1e-4), (0.2, 1e-4)], False, "saved without the learning rate", False, id="base-recorded"
            ),
            pytest.param(
                True,
                [(0.01, 1e-4), (0.02, 1e-4)],
                True,
                "2 resumed parameter groups were saved without the learning rate they started from",
                True,
                id="restarted-without-base",
            ),
        ],
    )
    def test_groups_without_recorded_base_are_reported(
        self,
        rf_detr_caplog: pytest.LogCaptureFixture,
        drop_base: bool,
        configured: list[tuple[float, float]],
        restart_without_base: bool,
        message: str,
        reported: bool,
    ) -> None:
        """Groups saved without ``initial_lr`` are logged when kept or restarted, and not when the base is recorded."""
        optimizer, scheduler = _restored_optimizer([0.1, 0.2], scheduler_kind="plateau", steps=3)
        if drop_base:
            for group in optimizer.param_groups:
                del group["initial_lr"]
        _apply_configured_param_group_settings(
            optimizer, scheduler, configured, restart_without_base=restart_without_base
        )
        assert (message in rf_detr_caplog.text) is reported

    def test_zero_restored_base_takes_configured_lr(self) -> None:
        """No schedule progress can be read off a group that trained at zero, so it starts at its configured lr."""
        optimizer, scheduler = _restored_optimizer([0.1, 0.0], scheduler_kind="lambda", steps=2)
        _apply_configured_param_group_settings(optimizer, scheduler, [(0.1, 1e-4), (0.02, 1e-4)])
        assert optimizer.param_groups[1]["lr"] == 0.02

    def test_configured_weight_decay_replaces_restored_one(self) -> None:
        """The configured weight decay replaces the restored one in every group."""
        optimizer, scheduler = _restored_optimizer([0.1, 0.2], scheduler_kind="lambda", steps=2)
        _apply_configured_param_group_settings(optimizer, scheduler, [(0.1, 5e-4), (0.2, 0.0)])
        assert [group["weight_decay"] for group in optimizer.param_groups] == [5e-4, 0.0]

    def test_unchanged_settings_leave_every_group_alone(self) -> None:
        """Settings equal to the restored ones change no group."""
        optimizer, scheduler = _restored_optimizer([0.1, 0.2], scheduler_kind="lambda", steps=2)
        assert _apply_configured_param_group_settings(optimizer, scheduler, [(0.1, 1e-4), (0.2, 1e-4)]) == 0

    def test_cosine_floor_is_kept_when_base_changes(self) -> None:
        """Half-way down a cosine to ``eta_min=0.01`` from 0.1 is 0.055; from 0.05 it is 0.03, not 0.055 / 2."""
        optimizer, scheduler = _restored_optimizer([0.1], scheduler_kind="cosine", steps=2)
        _apply_configured_param_group_settings(optimizer, scheduler, [(0.05, 1e-4)])
        assert optimizer.param_groups[0]["lr"] == pytest.approx(0.03)

    def test_cosine_continues_on_curve_of_configured_base(self) -> None:
        """After a resume the cosine continues on the curve of a fresh run at the configured base.

        One step after the resume is the third of the fresh run; the fourth would end both curves at ``eta_min`` and
        prove nothing.
        """
        optimizer, scheduler = _restored_optimizer([0.1], scheduler_kind="cosine", steps=2)
        _apply_configured_param_group_settings(optimizer, scheduler, [(0.05, 1e-4)])
        fresh_optimizer, fresh_scheduler = _build_optimizer_and_scheduler([0.05], 1e-4, "cosine")
        for _ in range(3):
            fresh_optimizer.step()
            fresh_scheduler.step()
        optimizer.step()
        scheduler.step()
        assert optimizer.param_groups[0]["lr"] == pytest.approx(fresh_optimizer.param_groups[0]["lr"])

    def test_plateau_never_drops_below_its_floor(self) -> None:
        """Two halvings of 0.1 gave 0.025; a base of 0.04 would rescale that to 0.01, under ``min_lr=0.02``."""
        optimizer, scheduler = _restored_optimizer([0.1], scheduler_kind="plateau-floor", steps=3)
        _apply_configured_param_group_settings(optimizer, scheduler, [(0.04, 1e-4)])
        assert optimizer.param_groups[0]["lr"] == 0.02

    def test_plateau_floor_never_lifts_rate_above_a_base_below_it(self) -> None:
        """A fresh plateau never raises the rate, so a base under ``min_lr`` stays where it was set."""
        optimizer, scheduler = _restored_optimizer([0.1], scheduler_kind="plateau-floor", steps=3)
        _apply_configured_param_group_settings(optimizer, scheduler, [(0.01, 1e-4)])
        assert optimizer.param_groups[0]["lr"] == 0.01

    def test_plateau_reductions_above_floor_scale_with_base(self) -> None:
        """Reductions above ``min_lr`` scale proportionally with the new base."""
        optimizer, scheduler = _restored_optimizer([0.1], scheduler_kind="plateau-floor", steps=3)
        _apply_configured_param_group_settings(optimizer, scheduler, [(0.2, 1e-4)])
        assert optimizer.param_groups[0]["lr"] == pytest.approx(0.05)

    @pytest.mark.parametrize("steps", [3, 4])
    def test_cosine_behind_a_warmup_continues_on_curve_of_configured_base(self, steps: int) -> None:
        """A cosine behind a warmup continues on the curve of a fresh run at the configured base.

        An explicit cosine with ``warmup_epochs > 0`` is always wrapped in a ``SequentialLR``; its ``eta_min`` is the
        floor once the warmup is over.
        """
        optimizer, scheduler = _restored_optimizer([0.1], scheduler_kind="cosine-warmup", steps=steps)
        _apply_configured_param_group_settings(optimizer, scheduler, [(0.05, 1e-4)])
        fresh_optimizer, fresh_scheduler = _build_optimizer_and_scheduler([0.05], 1e-4, "cosine-warmup")
        for _ in range(steps + 1):
            fresh_optimizer.step()
            fresh_scheduler.step()
        optimizer.step()
        scheduler.step()
        assert optimizer.param_groups[0]["lr"] == pytest.approx(fresh_optimizer.param_groups[0]["lr"])

    def test_cosine_during_warmup_scales_with_base(self) -> None:
        """Before the milestone the warmup ramp sets the rate, and it scales with its base."""
        optimizer, scheduler = _restored_optimizer([0.1], scheduler_kind="cosine-warmup", steps=1)
        before = optimizer.param_groups[0]["lr"]
        _apply_configured_param_group_settings(optimizer, scheduler, [(0.05, 1e-4)])
        assert optimizer.param_groups[0]["lr"] == pytest.approx(before / 2)

    def test_group_based_at_cosine_floor_takes_proportional_rescale(self) -> None:
        """A base equal to ``eta_min`` leaves no distance to scale, which would divide by zero."""
        optimizer, scheduler = _restored_optimizer([0.01], scheduler_kind="cosine", steps=2)
        _apply_configured_param_group_settings(optimizer, scheduler, [(0.05, 1e-4)])
        assert optimizer.param_groups[0]["lr"] == pytest.approx(0.05)

    def test_plateau_floor_is_read_per_group(self) -> None:
        """``min_lr`` may be a list with one floor per group."""
        optimizer, scheduler = _restored_optimizer([0.1, 0.1], scheduler_kind="plateau-floor", steps=3)
        scheduler.min_lrs = [0.001, 0.02]
        _apply_configured_param_group_settings(optimizer, scheduler, [(0.04, 1e-4), (0.04, 1e-4)])
        assert [group["lr"] for group in optimizer.param_groups] == pytest.approx([0.01, 0.02])

    def test_group_whose_configured_lr_is_unset_keeps_its_restored_lr(self) -> None:
        """``None`` marks a group no explicit setting feeds; its weight decay may still be applied."""
        optimizer, scheduler = _restored_optimizer([0.1, 0.2], scheduler_kind="lambda", steps=2)
        _apply_configured_param_group_settings(optimizer, scheduler, [(None, 5e-4), (0.02, None)])
        assert [group["lr"] for group in optimizer.param_groups] == pytest.approx([0.025, 0.005])
        assert [group["weight_decay"] for group in optimizer.param_groups] == pytest.approx([5e-4, 1e-4])


@pytest.fixture(scope="module")
def nano_model_and_args() -> tuple[torch.nn.Module, SimpleNamespace]:
    """An untrained Nano and the namespace its parameter groups are built from.

    Examples:
        >>> nano_model_and_args  # doctest: +SKIP
        A module-scoped pytest fixture that builds a model.
    """
    seed_all(_TRAIN_SEED)
    detector = RFDETRNano(pretrain_weights=None, resolution=224, device="cpu")
    args = _namespace_from_configs(detector.model_config, TrainConfig(dataset_dir="data"))
    return detector.model.model, args


def _masked_nano_settings(
    names: list[str], model: torch.nn.Module, args: SimpleNamespace
) -> tuple[list[tuple[float | None, float | None]], list[bool]]:
    """Mask the configured settings of Nano's optimizer by ``names``; also flag its encoder groups.

    Args:
        names: The settings passed explicitly.
        model: The model the optimizer is built for.
        args: Namespace the parameter groups are built from.

    Returns:
        ``(masked, is_encoder)`` per optimizer parameter group.

    Examples:
        >>> detector = RFDETRNano(pretrain_weights=None, resolution=224, device="cpu")
        >>> args = _namespace_from_configs(detector.model_config, TrainConfig(dataset_dir="data"))
        >>> masked, is_encoder = _masked_nano_settings(["lr_encoder"], detector.model.model, args)
        >>> {weight_decay for _, weight_decay in masked}, any(is_encoder)
        ({None}, True)
    """
    optimizer = torch.optim.AdamW(get_param_dict(args, model), lr=args.lr, weight_decay=args.weight_decay)
    configured = [(group["lr"], group["weight_decay"]) for group in optimizer.param_groups]
    encoder = {id(param) for name, param in model.named_parameters() if "backbone.0.encoder" in name}
    is_encoder = [all(id(param) in encoder for param in group["params"]) for group in optimizer.param_groups]
    return (
        _configured_settings_fed_by(names, configured, optimizer, args, lambda probe: get_param_dict(probe, model)),
        is_encoder,
    )


class TestConfiguredSettingsFedBy:
    """Only the groups an explicit setting feeds take the configured value; the others keep the restored one."""

    def test_lr_encoder_feeds_only_encoder_learning_rates(
        self, nano_model_and_args: tuple[torch.nn.Module, SimpleNamespace]
    ) -> None:
        """``lr_encoder`` feeds the encoder groups' learning rates and no other group's."""
        masked, is_encoder = _masked_nano_settings(["lr_encoder"], *nano_model_and_args)
        assert [lr is not None for lr, _ in masked] == is_encoder

    def test_lr_encoder_feeds_no_weight_decay(
        self, nano_model_and_args: tuple[torch.nn.Module, SimpleNamespace]
    ) -> None:
        """``lr_encoder`` feeds no group's weight decay."""
        masked, _ = _masked_nano_settings(["lr_encoder"], *nano_model_and_args)
        assert {weight_decay for _, weight_decay in masked} == {None}

    def test_weight_decay_feeds_no_learning_rate(
        self, nano_model_and_args: tuple[torch.nn.Module, SimpleNamespace]
    ) -> None:
        """``weight_decay`` feeds no group's learning rate."""
        masked, _ = _masked_nano_settings(["weight_decay"], *nano_model_and_args)
        assert {lr for lr, _ in masked} == {None}

    def test_weight_decay_skips_parameters_exempt_from_it(
        self, nano_model_and_args: tuple[torch.nn.Module, SimpleNamespace]
    ) -> None:
        """Biases and norms of the encoder have a weight decay of zero whatever ``weight_decay`` is."""
        masked, is_encoder = _masked_nano_settings(["weight_decay"], *nano_model_and_args)
        assert any(weight_decay is None for (_, weight_decay), encoder in zip(masked, is_encoder) if encoder)

    def test_lr_feeds_groups_built_from_it(self, nano_model_and_args: tuple[torch.nn.Module, SimpleNamespace]) -> None:
        """``lr`` feeds every non-encoder group's learning rate."""
        masked, is_encoder = _masked_nano_settings(["lr"], *nano_model_and_args)
        assert all(lr is not None for (lr, _), encoder in zip(masked, is_encoder) if not encoder)

    def test_lr_does_not_feed_encoder(self, nano_model_and_args: tuple[torch.nn.Module, SimpleNamespace]) -> None:
        """``lr`` feeds no encoder group's learning rate."""
        masked, is_encoder = _masked_nano_settings(["lr"], *nano_model_and_args)
        assert all(lr is None for (lr, _), encoder in zip(masked, is_encoder) if encoder)

    def test_weight_decay_feeds_groups_that_inherit_it(
        self, nano_model_and_args: tuple[torch.nn.Module, SimpleNamespace]
    ) -> None:
        """Non-encoder groups are fed by ``weight_decay``.

        The head and decoder groups carry no ``weight_decay`` of their own; the optimizer's default is the setting.
        """
        masked, is_encoder = _masked_nano_settings(["weight_decay"], *nano_model_and_args)
        assert all(weight_decay is not None for (_, weight_decay), encoder in zip(masked, is_encoder) if not encoder)

    def test_no_explicit_setting_feeds_nothing(
        self, nano_model_and_args: tuple[torch.nn.Module, SimpleNamespace]
    ) -> None:
        """Without explicit settings no group's learning rate or weight decay is fed."""
        masked, _ = _masked_nano_settings([], *nano_model_and_args)
        assert set(masked) == {(None, None)}

    def test_group_is_fed_when_any_of_its_parameters_is(self) -> None:
        """Parameters configured alike share a group; one that a setting moves feeds the whole group."""
        moved, still = torch.nn.Parameter(torch.zeros(1)), torch.nn.Parameter(torch.zeros(1))
        args = SimpleNamespace(lr=1e-4, lr_encoder=1e-3, weight_decay=1e-4)

        def build(namespace: SimpleNamespace) -> list[dict[str, Any]]:
            """Two parameters with one rate, of which only the first follows ``lr_encoder``."""
            return [{"params": moved, "lr": namespace.lr_encoder}, {"params": still, "lr": 1e-3}]

        optimizer = torch.optim.AdamW([{"params": [moved, still]}], lr=1e-3, weight_decay=1e-4)
        assert _configured_settings_fed_by(["lr_encoder"], [(1e-3, 1e-4)], optimizer, args, build) == [(1e-3, None)]

    def test_group_inheriting_weight_decay_is_fed_when_any_of_its_parameters_is(self) -> None:
        """One member inherits ``weight_decay``, the other has a weight decay of its own."""
        inheriting, own = torch.nn.Parameter(torch.zeros(1)), torch.nn.Parameter(torch.zeros(1))
        args = SimpleNamespace(lr=1e-4, weight_decay=1e-4)

        def build(namespace: SimpleNamespace) -> list[dict[str, Any]]:
            """One parameter that inherits the optimizer's weight decay, one that sets its own."""
            return [{"params": inheriting, "lr": 1e-4}, {"params": own, "lr": 1e-4, "weight_decay": 1e-4}]

        optimizer = torch.optim.AdamW([{"params": [inheriting, own]}], lr=1e-4, weight_decay=1e-4)
        assert _configured_settings_fed_by(["weight_decay"], [(1e-4, 1e-4)], optimizer, args, build) == [(None, 1e-4)]

    def test_leaves_namespace_it_probes_with_untouched(
        self, nano_model_and_args: tuple[torch.nn.Module, SimpleNamespace]
    ) -> None:
        """Probing the groups leaves the caller's namespace unchanged."""
        model, args = nano_model_and_args
        before = {name: getattr(args, name) for name in _PARAM_GROUP_SETTINGS}
        _masked_nano_settings(list(_PARAM_GROUP_SETTINGS), model, args)
        assert {name: getattr(args, name) for name in _PARAM_GROUP_SETTINGS} == before


@pytest.fixture(scope="module")
def dataset_dir(tmp_path_factory: pytest.TempPathFactory) -> Path:
    """A tiny synthetic COCO detection dataset.

    Examples:
        >>> dataset_dir  # doctest: +SKIP
        A module-scoped pytest fixture; it needs tmp_path_factory.
    """
    path = tmp_path_factory.mktemp("resume_optimizer_settings_dataset")
    build_synthetic_dataset(path, task="detection", num_images=16)
    return path


@pytest.fixture(scope="module")
def training_runs(dataset_dir: Path, tmp_path_factory: pytest.TempPathFactory) -> tuple[Path, Path]:
    """Train one epoch at :data:`_FIRST_RUN`, then resume it for a second with :data:`_RESUMED_RUN` set explicitly.

    Returns:
        The output directories of the first and the resumed run.

    Examples:
        >>> training_runs  # doctest: +SKIP
        A module-scoped pytest fixture that trains a model twice.
    """
    seed_all(_TRAIN_SEED)
    first_output_dir = tmp_path_factory.mktemp("resume_optimizer_settings_first")
    RFDETRNano(pretrain_weights=None, resolution=224, device="cpu").train(
        dataset_dir=str(dataset_dir), output_dir=str(first_output_dir), epochs=1, **_FIRST_RUN, **_TRAIN_KWARGS
    )
    resumed_output_dir = tmp_path_factory.mktemp("resume_optimizer_settings_resumed")
    RFDETRNano(pretrain_weights=None, resolution=224, device="cpu").train(
        dataset_dir=str(dataset_dir),
        output_dir=str(resumed_output_dir),
        epochs=2,
        resume=str(first_output_dir / "last.ckpt"),
        **_RESUMED_RUN,
        **_TRAIN_KWARGS,
    )
    return first_output_dir, resumed_output_dir


@pytest.fixture(scope="module")
def stale_args_resumed_ckpt(
    dataset_dir: Path, training_runs: tuple[Path, Path], tmp_path_factory: pytest.TempPathFactory
) -> dict[str, Any]:
    """Resume a first-run ``last.ckpt`` whose ``args.lr`` says :data:`_RESUMED_RUN`, passing that ``lr`` again.

    A resume on rfdetr 1.11.1 or 1.11.2 with a changed ``lr`` wrote such a file: ``args`` recorded the new ``lr`` while
    its optimizer kept training at the old one (#1613). Its author then resumes with the ``lr`` they asked for.

    Returns:
        The ``last.ckpt`` of that resumed run.

    Examples:
        >>> stale_args_resumed_ckpt  # doctest: +SKIP
        A module-scoped pytest fixture that trains a model.
    """
    seed_all(_TRAIN_SEED)
    stale_dir = tmp_path_factory.mktemp("resume_optimizer_settings_stale_args")
    checkpoint = torch.load(training_runs[0] / "last.ckpt", map_location="cpu", weights_only=True)
    checkpoint["args"]["lr"] = _RESUMED_RUN["lr"]
    torch.save(checkpoint, stale_dir / "stale.ckpt")
    RFDETRNano(pretrain_weights=None, resolution=224, device="cpu").train(
        dataset_dir=str(dataset_dir),
        output_dir=str(stale_dir),
        epochs=2,
        resume=str(stale_dir / "stale.ckpt"),
        lr=_RESUMED_RUN["lr"],
        **_TRAIN_KWARGS,
    )
    return torch.load(stale_dir / "last.ckpt", map_location="cpu", weights_only=True)


@pytest.fixture(scope="module")
def stale_omitted_setting_ckpt(
    dataset_dir: Path, training_runs: tuple[Path, Path], tmp_path_factory: pytest.TempPathFactory
) -> dict[str, Any]:
    """Resume a first-run ``last.ckpt`` whose ``args.lr_encoder`` is stale, passing only ``weight_decay``.

    The optimizer of the first run trained its encoder at :data:`_FIRST_RUN`'s ``lr_encoder``; a resume on 1.11.1 or
    1.11.2 that changed ``lr_encoder`` recorded one its optimizer never used (#1613).

    Returns:
        The ``last.ckpt`` of that resumed run.

    Examples:
        >>> stale_omitted_setting_ckpt  # doctest: +SKIP
        A module-scoped pytest fixture that trains a model.
    """
    seed_all(_TRAIN_SEED)
    stale_dir = tmp_path_factory.mktemp("resume_optimizer_settings_stale_omitted")
    checkpoint = torch.load(training_runs[0] / "last.ckpt", map_location="cpu", weights_only=True)
    checkpoint["args"]["lr_encoder"] = _CHECKPOINT_VALUE
    torch.save(checkpoint, stale_dir / "stale.ckpt")
    RFDETRNano(pretrain_weights=None, resolution=224, device="cpu").train(
        dataset_dir=str(dataset_dir),
        output_dir=str(stale_dir),
        epochs=2,
        resume=str(stale_dir / "stale.ckpt"),
        weight_decay=_RESUMED_RUN["weight_decay"],
        **_TRAIN_KWARGS,
    )
    return torch.load(stale_dir / "last.ckpt", map_location="cpu", weights_only=True)


@pytest.fixture(scope="module")
def last_ckpts(training_runs: tuple[Path, Path]) -> tuple[dict[str, Any], dict[str, Any]]:
    """The ``last.ckpt`` of the first run and of the resumed run.

    Examples:
        >>> last_ckpts  # doctest: +SKIP
        A module-scoped pytest fixture over the training runs.
    """
    return tuple(  # type: ignore[return-value]
        torch.load(output_dir / "last.ckpt", map_location="cpu", weights_only=True) for output_dir in training_runs
    )


@pytest.fixture(scope="module")
def resumed_training_config(training_runs: tuple[Path, Path]) -> dict[str, Any]:
    """The ``train_config`` section of the resumed run's ``training_config.json``.

    Examples:
        >>> resumed_training_config  # doctest: +SKIP
        A module-scoped pytest fixture over the training runs.
    """
    return json.loads((training_runs[1] / "training_config.json").read_text())["train_config"]


class TestResumeWithChangedSettings:
    """The issue's scenario: stop a run, change ``lr``, resume from ``last.ckpt``."""

    def test_schedule_follows_explicit_lr_and_restored_lr_encoder(
        self, last_ckpts: tuple[dict[str, Any], dict[str, Any]]
    ) -> None:
        """Resumed base learning rates follow the explicit ``lr`` for its groups and keep the restored ``lr_encoder``.

        Groups trained at ``lr`` (and the decoder's ``lr * lr_component_decay``) move to the new ``lr``; the backbone's,
        built from the unchanged ``lr_encoder``, stay where they were.
        """
        first, resumed = last_ckpts
        component_decay = TrainConfig.model_fields["lr_component_decay"].default
        new_base = {
            _FIRST_RUN["lr"]: _RESUMED_RUN["lr"],
            _FIRST_RUN["lr"] * component_decay: _RESUMED_RUN["lr"] * component_decay,
        }
        expected = [new_base.get(base, base) for base in first["lr_schedulers"][0]["base_lrs"]]
        assert resumed["lr_schedulers"][0]["base_lrs"] == expected

    def test_explicit_weight_decay_applies_where_group_decays(
        self, last_ckpts: tuple[dict[str, Any], dict[str, Any]]
    ) -> None:
        """Parameters exempt from weight decay (biases, norms) keep zero."""
        first, resumed = last_ckpts
        expected = [
            0.0 if group["weight_decay"] == 0.0 else _RESUMED_RUN["weight_decay"]
            for group in first["optimizer_states"][0]["param_groups"]
        ]
        assert [group["weight_decay"] for group in resumed["optimizer_states"][0]["param_groups"]] == expected

    def test_explicit_lr_applies_over_stale_recorded_args(self, stale_args_resumed_ckpt: dict[str, Any]) -> None:
        """The issue's own checkpoint, after the upgrade: ``args`` already say the new ``lr``."""
        assert stale_args_resumed_ckpt["lr_schedulers"][0]["base_lrs"][0] == _RESUMED_RUN["lr"]

    def test_omitted_setting_keeps_optimizer_value_over_stale_recorded_args(
        self, last_ckpts: tuple[dict[str, Any], dict[str, Any]], stale_omitted_setting_ckpt: dict[str, Any]
    ) -> None:
        """Only ``weight_decay`` is passed, so no learning rate moves, whatever ``args`` says about ``lr_encoder``."""
        assert (
            stale_omitted_setting_ckpt["lr_schedulers"][0]["base_lrs"] == last_ckpts[0]["lr_schedulers"][0]["base_lrs"]
        )

    @pytest.mark.parametrize("setting", ["lr", "lr_encoder", "weight_decay"])
    def test_training_config_records_what_ran(self, resumed_training_config: dict[str, Any], setting: str) -> None:
        """``training_config.json`` records the resumed run's effective setting."""
        assert resumed_training_config[setting] == {**_FIRST_RUN, **_RESUMED_RUN}[setting]

    @pytest.mark.parametrize("setting", ["lr", "lr_encoder", "weight_decay"])
    def test_checkpoint_args_record_what_ran(
        self, last_ckpts: tuple[dict[str, Any], dict[str, Any]], setting: str
    ) -> None:
        """The resumed ``last.ckpt`` ``args`` record the resumed run's effective setting."""
        assert last_ckpts[1]["args"][setting] == {**_FIRST_RUN, **_RESUMED_RUN}[setting]
