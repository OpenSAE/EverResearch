# Notebooks

Each `.ipynb` file here is rendered as a page under `/cookbooks/` in the docs site.

Cards on the cookbooks landing page are driven by [`cards.yaml`](cards.yaml). The MkDocs hook `docs/hooks/cookbooks_cards.py` loads that file and exposes it to `docs/theme/notebooks.html`, which renders each entry as a card via a Jinja loop.

## Converting a jupytext `.py` to `.ipynb`

Cookbook source files live as jupytext percent-format `.py` scripts (e.g. `fine-tune_keypoints.py`) inside `docs/cookbooks/`. Each script requires at minimum a **docs render copy**; some also have a `notebooks/` copy for users who want to run it directly. Regenerate every existing copy after each edit:

```bash
# Docs render copy (served by mkdocs-jupyter at /cookbooks/) — always required
jupytext --to notebook fine-tune_keypoints.py --output docs/cookbooks/fine-tune_keypoints.ipynb

# Runnable copy in notebooks/ — only for notebooks explicitly placed there
jupytext --to notebook fine-tune_keypoints.py --output notebooks/fine-tune_keypoints.ipynb
```

New notebooks default to the docs-only copy. Add a `notebooks/` copy only when there is an explicit need (e.g. a runnable starter notebook shipped with the repo). Omit `--execute` — notebooks are rendered statically by `mkdocs-jupyter` with `execute: false`, so pre-run outputs in the `.ipynb` are displayed as-is.

If jupytext is not installed: `pip install jupytext` (or `uv add jupytext --dev`).

## Adding a notebook

1. Add the `.ipynb` file here, named after its content (e.g. `custom-augmentations.ipynb`, `onnx-export.ipynb`).
2. Add a new entry to `docs/cookbooks/cards.yaml` under the `cards:` list:

<!-- prettier-ignore -->

```yaml
  - href: content-slug/
    name: Short Title
    labels: [LABEL1, LABEL2]
    version: vX.Y.0
    author: GitHubUsername
    description: One sentence describing what the notebook demonstrates.
```

Available labels (reuse these to keep tags standardised): `TRAINING`, `AUGMENTATION`, `EXPORT`, `TFLITE`, `PYTORCH LIGHTNING`, `INFERENCE`, `SEGMENTATION`, `DEPLOY`, `CUDA`, `CPU`, `MOBILE`, `APPLE`, `COCO2017`. Current tag colours are assigned dynamically by the docs UI, so they may change if cards or labels are added or reordered.

For newly added or updated notebooks, write markdown cells in plain, notebook-portable Markdown only — no MkDocs Material syntax (`!!! note`, `=== "Tab"`, admonition blocks). `mkdocs-jupyter` renders the site copy through the same plain renderer as a raw `.ipynb`, so MkDocs-only syntax shows up as literal text (e.g. `!!! warning "..."`) instead of a styled callout. Use a blockquote (`> **Note:** ...`) for callouts instead.

## Removing a notebook

1. Delete the `.ipynb` file.
2. Remove the matching entry (the `- href: content-slug/` block) from `docs/cookbooks/cards.yaml`.

## Current notebooks

| File                                    | Card title                                             | Version |
| --------------------------------------- | ------------------------------------------------------ | ------- |
| `coco-accuracy.ipynb`                   | Reproduce the COCO Accuracy of Pretrained Models       | v1.13.0 |
| `custom-augmentations.ipynb`            | Custom Augmentations and Live Training Progress        | v1.5.0  |
| `custom-optimizer-scheduler.ipynb`      | Custom Optimizer and LR Scheduler                      | v1.9.0  |
| `export-cuda.ipynb`                     | RF-DETR on NVIDIA GPUs — Export, Inference & Latency   | v1.11.0 |
| `export-cpu.ipynb`                      | RF-DETR on CPU — Export, Inference & Latency           | v1.11.0 |
| `export-mobile.ipynb`                   | RF-DETR on Mobile & Edge — Export, Inference & Latency | v1.11.0 |
| `export-apple.ipynb`                    | RF-DETR on Apple Silicon — Export, Inference & Latency | v1.11.0 |
| `measure-latency.ipynb`                 | Find the Fastest RF-DETR Configuration on Your GPU     | v1.13.0 |
| `multi-source-rf100vl.ipynb`            | Train on RF100-VL sources with size-balanced weights   | v1.13.0 |
| `fine-tune_detection.ipynb`             | Fine-Tune RF-DETR Object Detection                     | v1.8.0  |
| `fine-tune_keypoints.ipynb`             | Fine-Tune RF-DETR Keypoint Detection                   | v1.8.0  |
| `fine-tune_segmentation.ipynb`          | Fine-Tune RF-DETR Instance Segmentation                | v1.8.2  |
| `per-class-confidence-thresholds.ipynb` | Per-Class Confidence Thresholds                        | v1.12.0 |
| `pytorch-lightning.ipynb`               | Training with PyTorch Lightning                        | v1.6.0  |
| `train-coco2017.ipynb`                  | Train RF-DETR Nano on COCO2017                         | v1.10.0 |
