# ------------------------------------------------------------------------
# RF-DETR
# Copyright (c) 2025 Roboflow. All Rights Reserved.
# Licensed under the Apache License, Version 2.0 [see LICENSE for details]
# ------------------------------------------------------------------------
"""Tests for the encoder registry that lets extension packages plug a non-DINOv2 encoder into ``build_backbone``."""

from __future__ import annotations

from typing import Any, Literal

import pytest
import torch
from torch import Tensor, nn

from rfdetr.config import RFDETRNanoConfig
from rfdetr.inference import _build_model_context
from rfdetr.models import backbone as backbone_pkg
from rfdetr.models.backbone import Joiner, build_backbone, register_backbone
from rfdetr.models.backbone.backbone import Backbone
from rfdetr.models.backbone.dinov2 import DinoV2
from rfdetr.utilities.tensors import NestedTensor


class _ToyEncoder(nn.Module):
    """Stand-in encoder: one conv whose output is repeated once per requested feature level.

    Examples:
        >>> [tuple(feature.shape) for feature in _ToyEncoder(num_levels=2)(torch.zeros(1, 3, 8, 8))]
        [(1, 8, 2, 2), (1, 8, 2, 2)]
    """

    def __init__(self, num_levels: int, channels: int = 8, patch_size: int = 4) -> None:
        super().__init__()
        self.proj = nn.Conv2d(3, channels, kernel_size=patch_size, stride=patch_size)
        self.num_levels = num_levels
        self._out_feature_channels = [channels] * num_levels

    def forward(self, x: Tensor) -> list[Tensor]:
        """Return the patch projection once per feature level."""
        feat = self.proj(x)
        return [feat] * self.num_levels


class _ToyBackbone(Backbone):
    """Backbone subclass that swaps in ``_ToyEncoder`` and records the kwargs it was built with.

    Examples:
        >>> backbone = _ToyBackbone.__new__(_ToyBackbone)  # skips Backbone.__init__, which builds the encoder
        >>> backbone._build_encoder("toy_encoder", out_feature_indexes=[2, 5], patch_size=4).num_levels
        2
        >>> _ToyBackbone.received["name"]
        'toy_encoder'
    """

    received: dict[str, Any] = {}

    def _build_encoder(self, name: str, **kwargs: Any) -> nn.Module:
        """Record the build arguments and return a ``_ToyEncoder`` with one level per output feature index."""
        type(self).received = {"name": name, **kwargs}
        return _ToyEncoder(num_levels=len(kwargs["out_feature_indexes"]), patch_size=kwargs["patch_size"])


def _build(encoder: str, **overrides: Any) -> Joiner:
    """Call ``build_backbone`` for *encoder* with small test arguments, updated by *overrides*.

    Examples:
        >>> kwargs = {"out_feature_indexes": [12], "projector_scale": ["P3"], "patch_size": 16, "num_windows": 1}
        >>> type(_build("dinov2_windowed_small", **kwargs)[0]).__name__
        'Backbone'
    """
    kwargs: dict[str, Any] = dict(
        encoder=encoder,
        vit_encoder_num_layers=12,
        pretrained_encoder=None,
        window_block_indexes=None,
        drop_path=0.0,
        out_channels=16,
        out_feature_indexes=[2, 5, 8, 11],
        projector_scale=["P4"],
        use_cls_token=False,
        hidden_dim=16,
        position_embedding="sine",
        freeze_encoder=False,
        layer_norm=True,
        target_shape=(64, 64),
        rms_norm=False,
        backbone_lora=False,
        force_no_pretrain=False,
        gradient_checkpointing=False,
        load_dinov2_weights=False,
        patch_size=4,
        num_windows=2,
        positional_encoding_size=16,
    )
    kwargs.update(overrides)
    return build_backbone(**kwargs)


@pytest.fixture(autouse=True)
def _isolated_registry(mocker) -> None:
    """Restore the module-level registry after every test so registrations never leak.

    Examples:
        Fixture execution is managed by pytest, so this example cannot run standalone.
        >>> _isolated_registry()  # doctest: +SKIP
    """
    mocker.patch.dict(backbone_pkg._BACKBONE_REGISTRY)


class TestRegisterBackbone:
    """``register_backbone`` validation and idempotence."""

    def test_registered_class_builds_the_backbone(self) -> None:
        """``build_backbone`` returns a Joiner wrapping the registered Backbone subclass and its encoder."""
        register_backbone("toy_encoder", _ToyBackbone)

        joiner = _build("toy_encoder")

        assert isinstance(joiner, Joiner)
        assert type(joiner[0]) is _ToyBackbone
        assert isinstance(joiner[0].encoder, _ToyEncoder)

    def test_encoder_receives_the_build_arguments(self) -> None:
        """The registered backbone's ``_build_encoder`` receives the build arguments, including per-call overrides."""
        register_backbone("toy_encoder", _ToyBackbone)

        _build("toy_encoder", window_block_indexes=[0, 1], drop_path=0.1, gradient_checkpointing=True)

        assert _ToyBackbone.received == {
            "name": "toy_encoder",
            "out_feature_indexes": [2, 5, 8, 11],
            "target_shape": (64, 64),
            "gradient_checkpointing": True,
            "load_pretrained_weights": False,
            "patch_size": 4,
            "num_windows": 2,
            "positional_encoding_size": 16,
            "drop_path": 0.1,
            "window_block_indexes": [0, 1],
        }

    def test_registered_backbone_keeps_core_projector_and_masks(self) -> None:
        """The subclass only replaces the encoder; the projector and padding-mask plumbing stay core's."""
        register_backbone("toy_encoder", _ToyBackbone)
        joiner = _build("toy_encoder")
        images = torch.randn(2, 3, 64, 64)
        mask = torch.zeros(2, 64, 64, dtype=torch.bool)
        mask[1, :, 32:] = True

        features, poss, cross = joiner(NestedTensor(images, mask))

        assert cross is None
        assert [tuple(f.tensors.shape) for f in features] == [(2, 16, 16, 16)]
        assert features[0].mask[1, :, 8:].all() and not features[0].mask[0].any()
        assert tuple(poss[0].shape) == (2, 16, 16, 16)

    def test_re_registering_the_same_class_is_a_no_op(self) -> None:
        """Registering the same class under the same name twice is accepted and leaves the registry unchanged."""
        register_backbone("toy_encoder", _ToyBackbone)
        register_backbone("toy_encoder", _ToyBackbone)

        assert backbone_pkg._BACKBONE_REGISTRY["toy_encoder"] is _ToyBackbone

    def test_conflicting_registration_raises(self) -> None:
        """Registering a different class under an already-registered name raises ValueError."""
        register_backbone("toy_encoder", _ToyBackbone)

        class _OtherBackbone(_ToyBackbone):
            pass

        with pytest.raises(ValueError, match="already registered"):
            register_backbone("toy_encoder", _OtherBackbone)

    @pytest.mark.parametrize(
        "backbone_cls",
        [
            pytest.param(nn.Module, id="not-a-backbone-subclass"),
            pytest.param(_ToyEncoder(num_levels=1), id="instance-not-class"),
        ],
    )
    def test_non_backbone_class_raises(self, backbone_cls: Any) -> None:
        """Anything that is not a Backbone subclass (a plain Module class or an instance) raises TypeError."""
        with pytest.raises(TypeError, match="Backbone subclass"):
            register_backbone("toy_encoder", backbone_cls)

    @pytest.mark.parametrize("encoder", ["dinov2_windowed_small", "dinov2_windowed_base", "dinov2_base"])
    def test_dinov2_encoder_names_cannot_be_registered(self, encoder: str) -> None:
        """Every name Backbone would parse as DINOv2 stays DINOv2, including ones outside EncoderName."""
        with pytest.raises(ValueError, match="DINOv2"):
            register_backbone(encoder, _ToyBackbone)


class TestUnregisteredEncoders:
    """Encoders without a registration keep the DINOv2 path unchanged."""

    def test_dinov2_name_builds_core_backbone(self) -> None:
        """A DINOv2 encoder name still builds the core Backbone with a DinoV2 encoder, whatever else is registered."""
        register_backbone("toy_encoder", _ToyBackbone)

        joiner = _build(
            "dinov2_windowed_small", out_feature_indexes=[12], projector_scale=["P3"], patch_size=16, num_windows=1
        )

        assert type(joiner[0]) is Backbone
        assert isinstance(joiner[0].encoder, DinoV2)

    def test_unknown_non_dinov2_name_names_the_registered_encoders(self) -> None:
        """An unknown, non-DINOv2 encoder name raises ValueError listing exactly the registered encoders."""
        register_backbone("toy_encoder", _ToyBackbone)
        # Exactly the registry's contents: an installed extension package (e.g. rfdetr_plus) adds its own encoders.
        registered = ", ".join(sorted(backbone_pkg._BACKBONE_REGISTRY))
        assert "toy_encoder" in backbone_pkg._BACKBONE_REGISTRY

        with pytest.raises(ValueError) as exc_info:
            _build("not_a_registered_encoder")

        message = str(exc_info.value)
        assert message.startswith("Unknown encoder 'not_a_registered_encoder': ")
        assert f"(registered: {registered})." in message

    @pytest.mark.parametrize("force_no_pretrain", [False, True])
    def test_dinov2_encoder_receives_the_backbone_arguments(self, mocker, force_no_pretrain: bool) -> None:
        """Pins Backbone -> DinoV2 argument forwarding, which moved into Backbone._build_encoder.

        ``force_no_pretrain=True`` must reach DinoV2 as ``load_dinov2_weights=False`` even when the caller asked for
        upstream weights; otherwise every shipping DINOv2 model would fetch them again.
        """
        encoder = mocker.MagicMock(_out_feature_channels=[384])
        dinov2 = mocker.patch("rfdetr.models.backbone.backbone.DinoV2", return_value=encoder)

        _build(
            "dinov2_registers_windowed_small",
            out_feature_indexes=[12],
            window_block_indexes=[0, 1],
            drop_path=0.2,
            gradient_checkpointing=True,
            load_dinov2_weights=True,
            force_no_pretrain=force_no_pretrain,
            patch_size=14,
            num_windows=4,
            positional_encoding_size=37,
            target_shape=(518, 518),
        )

        dinov2.assert_called_once_with(
            size="small",
            out_feature_indexes=[12],
            shape=(518, 518),
            use_registers=True,
            use_windowed_attn=True,
            gradient_checkpointing=True,
            load_dinov2_weights=not force_no_pretrain,
            patch_size=14,
            num_windows=4,
            positional_encoding_size=37,
            drop_path_rate=0.2,
            window_block_indexes=[0, 1],
        )


class TestForceNoPretrain:
    """``force_no_pretrain`` stops every encoder, registered or DINOv2, from fetching upstream weights."""

    @pytest.mark.parametrize(("force", "expected"), [(False, True), (True, False)])
    def test_force_no_pretrain_overrides_load_dinov2_weights(self, force: bool, expected: bool) -> None:
        """A registered encoder is told to load pretrained weights unless ``force_no_pretrain`` overrides the
        request."""
        register_backbone("toy_encoder", _ToyBackbone)

        _build("toy_encoder", load_dinov2_weights=True, force_no_pretrain=force)

        assert _ToyBackbone.received["load_pretrained_weights"] is expected


class TestChannelAdaptation:
    """``num_channels != 3`` adapts DINOv2's patch embedding, which a registered encoder does not have."""

    def test_registered_encoder_with_extra_channels_raises(self) -> None:
        """Building a registered (non-DINOv2) encoder with ``num_channels=4`` raises a ValueError naming the encoder."""
        register_backbone("toy_encoder", _ToyBackbone)

        class _ToyConfig(RFDETRNanoConfig):
            """Extension config: redeclares ``encoder`` so validation accepts the registered name."""

            encoder: Literal["toy_encoder"] = "toy_encoder"  # type: ignore[assignment]

        config = _ToyConfig(num_channels=4, pretrain_weights=None, device="cpu")

        with pytest.raises(
            ValueError, match="num_channels=4 is supported for DINOv2 encoders only, not encoder='toy_encoder'"
        ):
            _build_model_context(config)
