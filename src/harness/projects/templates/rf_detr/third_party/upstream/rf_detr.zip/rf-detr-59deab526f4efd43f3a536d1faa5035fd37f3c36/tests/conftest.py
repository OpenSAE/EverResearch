# ------------------------------------------------------------------------
# RF-DETR
# Copyright (c) 2025 Roboflow. All Rights Reserved.
# Licensed under the Apache License, Version 2.0 [see LICENSE for details]
# ------------------------------------------------------------------------
import json
import os
import shutil
from pathlib import Path
from typing import Any, Generator

import pytest
import torch
from fuse_augmentations.data import SplitRatios, generate_dataset

from rfdetr.export._backend import preload_tensorflow_before_onnx

# NOTE: Model weights (rf-detr-*.pth) download to the CWD (typically tests/ when running pytest).
# This is a known limitation. Route: change pretrain_weights default to
# platformdirs.user_cache_dir("rfdetr") in a future PR.
from rfdetr.utilities.reproducibility import seed_all

# Collection imports ONNX in several test modules, before fixtures or exporters can preload TensorFlow.
# Keep their shared Abseil symbols owned by TensorFlow in each xdist worker; absent TensorFlow is a no-op.
preload_tensorflow_before_onnx()

#: Seed handed to ``generate_dataset``; it draws from fresh entropy when left unset, which would make
#: the session-scoped dataset fixtures differ between runs.
SYNTHETIC_DATASET_SEED = 42


@pytest.fixture(autouse=True)
def reset_random_seeds() -> None:
    """Reset all RNG sources before every test for reproducibility."""
    seed_all()


@pytest.fixture
def process_umask(request: pytest.FixtureRequest) -> Generator[int, None, None]:
    """Set the process umask for one test and restore the previous one afterwards, even if the test fails.

    Defaults to ``0o022``; parametrize indirectly to pick another value. Yields the umask in effect.

    Examples:
        A fixture, so this is documentation rather than a doctest:

        ```python
        @pytest.mark.parametrize("process_umask", [0o022, 0o027], indirect=True, ids=oct)
        def test_new_file_mode(tmp_path: Path, process_umask: int) -> None:
            (tmp_path / "file").touch()
            assert stat.S_IMODE((tmp_path / "file").stat().st_mode) == 0o666 & ~process_umask
        ```
    """
    umask = getattr(request, "param", 0o022)
    previous_umask = os.umask(umask)
    try:
        yield umask
    finally:
        os.umask(previous_umask)


@pytest.fixture
def tf32_disabled() -> Generator[None, None, None]:
    """Turn TF32 off for the cuBLAS matmul and cuDNN for one test and put the previous settings back afterwards.

    Torch serves ``allow_tf32`` on ``torch.backends.cuda.matmul`` from ``__getattr__``, so the flag is not an
    instance attribute. ``monkeypatch`` (pytest 9.2+) then records it as absent and undoes the patch with ``delattr``,
    which torch rejects. Restoring by assignment works on every pytest version.

    Examples:
        A fixture, so this is documentation rather than a doctest:

        ```python
        def test_strict_fp32_parity(tf32_disabled: None) -> None:
            assert not torch.backends.cuda.matmul.allow_tf32
        ```
    """
    backends = (torch.backends.cuda.matmul, torch.backends.cudnn)
    previous_flags = [backend.allow_tf32 for backend in backends]
    for backend in backends:
        backend.allow_tf32 = False
    try:
        yield
    finally:
        for backend, flag in zip(backends, previous_flags):
            backend.allow_tf32 = flag


def sparsify_category_ids(annotations_path: Path) -> None:
    """Re-encode a COCO JSON in place so category ids are sparse instead of consecutive.

    ``fuse_augmentations`` writes dense 1-based ids (1, 2, 3, …). Real COCO exports leave gaps, and
    rf-detr's ``cat2label`` remapping exists precisely to survive them, so the fixtures spread the ids
    out (``1, 3, 5, …``) to keep exercising that path. Annotation ``category_id`` values are remapped
    with the categories, so the file stays internally consistent.

    Args:
        annotations_path: COCO JSON file to rewrite.

    Examples:
        >>> import json
        >>> from pathlib import Path
        >>> from tempfile import TemporaryDirectory
        >>> with TemporaryDirectory() as tmp:
        ...     path = Path(tmp) / "_annotations.coco.json"
        ...     _ = path.write_text(
        ...         json.dumps(
        ...             {
        ...                 "categories": [{"id": 1, "name": "a"}, {"id": 2, "name": "b"}],
        ...                 "annotations": [{"id": 1, "category_id": 2}],
        ...             }
        ...         )
        ...     )
        ...     sparsify_category_ids(path)
        ...     content = json.loads(path.read_text())
        >>> [category["id"] for category in content["categories"]]
        [1, 3]
        >>> content["annotations"][0]["category_id"]
        3
    """
    content = json.loads(annotations_path.read_text())
    remap = {category["id"]: index * 2 + 1 for index, category in enumerate(content["categories"])}
    for category in content["categories"]:
        category["id"] = remap[category["id"]]
    for annotation in content.get("annotations", []):
        annotation["category_id"] = remap[annotation["category_id"]]
    annotations_path.write_text(json.dumps(content))


def build_synthetic_dataset(dataset_dir: Path, task: str, num_images: int = 100) -> None:
    """Generate a Roboflow-style synthetic COCO dataset in ``dataset_dir``.

    ``generate_dataset`` writes ``train``/``val`` splits; rf-detr's readers expect ``train``/``valid``/
    ``test``, so ``val`` is renamed and cloned into ``test``. Every split's category ids are sparsified
    by :func:`sparsify_category_ids`.

    Args:
        dataset_dir: Existing directory the dataset is written into.
        task: ``"detection"`` for boxes only, ``"segmentation"`` to also emit polygon annotations.
        num_images: Images across the train and valid splits (80/20).

    Examples:
        >>> from pathlib import Path
        >>> from tempfile import TemporaryDirectory
        >>> with TemporaryDirectory() as tmp:
        ...     build_synthetic_dataset(Path(tmp), task="detection", num_images=10)
        ...     sorted(p.name for p in Path(tmp).iterdir())
        ['test', 'train', 'valid']
    """
    generate_dataset(
        output_dir=dataset_dir,
        num_images=num_images,
        fmt="coco",
        task=task,
        class_mode="shape",
        split_ratios=SplitRatios(train=0.8, val=0.2, test=0.0),
        seed=SYNTHETIC_DATASET_SEED,
        img_size=224,
        min_objects=3,
        max_objects=7,
    )
    valid_dir = dataset_dir / "valid"
    (dataset_dir / "val").rename(valid_dir)
    test_dir = dataset_dir / "test"
    test_dir.mkdir()
    # The test split reuses the valid split's images so its annotations resolve to real files.
    for item in valid_dir.iterdir():
        shutil.copy2(item, test_dir / item.name)
    for split in ("train", "valid", "test"):
        sparsify_category_ids(dataset_dir / split / "_annotations.coco.json")


@pytest.fixture(scope="session")
def synthetic_shape_dataset_dir(tmp_path_factory: pytest.TempPathFactory) -> Generator[Path, Any, None]:
    """Build a synthetic COCO-style dataset on disk and clean it up after tests.

    Args:
        tmp_path_factory: Pytest factory for temporary directories.

    Yields:
        Path to the synthetic dataset directory.
    """
    dataset_dir = tmp_path_factory.mktemp("synthetic_dataset")
    build_synthetic_dataset(dataset_dir, task="detection")
    yield dataset_dir
    shutil.rmtree(dataset_dir)


@pytest.fixture(scope="session")
def synthetic_shape_segmentation_dataset_dir(
    tmp_path_factory: pytest.TempPathFactory,
) -> Generator[Path, Any, None]:
    """Build a synthetic COCO-style dataset with polygon segmentation annotations.

    Same layout as :func:`synthetic_shape_dataset_dir` but every annotation includes a ``segmentation`` polygon field so
    the dataset can be used to train or evaluate segmentation models.

    Args:
        tmp_path_factory: Pytest factory for temporary directories.

    Yields:
        Path to the synthetic segmentation dataset directory.
    """
    dataset_dir = tmp_path_factory.mktemp("synthetic_seg_dataset")
    build_synthetic_dataset(dataset_dir, task="segmentation")
    yield dataset_dir
    shutil.rmtree(dataset_dir)
