# ------------------------------------------------------------------------
# RF-DETR
# Copyright (c) 2025 Roboflow. All Rights Reserved.
# Licensed under the Apache License, Version 2.0 [see LICENSE for details]
# ------------------------------------------------------------------------
"""Load and execute native CoreML exports."""

from __future__ import annotations

from collections.abc import Mapping
from pathlib import Path
from typing import TYPE_CHECKING, Any

import torch

from rfdetr.export._runtime.adapters import (
    ExportRuntime,
    _check_input_interface,
    _check_output_interface,
    _input_array,
    _require_apple,
    _runtime_options,
    _single_input,
)
from rfdetr.export._runtime.metadata import ExportMetadata

if TYPE_CHECKING:
    from rfdetr.export._runtime.adapters import ExportRuntime


def load_export_runtime(path: Path, metadata: ExportMetadata, device: str, options: Mapping[str, Any]) -> ExportRuntime:
    """Load a CoreML model and validate its tensor interface; it reads no runtime options."""
    _runtime_options("CoreML", options, ())

    _require_apple("CoreML")
    try:
        import coremltools as ct
    except ImportError as exc:
        raise ImportError("CoreML inference requires coremltools.") from exc
    units = {
        "auto": ct.ComputeUnit.ALL,
        "cpu": ct.ComputeUnit.CPU_ONLY,
        "cpu_and_gpu": ct.ComputeUnit.CPU_AND_GPU,
        "cpu_and_ne": ct.ComputeUnit.CPU_AND_NE,
    }
    if device not in units:
        raise ValueError(
            "CoreML accepts auto, cpu, cpu_and_gpu, or cpu_and_ne. "
            "Its GPU and Neural Engine policies also permit CPU execution."
        )
    session = ct.models.MLModel(str(path), compute_units=units[device])
    spec = session.get_spec()
    input_info = _single_input("CoreML", spec.description.input)
    feature_type = input_info.type
    if feature_type.WhichOneof("Type") != "multiArrayType":
        raise ValueError("CoreML input must be a multiArrayType.")
    array_type = feature_type.multiArrayType
    coreml_dtypes = {65552: "float16", 65568: "float32", 65600: "float64"}
    # CoreML input shapes are fixed, so a -1 metadata batch is refused rather than read as a wildcard.
    _check_input_interface(
        "CoreML",
        metadata,
        None if metadata.input_name == 0 else input_info.name,
        [int(size) for size in array_type.shape],
        coreml_dtypes.get(array_type.dataType, f"CoreML data type {array_type.dataType}"),
    )
    names = [item.name for item in spec.description.output]
    _check_output_interface("CoreML", metadata, names)

    def execute(batch: torch.Tensor) -> dict[str, Any]:
        """Return outputs in the model specification's order."""
        prediction = session.predict({input_info.name: _input_array(batch, metadata)})
        return {name: prediction[name] for name in names}

    return ExportRuntime(
        "coreml", metadata, session=session, device_policy=device, execute=execute, borrowed_outputs=False
    )
