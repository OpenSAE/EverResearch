# RF-DETR - Agent Instructions

This file provides detailed technical context for AI coding agents working with RF-DETR.

**Canonical Sources:**

- **Contribution Guidelines:** [CONTRIBUTING.md](.github/CONTRIBUTING.md) - The authoritative source for all contribution practices
- **Human Documentation:** [README.md](README.md) - Project overview and usage
- **Copilot Instructions:** [.github/copilot-instructions.md](.github/copilot-instructions.md) - GitHub Copilot-specific guidance

This document supplements the contribution guidelines with detailed technical information for automated tooling.

## Agent Responsibilities

As an AI agent contributing to RF-DETR, you are responsible for:

1. **Following test-driven development practices**

    - Write failing tests first for bug fixes
    - Write comprehensive tests for new features
    - Ensure final PR commit has all tests passing

2. **Adhering to code quality standards**

    - Run `pre-commit run --all-files` before every commit
    - Follow type hint and docstring requirements
    - Prefer direct project imports; conventional third-party aliases are allowed

3. **Maintaining agentic documentation**

    - Update `AGENTS.md` when architecture patterns or technical conventions change
    - Update `.github/copilot-instructions.md` when high-level guidance changes
    - Update `.github/CONTRIBUTING.md` when human workflow is affected
    - Apply updates after receiving major feedback in PR reviews
    - For code reviews, follow the [code-review skill](.github/skills/code-review/SKILL.md)

4. **Consulting maintainers before major changes**

    - Open an issue before adding new models or significant features
    - Wait for approval on approach before implementing

5. **Writing secure, minimal code**

    - Avoid over-engineering and unnecessary abstractions
    - Write secure code (prevent injection vulnerabilities)
    - Follow existing patterns in the codebase

> [!NOTE]
>
> Keeping documentation current ensures consistency across agent contributions and reduces repeated feedback on the same issues.

## Build & Development Environment

> [!NOTE]
>
> **Canonical Reference:** See [Development Environment Setup](.github/CONTRIBUTING.md#development-environment-setup) in CONTRIBUTING.md for complete setup instructions.

### Setup

```bash
# Install uv (if not already installed)
pip install uv

# Create the virtual environment
uv venv

# Install the extras and groups used by the CPU test job (add ,coreml on macOS).
uv pip install -e ".[train,augment,cli,visual,data]" --group tests --torch-backend=cpu
```

**Prerequisites:** Python >=3.10 (tested on 3.10-3.14)

### Dependency Information

See `pyproject.toml` for complete dependency specifications:

- **Core:** PyTorch, torchvision, supervision, pydantic, pyDeprecate. `transformers` is not a core dependency: core code must not import it at module scope (the non-windowed DINOv2 backbone imports it lazily); `[train]` and `[lora]` install it through `peft`
- **Optional:** `[data]` (WebDataset streaming reader), `[train]` (minimal training loop dependencies, including the COCO evaluation backends selectable via `TrainConfig.eval_backend`), `[augment]` (custom Albumentations CPU augmentations and Kornia GPU augmentations), `[lora]` (LoRA fine-tuning), `[plus]` (Plus models), `[onnx]` (ONNX export), `[loggers]` (tensorboard, wandb, mlflow, clearml)
- **Development:** `tests`, `docs`, `build` groups

**Important version constraints:**

- PyTorch: >=2.2.0, \<3.0.0

## Testing

> [!NOTE]
>
> **Canonical Reference:** See [Test-Driven Development](.github/CONTRIBUTING.md#test-driven-development) in CONTRIBUTING.md for complete guidelines.
>
> **CI Workflows (Source of Truth):** See `.github/workflows/ci-tests-cpu.yml` and `.github/workflows/ci-tests-gpu.yml` for exact test commands used in CI.

### Commands

```bash
# CPU tests (default for local development; mirrors CI)
uv run --no-sync pytest src/ tests/ scripts/ -n 1 -m "not gpu" --ignore=tests/run_smoke_all_models.py --ignore=tests/legacy/test_checkpoint_compat.py --cov=rfdetr --cov-report=xml --timeout=240 --durations=50

# GPU tests (requires GPU; mirrors CI)
uv run --no-sync pytest tests/ -m gpu --ignore=tests/legacy/test_checkpoint_compat.py -n 2 --reruns 1 --only-rerun "OutOfMemoryError" --cov=rfdetr --cov-report=xml --timeout=600 --durations=20

# Pre-commit checks (ALWAYS run before committing)
pre-commit run --all-files
```

### Testing Principles

> [!IMPORTANT]
>
> **Testing Requirements:**
>
> - ⚠️ **During development:** Tests may fail as you work through TDD cycle
> - ✅ **Before opening PR:** Final commit MUST have all tests passing
> - ✅ **Before each commit:** Run `pre-commit run --all-files`

**Test-Driven Development:**

1. **Bug fixes:** Write failing test → Fix code → Verify all tests pass
2. **New features:** Write comprehensive tests → Implement feature → Refactor

**Test Organization:**

- Mirror the package in `tests/`: a test for `src/rfdetr/<pkg>/_<fmt>/` lives in `tests/<pkg>/<fmt>/` (for example `tests/export/onnx/`, `tests/export/tensorrt/`), and tests for format-independent code stay in `tests/<pkg>/`. Each test folder is a package (`__init__.py`), and fixtures shared by several formats go in the nearest common `conftest.py`.
- Patch with the `mocker` fixture (`pytest-mock`, in the `tests` group) in preference to `with patch(...)` blocks and `@patch` stacks. Keep a `with` block only where a patch must end before the end of the test. Use `monkeypatch` for environment variables, `sys.modules` and attributes.
- Group related tests in classes
- Use `pytest.param(..., id="name")` only for a function, object, compound setup passed as one case, a per-case mark, or when the raw value would produce an unclear/empty ID (e.g., `""`); use bare string/number/boolean/`None` values otherwise, and do not maintain a parallel `ids` list
- Mark GPU/heavy tests with `@pytest.mark.gpu`
- Never use `pytest.importorskip`, and do not use `pytest.skip()` for missing optional dependencies. Gate optional-dependency tests with a named `pytest.mark.skipif` decorator built from an `_IS_<PACKAGE>_INSTALLED` flag, applied to the test, the class, or a `pytest.param(..., marks=...)` case, never through a module-level `pytestmark`, even when every test in the module needs the package: a gate there is easy to overlook when a test is added later, so put it on each class or function. Name every skip marker `_requires_<what the test needs>` (`_requires_cuda`, `_requires_kornia`, `_requires_no_cuda` for a test that needs it absent), private by its leading underscore, and never write an inline `pytest.mark.skipif(...)` condition on a test, class or case, device and platform gates included; a gate two or more modules use lives in `tests/_markers.py`. Import the optional package locally inside the test or helper, which is the optional-dependency boundary the Imports rule allows, and gate helper doctests with `__doctest_requires__`
- Take the flag from `rfdetr.export.imports` (export formats) or `rfdetr.utilities.imports` (everything else); add a new flag to the matching module and never re-probe with `find_spec` in a test file. The one exception is a format whose exporter package guards its own import (`_IS_COREMLTOOLS_AVAILABLE`, `_IS_EXECUTORCH_AVAILABLE`, `_IS_ONNX2TF_AVAILABLE`, `_IS_POLYGRAPHY_AVAILABLE`): gate its tests on that flag, which skips a broken install instead of failing it. A flag proves a package is installed, not that it imports, so a broken install errors instead of skipping. Reserve in-body `pytest.skip()` for conditions that can only be discovered at runtime - see [CONTRIBUTING.md](.github/CONTRIBUTING.md#test-organization)
- Avoid multiple validation cases in a single test - see [CONTRIBUTING.md](.github/CONTRIBUTING.md#avoid-multiple-validation-cases-in-a-single-test) for details
- Fixtures return ready-to-use concrete state or a cohesive tuple of related state. Do not return a callable factory unless fixture-managed lifecycle is required; use an ordinary helper function for configurable construction.
- Keep fixture dependencies minimal, unpack only the values a test needs, and avoid aliases or wrappers that merely rename or forward an object without adding meaning.

**CI Information:** See [CI Testing](.github/CONTRIBUTING.md#ci-testing) in CONTRIBUTING.md for details on OS/Python version matrix and workflow configurations.

## Code Quality & Linting

> [!NOTE]
>
> **Canonical Reference:** See [Code Quality and Linting](.github/CONTRIBUTING.md#code-quality-and-linting) in CONTRIBUTING.md for setup and details.

### Command

```bash
# Always run full pre-commit (not individual tools)
pre-commit run --all-files
```

> [!TIP]
>
> Pre-commit hooks will auto-format many issues. Review changes and re-stage files.

**Configuration Files:**

- `.pre-commit-config.yaml` - Pre-commit hooks (ruff, mdformat, prettier, codespell, license headers)
- `pyproject.toml` - Ruff linting rules (`[tool.ruff]` section)

**Abstraction Discipline:**

- Introduce an abstraction only when it reduces cognitive load and the number of concepts a reader must follow. Extract stable repeated behavior or irrelevant construction mechanics while keeping behavior-defining inputs and outcomes explicit at call sites.
- Design an extracted helper for the complete related behavior already present, including relevant edge cases, and place it in the narrowest scope shared by its consumers. Prefer small visible duplication over a helper, wrapper, alias, or layer that adds indirection without semantic value.

**License Header (required for all Python files):**

```python
# ------------------------------------------------------------------------
# RF-DETR
# Copyright (c) 2025 Roboflow. All Rights Reserved.
# Licensed under the Apache License, Version 2.0 [see LICENSE for details]
# ------------------------------------------------------------------------
```

## Documentation

### Building Docs

```bash
# Full install (required for the Plus model pages: Atto, Femto, Pico, XLarge, 2XLarge)
uv pip install -e ".[plus]" "rfdetr_plus>=1.2.0" --group docs

# Serve locally (live reload)
uv run mkdocs serve

# Build static site
uv run mkdocs build
```

**Documentation Structure:**

- **Source:** `docs/` directory (Markdown)
- **Config:** `mkdocs.yaml` (uses custom YAML tags: `!!python/name`)
- **Deployment:** GitHub Actions publishes to GitHub Pages

**Note:** `mkdocs.yaml` is checked by the `check-yaml` pre-commit hook with `--unsafe` so custom YAML tags such as `!!python/name` are accepted.

## Package Building

```bash
# Install build dependencies
uv sync --group build

# Build distributions
uv build

# Validate build
uv run twine check --strict dist/*
```

**Build outputs:**

- Source distribution: `dist/rfdetr-*.tar.gz`
- Wheel: `dist/rfdetr-*.whl`

## Project Structure

> [!NOTE]
>
> **Canonical Reference:** See [Project Structure](.github/CONTRIBUTING.md#project-structure) in CONTRIBUTING.md for complete project organization, directory descriptions, and configuration files.
>
> **Quick summary:** `src/rfdetr/` (source code), `tests/` (test suite), `docs/` (documentation), `.github/` (CI/CD), `pyproject.toml` (dependencies and config).
>
> Internal package organization within `src/rfdetr/` is subject to change as this is an active research and development project.

## Architecture & Conventions

### Key Patterns

**Augmentations:**

- **Training** uses torchvision-native transforms **unless Albumentations is installed** — `augmentation_backend="cpu"` (the default) then auto-selects Albumentations and injects the default `AUG_CONFIG`, even when `aug_config=None`. Identical training code therefore resolves differently across environments; pass `augmentation_backend="torchvision"` to pin the torchvision pipeline regardless of what is installed. This backend selection only reaches the dataset builders: `_route_transforms` chooses Albumentations only for `image_set == "train"`, so validation always stays on torchvision, and prediction (`src/rfdetr/_prediction/core.py`) and export (`src/rfdetr/export/prepare.py`) call torchvision preprocessing directly — do not change inference/export behavior based on the training backend.
- Custom non-empty `aug_config` values on the CPU path use Albumentations and require `rfdetr[augment]`.
- `augmentation_backend="auto"` resolves to Kornia when CUDA and Kornia are available, falling back to CPU otherwise; `augmentation_backend="gpu"` pins Kornia and requires `rfdetr[augment]`.

**Model Architecture:**

- RFDETR wrappers: `self.model` is the model context returned by `get_model()`
- Underlying PyTorch module: `self.model.model`
- Segmentation models return `pred_masks` as `torch.Tensor` or dict with keys `['spatial_features', 'query_features', 'bias']`
- Opt-in CUDA graph training is routed by `RFDETRModelModule` through the plain-object `CudaGraphTrainingRunner`; never replace the registered `self.model`, because optimizer, EMA, and checkpoint keys must keep their existing parameter ownership. The graph path is single-GPU detection only; BF16 captures per execution signature, and capture failures are fatal (never retry eagerly in the damaged CUDA context). With `compile=True` as well, replay is delegated to Inductor cudagraph trees (`triton.cudagraphs` compile option + `torch.compiler.cudagraph_mark_step_begin()` per `training_step`); `CudaGraphTrainingRunner` never wraps the `OptimizedModule`.
- With `amp_dtype="fp8"`, `cuda_graphs=True`, and `compile=False`, pass the active Lightning precision-plugin recipe to the runner's optional Transformer Engine capture backend. Import the CUDA-only dependency lazily, require the FP8-aware API including cloned returned gradients, and keep one fixed execution signature with no accumulation and `square_resize_div_64=True`. Multi-scale, aspect-ratio resize, random-resize padding, distributed, segmentation/keypoints and gradient-checkpointing combinations stay eager with a warning. All three FP8/compile/graphs flags stay compile-only; do not nest capture runtimes. GPU numerical-parity coverage must accompany scope expansion.

**Prediction:**

- Keep prediction input type aliases private in `src/rfdetr/_prediction/types.py` (`_ImageInput`, `_PredictionSource`, `_PredictionInput`, `_ThresholdInput`, plus the `TYPE_CHECKING`-only `_PredictionResult` and `_PredictionOutput`); they are annotations, not exported API, so never re-export them from `rfdetr`. Import OpenCV lazily. Preserve RGB inputs and copy arrays used for source-image outputs. Store source images in `sv.Detections` metadata or `sv.KeyPoints` per-object data.
- Keep the prediction pipeline in the private `src/rfdetr/_prediction/` package (`core.py`, `pipelines.py`, `sources.py`, `streams.py`, `thresholds.py`, `types.py`); its tests mirror it in `tests/inference/prediction/` (`test_core.py`, `test_pipelines.py`, `test_preprocess.py`, `test_sources.py`, `test_source_expansion.py`, `test_streams.py`, `test_thresholds.py`, `test_imports.py`, `test_mask_filtering.py`). Keep source parsing in `src/rfdetr/_prediction/sources.py`. Only `RFDETRInference.predict()` uses it, through the shared pipeline in `src/rfdetr/_prediction/core.py`; runtime adapters never parse sources. Keep `RFDETR.predict()` images-only (one image, an iterable of images, or a BCHW tensor as one batch) so the research model stays light: it calls the single-batch path directly and raises `TypeError` for `stream`, `batch`, `vid_stride` and `stream_buffer`. Type collection inputs as `Iterable` and read non-list iterables into a list at the entry point; do not add `@overload` stubs just to narrow the return type. Classify sources with the `_SourceKind` enum, never bare strings. Distinguish live sources by explicit schemes and media suffixes. Treat extensionless HTTP URLs as images. Reject screen capture inside `.streams` manifests with a clear error.
- Keep confidence-threshold handling in `src/rfdetr/_prediction/thresholds.py`. `predict(threshold=...)` takes a single number or the public `ClassThresholds` (exported from `rfdetr`), never a plain list or `dict`: a `dict` alone defines no threshold for the classes it leaves out, so per-class values carry a `default` through `ClassThresholds`. Check values when a `ClassThresholds` is built, and fit it to `class_names` and the class-id map before the forward pass; per-class layout logic lives on the class, number parsing in module functions.
- Keep path and URL classification, including manifest-relative paths, in `_classify_source`. Classification must not open captures or resolve YouTube URLs; those operations stay lazy in source iteration.
- Preserve scalar still-image returns and image-list batching. Expanded finite inputs use bounded batches and flush the last partial batch. `.streams` predicts a batch in manifest order and stops when a known finite source ends. Live sources also support `stream=False`, so resolve live inputs before warning about accumulated results, including live entries in nested manifests.
- On a CUDA context, and only without `include_source_image`, the read-ahead workers leave baseline YCbCr JPEG files (4:4:4, 4:2:2, 4:2:0, gated from the header by `_decodes_on_gpu`) encoded, and each batch decodes them in one nvjpeg call (`_decode_jpegs_on_gpu`). Grayscale, CMYK, RGB-coded Adobe and progressive JPEG files, PNG files and every other device keep the CPU decoder, and off CUDA the batch never waits for all its decodes up front. The first file of each (device, subsampling) per process is compared bitwise with the CPU decode; a mismatch or an nvjpeg error sends that kind back to the CPU for the rest of the process. Keep that comparison exact: the GPU path exists only because it reproduces the CPU pixels. Whether nvjpeg matches depends on the GPU: on the CI Tesla T4 (no hardware JPEG decoder, torchvision 0.29) it differed from libjpeg for every subsampling, so there the path falls back after the first batch; on an L4 (torchvision 0.26) it matched every 4:4:4 file of COCO val2017 and differed for most 4:2:2 and 4:2:0 files, so there only 4:4:4 stays on the GPU. The GPU tests assert that the decoded pixels equal the CPU decode, never that nvjpeg itself matches. torchvision allocates nvjpeg's outputs on the caller's current stream but writes them from a stream of its own that does not wait for it, so a decode on the current stream can overwrite memory a queued forward pass still reads; call nvjpeg only through `_decode_on_own_stream`, which decodes on a per-device stream used for nothing else, makes the current stream wait for it and records each output on the current stream.
- Close source readers when iteration ends or callers close the generator. Network capture timeouts depend on OpenCV backend support. YouTube resolution and screen capture use the optional `rfdetr[stream]` extra.
- Resolve native contexts inside each inference batch. Do not keep `torch.inference_mode()` active across generator yields. Export shape and batch limits apply to every batch, including the final partial batch and concurrent streams; never pad or silently split an incompatible batch.

**Model Export:**

- Each format is an `Exporter` subclass in `src/rfdetr/export/_<format>/exporter.py`, built from its own frozen config dataclass defined in the same module. `RFDETR.export()` is a facade — signature and return value are the public surface; everything below it is internal.
- `src/rfdetr/export/base.py` names no format. It holds `ExportConfig`, `Exporter` and format-independent helpers only; per-format configs and their `RFDETR.export()` keyword mapping (`setting_names`) live with the exporter that reads them.
- `src/rfdetr/export/registry.py` is data: format name → exporter dotted path, plus pre-import capabilities and `RUNTIME_LOADERS`. Keep one lazy `load_export_runtime(path, metadata, device, options)` path per registered format; `tests/export/test_registry.py` checks the capability mirrors and loader coverage/resolution.
- `src/rfdetr/export/prepare.py` does the format-independent graph work once and returns an `ExportGraph`. Never duplicate it into a format.
- A format that needs another deformable-attention sampler swaps `MSDeformAttn.grid_sample` on the modules of the model it converts, through a context manager in its own package (`pixel_row_sampling` in `src/rfdetr/export/_litert/sampling.py`), never on the class or the live model: `RFDETR.export()` converts a copy, and the class default serves every other caller.
- Refuse a bad request before the forward pass: config values in `_check_capabilities` (config only), keywords that are derived, not stored, or hidden by a config default in `_format_settings`, missing packages in a `check_dependencies` override (called by `RFDETR.export` and `Exporter.__call__`, never by the constructor or the format itself), and what a setting needs of the installed packages or the host (a separate runtime library, a GPU recent enough to build on) in a `check_environment` override, which runs right after it at the same two places (a public entry point that bypasses `__call__`, such as TensorRT's `build_engine`, calls it itself). Only refusals that need the prepared graph go in `_convert`, first.
- Export metadata is captured with `ExportGraph` and published after conversion. Format exporters override `_metadata_artifacts` or `_metadata_for_artifact` when a format has multiple final artifacts or changes its interface. A metadata publication failure warns; it does not discard an artifact that conversion already wrote. Full loader and metadata recipe: [docs/exports/blueprint.md](docs/exports/blueprint.md).
- Static INT8 lives in the format's own `quantize.py` (`_onnx/`, `_openvino/`, `_tensorrt/`), never in its exporter: the exporter validates the request and calls one function. `src/rfdetr/export/_runtime/calibration.py` turns `calibration_data` into preprocessed batches for every format and must stay free of format-specific dependencies — it is what lets ONNX, OpenVINO and TensorRT share one definition of "representative data" without importing each other's runtime. `quantization="int8"` means *static* for these three formats (calibration data required, refused when absent) and *dynamic-range* for TFLite (calibration data genuinely unused); do not unify the keyword's meaning across them.
- For ONNX and OpenVINO, quantize `MatMul`/`Gemm` only, and keep attention-score multiplies, detection heads and quantized-op outputs in float. Any change to that op selection needs a COCO measurement, not a plausibility argument: run the INT8 and COCO val2017 accuracy sections of [docs/cookbooks/export-cpu.ipynb](docs/cookbooks/export-cpu.ipynb), which score the INT8 artifacts with a seeded subset, a calibration set held out of it, and recorded ONNX Runtime / NNCF versions, and compare against the fp32 rows.
- An engine that carries host code (a TensorRT 11 version-compatible engine) loads only through an explicit opt-in via `RFDETRInference(source, runtime_options={'engine_host_code_allowed': True})`, or `engine_host_code_allowed=True` on the deprecated `TRTInference` facade or `rfdetr.export.benchmark`, never by default: running host code from a file is a trust decision.
- Adding a format: config + exporter class and runtime loader in its own package, entries in `REGISTRY` and `RUNTIME_LOADERS`, the format name in the `ExportFormat` literal (`src/rfdetr/export/_runtime/metadata.py`), a `pyproject.toml` extra, tests. Never an edit to `base.py`.
- TensorRT INT8 placement (`src/rfdetr/export/_tensorrt/quantize.py`) encodes measurements and two TensorRT bugs, not a generic recipe: an MLP's `fc1` is quantized only together with its `fc2` (INT8 GEMM → GELU → FP16 consumer returns NaN), attention is all INT8 or all FP16 with no Q/DQ behind an FP16 attention (TensorRT 11.3 computes that wrongly) and is INT8 only up to 325 tokens per window (Large's 485 ran no faster and lost AP, Seg Large's 442 was a little faster and lost AP too, Keypoint's 577 and Seg Nano's 677 are above the fused kernel's 512 and ran much slower), and a convolution whose input channels are not a multiple of 32 stays FP16 (TensorRT stored the zero channels it added to the INT8 patch embedding's input in the engine, as a batch-sized constant), so `_patch_embedding_as_matmul` rewrites the patch embedding of an INT8 export as a `MatMul`, and INT8 quantizes it only when its flattened patch is a multiple of 32 values (the detection models' 768; the segmentation and keypoint models' 432 stay an FP16 `MatMul`). A detection export also smooths the backbone LayerNorm outputs (SmoothQuant, `measure_smoothing_scales`: per-channel factors folded into the norm's scale and bias and the rows of the projections reading it) and subtracts from each backbone MLP layer's bias the mean shift INT8 adds to its output (`measure_mlp_bias_shifts`); each is one more pass over the calibration images, and only constants change. Keep every new op off the GELU → `fc2` path: on TensorRT 11.4 a no-op `Sub` there moved `fc1`'s GELU and quantize from the GEMM's own epilogue into a generated fusion and cost Nano more box AP than the whole INT8 plan does. Any placement change needs a COCO AP and latency measurement. The TensorRT INT8 figures in the docs come from Section 8.1 of `docs/cookbooks/export-cuda.ipynb`, which builds the FP16 and INT8 engines of the four detection and four segmentation sizes and `RFDETRKeypointPreview`, scores them on val2017 and times them; Section 8 of the same notebook is a smaller check of the `MODEL_SIZE` model at batch 1 on a val2017 subset; its subsection *Batch 1, 4 and 8, end to end* times static FP16 and INT8 engines end to end and is the source of the `.trt` FP16 and INT8 rows of "Latency Across NVIDIA GPUs" in `docs/exports/tensorrt.md`, run once per size on each GPU. Regenerate the INT8 accuracy and engine-only tables from 8.1 with the settings its table lists, never from a number measured elsewhere.
- Do not quote INT8 accuracy or speed figures, for any format, that no harness in the repository reproduces.
- A helper that two or more cookbooks in `docs/cookbooks/` define belongs in a private package module, not in each notebook: the benchmark helpers (`BenchmarkConfig`, `BenchmarkRows`, `im_predict`, `time_folder`, `export_cached`, `cpu_brand`) in `src/rfdetr/export/_benchmark.py`, `_find_images` in `src/rfdetr/utilities/files.py` and `_save_final_checkpoint` in `src/rfdetr/training/callbacks/best_model.py`. A notebook imports it and keeps only what is specific to its own run; every such helper has a docstring with a doctest or a test in `tests/`. Notebook-only display settings (`%matplotlib inline`, `%config InlineBackend.close_figures = True`) stay as IPython magics in the notebook, never a package helper.
- `docs/cookbooks/measure-latency.ipynb` measures end-to-end batch-1 latency through `RFDETRInference.predict` and keeps, per model, the configuration with the lowest median call time and every configuration within `TIE_TOLERANCE` (5%) of it, because a gap that small is inside the run-to-run noise, for the `HARDWARE` you set (`cuda`, `apple` or `cpu`), timing one call for each of 500 distinct val2017 images (200 on the CPU, where a call is far slower) after 50 warm-up calls, with every CPU runtime pinned to the logical core count, and reporting the 95th percentile next to the median. It never picks hardware or falls back to another runtime: a missing device or package stops it, and `build_predictor` checks that `runtime_info` names the runtime and device of the configuration before it is timed. It scores no accuracy, so a configuration whose accuracy was not checked on that hardware (INT8 of Atto, Femto and Pico) is excluded in `INT8_EXCLUDED`.
- `docs/learn/benchmarks.md` keeps the official SAB numbers (T4, TensorRT 10.4 FP16) and states the source of each. The PyTorch FP32, TensorRT FP16 and TensorRT INT8 AP columns of the Run pages (`docs/learn/run/detection.md`, `segmentation.md`, `keypoints.md`) come from `docs/cookbooks/coco-accuracy.ipynb`, which scores every pretrained checkpoint through `RFDETRInference.predict` on full val2017 through `rfdetr.export._benchmark.evaluate_coco_ap`. Copy those columns from the notebook's results table, all from one run on one device, never retype or mix numbers from another harness, and update the run's GPU, versions and date in `docs/snippets/reproduced-coco-ap.md` with them.

**Inference:**

- `RFDETR.inference(compile=True, batch_size=1, dtype=torch.float32, compile_backend=None)` returns an independent `RFDETRInference` snapshot. It copies the current base weights, model configuration, labels, normalization and postprocessing settings once; later training or source mutations do not alter the predictor. It leaves the source model unchanged. The default captures a CUDA graph (`compile_backend="cudagraph"`) on CUDA, compiles with inductor on MPS (when the installed PyTorch has its MPS code generator) and TorchScript on every other device, batch size 1 and float32; inductor on the CPU compiled for about 18 s and ran slower than TorchScript, so keep it off the CPU default. Both the TorchScript and cudagraph backends trace through `_trace_for_prediction` without changing process-wide deterministic settings. For accelerator tracing, the owned segmentation snapshot uses native bilinear upsampling: the deterministic-backward decomposition of `F.interpolate` cannot be recorded by `torch.jit.trace`, and prediction never runs backward. Other export and training paths retain their existing interpolation. Capture the return value and call `predictor.predict(images)`. `inplace` is removed and rejected. The legacy `remove_optimized_model()` and `is_optimized_inplace` APIs remain for legacy model state and do not manage returned predictor lifetime; deleting the predictor releases its runtime when no other references remain.
- Inductor predictors compile under `_raised_dynamo_recompile_limit()` (Dynamo's `cache_size_limit` held at 64 or the caller's higher value, restored afterwards) and with `dynamic=False`. Every size shares one `forward`, so each inductor predictor in a process uses one of Dynamo's default 8 compiled variants; past that, later predictors silently run several times slower (measured on Apple M4 Max: Atto fp16 12.20 ms against 4.61 ms), and with dynamic shapes left on, Metal kernels with symbolic sizes can fail to compile (`no 'buffer' resource location available`). A benchmark that builds many predictors in one process measures that cliff, not the model. Never drop either setting without rerunning the Apple rows of `docs/cookbooks/measure-latency.ipynb`.
- Direct `RFDETRInference(live_model)` construction remains an explicitly borrowed path: it does not copy weights and sees current model state on each prediction, so it never takes the MPS rewrites. A checkpoint path loaded on MPS is owned and takes them (`_rewrite_for_mps_prediction`, shared with `inference()`). `RFDETRInference(checkpoint_or_export_path)` keeps its existing path-loading behavior and owns the loaded model or runtime. Keep these semantics distinct in examples and integrations.
- `RFDETR.inference()` may apply numerics-preserving, device-specific rewrites to the snapshot it owns, never to the live model or the class. It casts the snapshot to the requested dtype first; then, on MPS, it sets `_native_grid_sample` on the snapshot's `MSDeformAttn` modules and, except for an inductor-compiled predictor, folds each DINOv2 LayerScale into the Linear before it with `_fold_layer_scales`. Training keeps the gather-based sampler because MPS has no `F.grid_sample` backward.
- `RFDETRInference(source, *, device="auto", metadata=None, trust_checkpoint=False, runtime_options=None)` is the shared prediction API. It accepts a live `RFDETR` model, native `.pth`/`.pt`/`.ckpt` checkpoints, or a full artifact from any registered export format. A live source is borrowed, not copied; each prediction sees its current training and optimization state. Omit `device` for a live source and configure the native model itself. A path source loads and owns its model or exported runtime. Only a predictor that owns its model or runtime (a path source or an `inference()` snapshot) builds the next CUDA batch's input while the current batch runs; a borrowed live source runs its batches one at a time, so each batch reads the model's state when it starts.
- Keep input handling, preprocessing, postprocessing, and Supervision results shared across native and exported prediction. Eager image lists use one batch unless `batch` is passed; expanded sources and streamed inputs use bounded batches. Reject an incompatible batch or shape before runtime execution; do not split or pad it. Runtime adapters own format-specific input layout, dtype, output mapping, device policy, and buffer lifetime. Load optional runtime packages lazily, and reject an unavailable explicit device for a path source.
- Inference metadata records the artifact interface and task semantics. ONNX embeds versioned metadata; other formats use `<artifact-name>.rfdetr.json` beside the final artifact. Validate it against the actual interface; `metadata=` supplies missing semantics for older artifacts as a JSON path or mapping. Sidecar-backed loads hash the artifact to check for stale metadata. Intermediate ONNX files created by TensorRT and TFLite exports are conversion inputs without ONNX metadata. Do not treat user `notes` as inference metadata or infer task and background placement from tensor rank.
- `.trt` and `.engine` identify TensorRT engines. Both TFLite routes use `.tflite`, but onnx2tf uses NHWC and LiteRT uses NCHW; use metadata to select the layout. LiteRT cannot export full keypoint models. Reject backbone-only artifacts.
- `RFDETRInference` uses the common image and streaming prediction path. ONNX and TFLite keep private NumPy reference helpers for dependency-light numerical checks; these share raw runtime execution with their adapters. `TRTInference` and `OpenVINOInference` are deprecated compatibility facades. Their session loading and execution live in module-level functions shared with the adapters. Adapters never construct these facades. Removing them must not change runtime execution. CoreML and Core AI loaders use their vendor APIs directly. Raw examples remain useful for forward-only benchmarks.
- `runtime_info` reports the selected runtime and device policy; a vendor policy does not always identify a physical device.
- `runtime_options` is the one channel for format runtime settings: `RFDETRInference` → `load_exported_context` → `load_runtime` → the format's `load_export_runtime(path, metadata, device, options)`. Each loader passes its options through `_runtime_options` (`src/rfdetr/export/_runtime/adapters.py`) as its first statement, before importing its runtime or checking the host, so an unknown key raises `ValueError` everywhere. A loader module may import its optional runtime at module scope (TensorRT's does, for `tensorrt` and `pycuda`) only behind `try`/`except ImportError`: the module then stays importable without the package, and an unknown key still raises `ValueError` on that host. Expose a key only for a setting the format's own session loader already takes (TensorRT: `cuda_graph`, `engine_host_code_allowed`, `verbose`; OpenVINO: `cache_dir`, `inference_precision`, `config`, `num_threads`; ONNX, TFLite and LiteRT: `num_threads`; others: none). Native sources reject `runtime_options`. The TensorRT adapter keeps `execute_v2` as its default; `cuda_graph` is opt-in for fixed-profile engines.
- On ONNX Runtime's CUDA provider, the ONNX adapter's runtime device is the CUDA device, so preprocessing runs on the GPU, and `_run_onnx_bound` hands ONNX Runtime the batch's own memory and fresh output tensors through IO binding, after synchronizing torch's current stream. It keeps the host NumPy path when torch cannot see the GPU, an output is a scalar or does not lead with the input's batch axis, or an output has a dynamic axis other than the batch. The CPU provider and the NumPy reference helpers (`_run_onnx_raw`, `_run_inference`) stay on the host path.

**Model Selection (examples, docs, CI, tests, defaults):**

- **Default to `RFDETRSmall` / `"rfdetr-small"` in docs and examples.** Use it wherever an example needs a concrete detection model.
- **Default to `RFDETRNano` / `"rfdetr-nano"` in CI and tests.**
- **Never use base models** (`RFDETRBase` / `"rfdetr-base"`) in new examples, docs, CI, or tests — treat as deprecated; substitute `small` in docs/examples and `nano` in CI/tests.
- **Released detection sizes** — `nano`, `small`, `medium`, `large` (plus `atto`/`femto`/`pico` and `xlarge`/`2xlarge` Plus models). Always pick one of these for plain object detection; never a `-preview` variant.
- **Released segmentation sizes** — `RFDETRSegNano`/`Small`/`Medium`/`Large` / `"rfdetr-seg-{nano,small,medium,large}"` (plus `xlarge`/`2xlarge`). Use a sized seg model for segmentation; `RFDETRSegPreview` / `"rfdetr-seg-preview"` is now superseded — do not use it in new examples, docs, or tests.
- **`-preview` variants** are for capabilities with **no released sized version yet**. Only keypoints remain preview-only: `RFDETRKeypointPreview` / `"rfdetr-keypoint-preview"`. Use a preview variant **only** for that task — never as a stand-in for detection or segmentation.

**Imports:**

- Use absolute imports in tests, including imports from other test modules and helpers (for example, `from tests.training.helpers import ...`).
- Keep imports at module scope by default. Use a local import only for a verified circular-import boundary, optional dependency boundary, import-behavior test, or material startup/side-effect constraint; the reason must be evident from the surrounding code or documented where it is not obvious.

```python
# Prefer direct project imports. Standard aliases such as `numpy as np`,
# `torch.nn.functional as F`, and lazy module aliases are allowed when conventional.
from rfdetr.utilities.distributed import get_rank, get_world_size, is_main_process, save_on_master
from rfdetr.utilities.logger import get_logger

# Logger usage
logger = get_logger()  # Default name: "rf-detr", reads LOG_LEVEL env var

# TQDM (environment compatibility)
from tqdm.auto import tqdm  # NOT: from tqdm import tqdm
```

**Plus Models (Atto, Femto, Pico, XLarge, 2XLarge):**

- Requires separate `rfdetr_plus` package (PML 1.0 license). Atto, Femto and Pico (PE-Core-T backbone) need `rfdetr_plus>=1.2.0`; the `plus` extra floor stays at 1.1.0, so an older install keeps XLarge/2XLarge and gets an upgrade hint for the PE models. The `try-all-models` CI job smoke-tests both the latest release and `rfdetr_plus<1.2`.
- When describing licensing in docs or answers, name the license and say what it means in practice; never write a bare license name. Apache 2.0 (the package, Nano–Large detection, every Seg size, Keypoint): commercially usable out of the box, closed-source and self-hosted included, no license fee, no obligation to open-source your code. PML 1.0 (the Plus models listed in the README License section): commercial use is included when deploying on Roboflow; commercial self-hosting requires the Enterprise add-on. Reuse the shared snippets in `docs/snippets/` (`license-rfdetr.md`, `license-yolo-note.md`) instead of rewording them.
- Import handled lazily via `__getattr__` in `src/rfdetr/platform/models.py`
- Raises `ImportError` if package not installed

**Subprocess Usage:**

```python
import subprocess

result = subprocess.run(
    ["command", "arg1", "arg2"],
    check=True,  # Raise CalledProcessError on failure
    text=True,  # Return stdout/stderr as strings
    capture_output=True,
)
# Note: stderr is already a string, don't decode
```

**Logging:**

- Use `logger.debug()` for detailed tensor/shape information (not `logger.info()`)
- Use `logger.info()` for high-level progress/status

**Checkpoint Handling:**

- Always check file existence before operations
- Prevents errors when training is interrupted

### Type Hints & Docstrings

> [!IMPORTANT]
>
> **Canonical Reference:** See [Google-Style Docstrings and Mandatory Type Hints](.github/CONTRIBUTING.md#google-style-docstrings-and-mandatory-type-hints) in CONTRIBUTING.md for complete requirements and examples.
>
> **Requirements:**
>
> - MANDATORY type hints for all function parameters and return types
> - MANDATORY Google-style docstrings for all functions and classes
> - **Do not duplicate types in docstrings** - types are in the function signature
> - Target Python version: 3.10+
> - **Helper functions in `tests/` need a doctest too**: any non-`test_*` function used by tests (fixture builders, assertion helpers, reference implementations) needs a docstring with an `Examples` doctest that exercises it directly — `pyproject.toml` runs `--doctest-plus` across `tests/` on purpose. Skip the live doctest (`# doctest: +SKIP` + one-line reason) only when the helper can't run standalone (e.g. a `@pytest.fixture`, or needs real GPU/XLA/network hardware).

## Common Workflows

### Making Changes

1. **Setup:** Follow the [Development Environment Setup](.github/CONTRIBUTING.md#development-environment-setup) instructions.
2. **Before changes:** Run tests to establish baseline
3. **Development:**
    - Make minimal, focused changes
    - Follow existing patterns and conventions
    - Add type hints and docstrings
4. **Testing:**
    - Bug fixes: Write test first, then fix
    - Features: Test all major use cases
    - Run: `uv run --no-sync pytest src/ tests/ scripts/ -n 2 -m "not gpu" --ignore=tests/run_smoke_all_models.py --ignore=tests/legacy/test_checkpoint_compat.py --timeout=240 --durations=50`
5. **Quality checks:** `pre-commit run --all-files`
6. **Build (if needed):** `uv build`
7. **Commit:** Pre-commit hooks run automatically

### Adding New Model Variants

> [!IMPORTANT]
>
> **Canonical Reference:** See [Adding a New Model](.github/CONTRIBUTING.md#adding-a-new-model) in CONTRIBUTING.md for detailed guidance.
>
> Always consult maintainers before implementing new models.

### Security Considerations

- **Write secure code:** Avoid injection vulnerabilities (XSS, SQL injection, command injection)
- **Validate inputs:** Especially for file paths, URLs, and user-provided data
- **No credentials:** Never commit API keys, tokens, or credentials
- **Follow OWASP best practices**

## CI/CD Workflows

GitHub Actions workflows in `.github/workflows/`:

- **ci-tests-cpu.yml:** CPU tests on Linux across Python 3.10-3.14, plus Windows and macOS on Python 3.10 and 3.13
- **ci-tests-gpu.yml:** GPU-dependent tests
- **ci-github-tests.yml:** Tests and doctests for the helper scripts under `.github/scripts/`, which the CPU/GPU suites never collect; their tests live in `.github/_tests/`
- **ci-legacy-checkpoints.yml:** Backward-compatibility checkpoint-loading tests across historical rfdetr releases (advisory only — not a required check; a compat break does not block merge)
- **ci-deps-resolution.yml:** Dependency resolution (`uv lock`) plus an install-plan check (`uv sync --dry-run`) for every extra on every Python interpreter allowed by requires-python (3.10-3.14). Resolution alone does not prove a pinned version ships a wheel for the interpreter in use. The `list-extras` job derives the checked set from every `[project.optional-dependencies]` extra, so a new extra is covered automatically
- **build-package.yml:** Build and validate distributions
- **ci-build-docs.yml:** Documentation builds
- **publish-docs.yml:** Deploy docs to GitHub Pages

**Concurrency:** PRs cancel in-progress runs on new pushes

**Pretrained weights cache:** `try-all-models` never restores caches and disables uv caching, so every matrix leg tests live downloads. The independent `cache-model-weights` job also downloads fresh weights on every run: `.github/scripts/download_model_weights.py` instantiates each supported model on CPU without inference or checkpoint round-trips. Only on pushes to `develop` does that job save the shared archive through `.github/actions/cache-model-weights`. Publication requires successful initialization of every model in the downloader, but does not wait for the smoke matrix. The reusable action computes cache keys in Bash using Git object hashes and sets common directories with shell `echo`. Each successful push uses a fresh run/attempt suffix. Every other test job calls the action with `save: "false"` after dependencies and before tests, including every export row, TensorRT, Roboflow, XLA, legacy generation/compatibility, GitHub helper tests and the docs build test. These readers have no dependency on the publisher and download normally on a miss. The action sets `RF_HOME` to `${{ github.workspace }}/.roboflow` and owns `.huggingface` paths, identical archive patterns and cross-OS settings. Legacy checkpoint generation also runs from `RF_HOME` so historical releases that use the working directory share the restored weights. Key prefixes fingerprint the committed weight registry (`src/rfdetr/assets/model_weights.py`, including its MD5 checksums) and `pyproject.toml` using Git object hashes, with no OS/Python/job/format dimensions. Core and Plus jobs share the same source-based cache scope. Never save model caches from PR jobs or broaden fallback across different source fingerprints.

## Additional Resources

- **Documentation:** https://rfdetr.roboflow.com
- **Repository:** https://github.com/roboflow/rf-detr
- **Issues:** https://github.com/roboflow/rf-detr/issues
- **Discord:** https://discord.gg/GbfgXGJ8Bk
- **Contributing:** `.github/CONTRIBUTING.md`
- **Copilot Instructions:** `.github/copilot-instructions.md`

---

**Note:** This file is designed for AI coding agents. For human-readable project information, see README.md. For contribution guidelines, see CONTRIBUTING.md.
