# ------------------------------------------------------------------------
# RF-DETR
# Copyright (c) 2025 Roboflow. All Rights Reserved.
# Licensed under the Apache License, Version 2.0 [see LICENSE for details]
# ------------------------------------------------------------------------
"""Comprehensive unit tests for RFDETRDataModule (LightningDataModule wrapper)."""

import builtins
import logging
import random
import warnings
from pathlib import Path
from unittest.mock import MagicMock, patch

import numpy as np
import pytest
import torch
import torch.utils.data
from PIL import Image
from torch.utils.data import DataLoader

from rfdetr.config import AugmentationBackend, KeypointTrainConfig, RFDETRBaseConfig, TrainConfig
from rfdetr.datasets.aug_configs import AUG_CONFIG
from rfdetr.datasets.kornia_transforms import IMAGENET_MEAN, IMAGENET_STD, build_kornia_pipeline, collate_boxes
from rfdetr.datasets.multi_source import WeightedMultiSourceBatchSampler
from rfdetr.datasets.yolo import YoloDetection, YoloSplitUnavailableError
from rfdetr.training.module_data import _MIN_TRAIN_BATCHES, GradAccumAlignedDataset, RFDETRDataModule, _worker_init_fn
from rfdetr.utilities.tensors import (
    NestedTensor,
    PackedTargets,
    nested_tensor_from_tensor_list,
    pack_targets,
)
from tests._markers import _cuda_marks, _requires_kornia

_CUDA_DEVICE = pytest.param("cuda", marks=_cuda_marks)
_EVAL_LOADERS = ["val_dataloader", "test_dataloader", "predict_dataloader"]
_EVAL_LOADER_DATASETS = [
    pytest.param("val_dataloader", "_dataset_val", id="val"),
    pytest.param("test_dataloader", "_dataset_test", id="test"),
    pytest.param("predict_dataloader", "_dataset_val", id="predict"),
]

# ---------------------------------------------------------------------------
# Private helpers shared by module-level fixtures and class-level _setup_* methods (which cannot inject fixtures).
# Define one only when it has several call sites; single-use logic belongs in the fixture body.
# ---------------------------------------------------------------------------


def _base_model_config(**overrides):
    """Return a minimal RFDETRBaseConfig with pretrain_weights disabled.

    Examples:
        >>> config = _base_model_config(num_classes=7)
        >>> config.device, config.num_classes, config.pretrain_weights
        ('cpu', 7, None)
    """
    defaults = dict(pretrain_weights=None, device="cpu", num_classes=5)
    defaults.update(overrides)
    return RFDETRBaseConfig(**defaults)


def _base_train_config(tmp_path=None, **overrides):
    """Return a minimal TrainConfig suitable for unit tests.

    Examples:
        >>> config = _base_train_config(batch_size=4)
        >>> config.batch_size, config.dataset_dir.endswith("dataset"), config.output_dir.endswith("output")
        (4, True, True)
    """
    dataset_dir = str(tmp_path / "dataset") if tmp_path else "/nonexistent/dataset"
    output_dir = str(tmp_path / "output") if tmp_path else "/nonexistent/output"
    defaults = dict(
        dataset_dir=dataset_dir,
        output_dir=output_dir,
        epochs=10,
        lr=1e-4,
        lr_encoder=1.5e-4,
        batch_size=2,
        weight_decay=1e-4,
        lr_scheduler_kwargs={"lr_drop": 8},
        warmup_epochs=1.0,
        drop_path=0.0,
        multi_scale=False,
        expanded_scales=False,
        grad_accum_steps=1,
        tensorboard=False,
    )
    defaults.update(overrides)
    return TrainConfig(**defaults)


class _FakeDataset(torch.utils.data.Dataset):
    """Minimal dataset stub with a controllable length.

    Args:
        length: Number of items to report via ``__len__``.
        with_coco: If True, attach a mock ``.coco`` attribute with ``cats``
            so ``class_names`` can be tested.
    """

    def __init__(self, length: int = 100, with_coco: bool = False) -> None:
        self._length = length
        if with_coco:
            coco = MagicMock()
            coco.cats = {1: {"name": "cat"}, 2: {"name": "dog"}}
            self.coco = coco
        else:
            self.coco = None

    def __len__(self) -> int:
        return self._length

    def __getitem__(self, idx):
        raise NotImplementedError


def _fake_dataset(length: int = 100, with_coco: bool = False) -> _FakeDataset:
    """Return a minimal ``_FakeDataset`` with a controllable length.

    Examples:
        >>> dataset = _fake_dataset(length=3, with_coco=True)
        >>> len(dataset), dataset.coco.cats[1]["name"]
        (3, 'cat')
    """
    return _FakeDataset(length, with_coco)


class _VisualDataset(torch.utils.data.Dataset):
    """Minimal transformed dataset item for DataModule sample visualization."""

    def __len__(self) -> int:
        """Return the fixed fake dataset length."""
        return 1

    def __getitem__(self, idx: int) -> tuple[torch.Tensor, dict[str, torch.Tensor]]:
        """Return one normalized image tensor with box and keypoint targets."""
        return (
            torch.full((3, 16, 16), 0.5, dtype=torch.float32),
            {
                "boxes": torch.tensor([[0.5, 0.5, 0.5, 0.5]], dtype=torch.float32),
                "labels": torch.tensor([0], dtype=torch.int64),
                "keypoints": torch.tensor([[[0.25, 0.25, 2.0], [0.75, 0.75, 0.0]]], dtype=torch.float32),
                "size": torch.tensor([16, 16], dtype=torch.int64),
            },
        )


class _MaskedVisualDataset(torch.utils.data.Dataset):
    """Transformed dataset item carrying the given instance ``masks`` and no keypoints.

    Examples:
        >>> _, target = _MaskedVisualDataset(torch.ones(2, 16, 16, dtype=torch.bool))[0]
        >>> sorted(target)
        ['boxes', 'labels', 'masks', 'size']
    """

    def __init__(self, masks: torch.Tensor) -> None:
        self._masks = masks

    def __len__(self) -> int:
        """Return the fixed fake dataset length."""
        return 1

    def __getitem__(self, idx: int) -> tuple[torch.Tensor, dict[str, torch.Tensor]]:
        """Return one normalized image tensor with box and instance-mask targets."""
        return (
            torch.full((3, 16, 16), 0.5, dtype=torch.float32),
            {
                "boxes": torch.tensor([[0.5, 0.5, 0.5, 0.5]], dtype=torch.float32),
                "labels": torch.tensor([0], dtype=torch.int64),
                "masks": self._masks,
                "size": torch.tensor([16, 16], dtype=torch.int64),
            },
        )


def _make_batch(batch_size: int = 2, channels: int = 3, h: int = 16, w: int = 16):
    """Build a ``(NestedTensor, targets)`` tuple for transfer_batch_to_device tests.

    Examples:
        >>> samples, targets = _make_batch(batch_size=2, h=8, w=8)
        >>> samples.tensors.shape, len(targets)
        (torch.Size([2, 3, 8, 8]), 2)
    """
    tensors = torch.randn(batch_size, channels, h, w)
    mask = torch.zeros(batch_size, h, w, dtype=torch.bool)
    samples = NestedTensor(tensors, mask)
    targets = [
        {
            "boxes": torch.tensor([[0.5, 0.5, 0.1, 0.1]]),
            "labels": torch.tensor([1]),
            "image_id": torch.tensor(i),
            "orig_size": torch.tensor([h, w]),
        }
        for i in range(batch_size)
    ]
    return samples, targets


def _build_datamodule(model_config=None, train_config=None, tmp_path=None):
    """Construct RFDETRDataModule (build_dataset is not called at init time).

    Examples:
        >>> datamodule = _build_datamodule()
        >>> datamodule.model_config.device, datamodule.train_config.batch_size
        ('cpu', 2)
    """
    mc = model_config or _base_model_config()
    tc = train_config or _base_train_config(tmp_path)
    return RFDETRDataModule(mc, tc)


def _setup_fit_with_fake_datasets(datamodule: RFDETRDataModule) -> RFDETRDataModule:
    """Run ``setup("fit")`` with ``build_dataset`` stubbed to a 100-item train and a 20-item val fake dataset.

    Examples:
        >>> dm = _setup_fit_with_fake_datasets(_build_datamodule())
        >>> len(dm._dataset_train), len(dm._dataset_val)
        (100, 20)
    """
    datasets = {"train": _fake_dataset(100), "val": _fake_dataset(20)}
    with patch("rfdetr.training.module_data.build_dataset", side_effect=lambda image_set, *_: datasets[image_set]):
        datamodule.setup("fit")
    return datamodule


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def fixture_training_setup():
    """Return the default model config, train config, and DataModule together."""
    model_config = _base_model_config()
    train_config = _base_train_config()
    datamodule = _build_datamodule(model_config, train_config)
    return model_config, train_config, datamodule


@pytest.fixture
def coco_datamodule(tmp_path):
    """Return an RFDETRDataModule configured for a COCO dataset."""
    return _build_datamodule(
        train_config=_base_train_config(tmp_path, dataset_file="coco"),
        tmp_path=tmp_path,
    )


@pytest.fixture
def propagate_rf_detr_logs(monkeypatch):
    """Re-enable propagation on the ``rf-detr`` logger, which ``get_logger()`` disables, so ``caplog`` sees its
    records."""
    monkeypatch.setattr(logging.getLogger("rf-detr"), "propagate", True)


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestInit:
    """RFDETRDataModule.__init__ stores configs and initialises dataset slots."""

    def test_stores_model_config(self, tmp_path, base_model_config):
        """model_config is accessible as an attribute after construction."""
        mc = base_model_config(num_classes=3)
        dm = _build_datamodule(model_config=mc, tmp_path=tmp_path)
        assert dm.model_config is mc

    def test_stores_train_config(self, tmp_path, base_train_config):
        """train_config is accessible as an attribute after construction."""
        tc = base_train_config(epochs=42)
        dm = _build_datamodule(train_config=tc, tmp_path=tmp_path)
        assert dm.train_config is tc

    def test_datasets_start_as_none(self, fixture_training_setup):
        """All three dataset slots are None before setup() is called."""
        _, _, dm = fixture_training_setup
        assert dm._dataset_train is None
        assert dm._dataset_val is None
        assert dm._dataset_test is None

    @pytest.mark.parametrize(
        "num_workers, prefetch_factor, expected_prefetch_factor",
        [
            pytest.param(2, None, 2, id="defaults-to-two-when-workers-enabled"),
            pytest.param(2, 5, 5, id="honors-train-config"),
            pytest.param(0, 5, None, id="none-when-workers-disabled"),
        ],
    )
    def test_prefetch_factor(self, tmp_path, base_train_config, num_workers, prefetch_factor, expected_prefetch_factor):
        """_prefetch_factor is derived from num_workers and the configured prefetch_factor."""
        tc = base_train_config(num_workers=num_workers, prefetch_factor=prefetch_factor)
        dm = _build_datamodule(train_config=tc, tmp_path=tmp_path)
        assert dm._prefetch_factor == expected_prefetch_factor

    def test_pin_memory_override_is_respected(self, tmp_path, base_train_config):
        """pin_memory can be explicitly overridden from TrainConfig."""
        tc = base_train_config(pin_memory=False)
        dm = _build_datamodule(train_config=tc, tmp_path=tmp_path)
        assert dm._pin_memory is False

    def test_pin_memory_defaults_to_false_when_accelerator_is_cpu(self, mocker, tmp_path, base_train_config):
        """Default pin_memory stays off when training is explicitly CPU-only."""
        mocker.patch("rfdetr.config.DEVICE", "cuda")
        tc = base_train_config(pin_memory=None, accelerator="cpu")
        dm = _build_datamodule(train_config=tc, tmp_path=tmp_path)
        assert dm._pin_memory is False

    def test_persistent_workers_override_is_respected(self, tmp_path, base_train_config):
        """persistent_workers can be explicitly overridden from TrainConfig."""
        tc = base_train_config(num_workers=2, persistent_workers=False)
        dm = _build_datamodule(train_config=tc, tmp_path=tmp_path)
        assert dm._persistent_workers is False

    @pytest.mark.parametrize("strategy", ["ddp_notebook", "ddp"])
    def test_strategy_preserves_num_workers(self, tmp_path, base_train_config, strategy):
        """No DDP strategy rewrites num_workers, and prefetch_factor keeps its default of 2 for workers > 0.

        ``ddp_notebook`` spawns children that initialise CUDA fresh, and DataLoader fork workers are CPU-only and never
        touch CUDA, so nested forks are safe.
        """
        tc = base_train_config(num_workers=4, strategy=strategy)
        dm = _build_datamodule(train_config=tc, tmp_path=tmp_path)
        assert dm._num_workers == 4
        assert dm._prefetch_factor == 2


class TestPrivateShowSamples:
    """RFDETRDataModule._show_samples renders transformed input samples."""

    def test_returns_figure_for_keypoint_targets(self, fixture_training_setup, monkeypatch):
        """_show_samples should render transformed boxes and keypoints without raw COCO parsing."""
        _, _, dm = fixture_training_setup
        import matplotlib

        matplotlib.use("Agg", force=True)
        from matplotlib import pyplot as plt
        from matplotlib.figure import Figure

        monkeypatch.setattr(dm, "_get_dataset_for_visualization", lambda split: _VisualDataset())

        figure = dm._show_samples(1, split="train", columns=1)

        assert isinstance(figure, Figure)
        assert len(figure.axes) == 1
        plt.close(figure)

    def test_accepts_figure_size_and_shortens_long_titles(self, fixture_training_setup, monkeypatch):
        """_show_samples should keep long image names inside subplot titles."""
        _, _, dm = fixture_training_setup
        import matplotlib

        matplotlib.use("Agg", force=True)
        from matplotlib import pyplot as plt

        monkeypatch.setattr(dm, "_get_dataset_for_visualization", lambda split: _VisualDataset())
        monkeypatch.setattr(dm, "_source_image_path", lambda dataset, idx: Path(f"{'very_long_name_' * 8}.jpg"))

        figure = dm._show_samples(1, split="train", columns=1, figure_size=(4.0, 3.0))

        assert list(figure.get_size_inches()) == pytest.approx([4.0, 3.0])
        title = figure.axes[0].get_title()
        assert "..." in title
        assert len(title) <= 48
        plt.close(figure)

    def test_rejects_non_positive_count(self, fixture_training_setup):
        """_show_samples should fail fast for invalid counts."""
        _, _, dm = fixture_training_setup
        with pytest.raises(ValueError) as exc_info:
            dm._show_samples(0)
        assert "count must be positive" in str(exc_info.value)

    def test_rejects_invalid_figure_size(self, fixture_training_setup):
        """_show_samples should fail fast for invalid figure sizes."""
        _, _, dm = fixture_training_setup
        with pytest.raises(ValueError) as exc_info:
            dm._show_samples(1, figure_size=(4.0, 0.0))
        assert "figure_size values must be positive" in str(exc_info.value)

    def test_missing_visual_extra_has_install_hint(self, fixture_training_setup, monkeypatch):
        """_show_samples should explain how to install optional visualization dependencies."""
        _, _, dm = fixture_training_setup
        real_import = builtins.__import__

        def fake_import(name, *args, **kwargs):
            if name == "matplotlib.pyplot":
                raise ImportError("matplotlib is intentionally unavailable")
            return real_import(name, *args, **kwargs)

        monkeypatch.setattr(dm, "_get_dataset_for_visualization", lambda split: _VisualDataset())
        monkeypatch.setattr(builtins, "__import__", fake_import)

        with pytest.raises(ImportError) as exc_info:
            dm._show_samples(1)
        assert "rfdetr[visual]" in str(exc_info.value)

    @pytest.mark.parametrize(
        ("dataset", "expected_annotator_calls"),
        [
            pytest.param(_VisualDataset(), 0, id="no-masks-key"),
            pytest.param(_MaskedVisualDataset(torch.ones((1, 16, 16), dtype=torch.bool)), 1, id="instance-masks"),
            pytest.param(_MaskedVisualDataset(torch.zeros((0, 16, 16), dtype=torch.bool)), 0, id="zero-instance-masks"),
        ],
    )
    def test_mask_annotator_runs_only_for_non_empty_masks(
        self, mocker, fixture_training_setup, monkeypatch, dataset, expected_annotator_calls
    ):
        """_show_samples overlays instance masks only when the targets carry at least one mask."""
        _, _, dm = fixture_training_setup
        import matplotlib

        matplotlib.use("Agg", force=True)
        from matplotlib import pyplot as plt
        from matplotlib.figure import Figure

        mock_mask_ann = mocker.patch("supervision.MaskAnnotator")
        mock_mask_ann.return_value.annotate.return_value = np.zeros((16, 16, 3), dtype=np.uint8)
        monkeypatch.setattr(dm, "_get_dataset_for_visualization", lambda split: dataset)

        figure = dm._show_samples(1, split="train", columns=1)

        assert isinstance(figure, Figure)
        assert mock_mask_ann.call_count == expected_annotator_calls
        assert mock_mask_ann.return_value.annotate.call_count == expected_annotator_calls
        plt.close(figure)


class TestSetup:
    """Setup(stage) builds the correct dataset(s) for each PTL stage."""

    def _setup_with_mock(self, tmp_path, stage, dataset_file="roboflow", **train_overrides):
        """Helper: construct DataModule and call setup(stage) with build_dataset mocked."""
        mc = _base_model_config()
        tc = _base_train_config(tmp_path, dataset_file=dataset_file, **train_overrides)
        dm = RFDETRDataModule(mc, tc)
        fake_train = _fake_dataset(100)
        fake_val = _fake_dataset(20)
        fake_test = _fake_dataset(10)
        datasets = {"train": fake_train, "val": fake_val, "test": fake_test}

        def _build(image_set, args, resolution):
            return datasets[image_set]

        with patch("rfdetr.training.module_data.build_dataset", side_effect=_build):
            dm.setup(stage)
        return dm, fake_train, fake_val, fake_test

    def test_fit_builds_train_and_val(self, tmp_path):
        """Setup('fit') populates both _dataset_train and _dataset_val."""
        dm, fake_train, fake_val, _ = self._setup_with_mock(tmp_path, "fit")
        assert dm._dataset_train is fake_train
        assert dm._dataset_val is fake_val
        assert dm._dataset_test is None

    def test_validate_builds_only_val(self, tmp_path):
        """Setup('validate') populates only _dataset_val."""
        dm, _, fake_val, _ = self._setup_with_mock(tmp_path, "validate")
        assert dm._dataset_train is None
        assert dm._dataset_val is fake_val
        assert dm._dataset_test is None

    @pytest.mark.parametrize("dataset_file", ["roboflow", "yolo"])
    def test_test_stage_uses_test_split(self, tmp_path, dataset_file):
        """Setup('test') requests the 'test' split for both Roboflow and YOLO datasets."""
        dm, _, _, fake_test = self._setup_with_mock(tmp_path, "test", dataset_file=dataset_file)
        assert dm._dataset_test is fake_test

    @pytest.mark.parametrize("dataset_file", ["roboflow", "yolo"])
    def test_test_stage_falls_back_to_val_without_test_split(self, mocker, tmp_path, dataset_file):
        """Setup('test') falls back to 'val' when the dataset declares no test split.

        A ``dataset_file="roboflow"`` dataset whose detected format is YOLO-style (``build_roboflow`` ->
        ``build_roboflow_from_yolo``, a common Roboflow export format) routes through the same builder as
        ``dataset_file="yolo"`` and can raise the same ``YoloSplitUnavailableError`` -- Roboflow's export UI does not
        require a test split.
        """
        dm = _build_datamodule(train_config=_base_train_config(tmp_path, dataset_file=dataset_file))
        fake_val = _fake_dataset(20)

        def _build(image_set, args, resolution):
            if image_set == "test":
                raise YoloSplitUnavailableError(str(tmp_path / "test" / "images"))
            return fake_val

        mocker.patch("rfdetr.training.module_data.build_dataset", side_effect=_build)
        dm.setup("test")

        assert dm._dataset_test is fake_val

    def _write_yolo_dataset_without_test_split(self, dataset_dir: Path) -> None:
        """Write an on-disk YOLO dataset with one ``train/`` image and two ``valid/`` images, no ``test/`` split.

        The split sizes differ so that a length assertion on the dataset built for the ``test`` stage distinguishes the
        ``valid`` fallback from an accidental ``train`` one.
        """
        for split, image_count in (("train", 1), ("valid", 2)):
            (dataset_dir / split / "images").mkdir(parents=True)
            (dataset_dir / split / "labels").mkdir(parents=True)
            for idx in range(image_count):
                image_path = dataset_dir / split / "images" / f"sample{idx}.png"
                Image.new("RGB", (8, 6), color=(255, 255, 255)).save(image_path)
                (dataset_dir / split / "labels" / f"sample{idx}.txt").write_text(
                    "0 0.5 0.5 0.5 0.5\n", encoding="utf-8"
                )
        (dataset_dir / "data.yaml").write_text("names:\n  - person\n", encoding="utf-8")

    def test_test_stage_roboflow_yolo_format_falls_back_to_val_end_to_end(
        self, tmp_path, caplog, propagate_rf_detr_logs
    ):
        """A real, unmocked Roboflow-YOLO export without a ``test/`` split falls back to ``valid/``.

        Exercises ``detect_roboflow_format`` -> ``build_roboflow_from_yolo`` end to end, not just the
        ``_build_test_dataset`` control flow around a mocked ``build_dataset``.
        """
        dataset_dir = tmp_path / "dataset"
        self._write_yolo_dataset_without_test_split(dataset_dir)
        dm = _build_datamodule(
            model_config=_base_model_config(num_classes=1),
            train_config=_base_train_config(tmp_path, dataset_file="roboflow", dataset_dir=str(dataset_dir)),
        )

        with caplog.at_level(logging.WARNING, logger="rf-detr"):
            dm.setup("test")

        assert isinstance(dm._dataset_test, YoloDetection)
        assert len(dm._dataset_test) == 2
        assert any("No resolvable 'test' split" in record.getMessage() for record in caplog.records)

    def test_test_stage_plain_yolo_falls_back_to_val_end_to_end(self, tmp_path):
        """A real, unmocked ``dataset_file="yolo"`` dataset without a ``test/`` split falls back to ``valid/``.

        Unlike the ``roboflow`` route, this one never runs ``detect_roboflow_format``: ``build_dataset`` dispatches
        straight to ``build_roboflow_from_yolo``.
        """
        dataset_dir = tmp_path / "dataset"
        self._write_yolo_dataset_without_test_split(dataset_dir)
        dm = _build_datamodule(
            model_config=_base_model_config(num_classes=1),
            train_config=_base_train_config(tmp_path, dataset_file="yolo", dataset_dir=str(dataset_dir)),
        )

        dm.setup("test")

        assert isinstance(dm._dataset_test, YoloDetection)
        assert len(dm._dataset_test) == 2

    @pytest.mark.parametrize("dataset_file", ["roboflow", "yolo"])
    def test_test_stage_propagates_broken_test_split(self, mocker, tmp_path, dataset_file):
        """Setup('test') propagates builder failures after a test split is resolved."""
        dm = _build_datamodule(train_config=_base_train_config(tmp_path, dataset_file=dataset_file))

        def _build(image_set, args, resolution):
            if image_set == "test":
                raise FileNotFoundError("declared test annotation file is broken")
            return _fake_dataset(20)

        mocker.patch("rfdetr.training.module_data.build_dataset", side_effect=_build)
        with pytest.raises(FileNotFoundError) as exc_info:
            dm.setup("test")
        assert "declared test annotation file is broken" in str(exc_info.value)

    @pytest.mark.parametrize(
        "dataset_file, dataset_label",
        [pytest.param("roboflow", "Roboflow", id="roboflow"), pytest.param("yolo", "YOLO", id="yolo")],
    )
    def test_test_stage_warns_when_falling_back_to_val(self, mocker, tmp_path, dataset_file, dataset_label):
        """The test-to-val fallback is logged at WARNING rather than applied silently."""
        mock_logger = mocker.patch("rfdetr.training.module_data.logger")
        dm = _build_datamodule(train_config=_base_train_config(tmp_path, dataset_file=dataset_file))

        def _build(image_set, args, resolution):
            if image_set == "test":
                raise YoloSplitUnavailableError(str(tmp_path / "test" / "images"))
            return _fake_dataset(20)

        mocker.patch("rfdetr.training.module_data.build_dataset", side_effect=_build)
        dm.setup("test")

        mock_logger.warning.assert_called_once_with(
            "No resolvable 'test' split for this %s dataset (%s); evaluating the 'val' split instead.",
            dataset_label,
            str(tmp_path / "test" / "images"),
        )

    def test_test_stage_coco_uses_val_split(self, mocker, coco_datamodule):
        """Setup('test') falls back to 'val' for COCO, whose test2017 split is unlabelled test-dev."""
        requested_splits = []

        def _build(image_set, args, resolution):
            requested_splits.append(image_set)
            return _fake_dataset(10)

        mocker.patch("rfdetr.training.module_data.build_dataset", side_effect=_build)
        coco_datamodule.setup("test")

        assert "val" in requested_splits
        assert "test" not in requested_splits

    def test_test_stage_does_not_rebuild_after_val_fallback(self, tmp_path):
        """A second setup('test') reuses the val dataset resolved by the first fallback."""
        dm = _build_datamodule(train_config=_base_train_config(tmp_path, dataset_file="yolo"))
        fake_val = _fake_dataset(20)

        def _build(image_set, args, resolution):
            if image_set == "test":
                raise YoloSplitUnavailableError(str(tmp_path / "test" / "images"))
            return fake_val

        with patch("rfdetr.training.module_data.build_dataset", side_effect=_build):
            dm.setup("test")
        with patch("rfdetr.training.module_data.build_dataset") as mock_build:
            dm.setup("test")
            mock_build.assert_not_called()

        assert dm._dataset_test is fake_val

    def test_fit_does_not_rebuild_if_already_set(self, mocker, tmp_path):
        """Setup('fit') skips building if datasets are already populated."""
        mock_build = mocker.patch("rfdetr.training.module_data.build_dataset")
        dm = _build_datamodule(tmp_path=tmp_path)
        existing_train = _fake_dataset(50)
        existing_val = _fake_dataset(10)
        dm._dataset_train = existing_train
        dm._dataset_val = existing_val

        dm.setup("fit")
        mock_build.assert_not_called()

        assert dm._dataset_train is existing_train
        assert dm._dataset_val is existing_val

    def test_predict_stage_builds_val_dataset(self, tmp_path):
        """Setup('predict') populates _dataset_val with the 'val' split."""
        dm, _, fake_val, _ = self._setup_with_mock(tmp_path, "predict")
        assert dm._dataset_val is fake_val
        assert dm._dataset_train is None
        assert dm._dataset_test is None

    def test_predict_stage_does_not_rebuild_existing_val(self, mocker, tmp_path):
        """Setup('predict') skips building when _dataset_val is already set."""
        mock_build = mocker.patch("rfdetr.training.module_data.build_dataset")
        dm = _build_datamodule(tmp_path=tmp_path)
        existing_val = _fake_dataset(20)
        dm._dataset_val = existing_val

        dm.setup("predict")
        mock_build.assert_not_called()

        assert dm._dataset_val is existing_val


class TestKeypointAugmentationWarning:
    """Keypoint mode warns only for keypoint-unsafe GPU augmentation."""

    def _build_dm(self, tmp_path, *, use_grouppose_keypoints: bool, augmentation_backend: str = "cpu"):
        mc = _base_model_config(
            use_grouppose_keypoints=use_grouppose_keypoints,
            num_keypoints_per_class=[17] if use_grouppose_keypoints else [],
        )
        tc = _base_train_config(tmp_path, augmentation_backend=augmentation_backend)
        return RFDETRDataModule(mc, tc)

    @pytest.mark.parametrize("use_grouppose_keypoints", [True, False])
    def test_cpu_augmentation_emits_no_keypoint_warning(self, mocker, tmp_path, use_grouppose_keypoints):
        """Setup('fit') does not warn about keypoint augmentation on the CPU backend, in keypoint or detection mode."""
        dm = self._build_dm(tmp_path, use_grouppose_keypoints=use_grouppose_keypoints, augmentation_backend="cpu")
        mocker.patch("rfdetr.training.module_data.build_dataset", side_effect=lambda *a, **k: _fake_dataset(10))

        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            dm.setup("fit")

        assert not [w for w in caught if "Keypoint mode" in str(w.message)]

    @_requires_kornia
    def test_keypoint_mode_gpu_augmentation_builds_pipeline(self, mocker, tmp_path: Path) -> None:
        """Setup('fit') builds a keypoint-enabled Kornia pipeline when the requested GPU backend is ready."""
        dm = self._build_dm(tmp_path, use_grouppose_keypoints=True, augmentation_backend="gpu")
        mocker.patch("rfdetr.training.module_data.build_dataset", side_effect=lambda *a, **k: _fake_dataset(10))
        mocker.patch("rfdetr.training.module_data._has_cuda_device", return_value=True)
        build = mocker.patch("rfdetr.datasets.kornia_transforms.build_kornia_pipeline", wraps=build_kornia_pipeline)

        dm.setup("fit")

        assert dm._resolved_augmentation_backend == AugmentationBackend.KORNIA
        build.assert_called_once()
        assert build.call_args.kwargs["with_keypoints"] is True
        assert dm._kornia_pipeline is not None

    @_requires_kornia
    def test_keypoint_mode_auto_can_select_kornia(self, mocker, tmp_path: Path) -> None:
        """Auto backend can resolve to Kornia for keypoints on a CUDA host."""
        dm = self._build_dm(tmp_path, use_grouppose_keypoints=True, augmentation_backend="auto")
        mocker.patch("rfdetr.training.module_data.build_dataset", side_effect=lambda *a, **k: _fake_dataset(10))
        mocker.patch("rfdetr.training.module_data._has_cuda_device", return_value=True)
        setup_pipeline = mocker.patch.object(dm, "_setup_kornia_pipeline")

        dm.setup("fit")

        assert dm._resolved_augmentation_backend == AugmentationBackend.KORNIA
        setup_pipeline.assert_called_once()


class TestPadTargetsToKorniaGuard:
    """The Kornia GPU pipeline's collate_boxes/unpack_boxes don't know about pad_targets_to's.

    ``valid`` key -- they rebuild their own real/filler mask from the padded box count, then strip the fillers back out,
    undoing the fixed row count the option exists for. `setup('fit')` rejects the combination instead of silently losing
    shape stability.
    """

    def _build_dm(self, tmp_path, *, pad_targets_to, augmentation_backend):
        mc = _base_model_config()
        tc = _base_train_config(tmp_path, pad_targets_to=pad_targets_to, augmentation_backend=augmentation_backend)
        return RFDETRDataModule(mc, tc)

    def test_pad_targets_to_with_gpu_augmentation_raises(self, mocker, tmp_path):
        """Setup('fit') should raise ValueError when pad_targets_to is combined with GPU augmentation."""
        dm = self._build_dm(tmp_path, pad_targets_to=12, augmentation_backend="gpu")
        mocker.patch("rfdetr.training.module_data.build_dataset", side_effect=lambda *a, **k: _fake_dataset(10))
        mocker.patch("rfdetr.training.module_data._has_cuda_device", return_value=True)
        mocker.patch.object(dm, "_setup_kornia_pipeline")

        with pytest.raises(ValueError) as exc_info:
            dm.setup("fit")

        assert "does not support pad_targets_to" in str(exc_info.value)

    def test_pad_targets_to_with_cpu_augmentation_no_raise(self, mocker, tmp_path):
        """Setup('fit') should not raise when pad_targets_to is combined with CPU augmentation."""
        mocker.patch("rfdetr.training.module_data.build_dataset", side_effect=lambda *a, **k: _fake_dataset(10))
        dm = self._build_dm(tmp_path, pad_targets_to=12, augmentation_backend="cpu")

        dm.setup("fit")

        assert dm.train_config.pad_targets_to == 12


class TestTrainDataloader:
    """train_dataloader() returns the correct DataLoader for large and small datasets."""

    def _setup_dm_with_train(self, tmp_path, dataset_length, batch_size=2, grad_accum_steps=1, num_workers=0):
        """Construct DataModule and inject a fake _dataset_train of given length."""
        mc = _base_model_config()
        tc = _base_train_config(
            tmp_path,
            batch_size=batch_size,
            grad_accum_steps=grad_accum_steps,
            num_workers=num_workers,
        )
        dm = RFDETRDataModule(mc, tc)
        dm._dataset_train = _fake_dataset(dataset_length)
        return dm

    def test_returns_dataloader(self, tmp_path):
        """train_dataloader() returns a DataLoader instance."""
        dm = self._setup_dm_with_train(tmp_path, dataset_length=200)
        loader = dm.train_dataloader()
        assert isinstance(loader, DataLoader)

    def test_large_dataset_uses_batch_sampler(self, tmp_path):
        """A large dataset uses a BatchSampler (drop_last=True, no replacement)."""
        # 200 samples > 2*1*5=10 threshold → large path
        dm = self._setup_dm_with_train(tmp_path, dataset_length=200, batch_size=2, grad_accum_steps=1)
        loader = dm.train_dataloader()
        assert loader.batch_sampler is not None
        assert isinstance(loader.batch_sampler, torch.utils.data.BatchSampler)
        assert loader.batch_sampler.drop_last is True

    def test_small_dataset_uses_replacement_sampler(self, tmp_path):
        """A small dataset (< effective_batch * min_batches) uses a replacement sampler."""
        # 3 samples < 2*1*5=10 threshold → small path
        dm = self._setup_dm_with_train(tmp_path, dataset_length=3, batch_size=2, grad_accum_steps=1)
        loader = dm.train_dataloader()
        assert isinstance(loader.sampler, torch.utils.data.RandomSampler)
        assert loader.sampler.replacement is True

    def test_small_dataset_replacement_sampler_num_samples(self, tmp_path):
        """Replacement sampler has num_samples == effective_batch_size * _MIN_TRAIN_BATCHES."""
        batch_size = 2
        grad_accum_steps = 3
        dm = self._setup_dm_with_train(
            tmp_path,
            dataset_length=3,
            batch_size=batch_size,
            grad_accum_steps=grad_accum_steps,
        )
        loader = dm.train_dataloader()
        expected = batch_size * grad_accum_steps * _MIN_TRAIN_BATCHES
        assert loader.sampler.num_samples == expected

    def test_batch_size_forwarded(self, tmp_path):
        """The DataLoader's batch size matches the train config."""
        dm = self._setup_dm_with_train(tmp_path, dataset_length=200, batch_size=8)
        loader = dm.train_dataloader()
        assert loader.batch_sampler.batch_size == 8

    def test_num_workers_forwarded(self, tmp_path):
        """The DataLoader's num_workers matches the train config."""
        dm = self._setup_dm_with_train(tmp_path, dataset_length=200, num_workers=0)
        loader = dm.train_dataloader()
        assert loader.num_workers == 0

    def test_threshold_exact_boundary_uses_batch_sampler(self, tmp_path):
        """Dataset of exactly effective_batch_size * _MIN_TRAIN_BATCHES is NOT small."""
        batch_size = 2
        grad_accum = 1
        length = batch_size * grad_accum * _MIN_TRAIN_BATCHES  # exactly at threshold
        dm = self._setup_dm_with_train(tmp_path, dataset_length=length, batch_size=batch_size)
        loader = dm.train_dataloader()
        assert isinstance(loader.batch_sampler, torch.utils.data.BatchSampler)

    @pytest.mark.parametrize(
        "dataset_length, batch_size, grad_accum_steps",
        [
            pytest.param(100, 2, 1, id="already_aligned_ga1"),
            pytest.param(96, 2, 4, id="already_aligned_ga4"),
            pytest.param(101, 2, 4, id="unaligned_one_extra"),
            pytest.param(50, 2, 8, id="unaligned_ga8"),
            pytest.param(59143, 2, 8, id="large_unaligned_coco_like"),
            pytest.param(100, 3, 3, id="non_power_of_two_ga"),
        ],
    )
    def test_train_dataloader_length_is_multiple_of_grad_accum(
        self, tmp_path, dataset_length, batch_size, grad_accum_steps
    ):
        """len(train_dataloader()) is always a multiple of grad_accum_steps.

        Verifies the workaround for https://github.com/Lightning-AI/pytorch-lightning/issues/19987: the training
        DataLoader must never present a partial accumulation window to PTL.
        """
        dm = self._setup_dm_with_train(
            tmp_path,
            dataset_length=dataset_length,
            batch_size=batch_size,
            grad_accum_steps=grad_accum_steps,
        )
        loader = dm.train_dataloader()
        assert len(loader) % grad_accum_steps == 0, (
            f"len(loader)={len(loader)} is not a multiple of grad_accum_steps={grad_accum_steps}"
        )

    def test_train_dataloader_respects_trainer_world_size(self, tmp_path):
        """Large-dataset path aligns wrapped dataset length to effective_batch_size * world_size."""
        dm = self._setup_dm_with_train(
            tmp_path,
            dataset_length=101,
            batch_size=2,
            grad_accum_steps=4,
        )
        dm.trainer = MagicMock(world_size=3, accumulate_grad_batches=4)

        loader = dm.train_dataloader()

        assert len(loader.dataset) % (2 * 4 * 3) == 0
        assert len(loader.dataset) == 120

    def test_build_train_sampler_default_returns_none(self, tmp_path):
        """The base build_train_sampler() hook returns None, leaving default sampling untouched."""
        dm = self._setup_dm_with_train(tmp_path, dataset_length=200)
        assert dm.build_train_sampler(dm._dataset_train) is None

    def test_custom_batch_sampler_is_used_as_is(self, tmp_path):
        """A non-None build_train_sampler() override is passed straight through as batch_sampler."""
        dm = self._setup_dm_with_train(tmp_path, dataset_length=200, num_workers=0)
        custom_sampler = torch.utils.data.BatchSampler(
            torch.utils.data.SequentialSampler(dm._dataset_train), batch_size=4, drop_last=False
        )
        dm.build_train_sampler = MagicMock(return_value=custom_sampler)

        loader = dm.train_dataloader()

        assert loader.batch_sampler is custom_sampler
        dm.build_train_sampler.assert_called_once_with(dm._dataset_train)

    def test_custom_batch_sampler_preserves_loader_kwargs(self, tmp_path):
        """The custom-sampler branch keeps collate_fn/num_workers/pin_memory from the base config."""
        dm = self._setup_dm_with_train(tmp_path, dataset_length=200, num_workers=0)
        custom_sampler = torch.utils.data.BatchSampler(
            torch.utils.data.SequentialSampler(dm._dataset_train), batch_size=4, drop_last=False
        )
        dm.build_train_sampler = MagicMock(return_value=custom_sampler)

        loader = dm.train_dataloader()

        assert loader.collate_fn is dm._collate_fn
        assert loader.num_workers == dm._num_workers
        assert loader.pin_memory == dm._pin_memory

    def test_custom_batch_sampler_skips_grad_accum_alignment(self, tmp_path):
        """The custom-sampler branch does not wrap the dataset in GradAccumAlignedDataset."""
        dm = self._setup_dm_with_train(tmp_path, dataset_length=101, batch_size=2, grad_accum_steps=4)
        original_dataset = dm._dataset_train
        custom_sampler = torch.utils.data.BatchSampler(
            torch.utils.data.SequentialSampler(original_dataset), batch_size=4, drop_last=False
        )
        dm.build_train_sampler = MagicMock(return_value=custom_sampler)

        loader = dm.train_dataloader()

        assert loader.dataset is original_dataset

    def test_warns_when_custom_sampler_leaves_a_short_accumulation_window(self, tmp_path, caplog, monkeypatch):
        """A batch-sampler epoch that is not a multiple of grad_accum_steps under-scales the last optimizer step."""
        dm = self._setup_dm_with_train(tmp_path, dataset_length=101, batch_size=2, grad_accum_steps=4)
        # 101 samples in batches of 4 is 26 batches, and 26 % 4 == 2.
        custom_sampler = torch.utils.data.BatchSampler(
            torch.utils.data.SequentialSampler(dm._dataset_train), batch_size=4, drop_last=False
        )
        dm.build_train_sampler = MagicMock(return_value=custom_sampler)
        # get_logger() sets propagate=False on the "rf-detr" logger, so caplog's handler only sees its
        # records while propagation is re-enabled.
        monkeypatch.setattr(logging.getLogger("rf-detr"), "propagate", True)

        with caplog.at_level(logging.WARNING, logger="rf-detr"):
            dm.train_dataloader()

        assert "not a multiple of grad_accum_steps" in caplog.text

    def test_no_warning_when_custom_sampler_epoch_is_already_aligned(self, tmp_path, caplog, monkeypatch):
        """An aligned epoch must stay quiet, so the warning keeps its signal."""
        dm = self._setup_dm_with_train(tmp_path, dataset_length=96, batch_size=2, grad_accum_steps=4)
        # 96 samples in batches of 4 is exactly 24 batches, and 24 % 4 == 0.
        custom_sampler = torch.utils.data.BatchSampler(
            torch.utils.data.SequentialSampler(dm._dataset_train), batch_size=4, drop_last=False
        )
        dm.build_train_sampler = MagicMock(return_value=custom_sampler)
        monkeypatch.setattr(logging.getLogger("rf-detr"), "propagate", True)

        with caplog.at_level(logging.WARNING, logger="rf-detr"):
            dm.train_dataloader()

        assert "not a multiple of grad_accum_steps" not in caplog.text

    def test_no_warning_without_gradient_accumulation(self, tmp_path, caplog, monkeypatch):
        """With grad_accum_steps=1 every window is one micro-batch, so no epoch length can be short."""
        dm = self._setup_dm_with_train(tmp_path, dataset_length=101, batch_size=2, grad_accum_steps=1)
        custom_sampler = torch.utils.data.BatchSampler(
            torch.utils.data.SequentialSampler(dm._dataset_train), batch_size=4, drop_last=False
        )
        dm.build_train_sampler = MagicMock(return_value=custom_sampler)
        monkeypatch.setattr(logging.getLogger("rf-detr"), "propagate", True)

        with caplog.at_level(logging.WARNING, logger="rf-detr"):
            dm.train_dataloader()

        assert "not a multiple of grad_accum_steps" not in caplog.text

    def test_sampler_without_len_is_not_checked(self, tmp_path):
        """A sampler declaring no epoch length must not break loader construction."""

        class _UnsizedBatchSampler(torch.utils.data.Sampler):
            def __iter__(self):
                yield [0, 1]

        dm = self._setup_dm_with_train(tmp_path, dataset_length=101, batch_size=2, grad_accum_steps=4)
        # No constructor argument: torch dropped Sampler's deprecated `data_source` parameter, so on newer
        # versions this subclass inherits object.__init__ and any argument raises TypeError.
        dm.build_train_sampler = MagicMock(return_value=_UnsizedBatchSampler())

        assert dm.train_dataloader().batch_sampler is not None

    def test_batch_multiple_gives_the_loader_whole_accumulation_windows(self, tmp_path):
        """The documented fix: batch_multiple=grad_accum_steps makes len(loader) an exact number of windows."""
        dm = self._setup_dm_with_train(tmp_path, dataset_length=101, batch_size=2, grad_accum_steps=4)
        sampler = WeightedMultiSourceBatchSampler(
            [len(dm._dataset_train)], [1.0], batch_size=2, num_replicas=1, rank=0, batch_multiple=4
        )
        dm.build_train_sampler = MagicMock(return_value=sampler)

        loader = dm.train_dataloader()

        assert len(loader) % 4 == 0

    def test_check_custom_sampler_owns_ddp_noop_when_trainer_is_unset(self, tmp_path):
        """No Trainer attached (e.g. the guard called standalone) never raises."""
        dm = self._setup_dm_with_train(tmp_path, dataset_length=200)
        custom_sampler = torch.utils.data.BatchSampler(
            torch.utils.data.SequentialSampler(dm._dataset_train), batch_size=4, drop_last=False
        )
        dm._check_custom_sampler_owns_ddp(custom_sampler)

    def test_check_custom_sampler_owns_ddp_noop_for_single_device(self, tmp_path):
        """A non-distributed Trainer (distributed_sampler_kwargs is None) never raises."""
        dm = self._setup_dm_with_train(tmp_path, dataset_length=200)
        dm.trainer = MagicMock(distributed_sampler_kwargs=None)
        custom_sampler = torch.utils.data.BatchSampler(
            torch.utils.data.SequentialSampler(dm._dataset_train), batch_size=4, drop_last=False
        )
        dm._check_custom_sampler_owns_ddp(custom_sampler)

    def test_check_custom_sampler_owns_ddp_noop_when_use_distributed_sampler_is_false(self, tmp_path):
        """The correct configuration (use_distributed_sampler=False) never raises."""
        dm = self._setup_dm_with_train(tmp_path, dataset_length=200)
        trainer = MagicMock()
        trainer.distributed_sampler_kwargs = {"num_replicas": 2, "rank": 0}
        trainer._accelerator_connector.use_distributed_sampler = False
        dm.trainer = trainer
        custom_sampler = torch.utils.data.BatchSampler(
            torch.utils.data.SequentialSampler(dm._dataset_train), batch_size=4, drop_last=False
        )
        dm._check_custom_sampler_owns_ddp(custom_sampler)

    def test_check_custom_sampler_owns_ddp_raises_when_lightning_would_rewrap_the_sampler(self, tmp_path):
        """A distributed Trainer still set to use_distributed_sampler=True raises before Lightning's TypeError."""
        dm = self._setup_dm_with_train(tmp_path, dataset_length=200)
        trainer = MagicMock()
        trainer.distributed_sampler_kwargs = {"num_replicas": 2, "rank": 0}
        trainer._accelerator_connector.use_distributed_sampler = True
        trainer._accelerator_connector.is_distributed = True
        dm.trainer = trainer
        custom_sampler = torch.utils.data.BatchSampler(
            torch.utils.data.SequentialSampler(dm._dataset_train), batch_size=4, drop_last=False
        )

        with pytest.raises(RuntimeError, match="use_distributed_sampler=False"):
            dm._check_custom_sampler_owns_ddp(custom_sampler)

    def test_train_dataloader_raises_for_custom_sampler_under_misconfigured_ddp(self, tmp_path):
        """train_dataloader() surfaces the DDP guard's RuntimeError before constructing the DataLoader."""
        dm = self._setup_dm_with_train(tmp_path, dataset_length=200)
        trainer = MagicMock()
        trainer.distributed_sampler_kwargs = {"num_replicas": 2, "rank": 0}
        trainer._accelerator_connector.use_distributed_sampler = True
        trainer._accelerator_connector.is_distributed = True
        dm.trainer = trainer
        custom_sampler = torch.utils.data.BatchSampler(
            torch.utils.data.SequentialSampler(dm._dataset_train), batch_size=4, drop_last=False
        )
        dm.build_train_sampler = MagicMock(return_value=custom_sampler)

        with pytest.raises(RuntimeError, match="use_distributed_sampler=False"):
            dm.train_dataloader()

    def test_check_custom_sampler_owns_ddp_pins_ptl_private_attributes_on_a_real_trainer(self, tmp_path):
        """The guard's private PyTorch Lightning attributes still exist on a real (non-mocked) Trainer.

        Every other test in this group attaches a ``MagicMock`` trainer, which auto-vivifies any attribute name — so
        `getattr(x, attr, None)` never reaches its `None` default the way it would for a genuinely renamed or removed
        attribute. A real single-device Trainer pins the actual surface, so a PyTorch Lightning upgrade that renames it
        fails this test loudly instead of silently turning the guard into a no-op.
        """
        from pytorch_lightning import Trainer

        dm = self._setup_dm_with_train(tmp_path, dataset_length=200)
        trainer = Trainer(accelerator="cpu", devices=1, logger=False, enable_checkpointing=False)
        dm.trainer = trainer
        custom_sampler = torch.utils.data.BatchSampler(
            torch.utils.data.SequentialSampler(dm._dataset_train), batch_size=4, drop_last=False
        )

        assert hasattr(trainer._accelerator_connector, "use_distributed_sampler")
        assert hasattr(trainer._accelerator_connector, "is_distributed")
        dm._check_custom_sampler_owns_ddp(custom_sampler)  # single device: never raises

    def test_check_custom_sampler_owns_ddp_noop_when_flag_attribute_is_genuinely_absent(self, tmp_path):
        """A truly missing attribute (not a ``MagicMock`` auto-vivified one) still falls back safely.

        ``MagicMock`` returns a truthy sub-mock for any attribute name, so a MagicMock trainer can never exercise the
        ``getattr(..., None)`` fallback the way a real missing attribute would.
        """
        dm = self._setup_dm_with_train(tmp_path, dataset_length=200)

        class _AccelConnectorMissingUseDistributedSampler:
            is_distributed = True

        class _TrainerWithIncompleteConnector:
            distributed_sampler_kwargs = {"num_replicas": 2, "rank": 0}
            _accelerator_connector = _AccelConnectorMissingUseDistributedSampler()

        dm.trainer = _TrainerWithIncompleteConnector()
        custom_sampler = torch.utils.data.BatchSampler(
            torch.utils.data.SequentialSampler(dm._dataset_train), batch_size=4, drop_last=False
        )

        dm._check_custom_sampler_owns_ddp(custom_sampler)  # missing use_distributed_sampler -> no raise

    @pytest.mark.parametrize(
        ("dataset_length", "grad_accum_steps", "trainer_grad_accum_steps", "expected_samples"),
        [
            pytest.param(3, 1, 1, 20, id="far_below_threshold"),
            pytest.param(12, 1, 1, 20, id="between_single_and_ddp_thresholds"),
            pytest.param(19, 1, 1, 20, id="threshold_minus_one"),
            pytest.param(20, 1, 1, 20, id="exact_threshold"),
            pytest.param(21, 1, 1, 24, id="threshold_plus_one"),
            pytest.param(3, 3, 3, 60, id="configured_gradient_accumulation"),
            pytest.param(3, 1, 2, 40, id="trainer_gradient_accumulation_override"),
        ],
    )
    def test_ddp_preserves_minimum_effective_batches_per_rank(
        self,
        tmp_path: Path,
        dataset_length: int,
        grad_accum_steps: int,
        trainer_grad_accum_steps: int,
        expected_samples: int,
    ) -> None:
        """DDP keeps five complete optimizer steps per rank across the small-dataset threshold."""
        batch_size = 2
        world_size = 2
        dm = self._setup_dm_with_train(
            tmp_path,
            dataset_length=dataset_length,
            batch_size=batch_size,
            grad_accum_steps=grad_accum_steps,
        )
        dm.trainer = MagicMock(
            world_size=world_size,
            accumulate_grad_batches=trainer_grad_accum_steps,
        )

        loader = dm.train_dataloader()

        assert len(loader.dataset) == expected_samples

    def test_ddp_keypoint_uses_manually_owned_gradient_accumulation(self, tmp_path: Path) -> None:
        """Keypoint padding follows TrainConfig rather than Lightning's forced accumulation value of one."""
        model_config = _base_model_config(use_grouppose_keypoints=True)
        train_config = KeypointTrainConfig(
            **_base_train_config(tmp_path, batch_size=2, grad_accum_steps=3).model_dump()
        )
        dm = RFDETRDataModule(model_config, train_config)
        dm._dataset_train = _fake_dataset(3)
        dm.trainer = MagicMock(world_size=2, accumulate_grad_batches=1)

        loader = dm.train_dataloader()

        assert len(loader.dataset) == 60

    @staticmethod
    def _raw_sample(h: int = 16, w: int = 16) -> tuple[torch.Tensor, dict[str, torch.Tensor]]:
        """Build one (image, target) pair as a dataset __getitem__ would return it, for collate_fn input.

        Examples:
            >>> image, target = TestTrainDataloader._raw_sample()
            >>> image.shape, sorted(target)
            (torch.Size([3, 16, 16]), ['boxes', 'image_id', 'labels', 'orig_size'])
        """
        image = torch.randn(3, h, w)
        target = {
            "boxes": torch.tensor([[0.5, 0.5, 0.1, 0.1]]),
            "labels": torch.tensor([1]),
            "image_id": torch.tensor(0),
            "orig_size": torch.tensor([h, w]),
        }
        return image, target

    @pytest.mark.parametrize(
        ("loader_name", "dataset_attribute"),
        [
            pytest.param("train_dataloader", "_dataset_train", id="train"),
            pytest.param("val_dataloader", "_dataset_val", id="validation"),
            pytest.param("test_dataloader", "_dataset_test", id="test"),
            pytest.param("predict_dataloader", "_dataset_val", id="predict"),
        ],
    )
    def test_pack_targets_default_makes_every_loader_collate_packed_targets(
        self, tmp_path, loader_name, dataset_attribute
    ):
        """The default must make each public DataLoader's collate function return PackedTargets."""
        dm = RFDETRDataModule(_base_model_config(), _base_train_config(tmp_path))
        setattr(dm, dataset_attribute, _fake_dataset(200))

        loader = getattr(dm, loader_name)()
        _, targets = loader.collate_fn([self._raw_sample(), self._raw_sample()])

        assert isinstance(targets, PackedTargets)

    def test_pack_targets_false_keeps_collate_fn_output_a_tuple_of_dicts(self, tmp_path):
        """An explicit TrainConfig.pack_targets=False leaves train_dataloader().collate_fn output unpacked."""
        dm = RFDETRDataModule(_base_model_config(), _base_train_config(tmp_path, pack_targets=False))
        dm._dataset_train = _fake_dataset(200)

        loader = dm.train_dataloader()
        _, targets = loader.collate_fn([self._raw_sample(), self._raw_sample()])

        assert not isinstance(targets, PackedTargets)
        assert all(isinstance(t, dict) for t in targets)

    def test_pad_targets_to_composes_with_pack_for_the_train_loader(self, tmp_path):
        """pad_targets_to runs before pack in the collate seam (see make_collate_fn): once every sample shares one row
        count, a batch that previously packed still packs, at the padded shape."""
        dm = RFDETRDataModule(_base_model_config(), _base_train_config(tmp_path, pack_targets=True, pad_targets_to=4))
        dm._dataset_train = _fake_dataset(200)
        image, one_box = self._raw_sample()
        three_boxes = {**one_box, "boxes": torch.rand(3, 4), "labels": torch.arange(3)}

        loader = dm.train_dataloader()
        _, targets = loader.collate_fn([(image, one_box), (image, three_boxes)])

        assert isinstance(targets, PackedTargets)
        rebuilt = list(targets)
        assert [t["boxes"].shape[0] for t in rebuilt] == [4, 4]
        assert rebuilt[0]["valid"].tolist() == [True, False, False, False]
        assert rebuilt[1]["valid"].tolist() == [True, True, True, False]

    def test_pad_targets_to_only_reaches_the_train_loader(self, tmp_path):
        """Padding the eval loaders would feed filler rows to COCO matching as real ground truth, so only
        train_dataloader() may pad; val/test/predict keep the real, variable-length targets."""
        dm = RFDETRDataModule(_base_model_config(), _base_train_config(tmp_path, pack_targets=False, pad_targets_to=4))
        dm._dataset_train = _fake_dataset(200)
        dm._dataset_val = _fake_dataset(200)

        _, train_targets = dm.train_dataloader().collate_fn([self._raw_sample()])
        _, val_targets = dm.val_dataloader().collate_fn([self._raw_sample()])

        assert train_targets[0]["boxes"].shape[0] == 4
        assert "valid" in train_targets[0]
        assert val_targets[0]["boxes"].shape[0] == 1
        assert "valid" not in val_targets[0]

    @patch("rfdetr.training.module_data.build_webdataset_loader")
    def test_webdataset_loader_pads_only_the_fixed_epoch_train_call(self, mock_build_webdataset_loader, tmp_path):
        """_webdataset_loader is shared by train (fixed_epoch=True) and eval; only the train call may collate through
        the padded/packed self._collate_fn_train."""
        dm = RFDETRDataModule(_base_model_config(), _base_train_config(tmp_path, pack_targets=True, pad_targets_to=4))
        captured = {}

        def _fake_build_webdataset_loader(dataset, *, collate_fn, **kwargs):
            captured["collate_fn"] = collate_fn
            return MagicMock()

        mock_build_webdataset_loader.side_effect = _fake_build_webdataset_loader

        dm._webdataset_loader(MagicMock(), batch_size=2, fixed_epoch=True)
        assert captured["collate_fn"] is dm._collate_fn_train

        dm._webdataset_loader(MagicMock(), batch_size=2, fixed_epoch=False)
        assert captured["collate_fn"] is dm._collate_fn

    @staticmethod
    def _raw_segmentation_sample(
        h: int = 16, w: int = 16, num_instances: int = 1
    ) -> tuple[torch.Tensor, dict[str, torch.Tensor]]:
        """Build one (image, target) pair shaped exactly as the COCO reader produces for a
        segmentation model: ``masks`` is ``torch.bool`` of shape ``(num_instances, H, W)``,
        alongside the ``area``/``iscrowd``/``size`` fields ``rfdetr.datasets.coco.py`` always
        attaches next to it. ``image_id`` is rank-1 (``torch.as_tensor([image_id])``,
        ``coco.py:653``), not the rank-0 scalar ``ConvertCoco``'s own docstring calls it
        (``coco.py:615``) -- matched to the actual runtime shape here.

        Args:
            h: Image and mask height. Pass distinct values across samples in the same
                batch to exercise ``pack_targets``'s per-sample shape bookkeeping --
                ``RandomResize`` preserves each source image's own aspect ratio, so a real
                collated batch routinely mixes segmentation masks of different spatial shape.
            w: Image and mask width, independent of ``h`` for the same reason.
            num_instances: Number of instances in the sample; ``0`` produces an
                empty-but-shaped ``masks`` tensor.

        Returns:
            The synthetic image tensor and its matching target dict.

        Examples:
            >>> image, target = TestTrainDataloader._raw_segmentation_sample(num_instances=2)
            >>> target["masks"].shape, target["masks"].dtype
            (torch.Size([2, 16, 16]), torch.bool)
        """
        image = torch.randn(3, h, w)
        target = {
            "boxes": torch.rand(num_instances, 4),
            "labels": torch.arange(num_instances, dtype=torch.int64),
            "image_id": torch.as_tensor([0]),
            "area": torch.rand(num_instances),
            "iscrowd": torch.zeros(num_instances, dtype=torch.int64),
            "orig_size": torch.tensor([h, w]),
            "size": torch.tensor([h, w]),
            "masks": torch.rand(num_instances, h, w) > 0.5,
        }
        return image, target

    def test_pack_targets_round_trips_segmentation_masks_bit_identically(self, tmp_path):
        """#1399's own body flagged this as unmeasured: the packer handles any same-keyed field, including ``masks``,
        but no parity run existed for it.

        This pins correctness through the real DataModule collate seam, using ``to_list()`` -- the exact method
        ``transfer_batch_to_device`` calls on the real training path -- rather than a related but different
        iteration method. The middle, zero-instance sample mirrors
        ``TestPackedTargets.test_a_sample_with_no_instances_survives_the_round_trip`` in
        ``tests/utilities/test_tensors.py`` -- that test pins the same "must not collapse into a neighbour's rows"
        invariant for ``boxes``/``labels``, but never through a real segmentation batch's ``masks`` field.
        """
        model_config = _base_model_config(segmentation_head=True)
        dm = RFDETRDataModule(model_config, _base_train_config(tmp_path, pack_targets=True))
        dm._dataset_train = _fake_dataset(200)

        loader = dm.train_dataloader()
        # Distinct, non-transposed H/W per sample: RandomResize keeps aspect ratios, so real batches mix mask
        # shapes; same-shape samples would round-trip even if pack_targets reused one sample's spatial shape.
        sample_a = self._raw_segmentation_sample(h=14, w=22, num_instances=1)
        sample_zero = self._raw_segmentation_sample(h=20, w=10, num_instances=0)
        sample_b = self._raw_segmentation_sample(h=18, w=16, num_instances=3)
        _, packed = loader.collate_fn([sample_a, sample_zero, sample_b])

        assert isinstance(packed, PackedTargets), "a real segmentation batch must still pack"
        rebuilt = packed.to_list(torch.device("cpu"))
        for (_, expected), actual in zip([sample_a, sample_zero, sample_b], rebuilt, strict=True):
            assert actual["masks"].dtype == torch.bool
            assert actual["masks"].shape == expected["masks"].shape
            assert torch.equal(actual["masks"], expected["masks"]), "masks must round-trip bit-identically"
            assert torch.equal(actual["boxes"], expected["boxes"])
            assert torch.equal(actual["labels"], expected["labels"])
            assert torch.equal(actual["area"], expected["area"])
            assert torch.equal(actual["iscrowd"], expected["iscrowd"])
        assert rebuilt[1]["masks"].shape == (0, 20, 10), "the zero-instance sample must not collapse into a neighbour"


class TestGradAccumAlignedDataset:
    """Unit tests for the GradAccumAlignedDataset wrapper."""

    def _make_dataset(self, length: int) -> torch.utils.data.TensorDataset:
        """Return a simple TensorDataset of given length."""
        return torch.utils.data.TensorDataset(torch.arange(length))

    @pytest.mark.parametrize(
        "length, effective_batch_size, world_size, minimum_length, expected_length",
        [
            pytest.param(64, 16, 1, None, 64, id="no-padding-needed-when-already-aligned"),
            pytest.param(50, 16, 1, None, 64, id="padding-adds-correct-count"),  # 50 % 16 = 2 -> pad 14
            pytest.param(3, 2, 2, 20, 20, id="minimum-length-repeats-to-requested-aligned-size"),
        ],
    )
    def test_wrapped_length(self, length, effective_batch_size, world_size, minimum_length, expected_length):
        """Len(wrapped) reflects padding to the alignment unit, or to minimum_length when it is larger."""
        ds = self._make_dataset(length)
        wrapped = GradAccumAlignedDataset(
            ds, effective_batch_size=effective_batch_size, world_size=world_size, minimum_length=minimum_length
        )
        assert len(wrapped) == expected_length

    def test_getitem_forwards_to_original_dataset(self):
        """Items in the original range map directly to the underlying dataset."""
        ds = self._make_dataset(10)
        wrapped = GradAccumAlignedDataset(ds, effective_batch_size=4, world_size=1)
        for i in range(10):
            (val,) = wrapped[i]
            assert val.item() == i

    def test_padded_indices_are_valid(self):
        """All padded indices point to valid positions in the original dataset."""
        n = 10
        ds = self._make_dataset(n)
        wrapped = GradAccumAlignedDataset(ds, effective_batch_size=4, world_size=1)
        for i in range(len(wrapped)):
            (val,) = wrapped[i]
            assert 0 <= val.item() < n

    @pytest.mark.parametrize(
        "n, eff_bs, world_size",
        [
            pytest.param(100, 4, 1, id="aligned_single_gpu"),
            pytest.param(101, 4, 1, id="unaligned_single_gpu"),
            pytest.param(100, 4, 2, id="aligned_ddp2"),
            pytest.param(97, 4, 2, id="unaligned_ddp2"),
        ],
    )
    def test_length_always_multiple_of_pad_unit(self, n, eff_bs, world_size):
        """Len(wrapped) % (eff_bs * world_size) == 0 for all inputs."""
        ds = self._make_dataset(n)
        wrapped = GradAccumAlignedDataset(ds, effective_batch_size=eff_bs, world_size=world_size)
        assert len(wrapped) % (eff_bs * world_size) == 0

    @pytest.mark.parametrize(
        "effective_batch_size, world_size",
        [
            pytest.param(0, 1, id="zero_effective_batch_size"),
            pytest.param(-1, 1, id="negative_effective_batch_size"),
            pytest.param(2, 0, id="zero_world_size"),
            pytest.param(2, -1, id="negative_world_size"),
        ],
    )
    def test_raises_for_non_positive_alignment_inputs(self, effective_batch_size, world_size):
        """Non-positive alignment inputs fail with a clear ValueError."""
        ds = self._make_dataset(10)
        with pytest.raises(ValueError) as exc_info:
            GradAccumAlignedDataset(ds, effective_batch_size=effective_batch_size, world_size=world_size)
        assert "must be >= 1" in str(exc_info.value)


@pytest.mark.parametrize(("loader_name", "dataset_attribute"), _EVAL_LOADER_DATASETS)
class TestEvalDataloaders:
    """Val/test/predict dataloaders sample sequentially, keep the last partial batch and forward the train config."""

    @staticmethod
    def _build_dm(tmp_path, dataset_attribute, batch_size=2, num_workers=0):
        """Return a DataModule whose ``dataset_attribute`` holds a 50-item fake dataset.

        Examples:
            >>> dm = TestEvalDataloaders._build_dm(Path("dataset-root"), "_dataset_test", batch_size=4)
            >>> dm.train_config.batch_size, len(dm._dataset_test)
            (4, 50)
        """
        mc = _base_model_config()
        tc = _base_train_config(tmp_path, batch_size=batch_size, num_workers=num_workers)
        dm = RFDETRDataModule(mc, tc)
        setattr(dm, dataset_attribute, _fake_dataset(50))
        return dm

    def test_returns_dataloader(self, tmp_path, loader_name, dataset_attribute):
        """The loader factory returns a DataLoader instance."""
        loader = getattr(self._build_dm(tmp_path, dataset_attribute), loader_name)()
        assert isinstance(loader, DataLoader)

    def test_uses_sequential_sampler(self, tmp_path, loader_name, dataset_attribute):
        """The loader samples sequentially, so ordering is deterministic."""
        loader = getattr(self._build_dm(tmp_path, dataset_attribute), loader_name)()
        assert isinstance(loader.sampler, torch.utils.data.SequentialSampler)

    def test_drop_last_false(self, tmp_path, loader_name, dataset_attribute):
        """The loader does not drop the last incomplete batch."""
        loader = getattr(self._build_dm(tmp_path, dataset_attribute), loader_name)()
        assert loader.drop_last is False

    def test_batch_size_forwarded(self, tmp_path, loader_name, dataset_attribute):
        """The DataLoader's batch size matches the train config."""
        loader = getattr(self._build_dm(tmp_path, dataset_attribute, batch_size=6), loader_name)()
        assert loader.batch_size == 6

    def test_num_workers_forwarded(self, tmp_path, loader_name, dataset_attribute):
        """The DataLoader's num_workers matches the train config."""
        loader = getattr(self._build_dm(tmp_path, dataset_attribute, num_workers=0), loader_name)()
        assert loader.num_workers == 0


class TestEvalBatchSize:
    """eval_batch_size decouples the val/test/predict DataLoaders from the train micro-batch size."""

    def _setup_dm(
        self,
        tmp_path: Path,
        batch_size: int | str = 2,
        eval_batch_size: int | None = None,
        grad_accum_steps: int = 1,
        dataset_length: int = 50,
    ) -> RFDETRDataModule:
        """Build a data module with every loader dataset injected.

        Examples:
            >>> datamodule = TestEvalBatchSize()._setup_dm(Path("/tmp"), batch_size=4, eval_batch_size=8)
            >>> datamodule.train_config.batch_size, datamodule.train_config.eval_batch_size
            (4, 8)
        """
        mc = _base_model_config()
        tc = _base_train_config(
            tmp_path,
            batch_size=batch_size,
            eval_batch_size=eval_batch_size,
            grad_accum_steps=grad_accum_steps,
            num_workers=0,
        )
        dm = RFDETRDataModule(mc, tc)
        dm._dataset_train = _fake_dataset(dataset_length)
        dm._dataset_val = _fake_dataset(dataset_length)
        dm._dataset_test = _fake_dataset(dataset_length)
        return dm

    @pytest.mark.parametrize("loader_name", _EVAL_LOADERS)
    @pytest.mark.parametrize(
        "batch_size, eval_batch_size, expected_batch_size",
        [
            pytest.param(6, None, 6, id="defaults-to-train-batch-size"),
            pytest.param(2, 16, 16, id="explicit-value-overrides-train-batch-size"),
            pytest.param("auto", 8, 8, id="explicit-value-works-with-unresolved-auto-batch-size"),
        ],
    )
    def test_eval_loader_batch_size(
        self, tmp_path: Path, loader_name: str, batch_size, eval_batch_size, expected_batch_size
    ) -> None:
        """Every eval DataLoader's batch_size follows eval_batch_size when set, else the train batch_size."""
        dm = self._setup_dm(tmp_path, batch_size=batch_size, eval_batch_size=eval_batch_size)
        loader = getattr(dm, loader_name)()
        assert loader.batch_size == expected_batch_size

    def test_train_dataloader_keeps_train_batch_size(self, tmp_path: Path) -> None:
        """The training DataLoader ignores eval_batch_size and keeps the configured train batch size."""
        dm = self._setup_dm(tmp_path, batch_size=2, eval_batch_size=16)
        loader = dm.train_dataloader()
        assert loader.batch_sampler.batch_size == 2

    def test_train_dataloader_grad_accum_alignment_unaffected(self, tmp_path: Path) -> None:
        """Train-side grad-accum padding still aligns to batch_size * grad_accum_steps, not eval_batch_size."""
        dm = self._setup_dm(tmp_path, batch_size=2, eval_batch_size=16, grad_accum_steps=4, dataset_length=50)
        loader = dm.train_dataloader()
        assert len(loader.dataset) % (2 * 4) == 0

    def test_unresolved_auto_batch_size_still_raises_without_explicit_value(self, tmp_path: Path) -> None:
        """Without eval_batch_size, an unresolved batch_size='auto' still fails eval loader construction."""
        dm = self._setup_dm(tmp_path, batch_size="auto", eval_batch_size=None)
        with pytest.raises(RuntimeError) as exc_info:
            dm.val_dataloader()
        assert "was not resolved" in str(exc_info.value)


class TestClassNames:
    """class_names property extracts names from COCO dataset annotations."""

    def test_returns_none_before_setup(self, fixture_training_setup):
        """class_names is None when no dataset has been set up."""
        _, _, dm = fixture_training_setup
        assert dm.class_names is None

    def test_returns_names_from_train_dataset(self, tmp_path):
        """class_names reads from _dataset_train.coco.cats when available."""
        dm = _build_datamodule(tmp_path=tmp_path)
        dm._dataset_train = _fake_dataset(50, with_coco=True)
        assert dm.class_names == ["cat", "dog"]

    def test_returns_names_from_val_dataset_when_train_missing(self, tmp_path):
        """class_names falls back to _dataset_val when _dataset_train has no COCO."""
        dm = _build_datamodule(tmp_path=tmp_path)
        dm._dataset_train = _fake_dataset(50, with_coco=False)
        dm._dataset_val = _fake_dataset(20, with_coco=True)
        assert dm.class_names == ["cat", "dog"]

    def test_returns_none_when_no_coco_attribute(self, tmp_path):
        """class_names returns None when no dataset has a coco attribute."""
        dm = _build_datamodule(tmp_path=tmp_path)
        dm._dataset_train = _fake_dataset(50, with_coco=False)
        dm._dataset_val = _fake_dataset(20, with_coco=False)
        assert dm.class_names is None

    def test_class_names_sorted_by_category_id(self, tmp_path):
        """class_names are sorted by COCO category ID."""
        dm = _build_datamodule(tmp_path=tmp_path)
        dataset = _fake_dataset(50)
        coco = MagicMock()
        # Deliberately out of order IDs
        coco.cats = {3: {"name": "zebra"}, 1: {"name": "ant"}, 2: {"name": "bee"}}
        dataset.coco = coco
        dm._dataset_train = dataset
        assert dm.class_names == ["ant", "bee", "zebra"]

    def test_class_names_follow_label_slots_when_categories_are_remapped(self, tmp_path):
        """class_names should preserve empty label slots so prediction class IDs map to the right names."""
        dm = _build_datamodule(tmp_path=tmp_path)
        dataset = _fake_dataset(50)
        coco = MagicMock()
        coco.cats = {0: {"name": "person"}}
        dataset.coco = coco
        dataset.label2cat = {1: 0}
        dm._dataset_train = dataset

        assert dm.class_names == ["", "person"]

    def test_dataset_with_class_names_attribute_but_not_webdataset_is_ignored(self, tmp_path):
        """A dataset merely exposing a `class_names` attribute, without being a WebDatasetDetection, is not used.

        Regression test: this property used to duck-type on `getattr(dataset, "class_names", None)`, so any
        dataset happening to carry an attribute of that name would satisfy it without the guarantee a real
        `WebDatasetDetection` gives -- label-indexed names read from its packed shard index. `_FakeDataset` has
        no `class_names` of its own, so setting one directly on the instance stands in for that broader surface.
        """
        dm = _build_datamodule(tmp_path=tmp_path)
        dataset = _fake_dataset(50, with_coco=False)
        dataset.class_names = ["decoy"]
        dm._dataset_train = dataset
        assert dm.class_names is None


class TestClassNamesMatchDataset:
    """Setup("fit") checks explicit ``class_names`` against the class names read from the dataset."""

    @staticmethod
    def _fit_setup(dm: RFDETRDataModule) -> None:
        """Run ``setup("fit")`` on datasets whose COCO categories are ``cat`` and ``dog``.

        The ``label2cat`` mapping makes these datasets the remapped kind a Roboflow COCO export builds, where labels
        are contiguous indices into the category list rather than the raw category ids — the only kind whose names are
        indexed by label, and so the only kind the check compares against ``class_names`` at all.

        Args:
            dm: Data module to set up.

        Examples:
            >>> dm = RFDETRDataModule(_base_model_config(), _base_train_config())
            >>> TestClassNamesMatchDataset._fit_setup(dm)
            >>> dm.class_names
            ['cat', 'dog']
        """
        datasets = {"train": _fake_dataset(10, with_coco=True), "val": _fake_dataset(4, with_coco=True)}
        for dataset in datasets.values():
            dataset.label2cat = {0: 1, 1: 2}
        with patch("rfdetr.training.module_data.build_dataset", side_effect=lambda split, *_: datasets[split]):
            dm.setup("fit")

    def test_roboflow_root_category_in_front_raises(self, tmp_path: Path) -> None:
        """Names read from every entry of a Roboflow export's categories shift each class by one, so fit stops."""
        dm = RFDETRDataModule(_base_model_config(), _base_train_config(tmp_path, class_names=["animals", "cat", "dog"]))

        with pytest.raises(ValueError, match=r"'animals'.*shifted by one.*class_names=\['cat', 'dog'\]"):
            self._fit_setup(dm)

    @pytest.mark.parametrize(
        ("class_names", "listed_extras"),
        [
            pytest.param(["animals", "pets", "cat", "dog"], "'animals', 'pets'", id="two-parents-in-front"),
            pytest.param(["cat", "pets", "dog"], "'pets'", id="parent-between-classes"),
        ],
    )
    def test_extra_names_above_a_class_raise(self, tmp_path: Path, class_names: list[str], listed_extras: str) -> None:
        """Any unannotated parent in the list shifts the classes below it, wherever it sits, so fit stops.

        ``filter_parent_categories`` drops every unannotated grouping category, not only a leading one, so a list read
        from all of them can carry several parents and can carry one between two real classes. Comparing only against
        ``names[1:]`` saw neither shape and let the run start with each affected class mislabelled.
        """
        dm = RFDETRDataModule(_base_model_config(), _base_train_config(tmp_path, class_names=class_names))

        with pytest.raises(ValueError) as exc_info:
            self._fit_setup(dm)

        assert f"The extra entries — {listed_extras} —" in str(exc_info.value)

    @pytest.mark.parametrize(
        "class_names",
        [
            pytest.param([], id="empty"),
            pytest.param(["dog"], id="one-shorter"),
            pytest.param(["cat", "dog", "bird"], id="one-longer"),
        ],
    )
    def test_other_length_mismatch_warns(
        self, tmp_path: Path, caplog: pytest.LogCaptureFixture, propagate_rf_detr_logs: None, class_names: list[str]
    ) -> None:
        """A list of another length can't line up with the labels either, but may be deliberate, so it only warns.

        Covers both directions of a plain length mismatch — empty, shorter, and longer than the dataset's own names —
        none of which carries an extra entry above a real class, so each falls to the generic length-mismatch warning
        rather than the extra-names raise. The warning reaches the ``rf-detr`` logger only: a second ``warnings.warn``
        used to repeat it with a stacklevel that pointed inside Lightning's hook dispatcher instead of the caller's own
        code.
        """
        dm = RFDETRDataModule(_base_model_config(), _base_train_config(tmp_path, class_names=class_names))

        with caplog.at_level(logging.WARNING, logger="rf-detr"):
            self._fit_setup(dm)

        assert any(
            f"class_names has {len(class_names)} entries but the dataset has 2 classes" in record.getMessage()
            for record in caplog.records
        )

    def test_empty_dataset_categories_short_circuits(self, mocker, tmp_path: Path) -> None:
        """An explicit class_names passes silently when the dataset itself carries no categories.

        ``_check_class_names_match_dataset``'s ``not dataset_class_names`` short-circuit (module_data.py) was
        otherwise untested: a dataset with no COCO categories resolves ``class_names`` to ``[]``, which must skip
        the comparison outright rather than raise or warn on the explicit list.
        """
        dm = RFDETRDataModule(_base_model_config(), _base_train_config(tmp_path, class_names=["cat", "dog"]))
        datasets = {"train": _fake_dataset(10, with_coco=True), "val": _fake_dataset(4, with_coco=True)}
        for dataset in datasets.values():
            dataset.coco.cats = {}

        mocker.patch("rfdetr.training.module_data.build_dataset", side_effect=lambda split, *_: datasets[split])

        with warnings.catch_warnings():
            warnings.simplefilter("error")
            dm.setup("fit")

        assert dm.class_names == []

    def test_same_length_permutation_warns(
        self, tmp_path: Path, caplog: pytest.LogCaptureFixture, propagate_rf_detr_logs: None
    ) -> None:
        """The dataset's own names in another order warn, because the equal length otherwise hides the swap.

        ``["dog", "cat"]`` against a ``cat``/``dog`` dataset labels every prediction of one as the other, in checkpoints
        and in ``predict()`` output. It only warns: renaming one class to another's name is legal, and nothing here can
        tell that apart from a list pasted in the wrong order.
        """
        dm = RFDETRDataModule(_base_model_config(), _base_train_config(tmp_path, class_names=["dog", "cat"]))

        with caplog.at_level(logging.WARNING, logger="rf-detr"):
            self._fit_setup(dm)

        assert any("in a different order" in record.getMessage() for record in caplog.records)

    @pytest.mark.parametrize(
        "class_names",
        [
            None,
            pytest.param(["cat", "dog"], id="same"),
            pytest.param(["Katze", "Hund"], id="renamed"),
        ],
    )
    def test_matching_length_passes(self, tmp_path: Path, class_names: list[str] | None) -> None:
        """Unset, identical or renamed names of the right length set up without a warning."""
        dm = RFDETRDataModule(_base_model_config(), _base_train_config(tmp_path, class_names=class_names))

        with warnings.catch_warnings():
            warnings.simplefilter("error")
            self._fit_setup(dm)

        assert dm.class_names == ["cat", "dog"]

    def test_raw_category_id_dataset_is_not_compared(self, mocker, tmp_path: Path) -> None:
        """A raw-id dataset labels objects by category id, so a class_names indexed by those ids must be accepted.

        ``dataset_file="coco"`` builds ``CocoDetection`` without remapping, leaving labels equal to the 1-based COCO
        category ids while the names read back are ordered by id. The ``class_names`` that is correct for such a run
        therefore carries a placeholder for the unused id 0, which the length/shift comparison used to mistake for a
        Roboflow export's extra root category and reject with the off-by-one list as its remedy (#1572).
        """
        dm = RFDETRDataModule(_base_model_config(), _base_train_config(tmp_path, class_names=["", "cat", "dog"]))
        datasets = {"train": _fake_dataset(10, with_coco=True), "val": _fake_dataset(4, with_coco=True)}

        mocker.patch("rfdetr.training.module_data.build_dataset", side_effect=lambda split, *_: datasets[split])

        dm.setup("fit")

        assert dm.class_names == ["cat", "dog"]

    def test_dataset_names_with_empty_slot_warn_without_raising(
        self, mocker, tmp_path: Path, caplog: pytest.LogCaptureFixture, propagate_rf_detr_logs: None
    ) -> None:
        """A keypoint dataset's unnamed background slot is a length difference like any other: it warns, never raises.

        An empty name used to skip the comparison outright, which also disabled it for a dataset carrying a category
        genuinely named ``""``. Whether the labels are remapped now decides what is comparable, so the reserved slot
        only means the two lists differ in length — worth saying, not worth stopping a run over, because keypoint
        ``class_names`` follow the model's own slot convention.
        """
        dm = RFDETRDataModule(_base_model_config(), _base_train_config(tmp_path, class_names=["dog"]))
        datasets = {"train": _fake_dataset(10, with_coco=True), "val": _fake_dataset(4, with_coco=True)}
        for dataset in datasets.values():
            dataset.label2cat = {1: 2}
        mocker.patch("rfdetr.training.module_data.build_dataset", side_effect=lambda split, *_: datasets[split])

        with caplog.at_level(logging.WARNING, logger="rf-detr"):
            dm.setup("fit")

        assert any("dataset has 2 classes ['', 'dog']" in record.getMessage() for record in caplog.records)


class TestSegmentationSupport:
    """DataModule accepts SegmentationTrainConfig without errors."""

    def test_init_with_seg_train_config(self, base_model_config, seg_train_config):
        """RFDETRDataModule can be constructed with a SegmentationTrainConfig."""
        mc = base_model_config(segmentation_head=True)
        tc = seg_train_config()
        dm = RFDETRDataModule(mc, tc)
        assert dm.train_config is tc
        assert dm.model_config.segmentation_head is True

    def test_seg_args_have_mask_loss_coefs(self, base_model_config, seg_train_config):
        """Segmentation-specific loss coefficients are present on train_config."""
        mc = base_model_config(segmentation_head=True)
        tc = seg_train_config()
        dm = RFDETRDataModule(mc, tc)
        assert dm.train_config.mask_ce_loss_coef == pytest.approx(5.0)
        assert dm.train_config.mask_dice_loss_coef == pytest.approx(5.0)


class TestTransferBatchToDevice:
    """Tests for RFDETRDataModule.transfer_batch_to_device().

    Verifies that NestedTensor samples and all target-dict tensors are correctly moved to the target device without
    unwrapping the NestedTensor into plain tensors.
    """

    def test_samples_transferred_to_target_device(self, fixture_training_setup):
        """Both tensors and mask in NestedTensor must land on the target device."""
        _, _, dm = fixture_training_setup
        samples, targets = _make_batch()
        device = torch.device("cpu")

        result_samples, _ = dm.transfer_batch_to_device((samples, targets), device, dataloader_idx=0)

        assert result_samples.tensors.device == device
        assert result_samples.mask.device == device

    def test_targets_transferred_to_target_device(self, fixture_training_setup):
        """All tensor values in every target dict must be moved to the target device."""
        _, _, dm = fixture_training_setup
        samples, targets = _make_batch()
        device = torch.device("cpu")

        _, result_targets = dm.transfer_batch_to_device((samples, targets), device, dataloader_idx=0)

        for t in result_targets:
            for v in t.values():
                assert v.device == device

    def test_returns_tuple_of_correct_length(self, fixture_training_setup):
        """Return value must be a (samples, targets) tuple to match batch contract."""
        _, _, dm = fixture_training_setup
        result = dm.transfer_batch_to_device(_make_batch(), torch.device("cpu"), dataloader_idx=0)

        assert isinstance(result, tuple)
        assert len(result) == 2

    def test_preserves_nested_tensor_type(self, fixture_training_setup):
        """Device transfer must not unwrap NestedTensor into plain tensors."""
        _, _, dm = fixture_training_setup
        samples, targets = _make_batch()

        result_samples, _ = dm.transfer_batch_to_device((samples, targets), torch.device("cpu"), dataloader_idx=0)

        assert isinstance(result_samples, NestedTensor)

    def test_packed_targets_are_unpacked_to_a_plain_list_on_target_device(self, fixture_training_setup):
        """Packed targets (``TrainConfig.pack_targets=True``) reach downstream code as the plain per-sample dict list.

        ``on_after_batch_transfer`` mutates target dicts by key reassignment, and
        ``PackedTargets.__getitem__``/iteration rebuilds a fresh dict on every access, so a reassignment into an un-
        materialised ``PackedTargets`` would silently vanish on the next access.
        """
        _, _, dm = fixture_training_setup
        samples, plain_targets = _make_batch()
        packed_targets = pack_targets(plain_targets)
        assert isinstance(packed_targets, PackedTargets)
        device = torch.device("cpu")

        _, result_targets = dm.transfer_batch_to_device((samples, packed_targets), device, dataloader_idx=0)

        assert isinstance(result_targets, list)
        assert not isinstance(result_targets, PackedTargets)
        for t in result_targets:
            assert isinstance(t, dict)
            for v in t.values():
                assert v.device == device
        for original, rebuilt in zip(plain_targets, result_targets):
            for key, value in original.items():
                assert torch.equal(rebuilt[key], value)

    def test_packed_targets_are_materialised_without_a_whole_batch_device_copy(
        self, mocker, fixture_training_setup
    ) -> None:
        """Packed transfer must not create a device copy of every field before constructing per-sample tensors."""
        _, _, dm = fixture_training_setup
        samples, plain_targets = _make_batch()
        packed_targets = pack_targets(plain_targets)
        assert isinstance(packed_targets, PackedTargets)
        mocker.patch.object(
            PackedTargets, "to", side_effect=AssertionError("whole packed batch copied to the target device")
        )

        _, result_targets = dm.transfer_batch_to_device(
            (samples, packed_targets), torch.device("cpu"), dataloader_idx=0
        )

        assert isinstance(result_targets, list)


# ---------------------------------------------------------------------------
# TestBackendResolution — validates augmentation_backend logic in setup("fit")
# ---------------------------------------------------------------------------


class TestBackendResolution:
    """Backend resolution selects Kornia, CPU, or raises depending on environment.

    All tests run on CPU CI by mocking fork-safe CUDA detection and the ``kornia`` import as needed.
    """

    def _build_dm_with_backend(self, tmp_path, augmentation_backend="cpu"):
        """Construct a DataModule with the given augmentation_backend."""
        mc = _base_model_config()
        tc = _base_train_config(tmp_path, augmentation_backend=augmentation_backend)
        return RFDETRDataModule(mc, tc)

    def test_auto_no_cuda_falls_back_to_cpu(self, mocker, tmp_path):
        """Auto + no CUDA: _kornia_pipeline stays None, no error."""
        mocker.patch("rfdetr.training.module_data._has_cuda_device", return_value=False)
        dm = _setup_fit_with_fake_datasets(self._build_dm_with_backend(tmp_path, "auto"))
        assert getattr(dm, "_kornia_pipeline", None) is None, (
            "auto backend with no CUDA must not build a Kornia pipeline"
        )

    def test_auto_no_kornia_falls_back_to_cpu(self, mocker, tmp_path):
        """Auto + CUDA available but kornia not installed: fallback to CPU."""
        mocker.patch("rfdetr.training.module_data._has_cuda_device", return_value=True)
        mocker.patch.object(AugmentationBackend, "_is_available", lambda self: self is not AugmentationBackend.KORNIA)

        dm = _setup_fit_with_fake_datasets(self._build_dm_with_backend(tmp_path, "auto"))

        assert getattr(dm, "_kornia_pipeline", None) is None, (
            "auto backend with kornia missing must fall back to CPU (pipeline=None)"
        )

    def test_gpu_no_cuda_raises_runtime_error(self, mocker, tmp_path):
        """Gpu + no CUDA: must raise RuntimeError."""
        dm = self._build_dm_with_backend(tmp_path, "gpu")
        mocker.patch("rfdetr.training.module_data._has_cuda_device", return_value=False)

        with pytest.raises(RuntimeError) as exc_info:
            _setup_fit_with_fake_datasets(dm)

        assert "CUDA" in str(exc_info.value)

    def test_gpu_no_kornia_raises_import_error(self, mocker, tmp_path):
        """Gpu + CUDA but no kornia: must raise ImportError with install hint."""
        dm = self._build_dm_with_backend(tmp_path, "gpu")
        mocker.patch("rfdetr.training.module_data._has_cuda_device", return_value=True)
        mocker.patch.object(AugmentationBackend, "_is_available", lambda self: self is not AugmentationBackend.KORNIA)

        with pytest.raises(ImportError) as exc_info:
            _setup_fit_with_fake_datasets(dm)

        assert "rfdetr[augment]" in str(exc_info.value)

    def test_cpu_backend_builds_no_pipeline(self, tmp_path):
        """Default cpu backend: _kornia_pipeline stays None."""
        dm = _setup_fit_with_fake_datasets(self._build_dm_with_backend(tmp_path, "cpu"))
        assert getattr(dm, "_kornia_pipeline", None) is None, "cpu backend must never build a Kornia pipeline"

    def test_gpu_path_uses_aug_config_fallback(self, mocker, tmp_path):
        """When aug_config=None (default), GPU path passes AUG_CONFIG to build_kornia_pipeline."""
        dm = self._build_dm_with_backend(tmp_path, "auto")
        assert dm.train_config.aug_config is None, "precondition: aug_config must be None for this test"

        captured = {}

        def _fake_build_kornia(aug_cfg, resolution, with_masks=False):
            captured["aug_config"] = aug_cfg
            captured["with_masks"] = with_masks
            return MagicMock()

        mocker.patch("rfdetr.training.module_data._has_cuda_device", return_value=True)
        mocker.patch("rfdetr.training.module_data.build_dataset", side_effect=lambda *a, **k: _fake_dataset(10))
        mocker.patch.object(AugmentationBackend, "_is_available", lambda self: True)
        mocker.patch("rfdetr.datasets.kornia_transforms.build_kornia_pipeline", side_effect=_fake_build_kornia)
        mocker.patch("rfdetr.datasets.kornia_transforms.build_normalize", return_value=MagicMock())

        dm.setup("fit")

        assert captured.get("aug_config") is AUG_CONFIG, (
            "GPU path must fall back to AUG_CONFIG when train_config.aug_config is None"
        )
        assert captured.get("with_masks") is True, "GPU path must transport the padding mask for detection batches"

    def test_auto_no_cuda_does_not_strip_cpu_normalize(self, mocker, tmp_path):
        """Auto + no CUDA: the backend resolves to cpu before dataset build so CPU Normalize is retained."""
        mocker.patch("rfdetr.training.module_data._has_cuda_device", return_value=False)
        dm = self._build_dm_with_backend(tmp_path, "auto")
        resolved_backends = {}

        def _spy_build(image_set, args, resolution):
            resolved_backends[image_set] = getattr(args, "augmentation_backend", "cpu")
            return _fake_dataset(10)

        mocker.patch("rfdetr.training.module_data.build_dataset", side_effect=_spy_build)

        dm.setup("fit")

        assert resolved_backends.get("train") == "cpu", (
            "auto + no CUDA must resolve to cpu before dataset build to preserve CPU Normalize"
        )


# ---------------------------------------------------------------------------
# TestOnAfterBatchTransfer — validates GPU-side augmentation hook
# ---------------------------------------------------------------------------


class TestOnAfterBatchTransfer:
    """on_after_batch_transfer applies Kornia augmentation only during training.

    Uses CPU tensors with a mocked pipeline — no real GPU or Kornia needed.
    """

    def _build_dm(self, tmp_path, segmentation_head=False):
        """Construct a DataModule for on_after_batch_transfer tests."""
        mc = _base_model_config(segmentation_head=segmentation_head)
        tc = _base_train_config(tmp_path)
        return RFDETRDataModule(mc, tc)

    def _attach_mock_trainer(self, dm, training=True):
        """Attach a mock trainer with the given training state to the DataModule."""
        mock_trainer = MagicMock(training=training)
        type(dm).trainer = property(lambda self: mock_trainer)
        return dm

    def _make_kornia_batch(self, batch_size=2, h=16, w=16):
        """Build a batch with xyxy boxes suitable for on_after_batch_transfer.

        Returns (NestedTensor, targets) where boxes are in absolute xyxy format and pixel values are in [0, 1] (pre-
        normalization).
        """
        tensors = torch.rand(batch_size, 3, h, w)  # [0, 1] range
        mask = torch.zeros(batch_size, h, w, dtype=torch.bool)
        samples = NestedTensor(tensors, mask)
        targets = [
            {
                "boxes": torch.tensor([[2.0, 2.0, 10.0, 10.0]], dtype=torch.float32),
                "labels": torch.tensor([1]),
                "area": torch.tensor([64.0]),
                "iscrowd": torch.tensor([0]),
                "image_id": torch.tensor(i),
                "orig_size": torch.tensor([h, w]),
            }
            for i in range(batch_size)
        ]
        return samples, targets

    def _make_kornia_batch_with_masks(self, batch_size=2, h=16, w=16):
        """Build a ``_make_kornia_batch`` batch whose targets also carry a ``[1, H, W]`` bool instance mask each."""
        samples, targets = self._make_kornia_batch(batch_size, h, w)
        for target in targets:
            target["masks"] = torch.ones(1, h, w, dtype=torch.bool)
        return samples, targets

    def test_training_true_applies_augmentation(self, tmp_path):
        """When training=True and _kornia_pipeline is set, image/box outputs match CPU Normalize contract."""
        dm = self._build_dm(tmp_path)
        dm = self._attach_mock_trainer(dm, training=True)

        samples, targets = self._make_kornia_batch()
        img_aug = samples.tensors.clone()
        # Mock pipeline returns pixel-index boxes, the image, and transported padding mask.
        boxes_padded = torch.tensor([[[1.5, 1.5, 9.5, 9.5]]] * 2)
        padding_masks_aug = torch.zeros(2, 1, 16, 16, dtype=torch.float32)
        mock_pipeline = MagicMock(return_value=(img_aug, boxes_padded, padding_masks_aug))
        dm._kornia_pipeline = mock_pipeline

        # Normalize adds +1 so we can assert the normalization step is applied.
        dm._kornia_normalize = MagicMock(side_effect=lambda x: x + 1.0)

        result_samples, result_targets = dm.on_after_batch_transfer((samples, targets), dataloader_idx=0)

        mock_pipeline.assert_called_once()
        dm._kornia_normalize.assert_called_once()
        assert torch.allclose(result_samples.tensors, img_aug + 1.0)
        assert len(result_targets) == 2
        for target in result_targets:
            boxes = target["boxes"]
            assert boxes.shape == (1, 4)
            assert torch.all(boxes >= 0.0)
            assert torch.all(boxes <= 1.0)
            torch.testing.assert_close(
                boxes[0], torch.tensor([0.375, 0.375, 0.5, 0.5], dtype=torch.float32), rtol=1e-4, atol=1e-6
            )

    @_requires_kornia
    @pytest.mark.parametrize("segmentation_head", [False, True])
    @pytest.mark.parametrize("flip", ["HorizontalFlip", "VerticalFlip"])
    def test_detection_box_edges_follow_flipped_pixels(
        self, tmp_path: Path, segmentation_head: bool, flip: str
    ) -> None:
        """Continuous box edges, full-frame boxes, and optional masks follow the same flip."""
        height, width = 16, 32
        dm = self._attach_mock_trainer(self._build_dm(tmp_path, segmentation_head=segmentation_head))
        dm._kornia_pipeline = build_kornia_pipeline({flip: {"p": 1.0}}, height, with_masks=True)
        dm._kornia_normalize = torch.nn.Identity()
        image = torch.zeros(1, 3, height, width)
        image[:, :, 3:9, 4:12] = 1.0
        boxes = torch.tensor([[4.0, 3.0, 12.0, 9.0], [0.0, 0.0, float(width), float(height)]])
        target = {"boxes": boxes, "labels": torch.tensor([1, 2]), "area": torch.tensor([48.0, 512.0])}
        if segmentation_head:
            target["masks"] = torch.cat((image[0, :1].bool(), torch.ones(1, height, width, dtype=torch.bool)))

        samples_out, targets_out = dm.on_after_batch_transfer((NestedTensor(image, None), [target]), 0)

        # Expected continuous edges are W-x2/W-x1 or H-y2/H-y1, not the pixel-center W-1-x/H-1-y.
        expected_box = [20.0, 3.0, 28.0, 9.0] if flip == "HorizontalFlip" else [4.0, 7.0, 12.0, 13.0]
        x1, y1, x2, y2 = expected_box
        expected_boxes = torch.tensor(
            [
                [(x1 + x2) / (2 * width), (y1 + y2) / (2 * height), (x2 - x1) / width, (y2 - y1) / height],
                [0.5, 0.5, 1.0, 1.0],
            ]
        )
        torch.testing.assert_close(targets_out[0]["boxes"], expected_boxes)
        torch.testing.assert_close(targets_out[0]["labels"], target["labels"])
        torch.testing.assert_close(targets_out[0]["area"], target["area"])
        dimension = -1 if flip == "HorizontalFlip" else -2
        torch.testing.assert_close(samples_out.tensors, image.flip(dimension))
        if segmentation_head:
            torch.testing.assert_close(targets_out[0]["masks"], target["masks"].flip(dimension))

    @_requires_kornia
    def test_detection_identity_preserves_fractional_subpixel_and_padded_boxes(self, tmp_path: Path) -> None:
        """An identity pipeline preserves continuous edges and ignores padding for an empty image."""
        dm = self._attach_mock_trainer(self._build_dm(tmp_path))
        dm._kornia_pipeline = build_kornia_pipeline({}, 16, with_masks=True)
        dm._kornia_normalize = torch.nn.Identity()
        image = torch.zeros(2, 3, 16, 32)
        boxes = torch.tensor([[3.2, 2.1, 8.7, 6.4], [2.0, 2.0, 2.5, 2.5]])
        labels = torch.tensor([1, 2])
        targets = [
            {"boxes": boxes, "labels": labels},
            {"boxes": torch.zeros(0, 4), "labels": torch.zeros(0, dtype=torch.long)},
        ]

        _, targets_out = dm.on_after_batch_transfer((NestedTensor(image, None), targets), 0)

        expected = torch.tensor(
            [[5.95 / 32, 4.25 / 16, 5.5 / 32, 4.3 / 16], [2.25 / 32, 2.25 / 16, 0.5 / 32, 0.5 / 16]]
        )
        torch.testing.assert_close(targets_out[0]["boxes"], expected)
        torch.testing.assert_close(targets_out[0]["labels"], labels)
        assert targets_out[1]["boxes"].shape == (0, 4)
        assert targets_out[1]["labels"].shape == (0,)
        torch.testing.assert_close(targets[0]["boxes"], boxes)

    @_requires_kornia
    @pytest.mark.parametrize("flip", ["HorizontalFlip", "VerticalFlip"])
    def test_detection_flip_preserves_fractional_and_subpixel_edges(self, tmp_path: Path, flip: str) -> None:
        """Flips reflect fractional edges through width/height without changing subpixel extent."""
        dm = self._attach_mock_trainer(self._build_dm(tmp_path))
        dm._kornia_pipeline = build_kornia_pipeline({flip: {"p": 1.0}}, 16, with_masks=True)
        dm._kornia_normalize = torch.nn.Identity()
        image = torch.zeros(1, 3, 16, 32)
        target = {"boxes": torch.tensor([[3.2, 2.1, 8.7, 6.4], [2.0, 2.0, 2.5, 2.5]]), "labels": torch.tensor([1, 2])}

        _, targets_out = dm.on_after_batch_transfer((NestedTensor(image, None), [target]), 0)

        expected = torch.tensor(
            [[5.95 / 32, 4.25 / 16, 5.5 / 32, 4.3 / 16], [2.25 / 32, 2.25 / 16, 0.5 / 32, 0.5 / 16]]
        )
        axis = 0 if flip == "HorizontalFlip" else 1
        expected[:, axis] = 1.0 - expected[:, axis]
        torch.testing.assert_close(targets_out[0]["boxes"], expected)
        torch.testing.assert_close(targets_out[0]["labels"], target["labels"])

    @_requires_kornia
    def test_detection_flip_handles_all_empty_targets(self, tmp_path: Path) -> None:
        """An all-empty detection batch keeps zero-length annotation tensors through the bridge."""
        dm = self._attach_mock_trainer(self._build_dm(tmp_path))
        dm._kornia_pipeline = build_kornia_pipeline({"HorizontalFlip": {"p": 1.0}}, 16, with_masks=True)
        dm._kornia_normalize = torch.nn.Identity()
        image = torch.zeros(1, 3, 16, 32)
        target = {"boxes": torch.zeros(0, 4), "labels": torch.zeros(0, dtype=torch.long)}

        _, targets_out = dm.on_after_batch_transfer((NestedTensor(image, None), [target]), 0)

        assert targets_out[0]["boxes"].shape == (0, 4)
        assert targets_out[0]["labels"].shape == (0,)

    @_requires_kornia
    def test_detection_affine_scales_continuous_box_width(self, tmp_path: Path) -> None:
        """Scaling around the image center doubles fractional box extent without a one-pixel correction."""
        dm = self._attach_mock_trainer(self._build_dm(tmp_path))
        dm._kornia_pipeline = build_kornia_pipeline(
            {"Affine": {"scale": (2.0, 2.0), "rotate": (0.0, 0.0), "p": 1.0}}, 16, with_masks=True
        )
        dm._kornia_normalize = torch.nn.Identity()
        image = torch.zeros(1, 3, 16, 32)
        target = {"boxes": torch.tensor([[13.25, 5.5, 18.75, 10.5]]), "labels": torch.tensor([1])}

        _, targets_out = dm.on_after_batch_transfer((NestedTensor(image, None), [target]), 0)

        # Continuous image center is (16, 8): [13.25, 5.5, 18.75, 10.5] -> [10.5, 3, 21.5, 13].
        torch.testing.assert_close(targets_out[0]["boxes"], torch.tensor([[0.5, 0.5, 11 / 32, 10 / 16]]))

    @_requires_kornia
    @pytest.mark.parametrize("device", ["cpu", _CUDA_DEVICE])
    def test_pixel_affine_reaches_segmentation_training_batch(self, tmp_path: Path, device: str) -> None:
        """The real transfer hook moves pixels, boxes, instance masks, and padding masks together."""
        config = {"Affine": {"translate_px": {"x": (4, 4), "y": (0, 0)}, "p": 1.0}}
        dm = RFDETRDataModule(
            _base_model_config(segmentation_head=True),
            _base_train_config(tmp_path, aug_config=config, augmentation_backend="kornia"),
        )
        dm._resolved_augmentation_backend = AugmentationBackend.KORNIA
        dm._setup_kornia_pipeline()
        dm = self._attach_mock_trainer(dm, training=True)
        image = torch.zeros(1, 3, 64, 80, device=device)
        image[:, :, 30:34, 30:34] = 1.0
        padding = torch.zeros(1, 64, 80, device=device, dtype=torch.bool)
        padding[:, :, 70:] = True
        instance_mask = torch.zeros(1, 64, 80, device=device, dtype=torch.bool)
        instance_mask[:, 30:34, 30:34] = True
        target = {
            "boxes": torch.tensor([[30.0, 30.0, 34.0, 34.0]], device=device),
            "labels": torch.tensor([1], device=device),
            "area": torch.tensor([16.0], device=device),
            "iscrowd": torch.tensor([0], device=device),
            "masks": instance_mask,
        }

        samples_out, targets_out = dm.on_after_batch_transfer((NestedTensor(image, padding), [target]), 0)

        assert len(targets_out) == 1
        torch.testing.assert_close(
            targets_out[0]["boxes"],
            torch.tensor([[0.45, 0.5, 0.05, 0.0625]], device=device),
            rtol=0,
            atol=1e-5,
        )
        expected_mask = torch.zeros_like(instance_mask)
        expected_mask[:, 30:34, 34:38] = True
        torch.testing.assert_close(targets_out[0]["masks"], expected_mask, rtol=0, atol=0)
        expected_padding = torch.zeros_like(padding)
        expected_padding[:, :, 4:] = padding[:, :, :-4]
        torch.testing.assert_close(samples_out.mask, expected_padding, rtol=0, atol=0)
        mean = torch.tensor(IMAGENET_MEAN, device=device)
        std = torch.tensor(IMAGENET_STD, device=device)
        # The white square moved onto column 34 (input 1.0) and vacated column 30 (input 0.0); ImageNet-normalized.
        torch.testing.assert_close(samples_out.tensors[0, :, 30, 34], (1.0 - mean) / std, rtol=0, atol=1e-5)
        torch.testing.assert_close(samples_out.tensors[0, :, 30, 30], (0.0 - mean) / std, rtol=0, atol=1e-5)

    @_requires_kornia
    def test_pixel_affine_drops_box_and_mask_shifted_out_of_frame(self, tmp_path: Path) -> None:
        """A translated-out object must not remain as a zero-area training target."""
        dm = RFDETRDataModule(
            _base_model_config(segmentation_head=True),
            _base_train_config(
                tmp_path,
                aug_config={"Affine": {"translate_px": {"x": 60}, "p": 1.0}},
                augmentation_backend="kornia",
            ),
        )
        dm._resolved_augmentation_backend = AugmentationBackend.KORNIA
        dm._setup_kornia_pipeline()
        dm = self._attach_mock_trainer(dm, training=True)
        image = torch.zeros(1, 3, 64, 80)
        mask = torch.zeros(1, 64, 80, dtype=torch.bool)
        mask[:, 30:34, 30:34] = True
        target = {
            "boxes": torch.tensor([[30.0, 30.0, 34.0, 34.0]]),
            "labels": torch.tensor([1]),
            "area": torch.tensor([16.0]),
            "iscrowd": torch.tensor([0]),
            "masks": mask,
        }

        _, targets_out = dm.on_after_batch_transfer((NestedTensor(image, None), [target]), 0)

        for key in ("boxes", "labels", "area", "iscrowd", "masks"):
            assert targets_out[0][key].shape[0] == 0, key

    def test_training_uses_transformed_padding_mask(self, tmp_path) -> None:
        """The returned NestedTensor mask comes from the same Kornia geometry as the image."""
        dm = self._build_dm(tmp_path)
        dm = self._attach_mock_trainer(dm, training=True)

        samples, targets = self._make_kornia_batch()
        assert samples.mask is not None
        samples.mask[0, 8:, :] = True
        samples.mask[1, :, 12:] = True
        img_aug = samples.tensors.clone()
        boxes_padded = torch.tensor([[[2.0, 2.0, 10.0, 10.0]]] * 2)
        padding_masks_aug = torch.zeros(2, 1, 16, 16, dtype=torch.float32)
        padding_masks_aug[0, :, 5:, :] = 1.0
        padding_masks_aug[1, :, :, 3:] = 1.0
        dm._kornia_pipeline = MagicMock(return_value=(img_aug, boxes_padded, padding_masks_aug))
        dm._kornia_normalize = MagicMock(side_effect=lambda x: x)

        result_samples, _ = dm.on_after_batch_transfer((samples, targets), dataloader_idx=0)

        call_args, call_kwargs = dm._kornia_pipeline.call_args
        assert len(call_args) == 3
        assert not call_kwargs
        torch.testing.assert_close(call_args[2], samples.mask.unsqueeze(1).to(torch.float32), rtol=0, atol=0)
        assert result_samples.mask is not None
        assert result_samples.mask.dtype == torch.bool
        assert torch.equal(result_samples.mask, padding_masks_aug[:, 0].to(torch.bool))

    @_requires_kornia
    def test_perspective_warps_padding_mask_with_real_pipeline(self, tmp_path) -> None:
        """Perspective transports unequal-size batch padding through the real Kornia sequence."""
        dm = self._build_dm(tmp_path)
        dm = self._attach_mock_trainer(dm, training=True)
        samples = nested_tensor_from_tensor_list([torch.ones(3, 48, 48), torch.ones(3, 64, 64)])
        assert samples.mask is not None
        targets = [
            {
                "boxes": torch.tensor([[4.0, 4.0, 36.0, 36.0]]),
                "labels": torch.tensor([1]),
                "area": torch.tensor([1024.0]),
                "iscrowd": torch.tensor([0]),
                "image_id": torch.tensor(index),
                "orig_size": torch.tensor([size, size]),
            }
            for index, size in enumerate((48, 64))
        ]
        config = {"Perspective": {"scale": 0.4, "p": 1.0}}
        dm._kornia_pipeline = build_kornia_pipeline(config, 64, with_masks=True)
        dm._kornia_normalize = MagicMock(side_effect=lambda x: x)
        boxes_padded, _ = collate_boxes(targets, samples.tensors.device)
        reference_pipeline = build_kornia_pipeline(config, 64, with_masks=True)

        torch.manual_seed(7)
        _, _, expected_padding = reference_pipeline(
            samples.tensors,
            boxes_padded,
            samples.mask.unsqueeze(1).to(torch.float32),
        )
        torch.manual_seed(7)
        result_samples, _ = dm.on_after_batch_transfer((samples, targets), dataloader_idx=0)

        assert result_samples.mask is not None
        assert result_samples.mask.dtype == torch.bool
        assert torch.equal(result_samples.mask, expected_padding[:, 0].to(torch.bool))
        assert not torch.equal(result_samples.mask, samples.mask)

    def test_training_false_skips_augmentation(self, tmp_path):
        """When training=False, batch is returned unchanged."""
        dm = self._build_dm(tmp_path)
        dm = self._attach_mock_trainer(dm, training=False)

        samples, targets = self._make_kornia_batch()
        mock_pipeline = MagicMock()
        dm._kornia_pipeline = mock_pipeline
        dm._kornia_normalize = MagicMock()

        result = dm.on_after_batch_transfer((samples, targets), dataloader_idx=0)

        mock_pipeline.assert_not_called()
        # Batch returned as-is
        result_samples, result_targets = result
        assert result_samples is samples
        assert result_targets is targets

    def test_segmentation_model_applies_augmentation_with_masks(self, tmp_path):
        """Phase 2: segmentation_head=True now calls pipeline with image, boxes, and masks."""
        dm = self._build_dm(tmp_path, segmentation_head=True)
        dm = self._attach_mock_trainer(dm, training=True)

        samples, targets = self._make_kornia_batch_with_masks()
        img_aug = samples.tensors.clone()
        boxes_padded = torch.tensor([[[2.0, 2.0, 10.0, 10.0]]] * 2)
        masks_aug = torch.ones(2, 2, 16, 16, dtype=torch.float32)
        masks_aug[:, 1] = 0.0

        mock_pipeline = MagicMock(return_value=(img_aug, boxes_padded, masks_aug))
        dm._kornia_pipeline = mock_pipeline
        dm._kornia_normalize = MagicMock(side_effect=lambda x: x)

        result_samples, result_targets = dm.on_after_batch_transfer((samples, targets), dataloader_idx=0)

        mock_pipeline.assert_called_once()
        call_args, call_kwargs = mock_pipeline.call_args
        assert len(call_args) == 3, "segmentation augmentation must call pipeline with image, boxes, and masks"
        assert not call_kwargs, "segmentation augmentation should not pass unexpected keyword arguments"

        masks_arg = call_args[2]
        assert isinstance(masks_arg, torch.Tensor), "third pipeline argument must be a masks tensor"
        assert masks_arg.dtype == torch.float32, "masks passed to pipeline must be float32"
        assert masks_arg.shape == (2, 2, 16, 16), "masks passed to pipeline must include instance and padding channels"
        assert "masks" in result_targets[0], "masks key must be present in output targets for segmentation"
        assert result_samples.mask is not None
        assert not result_samples.mask.any()

    def test_segmentation_masks_stay_in_sync_with_boxes(self, tmp_path):
        """Masks are filtered in sync with boxes: one instance removed → one mask removed."""
        dm = self._build_dm(tmp_path, segmentation_head=True)
        dm = self._attach_mock_trainer(dm, training=True)

        h, w = 16, 16
        tensors = torch.rand(1, 3, h, w)
        mask_nt = torch.zeros(1, h, w, dtype=torch.bool)
        samples = NestedTensor(tensors, mask_nt)
        targets = [
            {
                "boxes": torch.tensor([[2.0, 2.0, 8.0, 8.0], [10.0, 10.0, 14.0, 14.0]]),
                "labels": torch.tensor([1, 2]),
                "area": torch.tensor([36.0, 16.0]),
                "iscrowd": torch.tensor([0, 0]),
                "image_id": torch.tensor(0),
                "orig_size": torch.tensor([h, w]),
                "masks": torch.ones(2, h, w, dtype=torch.bool),
            }
        ]
        # Augmented: box 0 survives, box 1 becomes zero-area
        boxes_aug_out = torch.tensor([[[2.0, 2.0, 8.0, 8.0], [5.0, 5.0, 5.0, 5.0]]])
        masks_aug_out = torch.ones(1, 3, h, w, dtype=torch.float32)
        masks_aug_out[:, 2] = 0.0
        mock_pipeline = MagicMock(return_value=(tensors, boxes_aug_out, masks_aug_out))
        dm._kornia_pipeline = mock_pipeline
        dm._kornia_normalize = MagicMock(side_effect=lambda x: x)

        _, result_targets = dm.on_after_batch_transfer((samples, targets), dataloader_idx=0)

        assert result_targets[0]["masks"].shape[0] == 1, (
            f"Expected 1 surviving mask (matching box), got {result_targets[0]['masks'].shape[0]}"
        )

    def test_returns_nested_tensor_in_batch(self, tmp_path):
        """Output batch still has NestedTensor as first element after augmentation."""
        dm = self._build_dm(tmp_path)
        dm = self._attach_mock_trainer(dm, training=True)

        samples, targets = self._make_kornia_batch()
        img_aug = samples.tensors.clone()
        boxes_padded = torch.tensor([[[2.0, 2.0, 10.0, 10.0]]] * 2)
        padding_masks_aug = torch.zeros(2, 1, 16, 16, dtype=torch.float32)
        dm._kornia_pipeline = MagicMock(return_value=(img_aug, boxes_padded, padding_masks_aug))
        dm._kornia_normalize = MagicMock(side_effect=lambda x: x)

        result_samples, _ = dm.on_after_batch_transfer((samples, targets), dataloader_idx=0)

        assert isinstance(result_samples, NestedTensor), f"Expected NestedTensor, got {type(result_samples).__name__}"

    def test_detection_gpu_augmentation_leaves_unrelated_keypoints_unchanged(self, tmp_path: Path) -> None:
        """The unchanged detection route does not enable keypoint geometry."""
        dm = self._build_dm(tmp_path)
        dm = self._attach_mock_trainer(dm, training=True)

        samples, targets = self._make_kornia_batch()
        keypoints = torch.tensor([[[3.0, 4.0, 2.0]]], dtype=torch.float32)
        targets[0]["keypoints"] = keypoints.clone()
        targets[1]["keypoints"] = keypoints.clone()
        input_keypoints = [target["keypoints"].clone() for target in targets]

        img_aug = samples.tensors.clone()
        boxes_padded = torch.tensor([[[2.0, 2.0, 10.0, 10.0]]] * 2)
        padding_masks_aug = torch.zeros(2, 1, 16, 16, dtype=torch.float32)
        dm._kornia_pipeline = MagicMock(return_value=(img_aug, boxes_padded, padding_masks_aug))
        dm._kornia_normalize = MagicMock(side_effect=lambda x: x)

        _, result_targets = dm.on_after_batch_transfer((samples, targets), dataloader_idx=0)

        for idx, target in enumerate(result_targets):
            torch.testing.assert_close(target["keypoints"], input_keypoints[idx], rtol=1e-4, atol=1e-6)

    @_requires_kornia
    @pytest.mark.parametrize("device_name", ["cpu", _CUDA_DEVICE])
    @pytest.mark.parametrize("height, width", [(16, 32), (32, 16)])
    def test_keypoint_mode_real_pipeline_flips_and_normalizes(
        self, tmp_path: Path, device_name: str, height: int, width: int
    ) -> None:
        """The public batch hook keeps box and joint geometry aligned on the requested device.

        Non-square images make a swapped width/height in the mirror or the normalization visible: x is mirrored and
        divided by the width, y is divided by the height.
        """
        mc = _base_model_config(use_grouppose_keypoints=True, num_keypoints_per_class=[2])
        tc = _base_train_config(tmp_path, keypoint_flip_pairs=[0, 1])
        dm = self._attach_mock_trainer(RFDETRDataModule(mc, tc), training=True)
        dm._kornia_pipeline = build_kornia_pipeline(
            {"HorizontalFlip": {"p": 1.0}},
            16,
            with_masks=True,
            include_keypoints=True,
            with_keypoints=True,
            keypoint_flip_pairs=[0, 1],
        )
        dm._kornia_normalize = MagicMock(side_effect=lambda x: x)
        samples, targets = self._make_kornia_batch(batch_size=1, h=height, w=width)
        targets[0]["keypoints"] = torch.tensor([[[3.0, 4.0, 2.0], [6.0, 7.0, 1.0]]])
        device = torch.device(device_name)
        samples = NestedTensor(samples.tensors.to(device), samples.mask.to(device))
        targets = [{key: value.to(device) for key, value in target.items()} for target in targets]

        _, result = dm.on_after_batch_transfer((samples, targets), dataloader_idx=0)

        # Mirrored x is width - x; the flip swaps the pair, so slot 0 holds the former slot-1 joint.
        expected_keypoints = torch.tensor(
            [[[(width - 6) / width, 7 / height, 1], [(width - 3) / width, 4 / height, 2]]], device=device
        )
        # Box [2, 2, 10, 10] mirrors to [width - 10, 2, width - 2, 10], then becomes normalized cxcywh.
        expected_boxes = torch.tensor([[(width - 6) / width, 6 / height, 8 / width, 8 / height]], device=device)
        torch.testing.assert_close(result[0]["keypoints"], expected_keypoints)
        torch.testing.assert_close(result[0]["boxes"], expected_boxes)

    @_requires_kornia
    def test_keypoint_mode_handles_all_empty_targets(self, tmp_path: Path) -> None:
        """An annotation-free batch still reaches Kornia without its zero-point reshape crash."""
        mc = _base_model_config(use_grouppose_keypoints=True, num_keypoints_per_class=[2])
        tc = _base_train_config(tmp_path, keypoint_flip_pairs=[0, 1])
        dm = self._attach_mock_trainer(RFDETRDataModule(mc, tc), training=True)
        dm._kornia_pipeline = build_kornia_pipeline(
            {"HorizontalFlip": {"p": 1.0}},
            16,
            with_masks=True,
            include_keypoints=True,
            with_keypoints=True,
            keypoint_flip_pairs=[0, 1],
        )
        dm._kornia_normalize = MagicMock(side_effect=lambda x: x)
        samples, targets = self._make_kornia_batch(batch_size=1)
        targets[0]["boxes"] = torch.zeros(0, 4)
        targets[0]["labels"] = torch.zeros(0, dtype=torch.long)
        targets[0]["keypoints"] = torch.zeros(0, 2, 3)

        _, result = dm.on_after_batch_transfer((samples, targets), dataloader_idx=0)

        assert result[0]["boxes"].shape == (0, 4)
        assert result[0]["keypoints"].shape == (0, 2, 3)

    @_requires_kornia
    def test_keypoints_and_instance_masks_share_flip(self, tmp_path: Path) -> None:
        """A combined target keeps its instance mask and joints with the flipped box."""
        mc = _base_model_config(segmentation_head=True, use_grouppose_keypoints=True, num_keypoints_per_class=[2])
        tc = _base_train_config(tmp_path, keypoint_flip_pairs=[0, 1])
        dm = self._attach_mock_trainer(RFDETRDataModule(mc, tc), training=True)
        dm._kornia_pipeline = build_kornia_pipeline(
            {"HorizontalFlip": {"p": 1.0}},
            16,
            with_masks=True,
            include_keypoints=True,
            with_keypoints=True,
            keypoint_flip_pairs=[0, 1],
        )
        dm._kornia_normalize = MagicMock(side_effect=lambda x: x)
        samples, targets = self._make_kornia_batch_with_masks(batch_size=1)
        targets[0]["masks"][:, :, :8] = False
        targets[0]["keypoints"] = torch.tensor([[[3.0, 4.0, 2.0], [6.0, 7.0, 1.0]]])

        _, result = dm.on_after_batch_transfer((samples, targets), dataloader_idx=0)

        assert result[0]["masks"][:, :, :8].all()
        assert not result[0]["masks"][:, :, 8:].any()
        torch.testing.assert_close(result[0]["keypoints"], torch.tensor([[[10 / 16, 7 / 16, 1], [13 / 16, 4 / 16, 2]]]))

    def _build_dm_with_setup_pipeline(self, tmp_path: Path, keypoint_flip_pairs: list[int]) -> RFDETRDataModule:
        """Build a keypoint DataModule whose Kornia pipeline comes from the real ``_setup_kornia_pipeline``.

        Only CUDA detection and dataset construction are patched, so ``setup("fit")`` wires the pipeline exactly as it
        does in training: a certain horizontal flip with the given left/right joint pairs.
        """
        mc = _base_model_config(use_grouppose_keypoints=True, num_keypoints_per_class=[2])
        tc = _base_train_config(
            tmp_path,
            augmentation_backend="gpu",
            aug_config={"HorizontalFlip": {"p": 1.0}},
            keypoint_flip_pairs=keypoint_flip_pairs,
        )
        dm = self._attach_mock_trainer(RFDETRDataModule(mc, tc), training=True)
        with (
            patch("rfdetr.training.module_data.build_dataset", side_effect=lambda *a, **k: _fake_dataset(10)),
            patch("rfdetr.training.module_data._has_cuda_device", return_value=True),
        ):
            dm.setup("fit")
        return dm

    def _run_setup_pipeline_batch(self, dm: RFDETRDataModule) -> dict[str, torch.Tensor]:
        """Push a 16x16 batch with two joints (slot 0 at (3, 4), slot 1 at (6, 7)) through the batch hook."""
        samples, targets = self._make_kornia_batch(batch_size=1)
        targets[0]["keypoints"] = torch.tensor([[[3.0, 4.0, 2.0], [6.0, 7.0, 1.0]]])

        _, result = dm.on_after_batch_transfer((samples, targets), dataloader_idx=0)

        return result[0]

    @_requires_kornia
    def test_setup_pipeline_with_flip_pairs_swaps_left_right_keypoints(self, tmp_path: Path) -> None:
        """A flipped sample relabels paired joints: slot 0 receives the mirrored slot-1 joint and vice versa."""
        dm = self._build_dm_with_setup_pipeline(tmp_path, keypoint_flip_pairs=[0, 1])

        target = self._run_setup_pipeline_batch(dm)

        torch.testing.assert_close(target["keypoints"], torch.tensor([[[10 / 16, 7 / 16, 1], [13 / 16, 4 / 16, 2]]]))

    @_requires_kornia
    def test_setup_pipeline_without_flip_pairs_leaves_keypoints_unflipped(self, tmp_path: Path) -> None:
        """Without flip pairs the flip is disabled, so joints keep their coordinates and slots (normalized by W, H)."""
        dm = self._build_dm_with_setup_pipeline(tmp_path, keypoint_flip_pairs=[])

        target = self._run_setup_pipeline_batch(dm)

        torch.testing.assert_close(target["keypoints"], torch.tensor([[[3 / 16, 4 / 16, 2], [6 / 16, 7 / 16, 1]]]))

    @_requires_kornia
    def test_setup_pipeline_without_flip_pairs_leaves_boxes_unflipped(self, tmp_path: Path) -> None:
        """Without flip pairs the box [2, 2, 10, 10] stays put: cxcywh (6, 6, 8, 8) / 16."""
        dm = self._build_dm_with_setup_pipeline(tmp_path, keypoint_flip_pairs=[])

        target = self._run_setup_pipeline_batch(dm)

        torch.testing.assert_close(target["boxes"], torch.tensor([[6 / 16, 6 / 16, 8 / 16, 8 / 16]]))


# ---------------------------------------------------------------------------
# TestKorniaSetupDoneSentinel — validates the _kornia_setup_done guard
# ---------------------------------------------------------------------------


class TestKorniaSetupDoneSentinel:
    """_kornia_setup_done prevents _setup_kornia_pipeline re-running on repeated setup('fit') calls."""

    def _build_dm(self, tmp_path, augmentation_backend="auto"):
        mc = _base_model_config()
        tc = _base_train_config(tmp_path, augmentation_backend=augmentation_backend)
        return RFDETRDataModule(mc, tc)

    def test_sentinel_starts_false(self, tmp_path):
        """_kornia_setup_done is False immediately after __init__."""
        dm = self._build_dm(tmp_path)
        assert dm._kornia_setup_done is False

    def test_sentinel_set_after_fit(self, mocker, tmp_path):
        """_kornia_setup_done becomes True after the first setup('fit') (no CUDA falls back to CPU)."""
        mocker.patch("rfdetr.training.module_data._has_cuda_device", return_value=False)
        dm = _setup_fit_with_fake_datasets(self._build_dm(tmp_path))
        assert dm._kornia_setup_done is True

    def test_setup_kornia_pipeline_not_called_twice(self, mocker, tmp_path):
        """Calling setup('fit') twice only calls _setup_kornia_pipeline once."""
        mocker.patch("rfdetr.training.module_data._has_cuda_device", return_value=False)
        dm = self._build_dm(tmp_path)
        setup_pipeline = mocker.patch.object(dm, "_setup_kornia_pipeline", wraps=dm._setup_kornia_pipeline)

        _setup_fit_with_fake_datasets(dm)
        _setup_fit_with_fake_datasets(dm)

        assert setup_pipeline.call_count == 1, (
            f"_setup_kornia_pipeline called {setup_pipeline.call_count} times; expected exactly 1"
        )


class TestWorkerInitFn:
    """DataLoaders seed NumPy/random per worker so augmentation streams are not duplicated across workers."""

    def test_worker_init_fn_seeds_from_torch_initial_seed(self, monkeypatch):
        """_worker_init_fn derives a reproducible NumPy/random seed from ``torch.initial_seed``."""
        monkeypatch.setattr(torch, "initial_seed", lambda: 12345)
        _worker_init_fn(0)
        first = (float(np.random.rand()), random.random())

        # worker_id is irrelevant; the seed is derived from torch's per-worker seed.
        monkeypatch.setattr(torch, "initial_seed", lambda: 12345)
        _worker_init_fn(3)
        second = (float(np.random.rand()), random.random())

        assert first == second

    @pytest.mark.parametrize("loader_name", _EVAL_LOADERS)
    def test_eval_dataloaders_set_worker_init_fn(self, fixture_training_setup, loader_name):
        """Validation/test/predict DataLoaders wire the module-level worker seeding hook."""
        _, _, dm = fixture_training_setup
        dm._dataset_val = _fake_dataset()
        dm._dataset_test = _fake_dataset()

        loader = getattr(dm, loader_name)()

        assert loader.worker_init_fn is _worker_init_fn

    def test_train_dataloader_sets_worker_init_fn(self, fixture_training_setup):
        """The training DataLoader wires the module-level worker seeding hook."""
        _, _, dm = fixture_training_setup
        dm._dataset_train = _fake_dataset()

        loader = dm.train_dataloader()

        assert loader.worker_init_fn is _worker_init_fn
