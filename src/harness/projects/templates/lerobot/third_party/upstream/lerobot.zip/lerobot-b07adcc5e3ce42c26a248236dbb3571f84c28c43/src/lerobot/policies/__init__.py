# Copyright 2024 The HuggingFace Inc. team. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from lerobot.utils.action_interpolator import ActionInterpolator as ActionInterpolator
from lerobot.utils.feature_spec import FeatureSpec

from .act.configuration_act import ACTConfig as ACTConfig
from .chunk import ChunkPolicySpec, ExecutionMode
from .cosmos3.configuration_cosmos3 import (
    Cosmos3EdgeConfig as Cosmos3EdgeConfig,
    Cosmos3NanoConfig as Cosmos3NanoConfig,
)
from .diffusion.configuration_diffusion import DiffusionConfig as DiffusionConfig
from .dm05.configuration_dm05 import DM05Config as DM05Config
from .eo1.configuration_eo1 import EO1Config as EO1Config
from .evo1.configuration_evo1 import Evo1Config as Evo1Config
from .factory import get_policy_class, make_policy, make_policy_config, make_pre_post_processors
from .fastwam.configuration_fastwam import FastWAMConfig as FastWAMConfig
from .fineart_vla.configuration_fineart_vla import FineARTVLAConfig as FineARTVLAConfig
from .flux3.configuration_flux3 import Flux3Config as Flux3Config
from .g05.configuration_g05 import G05Config as G05Config
from .gaussian_actor.configuration_gaussian_actor import GaussianActorConfig as GaussianActorConfig
from .groot.configuration_groot import GrootConfig as GrootConfig
from .lawam.configuration_lawam import LaWAMConfig as LaWAMConfig
from .lingbot_va.configuration_lingbot_va import LingBotVAConfig as LingBotVAConfig
from .lingbot_vla_v2.configuration_lingbot_vla_v2 import LingbotVLAV2Config as LingbotVLAV2Config
from .longwam.configuration_longwam import LongWAMConfig as LongWAMConfig
from .molmoact2.configuration_molmoact2 import MolmoAct2Config as MolmoAct2Config
from .multi_task_dit.configuration_multi_task_dit import MultiTaskDiTConfig as MultiTaskDiTConfig
from .nat_vla.configuration_nat_vla import NATVLAConfig as NATVLAConfig
from .pi0.configuration_pi0 import PI0Config as PI0Config
from .pi0_fast.configuration_pi0_fast import PI0FastConfig as PI0FastConfig
from .pi05.configuration_pi05 import PI05Config as PI05Config
from .praxis.configuration_praxis import PraxisConfig as PraxisConfig
from .pretrained import PreTrainedPolicy as PreTrainedPolicy
from .rtc import (
    ActionQueue,
    QueueSnapshot,
    RTCConfig,
    reanchor_relative_rtc_prefix,
    validate_trained_rtc_horizon,
)
from .smolvla.configuration_smolvla import SmolVLAConfig as SmolVLAConfig
from .tdmpc.configuration_tdmpc import TDMPCConfig as TDMPCConfig
from .utils import make_robot_action, prepare_observation_for_inference
from .vla_jepa.configuration_vla_jepa import VLAJEPAConfig as VLAJEPAConfig
from .vqbet.configuration_vqbet import VQBeTConfig as VQBeTConfig
from .wall_oss_05.configuration_wall_oss_05 import WallOSS05Config as WallOSS05Config
from .wall_x.configuration_wall_x import WallXConfig as WallXConfig
from .xvla.configuration_xvla import XVLAConfig as XVLAConfig

# NOTE: Policy modeling classes (e.g., GaussianActorPolicy) are intentionally NOT re-exported here.
# They have heavy optional dependencies and are loaded lazily via get_policy_class().
# Import directly: ``from lerobot.policies.gaussian_actor.modeling_gaussian_actor import GaussianActorPolicy``

__all__ = [
    # Configuration classes
    "ACTConfig",
    "Cosmos3EdgeConfig",
    "Cosmos3NanoConfig",
    "DiffusionConfig",
    "DM05Config",
    "EO1Config",
    "FastWAMConfig",
    "FineARTVLAConfig",
    "Flux3Config",
    "GaussianActorConfig",
    "G05Config",
    "Evo1Config",
    "GrootConfig",
    "LaWAMConfig",
    "LingBotVAConfig",
    "NATVLAConfig",
    "LingbotVLAV2Config",
    "LongWAMConfig",
    "MolmoAct2Config",
    "MultiTaskDiTConfig",
    "PI0Config",
    "PI0FastConfig",
    "PI05Config",
    "PraxisConfig",
    "SmolVLAConfig",
    "TDMPCConfig",
    "VLAJEPAConfig",
    "VQBeTConfig",
    "WallXConfig",
    "WallOSS05Config",
    "XVLAConfig",
    # Chunk execution contracts
    "ChunkPolicySpec",
    "ExecutionMode",
    "FeatureSpec",
    # Base class
    "PreTrainedPolicy",
    # RTC utilities
    "ActionInterpolator",
    "ActionQueue",
    "QueueSnapshot",
    "RTCConfig",
    "reanchor_relative_rtc_prefix",
    "validate_trained_rtc_horizon",
    # Utility functions
    "make_robot_action",
    "prepare_observation_for_inference",
    # Factory functions
    "get_policy_class",
    "make_policy",
    "make_policy_config",
    "make_pre_post_processors",
]
