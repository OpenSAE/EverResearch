# Copyright 2026 The HuggingFace Inc. team. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Serve a simulator over the network, so another process or machine can step it.

``lerobot-env-server`` is the server. ``RemoteVectorEnv`` is the client, with the same API as
``LocalVectorEnv``.
"""

from .client import EnvClient, RemoteVectorEnv
from .protocol import DEFAULT_MAX_PAYLOAD_BYTES
from .server import EnvServer, EnvServerConfig

__all__ = [
    "DEFAULT_MAX_PAYLOAD_BYTES",
    "EnvClient",
    "EnvServer",
    "EnvServerConfig",
    "RemoteVectorEnv",
]
